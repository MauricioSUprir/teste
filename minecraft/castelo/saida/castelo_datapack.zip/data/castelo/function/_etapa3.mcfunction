execute as @e[type=minecraft:marker,tag=castelo_origem,limit=1] at @s run function castelo:_blocos3
tellraw @a [{"text":"[Castelo] ","color":"gold"},{"text":"Construindo... 37%","color":"gray"}]
schedule function castelo:_etapa4 1t
