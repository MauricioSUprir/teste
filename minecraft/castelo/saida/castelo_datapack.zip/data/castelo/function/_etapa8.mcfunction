execute as @e[type=minecraft:marker,tag=castelo_origem,limit=1] at @s run function castelo:_blocos8
execute as @e[type=minecraft:marker,tag=castelo_origem,limit=1] at @s run forceload remove ~-100 ~-196 ~100 ~4
kill @e[type=minecraft:marker,tag=castelo_origem]
tellraw @a [{"text":"[Castelo] ","color":"gold"},{"text":"Pronto! Atravesse a ponte levadiça. Dica: na biblioteca do 1º andar, coloque um livro no atril...","color":"green"}]
