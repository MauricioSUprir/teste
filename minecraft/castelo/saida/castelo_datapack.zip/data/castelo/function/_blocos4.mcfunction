fill ~-26 ~54 ~-141 ~-24 ~54 ~-141 minecraft:deepslate_tiles
fill ~-26 ~54 ~-97 ~-24 ~54 ~-97 minecraft:deepslate_tiles
fill ~-26 ~57 ~-143 ~-24 ~57 ~-143 minecraft:deepslate_tiles
fill ~-26 ~57 ~-99 ~-24 ~57 ~-99 minecraft:deepslate_tiles
fill ~-26 ~58 ~-149 ~-25 ~58 ~-148 minecraft:deepslate_tiles
fill ~-26 ~58 ~-105 ~-25 ~58 ~-104 minecraft:deepslate_tiles
fill ~-26 ~59 ~-144 ~-25 ~59 ~-144 minecraft:deepslate_tiles
fill ~-26 ~59 ~-100 ~-25 ~59 ~-100 minecraft:deepslate_tiles
fill ~-26 ~60 ~-148 ~-26 ~60 ~-147 minecraft:deepslate_tiles
setblock ~-26 ~60 ~-144 minecraft:deepslate_tiles
fill ~-26 ~60 ~-104 ~-26 ~60 ~-103 minecraft:deepslate_tiles
setblock ~-26 ~60 ~-100 minecraft:deepslate_tiles
fill ~-26 ~62 ~-146 ~-26 ~65 ~-146 minecraft:deepslate_tiles
fill ~-26 ~62 ~-102 ~-26 ~65 ~-102 minecraft:deepslate_tiles
fill ~-25 ~54 ~-150 ~-23 ~54 ~-150 minecraft:deepslate_tiles
fill ~-25 ~54 ~-142 ~-23 ~54 ~-142 minecraft:deepslate_tiles
fill ~-25 ~54 ~-106 ~-23 ~54 ~-106 minecraft:deepslate_tiles
fill ~-25 ~54 ~-98 ~-23 ~54 ~-98 minecraft:deepslate_tiles
fill ~-25 ~56 ~-149 ~-23 ~56 ~-149 minecraft:deepslate_tiles
fill ~-25 ~56 ~-143 ~-23 ~56 ~-143 minecraft:deepslate_tiles
fill ~-25 ~56 ~-105 ~-23 ~56 ~-105 minecraft:deepslate_tiles
fill ~-25 ~56 ~-99 ~-23 ~56 ~-99 minecraft:deepslate_tiles
fill ~-25 ~59 ~-147 ~-24 ~59 ~-147 minecraft:deepslate_tiles
fill ~-25 ~59 ~-145 ~-24 ~59 ~-145 minecraft:deepslate_tiles
fill ~-25 ~59 ~-103 ~-24 ~59 ~-103 minecraft:deepslate_tiles
fill ~-25 ~59 ~-101 ~-24 ~59 ~-101 minecraft:deepslate_tiles
fill ~-25 ~60 ~-146 ~-24 ~60 ~-146 minecraft:deepslate_tiles
fill ~-25 ~60 ~-102 ~-24 ~60 ~-102 minecraft:deepslate_tiles
fill ~-24 ~55 ~-149 ~-23 ~56 ~-149 minecraft:deepslate_tiles
fill ~-24 ~55 ~-143 ~-23 ~56 ~-143 minecraft:deepslate_tiles
fill ~-24 ~55 ~-105 ~-23 ~56 ~-105 minecraft:deepslate_tiles
fill ~-24 ~55 ~-99 ~-23 ~56 ~-99 minecraft:deepslate_tiles
fill ~-24 ~57 ~-148 ~-23 ~57 ~-148 minecraft:deepslate_tiles
fill ~-24 ~57 ~-144 ~-23 ~57 ~-144 minecraft:deepslate_tiles
fill ~-24 ~57 ~-104 ~-23 ~57 ~-104 minecraft:deepslate_tiles
fill ~-24 ~57 ~-100 ~-23 ~57 ~-100 minecraft:deepslate_tiles
fill ~-24 ~58 ~-147 ~-23 ~58 ~-145 minecraft:deepslate_tiles
fill ~-24 ~58 ~-103 ~-23 ~58 ~-101 minecraft:deepslate_tiles
fill ~-24 ~59 ~-146 ~-24 ~59 ~-145 minecraft:deepslate_tiles
fill ~-24 ~59 ~-102 ~-24 ~59 ~-101 minecraft:deepslate_tiles
fill ~-23 ~53 ~-150 ~-22 ~53 ~-150 minecraft:deepslate_tiles
fill ~-23 ~53 ~-142 ~-22 ~53 ~-142 minecraft:deepslate_tiles
fill ~-23 ~53 ~-106 ~-22 ~53 ~-106 minecraft:deepslate_tiles
fill ~-23 ~53 ~-98 ~-22 ~53 ~-98 minecraft:deepslate_tiles
fill ~-23 ~54 ~-149 ~-22 ~54 ~-149 minecraft:deepslate_tiles
fill ~-23 ~54 ~-143 ~-22 ~54 ~-143 minecraft:deepslate_tiles
fill ~-23 ~54 ~-105 ~-22 ~54 ~-105 minecraft:deepslate_tiles
fill ~-23 ~54 ~-99 ~-22 ~54 ~-99 minecraft:deepslate_tiles
fill ~-23 ~55 ~-148 ~-22 ~55 ~-148 minecraft:deepslate_tiles
fill ~-23 ~55 ~-144 ~-22 ~55 ~-144 minecraft:deepslate_tiles
fill ~-23 ~55 ~-104 ~-22 ~55 ~-104 minecraft:deepslate_tiles
fill ~-23 ~55 ~-100 ~-22 ~55 ~-100 minecraft:deepslate_tiles
fill ~-23 ~56 ~-148 ~-23 ~57 ~-147 minecraft:deepslate_tiles
fill ~-23 ~56 ~-145 ~-22 ~56 ~-145 minecraft:deepslate_tiles
fill ~-23 ~56 ~-144 ~-23 ~56 ~-143 minecraft:deepslate_tiles
fill ~-23 ~56 ~-104 ~-23 ~57 ~-103 minecraft:deepslate_tiles
fill ~-23 ~56 ~-100 ~-23 ~56 ~-99 minecraft:deepslate_tiles
fill ~-23 ~57 ~-146 ~-23 ~57 ~-144 minecraft:deepslate_tiles
fill ~-23 ~57 ~-102 ~-23 ~57 ~-100 minecraft:deepslate_tiles
fill ~-22 ~31 ~-33 ~-21 ~31 ~-33 minecraft:deepslate_tiles
fill ~-22 ~31 ~-32 ~-22 ~31 ~-27 minecraft:deepslate_tiles
fill ~-22 ~32 ~-32 ~-21 ~32 ~-32 minecraft:deepslate_tiles
fill ~-22 ~32 ~-31 ~-22 ~32 ~-28 minecraft:deepslate_tiles
fill ~-22 ~53 ~-149 ~-21 ~53 ~-149 minecraft:deepslate_tiles
fill ~-22 ~53 ~-143 ~-21 ~53 ~-143 minecraft:deepslate_tiles
fill ~-22 ~53 ~-105 ~-21 ~53 ~-105 minecraft:deepslate_tiles
fill ~-22 ~53 ~-99 ~-20 ~53 ~-99 minecraft:deepslate_tiles
fill ~-22 ~54 ~-148 ~-21 ~54 ~-147 minecraft:deepslate_tiles
fill ~-22 ~54 ~-145 ~-21 ~54 ~-144 minecraft:deepslate_tiles
fill ~-22 ~54 ~-104 ~-21 ~54 ~-103 minecraft:deepslate_tiles
fill ~-22 ~54 ~-101 ~-21 ~54 ~-100 minecraft:deepslate_tiles
fill ~-22 ~55 ~-147 ~-22 ~55 ~-144 minecraft:deepslate_tiles
fill ~-22 ~55 ~-103 ~-22 ~55 ~-100 minecraft:deepslate_tiles
fill ~-22 ~56 ~-147 ~-22 ~56 ~-145 minecraft:deepslate_tiles
fill ~-22 ~56 ~-103 ~-22 ~56 ~-101 minecraft:deepslate_tiles
fill ~-21 ~31 ~-35 ~-20 ~31 ~-35 minecraft:deepslate_tiles
fill ~-21 ~31 ~-34 ~-21 ~32 ~-33 minecraft:deepslate_tiles
fill ~-21 ~31 ~-27 ~-21 ~31 ~-25 minecraft:deepslate_tiles
fill ~-21 ~32 ~-28 ~-21 ~32 ~-26 minecraft:deepslate_tiles
fill ~-21 ~33 ~-33 ~-20 ~33 ~-33 minecraft:deepslate_tiles
fill ~-21 ~33 ~-32 ~-21 ~33 ~-27 minecraft:deepslate_tiles
fill ~-21 ~34 ~-32 ~-20 ~34 ~-31 minecraft:deepslate_tiles
fill ~-21 ~34 ~-30 ~-21 ~34 ~-28 minecraft:deepslate_tiles
fill ~-21 ~53 ~-148 ~-21 ~53 ~-143 minecraft:deepslate_tiles
fill ~-21 ~53 ~-104 ~-21 ~53 ~-99 minecraft:deepslate_tiles
fill ~-21 ~54 ~-146 ~-21 ~54 ~-144 minecraft:deepslate_tiles
fill ~-21 ~54 ~-102 ~-21 ~54 ~-100 minecraft:deepslate_tiles
fill ~-20 ~31 ~-36 ~-18 ~31 ~-36 minecraft:deepslate_tiles
fill ~-20 ~31 ~-25 ~-20 ~31 ~-24 minecraft:deepslate_tiles
fill ~-20 ~32 ~-35 ~-19 ~32 ~-35 minecraft:deepslate_tiles
fill ~-20 ~32 ~-34 ~-20 ~33 ~-34 minecraft:deepslate_tiles
fill ~-20 ~32 ~-26 ~-20 ~32 ~-25 minecraft:deepslate_tiles
fill ~-20 ~33 ~-26 ~-19 ~33 ~-26 minecraft:deepslate_tiles
fill ~-20 ~34 ~-33 ~-20 ~34 ~-31 minecraft:deepslate_tiles
fill ~-20 ~34 ~-29 ~-20 ~34 ~-27 minecraft:deepslate_tiles
fill ~-20 ~35 ~-32 ~-20 ~35 ~-28 minecraft:deepslate_tiles
fill ~-20 ~36 ~-31 ~-19 ~36 ~-29 minecraft:deepslate_tiles
fill ~-19 ~31 ~-24 ~-18 ~32 ~-24 minecraft:deepslate_tiles
fill ~-19 ~32 ~-36 ~-17 ~32 ~-36 minecraft:deepslate_tiles
fill ~-19 ~32 ~-25 ~-19 ~32 ~-24 minecraft:deepslate_tiles
fill ~-19 ~33 ~-35 ~-18 ~33 ~-35 minecraft:deepslate_tiles
fill ~-19 ~33 ~-34 ~-19 ~35 ~-34 minecraft:deepslate_tiles
fill ~-19 ~33 ~-25 ~-18 ~33 ~-25 minecraft:deepslate_tiles
fill ~-19 ~34 ~-26 ~-19 ~35 ~-26 minecraft:deepslate_tiles
fill ~-19 ~35 ~-33 ~-19 ~36 ~-33 minecraft:deepslate_tiles
fill ~-19 ~35 ~-27 ~-19 ~35 ~-26 minecraft:deepslate_tiles
fill ~-19 ~36 ~-32 ~-19 ~36 ~-27 minecraft:deepslate_tiles
fill ~-19 ~37 ~-32 ~-18 ~37 ~-32 minecraft:deepslate_tiles
fill ~-19 ~37 ~-31 ~-19 ~37 ~-28 minecraft:deepslate_tiles
fill ~-19 ~38 ~-30 ~-18 ~38 ~-30 minecraft:deepslate_tiles
fill ~-18 ~31 ~-37 ~-12 ~31 ~-37 minecraft:deepslate_tiles
fill ~-18 ~31 ~-23 ~-12 ~31 ~-23 minecraft:deepslate_tiles
fill ~-18 ~33 ~-36 ~-12 ~33 ~-36 minecraft:deepslate_tiles
fill ~-18 ~33 ~-24 ~-12 ~33 ~-24 minecraft:deepslate_tiles
fill ~-18 ~34 ~-35 ~-16 ~34 ~-35 minecraft:deepslate_tiles
fill ~-18 ~34 ~-25 ~-16 ~34 ~-25 minecraft:deepslate_tiles
fill ~-18 ~35 ~-34 ~-18 ~36 ~-34 minecraft:deepslate_tiles
fill ~-18 ~35 ~-26 ~-18 ~36 ~-26 minecraft:deepslate_tiles
fill ~-18 ~36 ~-33 ~-18 ~37 ~-33 minecraft:deepslate_tiles
fill ~-18 ~36 ~-27 ~-18 ~36 ~-26 minecraft:deepslate_tiles
fill ~-18 ~37 ~-28 ~-18 ~37 ~-27 minecraft:deepslate_tiles
fill ~-18 ~38 ~-32 ~-17 ~38 ~-32 minecraft:deepslate_tiles
fill ~-18 ~38 ~-31 ~-18 ~38 ~-28 minecraft:deepslate_tiles
fill ~-18 ~39 ~-31 ~-18 ~39 ~-29 minecraft:deepslate_tiles
fill ~-18 ~40 ~-30 ~-17 ~40 ~-30 minecraft:deepslate_tiles
fill ~-17 ~32 ~-37 ~-13 ~32 ~-37 minecraft:deepslate_tiles
fill ~-17 ~32 ~-24 ~-17 ~32 ~-23 minecraft:deepslate_tiles
fill ~-17 ~34 ~-24 ~-13 ~34 ~-24 minecraft:deepslate_tiles
fill ~-17 ~35 ~-35 ~-13 ~35 ~-35 minecraft:deepslate_tiles
fill ~-17 ~35 ~-25 ~-13 ~35 ~-25 minecraft:deepslate_tiles
fill ~-17 ~36 ~-34 ~-12 ~36 ~-34 minecraft:deepslate_tiles
fill ~-17 ~36 ~-26 ~-12 ~36 ~-26 minecraft:deepslate_tiles
fill ~-17 ~37 ~-34 ~-13 ~37 ~-34 minecraft:deepslate_tiles
fill ~-17 ~37 ~-33 ~-17 ~38 ~-33 minecraft:deepslate_tiles
fill ~-17 ~37 ~-27 ~-17 ~37 ~-26 minecraft:deepslate_tiles
fill ~-17 ~38 ~-28 ~-17 ~38 ~-27 minecraft:deepslate_tiles
fill ~-17 ~39 ~-32 ~-17 ~40 ~-32 minecraft:deepslate_tiles
fill ~-17 ~39 ~-28 ~-17 ~40 ~-28 minecraft:deepslate_tiles
fill ~-17 ~40 ~-31 ~-17 ~40 ~-28 minecraft:deepslate_tiles
fill ~-17 ~41 ~-31 ~-16 ~41 ~-31 minecraft:deepslate_tiles
fill ~-17 ~41 ~-30 ~-17 ~41 ~-29 minecraft:deepslate_tiles
fill ~-16 ~32 ~-23 ~-13 ~32 ~-23 minecraft:deepslate_tiles
fill ~-16 ~34 ~-36 ~-13 ~34 ~-36 minecraft:deepslate_tiles
fill ~-16 ~36 ~-35 ~-14 ~36 ~-34 minecraft:deepslate_tiles
fill ~-16 ~36 ~-25 ~-14 ~36 ~-25 minecraft:deepslate_tiles
fill ~-16 ~37 ~-26 ~-13 ~37 ~-26 minecraft:deepslate_tiles
fill ~-16 ~38 ~-33 ~-13 ~38 ~-33 minecraft:deepslate_tiles
fill ~-16 ~38 ~-27 ~-13 ~38 ~-27 minecraft:deepslate_tiles
fill ~-16 ~39 ~-33 ~-14 ~39 ~-33 minecraft:deepslate_tiles
fill ~-16 ~39 ~-27 ~-14 ~39 ~-27 minecraft:deepslate_tiles
fill ~-16 ~40 ~-32 ~-13 ~40 ~-32 minecraft:deepslate_tiles
fill ~-16 ~40 ~-28 ~-13 ~40 ~-28 minecraft:deepslate_tiles
fill ~-16 ~41 ~-32 ~-14 ~41 ~-32 minecraft:deepslate_tiles
fill ~-16 ~41 ~-29 ~-16 ~41 ~-28 minecraft:deepslate_tiles
fill ~-16 ~42 ~-31 ~-14 ~42 ~-31 minecraft:deepslate_tiles
fill ~-16 ~42 ~-30 ~-16 ~42 ~-29 minecraft:deepslate_tiles
fill ~-16 ~43 ~-30 ~-14 ~43 ~-30 minecraft:deepslate_tiles
fill ~-15 ~38 ~-34 ~-15 ~38 ~-33 minecraft:deepslate_tiles
setblock ~-15 ~38 ~-26 minecraft:deepslate_tiles
fill ~-15 ~40 ~-33 ~-15 ~40 ~-32 minecraft:deepslate_tiles
setblock ~-15 ~40 ~-27 minecraft:deepslate_tiles
fill ~-15 ~41 ~-28 ~-14 ~41 ~-28 minecraft:deepslate_tiles
fill ~-15 ~42 ~-29 ~-14 ~42 ~-29 minecraft:deepslate_tiles
fill ~-15 ~43 ~-31 ~-15 ~43 ~-29 minecraft:deepslate_tiles
fill ~-15 ~44 ~-30 ~-15 ~46 ~-30 minecraft:deepslate_tiles
fill ~-14 ~34 ~-35 ~-12 ~34 ~-35 minecraft:deepslate_tiles
fill ~-14 ~34 ~-25 ~-12 ~34 ~-25 minecraft:deepslate_tiles
fill ~-14 ~41 ~-29 ~-13 ~41 ~-29 minecraft:deepslate_tiles
fill ~-14 ~42 ~-30 ~-14 ~42 ~-29 minecraft:deepslate_tiles
fill ~-13 ~32 ~-36 ~-11 ~32 ~-36 minecraft:deepslate_tiles
fill ~-13 ~32 ~-24 ~-11 ~32 ~-24 minecraft:deepslate_tiles
fill ~-13 ~37 ~-33 ~-12 ~37 ~-33 minecraft:deepslate_tiles
fill ~-13 ~37 ~-27 ~-12 ~37 ~-27 minecraft:deepslate_tiles
fill ~-13 ~38 ~-32 ~-12 ~38 ~-32 minecraft:deepslate_tiles
fill ~-13 ~38 ~-28 ~-12 ~38 ~-28 minecraft:deepslate_tiles
fill ~-13 ~39 ~-32 ~-13 ~40 ~-32 minecraft:deepslate_tiles
fill ~-13 ~39 ~-28 ~-13 ~40 ~-28 minecraft:deepslate_tiles
fill ~-13 ~40 ~-31 ~-13 ~40 ~-28 minecraft:deepslate_tiles
fill ~-13 ~41 ~-31 ~-13 ~41 ~-29 minecraft:deepslate_tiles
fill ~-12 ~31 ~-24 ~-10 ~31 ~-24 minecraft:deepslate_tiles
fill ~-12 ~33 ~-35 ~-11 ~33 ~-35 minecraft:deepslate_tiles
fill ~-12 ~33 ~-25 ~-11 ~33 ~-25 minecraft:deepslate_tiles
fill ~-12 ~35 ~-34 ~-11 ~35 ~-34 minecraft:deepslate_tiles
fill ~-12 ~35 ~-26 ~-11 ~35 ~-26 minecraft:deepslate_tiles
fill ~-12 ~36 ~-33 ~-11 ~36 ~-33 minecraft:deepslate_tiles
fill ~-12 ~36 ~-27 ~-11 ~36 ~-27 minecraft:deepslate_tiles
fill ~-12 ~37 ~-32 ~-11 ~37 ~-32 minecraft:deepslate_tiles
fill ~-12 ~37 ~-28 ~-11 ~37 ~-28 minecraft:deepslate_tiles
fill ~-12 ~38 ~-31 ~-12 ~38 ~-28 minecraft:deepslate_tiles
fill ~-12 ~39 ~-31 ~-12 ~39 ~-29 minecraft:deepslate_tiles
setblock ~-12 ~40 ~-30 minecraft:deepslate_tiles
fill ~-11 ~31 ~-36 ~-10 ~31 ~-36 minecraft:deepslate_tiles
fill ~-11 ~32 ~-35 ~-10 ~32 ~-35 minecraft:deepslate_tiles
fill ~-11 ~32 ~-25 ~-10 ~32 ~-25 minecraft:deepslate_tiles
fill ~-11 ~33 ~-34 ~-10 ~33 ~-34 minecraft:deepslate_tiles
fill ~-11 ~33 ~-26 ~-10 ~33 ~-26 minecraft:deepslate_tiles
fill ~-11 ~34 ~-34 ~-11 ~35 ~-34 minecraft:deepslate_tiles
fill ~-11 ~34 ~-26 ~-11 ~35 ~-26 minecraft:deepslate_tiles
fill ~-11 ~35 ~-33 ~-11 ~36 ~-33 minecraft:deepslate_tiles
fill ~-11 ~35 ~-27 ~-11 ~35 ~-26 minecraft:deepslate_tiles
fill ~-11 ~36 ~-32 ~-11 ~36 ~-27 minecraft:deepslate_tiles
fill ~-11 ~37 ~-31 ~-11 ~37 ~-28 minecraft:deepslate_tiles
setblock ~-11 ~38 ~-30 minecraft:deepslate_tiles
fill ~-10 ~31 ~-35 ~-9 ~31 ~-35 minecraft:deepslate_tiles
fill ~-10 ~31 ~-25 ~-9 ~31 ~-25 minecraft:deepslate_tiles
fill ~-10 ~32 ~-34 ~-9 ~32 ~-34 minecraft:deepslate_tiles
fill ~-10 ~32 ~-26 ~-9 ~32 ~-26 minecraft:deepslate_tiles
fill ~-10 ~33 ~-33 ~-9 ~33 ~-33 minecraft:deepslate_tiles
fill ~-10 ~34 ~-33 ~-10 ~34 ~-31 minecraft:deepslate_tiles
fill ~-10 ~34 ~-29 ~-9 ~34 ~-28 minecraft:deepslate_tiles
setblock ~-10 ~34 ~-27 minecraft:deepslate_tiles
fill ~-10 ~35 ~-32 ~-10 ~35 ~-28 minecraft:deepslate_tiles
fill ~-10 ~36 ~-31 ~-10 ~36 ~-29 minecraft:deepslate_tiles
fill ~-9 ~31 ~-33 ~-8 ~31 ~-33 minecraft:deepslate_tiles
fill ~-9 ~31 ~-27 ~-8 ~31 ~-27 minecraft:deepslate_tiles
fill ~-9 ~31 ~-26 ~-9 ~31 ~-25 minecraft:deepslate_tiles
fill ~-9 ~32 ~-33 ~-9 ~33 ~-32 minecraft:deepslate_tiles
fill ~-9 ~32 ~-28 ~-8 ~32 ~-28 minecraft:deepslate_tiles
fill ~-9 ~32 ~-27 ~-9 ~32 ~-26 minecraft:deepslate_tiles
fill ~-9 ~33 ~-31 ~-9 ~33 ~-27 minecraft:deepslate_tiles
fill ~-9 ~34 ~-32 ~-9 ~34 ~-28 minecraft:deepslate_tiles
fill ~-9 ~67 ~-128 ~-8 ~67 ~-128 minecraft:deepslate_tiles
fill ~-9 ~67 ~-127 ~-9 ~67 ~-120 minecraft:deepslate_tiles
fill ~-9 ~68 ~-126 ~-8 ~68 ~-126 minecraft:deepslate_tiles
fill ~-9 ~68 ~-125 ~-9 ~68 ~-122 minecraft:deepslate_tiles
fill ~-8 ~31 ~-32 ~-8 ~32 ~-32 minecraft:deepslate_tiles
fill ~-8 ~31 ~-28 ~-8 ~31 ~-27 minecraft:deepslate_tiles
fill ~-8 ~67 ~-129 ~-8 ~68 ~-128 minecraft:deepslate_tiles
fill ~-8 ~67 ~-120 ~-8 ~68 ~-119 minecraft:deepslate_tiles
fill ~-8 ~68 ~-127 ~-8 ~69 ~-126 minecraft:deepslate_tiles
fill ~-8 ~68 ~-122 ~-8 ~68 ~-119 minecraft:deepslate_tiles
fill ~-8 ~69 ~-125 ~-8 ~69 ~-121 minecraft:deepslate_tiles
fill ~-8 ~70 ~-126 ~-7 ~70 ~-125 minecraft:deepslate_tiles
fill ~-8 ~70 ~-124 ~-8 ~70 ~-122 minecraft:deepslate_tiles
fill ~-7 ~67 ~-130 ~-7 ~68 ~-130 minecraft:deepslate_tiles
fill ~-7 ~67 ~-118 ~-7 ~67 ~-116 minecraft:deepslate_tiles
fill ~-7 ~68 ~-129 ~-7 ~69 ~-129 minecraft:deepslate_tiles
fill ~-7 ~68 ~-119 ~-7 ~68 ~-118 minecraft:deepslate_tiles
fill ~-7 ~69 ~-128 ~-7 ~70 ~-127 minecraft:deepslate_tiles
fill ~-7 ~69 ~-121 ~-7 ~69 ~-119 minecraft:deepslate_tiles
fill ~-7 ~70 ~-123 ~-7 ~70 ~-120 minecraft:deepslate_tiles
fill ~-7 ~71 ~-127 ~-6 ~71 ~-127 minecraft:deepslate_tiles
fill ~-7 ~71 ~-126 ~-7 ~71 ~-121 minecraft:deepslate_tiles
fill ~-7 ~72 ~-125 ~-6 ~72 ~-123 minecraft:deepslate_tiles
fill ~-6 ~27 ~-163 ~-5 ~27 ~-163 minecraft:deepslate_tiles
fill ~-6 ~27 ~-162 ~-6 ~27 ~-157 minecraft:deepslate_tiles
fill ~-6 ~28 ~-162 ~-5 ~28 ~-162 minecraft:deepslate_tiles
fill ~-6 ~28 ~-161 ~-6 ~28 ~-158 minecraft:deepslate_tiles
fill ~-6 ~67 ~-131 ~-6 ~68 ~-131 minecraft:deepslate_tiles
fill ~-6 ~67 ~-117 ~-6 ~68 ~-117 minecraft:deepslate_tiles
fill ~-6 ~68 ~-130 ~-6 ~69 ~-130 minecraft:deepslate_tiles
fill ~-6 ~68 ~-118 ~-6 ~68 ~-117 minecraft:deepslate_tiles
fill ~-6 ~69 ~-129 ~-6 ~70 ~-129 minecraft:deepslate_tiles
fill ~-6 ~69 ~-119 ~-6 ~69 ~-118 minecraft:deepslate_tiles
fill ~-6 ~70 ~-128 ~-6 ~72 ~-128 minecraft:deepslate_tiles
fill ~-6 ~70 ~-120 ~-6 ~70 ~-119 minecraft:deepslate_tiles
fill ~-6 ~71 ~-121 ~-6 ~72 ~-120 minecraft:deepslate_tiles
fill ~-6 ~72 ~-127 ~-6 ~72 ~-120 minecraft:deepslate_tiles
fill ~-6 ~73 ~-126 ~-5 ~73 ~-126 minecraft:deepslate_tiles
fill ~-6 ~73 ~-125 ~-6 ~73 ~-122 minecraft:deepslate_tiles
fill ~-6 ~74 ~-125 ~-5 ~74 ~-123 minecraft:deepslate_tiles
fill ~-5 ~27 ~-164 ~-5 ~28 ~-163 minecraft:deepslate_tiles
fill ~-5 ~27 ~-157 ~-5 ~28 ~-156 minecraft:deepslate_tiles
fill ~-5 ~28 ~-158 ~-5 ~28 ~-156 minecraft:deepslate_tiles
fill ~-5 ~29 ~-162 ~-5 ~29 ~-157 minecraft:deepslate_tiles
fill ~-5 ~30 ~-161 ~-4 ~30 ~-161 minecraft:deepslate_tiles
fill ~-5 ~30 ~-160 ~-5 ~30 ~-159 minecraft:deepslate_tiles
fill ~-5 ~67 ~-132 ~-4 ~68 ~-132 minecraft:deepslate_tiles
fill ~-5 ~67 ~-116 ~-4 ~68 ~-116 minecraft:deepslate_tiles
fill ~-5 ~68 ~-131 ~-5 ~69 ~-131 minecraft:deepslate_tiles
fill ~-5 ~68 ~-117 ~-5 ~68 ~-116 minecraft:deepslate_tiles
fill ~-5 ~69 ~-130 ~-5 ~70 ~-130 minecraft:deepslate_tiles
fill ~-5 ~69 ~-118 ~-5 ~69 ~-117 minecraft:deepslate_tiles
fill ~-5 ~70 ~-129 ~-5 ~72 ~-129 minecraft:deepslate_tiles
fill ~-5 ~70 ~-119 ~-5 ~70 ~-118 minecraft:deepslate_tiles
fill ~-5 ~71 ~-119 ~-5 ~72 ~-119 minecraft:deepslate_tiles
fill ~-5 ~72 ~-128 ~-5 ~73 ~-128 minecraft:deepslate_tiles
fill ~-5 ~72 ~-120 ~-5 ~72 ~-119 minecraft:deepslate_tiles
fill ~-5 ~73 ~-127 ~-5 ~74 ~-126 minecraft:deepslate_tiles
fill ~-5 ~73 ~-122 ~-5 ~73 ~-120 minecraft:deepslate_tiles
fill ~-5 ~74 ~-122 ~-5 ~74 ~-121 minecraft:deepslate_tiles
fill ~-5 ~75 ~-126 ~-4 ~75 ~-126 minecraft:deepslate_tiles
fill ~-5 ~75 ~-125 ~-5 ~75 ~-122 minecraft:deepslate_tiles
fill ~-5 ~76 ~-124 ~-4 ~76 ~-124 minecraft:deepslate_tiles
fill ~-4 ~27 ~-155 ~-3 ~28 ~-155 minecraft:deepslate_tiles
fill ~-4 ~28 ~-165 ~-2 ~28 ~-165 minecraft:deepslate_tiles
fill ~-4 ~28 ~-164 ~-4 ~29 ~-164 minecraft:deepslate_tiles
fill ~-4 ~28 ~-156 ~-4 ~28 ~-155 minecraft:deepslate_tiles
fill ~-4 ~29 ~-163 ~-4 ~30 ~-163 minecraft:deepslate_tiles
fill ~-4 ~29 ~-157 ~-4 ~29 ~-156 minecraft:deepslate_tiles
fill ~-4 ~30 ~-162 ~-4 ~31 ~-161 minecraft:deepslate_tiles
fill ~-4 ~30 ~-159 ~-4 ~30 ~-157 minecraft:deepslate_tiles
fill ~-4 ~31 ~-160 ~-4 ~31 ~-158 minecraft:deepslate_tiles
fill ~-4 ~32 ~-160 ~-3 ~32 ~-159 minecraft:deepslate_tiles
fill ~-4 ~67 ~-133 ~4 ~67 ~-133 minecraft:deepslate_tiles
fill ~-4 ~67 ~-115 ~-2 ~67 ~-115 minecraft:deepslate_tiles
fill ~-4 ~69 ~-131 ~-3 ~70 ~-131 minecraft:deepslate_tiles
fill ~-4 ~69 ~-117 ~-3 ~70 ~-117 minecraft:deepslate_tiles
fill ~-4 ~70 ~-130 ~-4 ~72 ~-130 minecraft:deepslate_tiles
fill ~-4 ~70 ~-118 ~-4 ~70 ~-117 minecraft:deepslate_tiles
fill ~-4 ~71 ~-118 ~-3 ~72 ~-118 minecraft:deepslate_tiles
fill ~-4 ~72 ~-129 ~-4 ~73 ~-129 minecraft:deepslate_tiles
fill ~-4 ~73 ~-128 ~-4 ~74 ~-128 minecraft:deepslate_tiles
fill ~-4 ~73 ~-120 ~-4 ~73 ~-119 minecraft:deepslate_tiles
fill ~-4 ~74 ~-127 ~-4 ~76 ~-127 minecraft:deepslate_tiles
fill ~-4 ~74 ~-121 ~-4 ~74 ~-120 minecraft:deepslate_tiles
fill ~-4 ~75 ~-122 ~-4 ~76 ~-121 minecraft:deepslate_tiles
fill ~-4 ~76 ~-126 ~-4 ~76 ~-121 minecraft:deepslate_tiles
fill ~-4 ~77 ~-126 ~-3 ~77 ~-125 minecraft:deepslate_tiles
fill ~-4 ~77 ~-124 ~-4 ~77 ~-122 minecraft:deepslate_tiles
fill ~-3 ~27 ~-166 ~3 ~27 ~-166 minecraft:deepslate_tiles
fill ~-3 ~27 ~-165 ~-3 ~29 ~-165 minecraft:deepslate_tiles
fill ~-3 ~27 ~-154 ~-2 ~27 ~-154 minecraft:deepslate_tiles
fill ~-3 ~29 ~-164 ~-3 ~30 ~-164 minecraft:deepslate_tiles
fill ~-3 ~29 ~-156 ~-3 ~29 ~-155 minecraft:deepslate_tiles
fill ~-3 ~30 ~-163 ~-3 ~31 ~-163 minecraft:deepslate_tiles
fill ~-3 ~30 ~-157 ~-3 ~30 ~-156 minecraft:deepslate_tiles
fill ~-3 ~31 ~-162 ~-3 ~33 ~-162 minecraft:deepslate_tiles
fill ~-3 ~31 ~-158 ~-3 ~31 ~-157 minecraft:deepslate_tiles
fill ~-3 ~32 ~-161 ~-3 ~33 ~-158 minecraft:deepslate_tiles
fill ~-3 ~34 ~-160 ~-2 ~34 ~-160 minecraft:deepslate_tiles
fill ~-3 ~68 ~-132 ~-2 ~69 ~-132 minecraft:deepslate_tiles
fill ~-3 ~68 ~-116 ~-2 ~69 ~-116 minecraft:deepslate_tiles
fill ~-3 ~71 ~-131 ~3 ~71 ~-131 minecraft:deepslate_tiles
fill ~-3 ~71 ~-130 ~-3 ~72 ~-130 minecraft:deepslate_tiles
fill ~-3 ~71 ~-117 ~3 ~71 ~-117 minecraft:deepslate_tiles
fill ~-3 ~73 ~-129 ~-2 ~74 ~-129 minecraft:deepslate_tiles
fill ~-3 ~73 ~-119 ~-2 ~74 ~-119 minecraft:deepslate_tiles
fill ~-3 ~74 ~-128 ~-3 ~76 ~-128 minecraft:deepslate_tiles
fill ~-3 ~74 ~-120 ~-3 ~74 ~-119 minecraft:deepslate_tiles
fill ~-3 ~75 ~-120 ~-2 ~76 ~-120 minecraft:deepslate_tiles
fill ~-3 ~76 ~-127 ~-3 ~77 ~-127 minecraft:deepslate_tiles
fill ~-3 ~76 ~-121 ~-3 ~76 ~-120 minecraft:deepslate_tiles
fill ~-3 ~77 ~-123 ~-3 ~77 ~-121 minecraft:deepslate_tiles
fill ~-3 ~78 ~-126 ~-2 ~78 ~-126 minecraft:deepslate_tiles
fill ~-3 ~78 ~-125 ~-3 ~78 ~-122 minecraft:deepslate_tiles
fill ~-3 ~79 ~-125 ~-2 ~79 ~-125 minecraft:deepslate_tiles
fill ~-3 ~79 ~-124 ~-3 ~79 ~-123 minecraft:deepslate_tiles
fill ~-2 ~28 ~-166 ~2 ~28 ~-166 minecraft:deepslate_tiles
fill ~-2 ~28 ~-155 ~-2 ~28 ~-154 minecraft:deepslate_tiles
fill ~-2 ~29 ~-165 ~3 ~29 ~-165 minecraft:deepslate_tiles
fill ~-2 ~29 ~-155 ~3 ~29 ~-155 minecraft:deepslate_tiles
fill ~-2 ~30 ~-164 ~-1 ~31 ~-164 minecraft:deepslate_tiles
fill ~-2 ~30 ~-156 ~-1 ~31 ~-156 minecraft:deepslate_tiles
fill ~-2 ~31 ~-163 ~-2 ~33 ~-163 minecraft:deepslate_tiles
fill ~-2 ~31 ~-157 ~-2 ~31 ~-156 minecraft:deepslate_tiles
fill ~-2 ~32 ~-157 ~2 ~33 ~-157 minecraft:deepslate_tiles
fill ~-2 ~33 ~-162 ~-2 ~34 ~-162 minecraft:deepslate_tiles
fill ~-2 ~33 ~-158 ~-2 ~33 ~-157 minecraft:deepslate_tiles
fill ~-2 ~34 ~-161 ~-2 ~34 ~-158 minecraft:deepslate_tiles
fill ~-2 ~35 ~-161 ~-1 ~35 ~-161 minecraft:deepslate_tiles
fill ~-2 ~35 ~-160 ~-2 ~35 ~-159 minecraft:deepslate_tiles
fill ~-2 ~68 ~-133 ~2 ~68 ~-133 minecraft:deepslate_tiles
setblock ~-2 ~68 ~-115 minecraft:deepslate_tiles
fill ~-2 ~70 ~-132 ~2 ~70 ~-132 minecraft:deepslate_tiles
fill ~-2 ~70 ~-131 ~-1 ~71 ~-131 minecraft:deepslate_tiles
fill ~-2 ~70 ~-117 ~-1 ~70 ~-116 minecraft:deepslate_tiles
fill ~-2 ~72 ~-130 ~4 ~72 ~-130 minecraft:deepslate_tiles
fill ~-2 ~72 ~-118 ~4 ~72 ~-118 minecraft:deepslate_tiles
fill ~-2 ~73 ~-130 ~2 ~73 ~-130 minecraft:deepslate_tiles
fill ~-2 ~73 ~-118 ~2 ~73 ~-118 minecraft:deepslate_tiles
fill ~-2 ~75 ~-128 ~-2 ~77 ~-128 minecraft:deepslate_tiles
fill ~-2 ~75 ~-119 ~2 ~75 ~-119 minecraft:deepslate_tiles
fill ~-2 ~77 ~-121 ~-1 ~77 ~-120 minecraft:deepslate_tiles
fill ~-2 ~78 ~-127 ~2 ~78 ~-127 minecraft:deepslate_tiles
fill ~-2 ~78 ~-122 ~-2 ~78 ~-121 minecraft:deepslate_tiles
fill ~-2 ~79 ~-126 ~-1 ~79 ~-126 minecraft:deepslate_tiles
fill ~-2 ~79 ~-123 ~-2 ~79 ~-122 minecraft:deepslate_tiles
fill ~-2 ~80 ~-125 ~-2 ~81 ~-123 minecraft:deepslate_tiles
fill ~-1 ~30 ~-165 ~1 ~30 ~-165 minecraft:deepslate_tiles
fill ~-1 ~30 ~-155 ~1 ~30 ~-155 minecraft:deepslate_tiles
fill ~-1 ~32 ~-164 ~1 ~32 ~-163 minecraft:deepslate_tiles
fill ~-1 ~32 ~-156 ~1 ~32 ~-156 minecraft:deepslate_tiles
fill ~-1 ~33 ~-163 ~2 ~33 ~-163 minecraft:deepslate_tiles
fill ~-1 ~34 ~-162 ~2 ~34 ~-162 minecraft:deepslate_tiles
fill ~-1 ~34 ~-158 ~2 ~34 ~-158 minecraft:deepslate_tiles
fill ~-1 ~35 ~-162 ~1 ~35 ~-162 minecraft:deepslate_tiles
fill ~-1 ~35 ~-159 ~-1 ~35 ~-158 minecraft:deepslate_tiles
fill ~-1 ~36 ~-160 ~-1 ~37 ~-159 minecraft:deepslate_tiles
fill ~-1 ~37 ~-161 ~1 ~37 ~-159 minecraft:deepslate_tiles
fill ~-1 ~69 ~-132 ~3 ~69 ~-132 minecraft:deepslate_tiles
fill ~-1 ~69 ~-116 ~3 ~69 ~-116 minecraft:deepslate_tiles
fill ~-1 ~72 ~-131 ~1 ~72 ~-130 minecraft:deepslate_tiles
fill ~-1 ~72 ~-117 ~1 ~72 ~-117 minecraft:deepslate_tiles
fill ~-1 ~74 ~-130 ~1 ~74 ~-129 minecraft:deepslate_tiles
fill ~-1 ~74 ~-119 ~3 ~74 ~-119 minecraft:deepslate_tiles
fill ~-1 ~74 ~-118 ~1 ~74 ~-118 minecraft:deepslate_tiles
fill ~-1 ~75 ~-129 ~2 ~75 ~-129 minecraft:deepslate_tiles
fill ~-1 ~76 ~-128 ~3 ~76 ~-128 minecraft:deepslate_tiles
fill ~-1 ~76 ~-120 ~3 ~76 ~-120 minecraft:deepslate_tiles
fill ~-1 ~77 ~-128 ~2 ~77 ~-128 minecraft:deepslate_tiles
fill ~-1 ~77 ~-127 ~-1 ~79 ~-127 minecraft:deepslate_tiles
fill ~-1 ~78 ~-121 ~2 ~78 ~-121 minecraft:deepslate_tiles
fill ~-1 ~79 ~-122 ~-1 ~79 ~-121 minecraft:deepslate_tiles
fill ~-1 ~80 ~-126 ~1 ~81 ~-126 minecraft:deepslate_tiles
fill ~-1 ~80 ~-122 ~1 ~81 ~-122 minecraft:deepslate_tiles
fill ~-1 ~81 ~-125 ~2 ~81 ~-125 minecraft:deepslate_tiles
fill ~-1 ~81 ~-124 ~-1 ~81 ~-122 minecraft:deepslate_tiles
fill ~-1 ~82 ~-125 ~1 ~82 ~-123 minecraft:deepslate_tiles
fill ~-1 ~83 ~-124 ~1 ~83 ~-124 minecraft:deepslate_tiles
fill ~ ~31 ~-164 ~2 ~31 ~-164 minecraft:deepslate_tiles
fill ~ ~31 ~-156 ~2 ~31 ~-156 minecraft:deepslate_tiles
fill ~ ~34 ~-163 ~ ~34 ~-162 minecraft:deepslate_tiles
setblock ~ ~34 ~-157 minecraft:deepslate_tiles
fill ~ ~35 ~-158 ~1 ~35 ~-158 minecraft:deepslate_tiles
fill ~ ~36 ~-161 ~1 ~37 ~-161 minecraft:deepslate_tiles
fill ~ ~36 ~-159 ~1 ~37 ~-159 minecraft:deepslate_tiles
fill ~ ~38 ~-160 ~ ~40 ~-160 minecraft:deepslate_tiles
fill ~ ~70 ~-116 ~2 ~70 ~-116 minecraft:deepslate_tiles
fill ~ ~76 ~-129 ~ ~76 ~-128 minecraft:deepslate_tiles
setblock ~ ~76 ~-119 minecraft:deepslate_tiles
fill ~ ~77 ~-120 ~2 ~77 ~-120 minecraft:deepslate_tiles
fill ~ ~79 ~-127 ~1 ~79 ~-127 minecraft:deepslate_tiles
fill ~ ~79 ~-121 ~1 ~79 ~-121 minecraft:deepslate_tiles
fill ~ ~81 ~-123 ~2 ~81 ~-123 minecraft:deepslate_tiles
fill ~ ~83 ~-125 ~ ~83 ~-123 minecraft:deepslate_tiles
fill ~ ~84 ~-124 ~ ~86 ~-124 minecraft:deepslate_tiles
fill ~1 ~30 ~-164 ~3 ~30 ~-164 minecraft:deepslate_tiles
fill ~1 ~30 ~-156 ~3 ~30 ~-156 minecraft:deepslate_tiles
fill ~1 ~35 ~-161 ~2 ~35 ~-161 minecraft:deepslate_tiles
fill ~1 ~35 ~-159 ~2 ~35 ~-159 minecraft:deepslate_tiles
fill ~1 ~36 ~-160 ~1 ~37 ~-159 minecraft:deepslate_tiles
fill ~1 ~70 ~-131 ~4 ~70 ~-131 minecraft:deepslate_tiles
fill ~1 ~77 ~-127 ~3 ~77 ~-127 minecraft:deepslate_tiles
fill ~1 ~77 ~-121 ~3 ~77 ~-121 minecraft:deepslate_tiles
fill ~1 ~79 ~-126 ~2 ~79 ~-126 minecraft:deepslate_tiles
fill ~1 ~79 ~-122 ~2 ~79 ~-122 minecraft:deepslate_tiles
fill ~1 ~81 ~-124 ~2 ~81 ~-123 minecraft:deepslate_tiles
fill ~2 ~27 ~-154 ~3 ~27 ~-154 minecraft:deepslate_tiles
fill ~2 ~28 ~-165 ~4 ~28 ~-165 minecraft:deepslate_tiles
fill ~2 ~28 ~-155 ~4 ~28 ~-155 minecraft:deepslate_tiles
fill ~2 ~31 ~-163 ~3 ~31 ~-163 minecraft:deepslate_tiles
fill ~2 ~31 ~-157 ~3 ~31 ~-157 minecraft:deepslate_tiles
fill ~2 ~32 ~-163 ~2 ~33 ~-163 minecraft:deepslate_tiles
fill ~2 ~33 ~-162 ~3 ~33 ~-162 minecraft:deepslate_tiles
fill ~2 ~33 ~-158 ~3 ~33 ~-158 minecraft:deepslate_tiles
fill ~2 ~34 ~-161 ~2 ~34 ~-158 minecraft:deepslate_tiles
fill ~2 ~35 ~-160 ~2 ~35 ~-159 minecraft:deepslate_tiles
fill ~2 ~67 ~-115 ~4 ~67 ~-115 minecraft:deepslate_tiles
fill ~2 ~68 ~-132 ~5 ~68 ~-132 minecraft:deepslate_tiles
fill ~2 ~68 ~-116 ~5 ~68 ~-116 minecraft:deepslate_tiles
setblock ~2 ~68 ~-115 minecraft:deepslate_tiles
fill ~2 ~73 ~-129 ~4 ~73 ~-129 minecraft:deepslate_tiles
fill ~2 ~73 ~-119 ~4 ~73 ~-119 minecraft:deepslate_tiles
fill ~2 ~74 ~-129 ~3 ~74 ~-129 minecraft:deepslate_tiles
fill ~2 ~75 ~-128 ~3 ~76 ~-128 minecraft:deepslate_tiles
fill ~2 ~75 ~-120 ~3 ~76 ~-120 minecraft:deepslate_tiles
fill ~2 ~78 ~-126 ~3 ~78 ~-126 minecraft:deepslate_tiles
fill ~2 ~78 ~-122 ~3 ~78 ~-122 minecraft:deepslate_tiles
fill ~2 ~79 ~-125 ~3 ~79 ~-125 minecraft:deepslate_tiles
fill ~2 ~79 ~-123 ~3 ~79 ~-123 minecraft:deepslate_tiles
fill ~2 ~80 ~-125 ~2 ~81 ~-123 minecraft:deepslate_tiles
fill ~3 ~27 ~-165 ~4 ~28 ~-165 minecraft:deepslate_tiles
fill ~3 ~27 ~-155 ~4 ~28 ~-155 minecraft:deepslate_tiles
fill ~3 ~29 ~-164 ~4 ~29 ~-164 minecraft:deepslate_tiles
fill ~3 ~29 ~-156 ~4 ~29 ~-156 minecraft:deepslate_tiles
fill ~3 ~30 ~-163 ~4 ~30 ~-163 minecraft:deepslate_tiles
fill ~3 ~30 ~-157 ~4 ~30 ~-157 minecraft:deepslate_tiles
fill ~3 ~31 ~-162 ~4 ~31 ~-162 minecraft:deepslate_tiles
fill ~3 ~31 ~-158 ~4 ~31 ~-158 minecraft:deepslate_tiles
fill ~3 ~32 ~-162 ~3 ~33 ~-158 minecraft:deepslate_tiles
setblock ~3 ~34 ~-160 minecraft:deepslate_tiles
fill ~3 ~69 ~-131 ~5 ~69 ~-131 minecraft:deepslate_tiles
fill ~3 ~69 ~-117 ~5 ~69 ~-117 minecraft:deepslate_tiles
fill ~3 ~70 ~-117 ~4 ~70 ~-117 minecraft:deepslate_tiles
fill ~3 ~71 ~-130 ~4 ~72 ~-130 minecraft:deepslate_tiles
fill ~3 ~71 ~-118 ~4 ~72 ~-118 minecraft:deepslate_tiles
fill ~3 ~74 ~-128 ~4 ~74 ~-128 minecraft:deepslate_tiles
fill ~3 ~74 ~-120 ~4 ~74 ~-120 minecraft:deepslate_tiles
fill ~3 ~76 ~-127 ~4 ~76 ~-127 minecraft:deepslate_tiles
fill ~3 ~76 ~-121 ~4 ~76 ~-121 minecraft:deepslate_tiles
fill ~3 ~77 ~-126 ~4 ~77 ~-125 minecraft:deepslate_tiles
fill ~3 ~77 ~-123 ~4 ~77 ~-122 minecraft:deepslate_tiles
fill ~3 ~78 ~-125 ~3 ~78 ~-122 minecraft:deepslate_tiles
fill ~3 ~79 ~-124 ~3 ~79 ~-123 minecraft:deepslate_tiles
fill ~4 ~28 ~-164 ~5 ~28 ~-164 minecraft:deepslate_tiles
fill ~4 ~28 ~-156 ~5 ~28 ~-156 minecraft:deepslate_tiles
fill ~4 ~29 ~-163 ~5 ~29 ~-163 minecraft:deepslate_tiles
fill ~4 ~29 ~-157 ~5 ~29 ~-157 minecraft:deepslate_tiles
fill ~4 ~30 ~-162 ~4 ~31 ~-161 minecraft:deepslate_tiles
fill ~4 ~30 ~-159 ~5 ~30 ~-159 minecraft:deepslate_tiles
fill ~4 ~30 ~-158 ~4 ~30 ~-157 minecraft:deepslate_tiles
fill ~4 ~31 ~-160 ~4 ~31 ~-158 minecraft:deepslate_tiles
fill ~4 ~32 ~-161 ~4 ~32 ~-159 minecraft:deepslate_tiles
fill ~4 ~67 ~-132 ~5 ~68 ~-132 minecraft:deepslate_tiles
fill ~4 ~67 ~-116 ~5 ~68 ~-116 minecraft:deepslate_tiles
fill ~4 ~70 ~-130 ~5 ~70 ~-130 minecraft:deepslate_tiles
fill ~4 ~70 ~-118 ~5 ~70 ~-118 minecraft:deepslate_tiles
fill ~4 ~72 ~-129 ~5 ~72 ~-129 minecraft:deepslate_tiles
fill ~4 ~72 ~-119 ~5 ~72 ~-119 minecraft:deepslate_tiles
fill ~4 ~73 ~-128 ~5 ~73 ~-128 minecraft:deepslate_tiles
fill ~4 ~73 ~-120 ~5 ~73 ~-120 minecraft:deepslate_tiles
fill ~4 ~74 ~-127 ~5 ~74 ~-127 minecraft:deepslate_tiles
fill ~4 ~74 ~-121 ~5 ~74 ~-121 minecraft:deepslate_tiles
fill ~4 ~75 ~-127 ~4 ~76 ~-126 minecraft:deepslate_tiles
fill ~4 ~75 ~-122 ~5 ~75 ~-122 minecraft:deepslate_tiles
fill ~4 ~75 ~-121 ~4 ~76 ~-121 minecraft:deepslate_tiles
fill ~4 ~76 ~-125 ~4 ~76 ~-121 minecraft:deepslate_tiles
fill ~4 ~77 ~-124 ~4 ~77 ~-122 minecraft:deepslate_tiles
fill ~5 ~27 ~-164 ~5 ~28 ~-163 minecraft:deepslate_tiles
fill ~5 ~27 ~-157 ~6 ~27 ~-157 minecraft:deepslate_tiles
fill ~5 ~27 ~-156 ~5 ~28 ~-156 minecraft:deepslate_tiles
fill ~5 ~28 ~-162 ~6 ~28 ~-162 minecraft:deepslate_tiles
fill ~5 ~28 ~-158 ~6 ~28 ~-158 minecraft:deepslate_tiles
fill ~5 ~28 ~-157 ~5 ~28 ~-156 minecraft:deepslate_tiles
fill ~5 ~29 ~-162 ~5 ~29 ~-157 minecraft:deepslate_tiles
fill ~5 ~30 ~-161 ~5 ~30 ~-159 minecraft:deepslate_tiles
fill ~5 ~68 ~-131 ~6 ~68 ~-131 minecraft:deepslate_tiles
fill ~5 ~68 ~-117 ~6 ~68 ~-117 minecraft:deepslate_tiles
fill ~5 ~69 ~-130 ~6 ~69 ~-130 minecraft:deepslate_tiles
fill ~5 ~69 ~-118 ~6 ~69 ~-118 minecraft:deepslate_tiles
fill ~5 ~70 ~-129 ~6 ~70 ~-129 minecraft:deepslate_tiles
fill ~5 ~70 ~-119 ~6 ~70 ~-119 minecraft:deepslate_tiles
fill ~5 ~71 ~-129 ~5 ~72 ~-129 minecraft:deepslate_tiles
fill ~5 ~71 ~-119 ~5 ~72 ~-119 minecraft:deepslate_tiles
fill ~5 ~72 ~-128 ~6 ~72 ~-128 minecraft:deepslate_tiles
fill ~5 ~72 ~-120 ~6 ~72 ~-120 minecraft:deepslate_tiles
fill ~5 ~73 ~-127 ~5 ~74 ~-126 minecraft:deepslate_tiles
fill ~5 ~73 ~-122 ~6 ~73 ~-122 minecraft:deepslate_tiles
fill ~5 ~73 ~-121 ~5 ~73 ~-120 minecraft:deepslate_tiles
fill ~5 ~74 ~-125 ~6 ~74 ~-123 minecraft:deepslate_tiles
fill ~5 ~74 ~-122 ~5 ~74 ~-121 minecraft:deepslate_tiles
fill ~5 ~75 ~-126 ~5 ~75 ~-122 minecraft:deepslate_tiles
setblock ~5 ~76 ~-124 minecraft:deepslate_tiles
fill ~6 ~27 ~-163 ~6 ~27 ~-157 minecraft:deepslate_tiles
fill ~6 ~28 ~-161 ~6 ~28 ~-158 minecraft:deepslate_tiles
fill ~6 ~67 ~-131 ~7 ~67 ~-131 minecraft:deepslate_tiles
fill ~6 ~67 ~-117 ~7 ~67 ~-117 minecraft:deepslate_tiles
fill ~6 ~68 ~-130 ~7 ~68 ~-130 minecraft:deepslate_tiles
fill ~6 ~68 ~-118 ~7 ~68 ~-118 minecraft:deepslate_tiles
fill ~6 ~69 ~-129 ~7 ~69 ~-129 minecraft:deepslate_tiles
fill ~6 ~69 ~-119 ~7 ~69 ~-119 minecraft:deepslate_tiles
fill ~6 ~70 ~-128 ~7 ~70 ~-128 minecraft:deepslate_tiles
fill ~6 ~70 ~-120 ~7 ~70 ~-120 minecraft:deepslate_tiles
fill ~6 ~71 ~-128 ~6 ~72 ~-127 minecraft:deepslate_tiles
fill ~6 ~71 ~-121 ~7 ~71 ~-121 minecraft:deepslate_tiles
fill ~6 ~71 ~-120 ~6 ~72 ~-120 minecraft:deepslate_tiles
fill ~6 ~72 ~-126 ~6 ~72 ~-120 minecraft:deepslate_tiles
fill ~6 ~73 ~-126 ~6 ~73 ~-122 minecraft:deepslate_tiles
fill ~7 ~67 ~-130 ~7 ~68 ~-130 minecraft:deepslate_tiles
fill ~7 ~67 ~-118 ~7 ~67 ~-117 minecraft:deepslate_tiles
fill ~7 ~68 ~-129 ~8 ~68 ~-129 minecraft:deepslate_tiles
fill ~7 ~68 ~-119 ~8 ~68 ~-119 minecraft:deepslate_tiles
fill ~7 ~69 ~-127 ~8 ~69 ~-127 minecraft:deepslate_tiles
fill ~7 ~69 ~-121 ~8 ~69 ~-121 minecraft:deepslate_tiles
fill ~7 ~69 ~-120 ~7 ~69 ~-119 minecraft:deepslate_tiles
fill ~7 ~70 ~-127 ~7 ~71 ~-125 minecraft:deepslate_tiles
fill ~7 ~70 ~-123 ~8 ~70 ~-122 minecraft:deepslate_tiles
fill ~7 ~70 ~-121 ~7 ~70 ~-120 minecraft:deepslate_tiles
fill ~7 ~71 ~-124 ~7 ~71 ~-121 minecraft:deepslate_tiles
fill ~7 ~72 ~-125 ~7 ~72 ~-123 minecraft:deepslate_tiles
fill ~8 ~31 ~-33 ~9 ~31 ~-33 minecraft:deepslate_tiles
fill ~8 ~31 ~-32 ~8 ~32 ~-32 minecraft:deepslate_tiles
fill ~8 ~31 ~-28 ~8 ~31 ~-27 minecraft:deepslate_tiles
fill ~8 ~32 ~-28 ~9 ~32 ~-28 minecraft:deepslate_tiles
fill ~8 ~67 ~-129 ~8 ~68 ~-128 minecraft:deepslate_tiles
fill ~8 ~67 ~-120 ~9 ~67 ~-120 minecraft:deepslate_tiles
fill ~8 ~67 ~-119 ~8 ~68 ~-119 minecraft:deepslate_tiles
fill ~8 ~68 ~-127 ~8 ~69 ~-126 minecraft:deepslate_tiles
fill ~8 ~68 ~-122 ~9 ~68 ~-122 minecraft:deepslate_tiles
fill ~8 ~68 ~-121 ~8 ~68 ~-119 minecraft:deepslate_tiles
fill ~8 ~69 ~-125 ~8 ~69 ~-121 minecraft:deepslate_tiles
fill ~8 ~70 ~-126 ~8 ~70 ~-122 minecraft:deepslate_tiles
fill ~9 ~31 ~-35 ~10 ~31 ~-35 minecraft:deepslate_tiles
fill ~9 ~31 ~-34 ~9 ~32 ~-33 minecraft:deepslate_tiles
fill ~9 ~31 ~-27 ~9 ~31 ~-25 minecraft:deepslate_tiles
fill ~9 ~32 ~-32 ~9 ~34 ~-32 minecraft:deepslate_tiles
fill ~9 ~32 ~-27 ~9 ~32 ~-26 minecraft:deepslate_tiles
fill ~9 ~33 ~-33 ~10 ~33 ~-33 minecraft:deepslate_tiles
fill ~9 ~33 ~-31 ~9 ~33 ~-27 minecraft:deepslate_tiles
fill ~9 ~34 ~-31 ~10 ~34 ~-31 minecraft:deepslate_tiles
fill ~9 ~34 ~-30 ~9 ~34 ~-28 minecraft:deepslate_tiles
fill ~9 ~67 ~-128 ~9 ~67 ~-120 minecraft:deepslate_tiles
fill ~9 ~68 ~-126 ~9 ~68 ~-122 minecraft:deepslate_tiles
fill ~10 ~31 ~-36 ~12 ~31 ~-36 minecraft:deepslate_tiles
fill ~10 ~31 ~-25 ~10 ~31 ~-24 minecraft:deepslate_tiles
fill ~10 ~32 ~-35 ~11 ~32 ~-35 minecraft:deepslate_tiles
fill ~10 ~32 ~-34 ~10 ~33 ~-34 minecraft:deepslate_tiles
fill ~10 ~32 ~-26 ~10 ~32 ~-25 minecraft:deepslate_tiles
fill ~10 ~33 ~-27 ~10 ~33 ~-26 minecraft:deepslate_tiles
fill ~10 ~34 ~-33 ~10 ~34 ~-31 minecraft:deepslate_tiles
fill ~10 ~34 ~-29 ~10 ~34 ~-27 minecraft:deepslate_tiles
fill ~10 ~35 ~-32 ~10 ~35 ~-28 minecraft:deepslate_tiles
fill ~10 ~36 ~-31 ~11 ~36 ~-29 minecraft:deepslate_tiles
fill ~11 ~31 ~-24 ~12 ~32 ~-24 minecraft:deepslate_tiles
fill ~11 ~32 ~-36 ~13 ~32 ~-36 minecraft:deepslate_tiles
fill ~11 ~32 ~-25 ~11 ~32 ~-24 minecraft:deepslate_tiles
fill ~11 ~33 ~-35 ~12 ~33 ~-35 minecraft:deepslate_tiles
fill ~11 ~33 ~-34 ~11 ~35 ~-34 minecraft:deepslate_tiles
fill ~11 ~33 ~-26 ~11 ~33 ~-25 minecraft:deepslate_tiles
fill ~11 ~34 ~-26 ~11 ~35 ~-26 minecraft:deepslate_tiles
fill ~11 ~35 ~-33 ~11 ~36 ~-33 minecraft:deepslate_tiles
fill ~11 ~35 ~-27 ~11 ~35 ~-26 minecraft:deepslate_tiles
fill ~11 ~36 ~-28 ~11 ~36 ~-27 minecraft:deepslate_tiles
fill ~11 ~37 ~-32 ~12 ~37 ~-32 minecraft:deepslate_tiles
fill ~11 ~37 ~-31 ~11 ~37 ~-28 minecraft:deepslate_tiles
fill ~11 ~38 ~-30 ~12 ~38 ~-30 minecraft:deepslate_tiles
fill ~12 ~31 ~-37 ~18 ~31 ~-37 minecraft:deepslate_tiles
fill ~12 ~31 ~-23 ~18 ~31 ~-23 minecraft:deepslate_tiles
fill ~12 ~33 ~-25 ~12 ~33 ~-24 minecraft:deepslate_tiles
fill ~12 ~34 ~-35 ~14 ~34 ~-35 minecraft:deepslate_tiles
fill ~12 ~34 ~-25 ~14 ~34 ~-25 minecraft:deepslate_tiles
fill ~12 ~35 ~-26 ~12 ~36 ~-26 minecraft:deepslate_tiles
fill ~12 ~36 ~-34 ~18 ~36 ~-34 minecraft:deepslate_tiles
fill ~12 ~36 ~-33 ~12 ~37 ~-33 minecraft:deepslate_tiles
fill ~12 ~36 ~-27 ~12 ~36 ~-26 minecraft:deepslate_tiles
fill ~12 ~37 ~-28 ~12 ~37 ~-27 minecraft:deepslate_tiles
fill ~12 ~38 ~-32 ~13 ~38 ~-32 minecraft:deepslate_tiles
fill ~12 ~38 ~-31 ~12 ~38 ~-28 minecraft:deepslate_tiles
fill ~12 ~39 ~-31 ~12 ~39 ~-29 minecraft:deepslate_tiles
fill ~12 ~40 ~-30 ~13 ~40 ~-30 minecraft:deepslate_tiles
fill ~13 ~32 ~-37 ~17 ~32 ~-37 minecraft:deepslate_tiles
fill ~13 ~32 ~-24 ~13 ~32 ~-23 minecraft:deepslate_tiles
fill ~13 ~33 ~-36 ~18 ~33 ~-36 minecraft:deepslate_tiles
fill ~13 ~33 ~-24 ~18 ~33 ~-24 minecraft:deepslate_tiles
fill ~13 ~34 ~-36 ~17 ~34 ~-36 minecraft:deepslate_tiles
fill ~13 ~34 ~-24 ~17 ~34 ~-24 minecraft:deepslate_tiles
fill ~13 ~35 ~-35 ~17 ~35 ~-35 minecraft:deepslate_tiles
fill ~13 ~35 ~-25 ~17 ~35 ~-25 minecraft:deepslate_tiles
fill ~13 ~36 ~-26 ~18 ~36 ~-26 minecraft:deepslate_tiles
fill ~13 ~37 ~-34 ~17 ~37 ~-34 minecraft:deepslate_tiles
fill ~13 ~37 ~-33 ~13 ~38 ~-33 minecraft:deepslate_tiles
fill ~13 ~37 ~-27 ~13 ~37 ~-26 minecraft:deepslate_tiles
fill ~13 ~38 ~-28 ~13 ~38 ~-27 minecraft:deepslate_tiles
fill ~13 ~39 ~-32 ~13 ~40 ~-32 minecraft:deepslate_tiles
fill ~13 ~39 ~-28 ~13 ~40 ~-28 minecraft:deepslate_tiles
fill ~13 ~40 ~-31 ~13 ~40 ~-28 minecraft:deepslate_tiles
fill ~13 ~41 ~-31 ~14 ~41 ~-31 minecraft:deepslate_tiles
fill ~13 ~41 ~-30 ~13 ~41 ~-29 minecraft:deepslate_tiles
fill ~14 ~32 ~-23 ~17 ~32 ~-23 minecraft:deepslate_tiles
fill ~14 ~36 ~-35 ~16 ~36 ~-34 minecraft:deepslate_tiles
fill ~14 ~36 ~-25 ~16 ~36 ~-25 minecraft:deepslate_tiles
fill ~14 ~37 ~-26 ~17 ~37 ~-26 minecraft:deepslate_tiles
fill ~14 ~38 ~-33 ~17 ~38 ~-33 minecraft:deepslate_tiles
fill ~14 ~38 ~-27 ~17 ~38 ~-27 minecraft:deepslate_tiles
fill ~14 ~39 ~-33 ~16 ~39 ~-33 minecraft:deepslate_tiles
fill ~14 ~39 ~-27 ~16 ~39 ~-27 minecraft:deepslate_tiles
fill ~14 ~40 ~-32 ~17 ~40 ~-32 minecraft:deepslate_tiles
fill ~14 ~40 ~-28 ~17 ~40 ~-28 minecraft:deepslate_tiles
fill ~14 ~41 ~-32 ~16 ~41 ~-32 minecraft:deepslate_tiles
fill ~14 ~41 ~-29 ~14 ~41 ~-28 minecraft:deepslate_tiles
fill ~14 ~42 ~-31 ~16 ~42 ~-31 minecraft:deepslate_tiles
fill ~14 ~42 ~-30 ~14 ~42 ~-29 minecraft:deepslate_tiles
fill ~14 ~43 ~-30 ~16 ~43 ~-30 minecraft:deepslate_tiles
fill ~15 ~38 ~-34 ~15 ~38 ~-33 minecraft:deepslate_tiles
setblock ~15 ~38 ~-26 minecraft:deepslate_tiles
fill ~15 ~40 ~-33 ~15 ~40 ~-32 minecraft:deepslate_tiles
setblock ~15 ~40 ~-27 minecraft:deepslate_tiles
fill ~15 ~41 ~-28 ~16 ~41 ~-28 minecraft:deepslate_tiles
fill ~15 ~42 ~-29 ~16 ~42 ~-29 minecraft:deepslate_tiles
fill ~15 ~43 ~-31 ~15 ~43 ~-29 minecraft:deepslate_tiles
fill ~16 ~34 ~-35 ~18 ~34 ~-35 minecraft:deepslate_tiles
fill ~16 ~34 ~-25 ~18 ~34 ~-25 minecraft:deepslate_tiles
fill ~16 ~41 ~-31 ~17 ~41 ~-31 minecraft:deepslate_tiles
fill ~16 ~41 ~-29 ~17 ~41 ~-29 minecraft:deepslate_tiles
fill ~16 ~42 ~-30 ~16 ~42 ~-29 minecraft:deepslate_tiles
fill ~17 ~32 ~-36 ~19 ~32 ~-36 minecraft:deepslate_tiles
fill ~17 ~37 ~-33 ~18 ~37 ~-33 minecraft:deepslate_tiles
fill ~17 ~37 ~-27 ~18 ~37 ~-27 minecraft:deepslate_tiles
fill ~17 ~38 ~-32 ~18 ~38 ~-32 minecraft:deepslate_tiles
fill ~17 ~38 ~-28 ~18 ~38 ~-28 minecraft:deepslate_tiles
fill ~17 ~39 ~-32 ~17 ~40 ~-32 minecraft:deepslate_tiles
fill ~17 ~40 ~-30 ~18 ~40 ~-30 minecraft:deepslate_tiles
fill ~17 ~40 ~-29 ~17 ~40 ~-28 minecraft:deepslate_tiles
fill ~17 ~41 ~-30 ~17 ~41 ~-29 minecraft:deepslate_tiles
fill ~18 ~31 ~-36 ~20 ~31 ~-36 minecraft:deepslate_tiles
fill ~18 ~31 ~-24 ~20 ~31 ~-24 minecraft:deepslate_tiles
fill ~18 ~32 ~-24 ~19 ~32 ~-24 minecraft:deepslate_tiles
fill ~18 ~33 ~-35 ~19 ~33 ~-35 minecraft:deepslate_tiles
fill ~18 ~33 ~-25 ~19 ~33 ~-25 minecraft:deepslate_tiles
fill ~18 ~35 ~-34 ~19 ~35 ~-34 minecraft:deepslate_tiles
fill ~18 ~35 ~-26 ~19 ~35 ~-26 minecraft:deepslate_tiles
fill ~18 ~36 ~-33 ~19 ~36 ~-33 minecraft:deepslate_tiles
fill ~18 ~36 ~-27 ~19 ~36 ~-27 minecraft:deepslate_tiles
fill ~18 ~37 ~-32 ~19 ~37 ~-32 minecraft:deepslate_tiles
fill ~18 ~37 ~-28 ~19 ~37 ~-28 minecraft:deepslate_tiles
fill ~18 ~38 ~-31 ~18 ~38 ~-28 minecraft:deepslate_tiles
fill ~18 ~39 ~-31 ~18 ~39 ~-29 minecraft:deepslate_tiles
fill ~19 ~32 ~-35 ~20 ~32 ~-35 minecraft:deepslate_tiles
fill ~19 ~32 ~-25 ~20 ~32 ~-25 minecraft:deepslate_tiles
fill ~19 ~33 ~-34 ~20 ~33 ~-34 minecraft:deepslate_tiles
fill ~19 ~33 ~-26 ~20 ~33 ~-26 minecraft:deepslate_tiles
fill ~19 ~34 ~-34 ~19 ~35 ~-34 minecraft:deepslate_tiles
fill ~19 ~34 ~-26 ~19 ~35 ~-26 minecraft:deepslate_tiles
fill ~19 ~35 ~-33 ~19 ~36 ~-33 minecraft:deepslate_tiles
fill ~19 ~35 ~-27 ~19 ~35 ~-26 minecraft:deepslate_tiles
fill ~19 ~36 ~-32 ~19 ~36 ~-27 minecraft:deepslate_tiles
fill ~19 ~37 ~-31 ~19 ~37 ~-28 minecraft:deepslate_tiles
setblock ~19 ~38 ~-30 minecraft:deepslate_tiles
fill ~20 ~31 ~-35 ~21 ~31 ~-35 minecraft:deepslate_tiles
fill ~20 ~31 ~-25 ~21 ~31 ~-25 minecraft:deepslate_tiles
fill ~20 ~32 ~-34 ~21 ~32 ~-34 minecraft:deepslate_tiles
fill ~20 ~32 ~-26 ~21 ~32 ~-26 minecraft:deepslate_tiles
fill ~20 ~33 ~-33 ~21 ~33 ~-33 minecraft:deepslate_tiles
fill ~20 ~33 ~-27 ~21 ~33 ~-27 minecraft:deepslate_tiles
fill ~20 ~34 ~-33 ~20 ~34 ~-31 minecraft:deepslate_tiles
fill ~20 ~34 ~-29 ~21 ~34 ~-28 minecraft:deepslate_tiles
setblock ~20 ~34 ~-27 minecraft:deepslate_tiles
fill ~20 ~35 ~-32 ~20 ~35 ~-28 minecraft:deepslate_tiles
fill ~20 ~36 ~-31 ~20 ~36 ~-29 minecraft:deepslate_tiles
fill ~21 ~31 ~-34 ~21 ~32 ~-33 minecraft:deepslate_tiles
fill ~21 ~31 ~-27 ~22 ~31 ~-27 minecraft:deepslate_tiles
fill ~21 ~31 ~-26 ~21 ~31 ~-25 minecraft:deepslate_tiles
fill ~21 ~32 ~-32 ~22 ~32 ~-32 minecraft:deepslate_tiles
fill ~21 ~32 ~-28 ~22 ~32 ~-28 minecraft:deepslate_tiles
fill ~21 ~32 ~-27 ~21 ~32 ~-26 minecraft:deepslate_tiles
fill ~21 ~33 ~-32 ~21 ~33 ~-27 minecraft:deepslate_tiles
fill ~21 ~34 ~-32 ~21 ~34 ~-28 minecraft:deepslate_tiles
fill ~21 ~53 ~-149 ~22 ~53 ~-149 minecraft:deepslate_tiles
fill ~21 ~53 ~-148 ~21 ~53 ~-143 minecraft:deepslate_tiles
fill ~21 ~53 ~-105 ~22 ~53 ~-105 minecraft:deepslate_tiles
fill ~21 ~53 ~-104 ~21 ~53 ~-99 minecraft:deepslate_tiles
fill ~21 ~54 ~-148 ~22 ~54 ~-147 minecraft:deepslate_tiles
fill ~21 ~54 ~-145 ~22 ~54 ~-144 minecraft:deepslate_tiles
fill ~21 ~54 ~-104 ~22 ~54 ~-103 minecraft:deepslate_tiles
fill ~21 ~54 ~-102 ~21 ~54 ~-100 minecraft:deepslate_tiles
fill ~22 ~31 ~-33 ~22 ~31 ~-27 minecraft:deepslate_tiles
fill ~22 ~32 ~-31 ~22 ~32 ~-28 minecraft:deepslate_tiles
fill ~22 ~53 ~-150 ~23 ~53 ~-150 minecraft:deepslate_tiles
fill ~22 ~53 ~-143 ~22 ~53 ~-142 minecraft:deepslate_tiles
fill ~22 ~53 ~-106 ~23 ~53 ~-106 minecraft:deepslate_tiles
fill ~22 ~53 ~-99 ~22 ~53 ~-98 minecraft:deepslate_tiles
fill ~22 ~54 ~-149 ~23 ~54 ~-149 minecraft:deepslate_tiles
fill ~22 ~54 ~-143 ~23 ~54 ~-143 minecraft:deepslate_tiles
fill ~22 ~54 ~-105 ~23 ~54 ~-105 minecraft:deepslate_tiles
fill ~22 ~54 ~-101 ~22 ~54 ~-99 minecraft:deepslate_tiles
fill ~22 ~55 ~-148 ~23 ~55 ~-148 minecraft:deepslate_tiles
fill ~22 ~55 ~-147 ~22 ~55 ~-144 minecraft:deepslate_tiles
fill ~22 ~55 ~-104 ~23 ~55 ~-104 minecraft:deepslate_tiles
fill ~22 ~55 ~-103 ~22 ~55 ~-100 minecraft:deepslate_tiles
fill ~22 ~56 ~-147 ~23 ~56 ~-147 minecraft:deepslate_tiles
fill ~22 ~56 ~-146 ~22 ~56 ~-145 minecraft:deepslate_tiles
fill ~22 ~56 ~-103 ~23 ~56 ~-103 minecraft:deepslate_tiles
fill ~22 ~56 ~-102 ~22 ~56 ~-101 minecraft:deepslate_tiles
fill ~23 ~53 ~-151 ~29 ~53 ~-151 minecraft:deepslate_tiles
fill ~23 ~53 ~-142 ~23 ~53 ~-141 minecraft:deepslate_tiles
fill ~23 ~53 ~-107 ~29 ~53 ~-107 minecraft:deepslate_tiles
fill ~23 ~53 ~-98 ~23 ~53 ~-97 minecraft:deepslate_tiles
fill ~23 ~54 ~-150 ~25 ~54 ~-150 minecraft:deepslate_tiles
fill ~23 ~54 ~-142 ~25 ~54 ~-142 minecraft:deepslate_tiles
fill ~23 ~54 ~-106 ~25 ~54 ~-106 minecraft:deepslate_tiles
fill ~23 ~54 ~-99 ~23 ~54 ~-98 minecraft:deepslate_tiles
fill ~23 ~55 ~-144 ~23 ~56 ~-143 minecraft:deepslate_tiles
fill ~23 ~55 ~-105 ~24 ~56 ~-105 minecraft:deepslate_tiles
fill ~23 ~55 ~-100 ~23 ~56 ~-99 minecraft:deepslate_tiles
fill ~23 ~56 ~-149 ~25 ~56 ~-149 minecraft:deepslate_tiles
fill ~23 ~56 ~-148 ~23 ~57 ~-147 minecraft:deepslate_tiles
fill ~23 ~56 ~-145 ~23 ~56 ~-143 minecraft:deepslate_tiles
fill ~23 ~56 ~-104 ~23 ~57 ~-103 minecraft:deepslate_tiles
fill ~23 ~56 ~-101 ~23 ~56 ~-99 minecraft:deepslate_tiles
fill ~23 ~57 ~-146 ~23 ~57 ~-144 minecraft:deepslate_tiles
fill ~23 ~57 ~-102 ~23 ~57 ~-100 minecraft:deepslate_tiles
fill ~23 ~58 ~-147 ~24 ~58 ~-145 minecraft:deepslate_tiles
fill ~23 ~58 ~-103 ~24 ~58 ~-101 minecraft:deepslate_tiles
fill ~24 ~53 ~-141 ~29 ~53 ~-141 minecraft:deepslate_tiles
fill ~24 ~53 ~-97 ~29 ~53 ~-97 minecraft:deepslate_tiles
fill ~24 ~54 ~-151 ~28 ~54 ~-151 minecraft:deepslate_tiles
fill ~24 ~54 ~-141 ~28 ~54 ~-141 minecraft:deepslate_tiles
fill ~24 ~54 ~-107 ~28 ~54 ~-107 minecraft:deepslate_tiles
fill ~24 ~54 ~-98 ~25 ~54 ~-97 minecraft:deepslate_tiles
fill ~24 ~55 ~-150 ~28 ~55 ~-150 minecraft:deepslate_tiles
fill ~24 ~55 ~-149 ~24 ~57 ~-149 minecraft:deepslate_tiles
fill ~24 ~55 ~-142 ~28 ~55 ~-142 minecraft:deepslate_tiles
fill ~24 ~55 ~-106 ~28 ~55 ~-106 minecraft:deepslate_tiles
fill ~24 ~55 ~-99 ~24 ~55 ~-98 minecraft:deepslate_tiles
fill ~24 ~56 ~-143 ~25 ~57 ~-143 minecraft:deepslate_tiles
fill ~24 ~56 ~-99 ~25 ~57 ~-99 minecraft:deepslate_tiles
fill ~24 ~57 ~-148 ~24 ~58 ~-148 minecraft:deepslate_tiles
fill ~24 ~57 ~-144 ~24 ~57 ~-143 minecraft:deepslate_tiles
fill ~24 ~57 ~-105 ~28 ~57 ~-105 minecraft:deepslate_tiles
fill ~24 ~57 ~-104 ~24 ~58 ~-104 minecraft:deepslate_tiles
fill ~24 ~57 ~-100 ~24 ~57 ~-99 minecraft:deepslate_tiles
fill ~24 ~58 ~-144 ~28 ~58 ~-144 minecraft:deepslate_tiles
fill ~24 ~58 ~-100 ~28 ~58 ~-100 minecraft:deepslate_tiles
fill ~24 ~59 ~-147 ~25 ~59 ~-147 minecraft:deepslate_tiles
fill ~24 ~59 ~-146 ~24 ~59 ~-145 minecraft:deepslate_tiles
fill ~24 ~59 ~-103 ~25 ~59 ~-103 minecraft:deepslate_tiles
fill ~24 ~59 ~-102 ~24 ~59 ~-101 minecraft:deepslate_tiles
fill ~24 ~60 ~-146 ~25 ~60 ~-146 minecraft:deepslate_tiles
fill ~24 ~60 ~-102 ~25 ~60 ~-102 minecraft:deepslate_tiles
fill ~25 ~55 ~-98 ~28 ~55 ~-98 minecraft:deepslate_tiles
fill ~25 ~56 ~-150 ~27 ~56 ~-150 minecraft:deepslate_tiles
fill ~25 ~56 ~-142 ~27 ~56 ~-142 minecraft:deepslate_tiles
fill ~25 ~56 ~-106 ~27 ~56 ~-106 minecraft:deepslate_tiles
fill ~25 ~56 ~-105 ~25 ~58 ~-105 minecraft:deepslate_tiles
fill ~25 ~56 ~-98 ~27 ~56 ~-98 minecraft:deepslate_tiles
fill ~25 ~57 ~-149 ~28 ~57 ~-149 minecraft:deepslate_tiles
fill ~25 ~58 ~-149 ~27 ~58 ~-148 minecraft:deepslate_tiles
fill ~25 ~58 ~-143 ~27 ~58 ~-143 minecraft:deepslate_tiles
fill ~25 ~58 ~-104 ~28 ~58 ~-104 minecraft:deepslate_tiles
fill ~25 ~58 ~-99 ~27 ~58 ~-99 minecraft:deepslate_tiles
fill ~25 ~59 ~-148 ~27 ~59 ~-148 minecraft:deepslate_tiles
fill ~25 ~59 ~-145 ~25 ~59 ~-144 minecraft:deepslate_tiles
fill ~25 ~59 ~-104 ~27 ~59 ~-104 minecraft:deepslate_tiles
fill ~25 ~59 ~-101 ~25 ~59 ~-100 minecraft:deepslate_tiles
fill ~25 ~60 ~-147 ~27 ~61 ~-147 minecraft:deepslate_tiles
fill ~25 ~60 ~-145 ~27 ~61 ~-145 minecraft:deepslate_tiles
fill ~25 ~60 ~-101 ~27 ~61 ~-101 minecraft:deepslate_tiles
fill ~25 ~61 ~-146 ~27 ~61 ~-145 minecraft:deepslate_tiles
fill ~25 ~61 ~-103 ~27 ~61 ~-101 minecraft:deepslate_tiles
fill ~26 ~54 ~-97 ~28 ~54 ~-97 minecraft:deepslate_tiles
fill ~26 ~57 ~-143 ~28 ~57 ~-143 minecraft:deepslate_tiles
fill ~26 ~57 ~-99 ~28 ~57 ~-99 minecraft:deepslate_tiles
fill ~26 ~58 ~-105 ~27 ~58 ~-104 minecraft:deepslate_tiles
fill ~26 ~59 ~-144 ~27 ~59 ~-144 minecraft:deepslate_tiles
fill ~26 ~59 ~-100 ~27 ~59 ~-100 minecraft:deepslate_tiles
fill ~26 ~60 ~-148 ~26 ~60 ~-147 minecraft:deepslate_tiles
setblock ~26 ~60 ~-144 minecraft:deepslate_tiles
fill ~26 ~60 ~-104 ~26 ~60 ~-103 minecraft:deepslate_tiles
setblock ~26 ~60 ~-100 minecraft:deepslate_tiles
fill ~26 ~62 ~-146 ~26 ~65 ~-146 minecraft:deepslate_tiles
fill ~26 ~62 ~-102 ~26 ~65 ~-102 minecraft:deepslate_tiles
fill ~27 ~54 ~-150 ~29 ~54 ~-150 minecraft:deepslate_tiles
fill ~27 ~54 ~-142 ~29 ~54 ~-142 minecraft:deepslate_tiles
fill ~27 ~54 ~-106 ~29 ~54 ~-106 minecraft:deepslate_tiles
fill ~27 ~54 ~-98 ~29 ~54 ~-98 minecraft:deepslate_tiles
fill ~27 ~56 ~-149 ~29 ~56 ~-149 minecraft:deepslate_tiles
fill ~27 ~56 ~-143 ~29 ~56 ~-143 minecraft:deepslate_tiles
fill ~27 ~56 ~-105 ~29 ~56 ~-105 minecraft:deepslate_tiles
fill ~27 ~56 ~-99 ~29 ~56 ~-99 minecraft:deepslate_tiles
fill ~27 ~59 ~-147 ~28 ~59 ~-147 minecraft:deepslate_tiles
fill ~27 ~59 ~-145 ~28 ~59 ~-145 minecraft:deepslate_tiles
fill ~27 ~59 ~-103 ~28 ~59 ~-103 minecraft:deepslate_tiles
fill ~27 ~59 ~-101 ~28 ~59 ~-101 minecraft:deepslate_tiles
fill ~27 ~60 ~-103 ~27 ~61 ~-101 minecraft:deepslate_tiles
fill ~28 ~55 ~-149 ~29 ~56 ~-149 minecraft:deepslate_tiles
fill ~28 ~55 ~-143 ~29 ~56 ~-143 minecraft:deepslate_tiles
fill ~28 ~55 ~-105 ~29 ~56 ~-105 minecraft:deepslate_tiles
fill ~28 ~55 ~-99 ~29 ~56 ~-99 minecraft:deepslate_tiles
fill ~28 ~57 ~-148 ~29 ~57 ~-148 minecraft:deepslate_tiles
fill ~28 ~57 ~-144 ~29 ~57 ~-144 minecraft:deepslate_tiles
fill ~28 ~57 ~-104 ~29 ~57 ~-104 minecraft:deepslate_tiles
fill ~28 ~57 ~-100 ~29 ~57 ~-100 minecraft:deepslate_tiles
fill ~28 ~58 ~-148 ~28 ~58 ~-144 minecraft:deepslate_tiles
fill ~28 ~58 ~-103 ~29 ~58 ~-101 minecraft:deepslate_tiles
fill ~28 ~59 ~-146 ~28 ~59 ~-145 minecraft:deepslate_tiles
fill ~28 ~59 ~-102 ~28 ~59 ~-101 minecraft:deepslate_tiles
setblock ~28 ~60 ~-146 minecraft:deepslate_tiles
setblock ~28 ~60 ~-102 minecraft:deepslate_tiles
fill ~29 ~53 ~-150 ~30 ~53 ~-150 minecraft:deepslate_tiles
fill ~29 ~53 ~-142 ~30 ~53 ~-142 minecraft:deepslate_tiles
fill ~29 ~53 ~-106 ~30 ~53 ~-106 minecraft:deepslate_tiles
fill ~29 ~53 ~-98 ~30 ~53 ~-98 minecraft:deepslate_tiles
fill ~29 ~54 ~-149 ~30 ~54 ~-149 minecraft:deepslate_tiles
fill ~29 ~54 ~-143 ~30 ~54 ~-143 minecraft:deepslate_tiles
fill ~29 ~54 ~-105 ~30 ~54 ~-105 minecraft:deepslate_tiles
fill ~29 ~54 ~-99 ~30 ~54 ~-99 minecraft:deepslate_tiles
fill ~29 ~55 ~-148 ~30 ~55 ~-148 minecraft:deepslate_tiles
fill ~29 ~55 ~-144 ~30 ~55 ~-144 minecraft:deepslate_tiles
fill ~29 ~55 ~-104 ~30 ~55 ~-104 minecraft:deepslate_tiles
fill ~29 ~55 ~-100 ~30 ~55 ~-100 minecraft:deepslate_tiles
fill ~29 ~56 ~-148 ~29 ~57 ~-147 minecraft:deepslate_tiles
fill ~29 ~56 ~-144 ~29 ~56 ~-143 minecraft:deepslate_tiles
fill ~29 ~56 ~-104 ~29 ~57 ~-103 minecraft:deepslate_tiles
fill ~29 ~56 ~-101 ~30 ~56 ~-101 minecraft:deepslate_tiles
fill ~29 ~56 ~-100 ~29 ~56 ~-99 minecraft:deepslate_tiles
fill ~29 ~57 ~-146 ~29 ~57 ~-144 minecraft:deepslate_tiles
fill ~29 ~57 ~-102 ~29 ~57 ~-100 minecraft:deepslate_tiles
fill ~29 ~58 ~-147 ~29 ~58 ~-145 minecraft:deepslate_tiles
fill ~30 ~53 ~-149 ~31 ~53 ~-149 minecraft:deepslate_tiles
fill ~30 ~53 ~-143 ~31 ~53 ~-143 minecraft:deepslate_tiles
fill ~30 ~53 ~-105 ~31 ~53 ~-105 minecraft:deepslate_tiles
fill ~30 ~53 ~-99 ~31 ~53 ~-99 minecraft:deepslate_tiles
fill ~30 ~54 ~-148 ~31 ~54 ~-147 minecraft:deepslate_tiles
fill ~30 ~54 ~-145 ~31 ~54 ~-144 minecraft:deepslate_tiles
fill ~30 ~54 ~-103 ~31 ~54 ~-103 minecraft:deepslate_tiles
fill ~30 ~54 ~-101 ~31 ~54 ~-100 minecraft:deepslate_tiles
fill ~30 ~55 ~-147 ~30 ~55 ~-144 minecraft:deepslate_tiles
fill ~30 ~55 ~-103 ~30 ~55 ~-100 minecraft:deepslate_tiles
fill ~30 ~56 ~-147 ~30 ~56 ~-145 minecraft:deepslate_tiles
fill ~30 ~56 ~-103 ~30 ~56 ~-101 minecraft:deepslate_tiles
fill ~31 ~-27 ~-127 ~35 ~-23 ~-127 minecraft:deepslate_tiles
fill ~31 ~-23 ~-129 ~35 ~-23 ~-127 minecraft:deepslate_tiles
fill ~31 ~53 ~-148 ~31 ~53 ~-143 minecraft:deepslate_tiles
fill ~31 ~53 ~-104 ~31 ~53 ~-99 minecraft:deepslate_tiles
fill ~31 ~54 ~-146 ~31 ~54 ~-144 minecraft:deepslate_tiles
fill ~31 ~54 ~-104 ~31 ~54 ~-100 minecraft:deepslate_tiles
fill ~32 ~-27 ~-129 ~35 ~-23 ~-127 minecraft:deepslate_tiles
fill ~33 ~-27 ~-126 ~35 ~-23 ~-69 minecraft:deepslate_tiles
fill ~54 ~31 ~-164 ~55 ~31 ~-164 minecraft:deepslate_tiles
fill ~54 ~31 ~-163 ~54 ~31 ~-156 minecraft:deepslate_tiles
fill ~54 ~31 ~-36 ~55 ~31 ~-36 minecraft:deepslate_tiles
fill ~54 ~31 ~-35 ~54 ~31 ~-28 minecraft:deepslate_tiles
fill ~54 ~32 ~-162 ~55 ~32 ~-162 minecraft:deepslate_tiles
fill ~54 ~32 ~-161 ~54 ~32 ~-158 minecraft:deepslate_tiles
fill ~54 ~32 ~-34 ~55 ~32 ~-34 minecraft:deepslate_tiles
fill ~54 ~32 ~-33 ~54 ~32 ~-30 minecraft:deepslate_tiles
fill ~55 ~31 ~-166 ~56 ~31 ~-166 minecraft:deepslate_tiles
fill ~55 ~31 ~-165 ~55 ~32 ~-164 minecraft:deepslate_tiles
fill ~55 ~31 ~-156 ~55 ~31 ~-154 minecraft:deepslate_tiles
fill ~55 ~31 ~-38 ~56 ~31 ~-38 minecraft:deepslate_tiles
fill ~55 ~31 ~-37 ~55 ~32 ~-36 minecraft:deepslate_tiles
fill ~55 ~31 ~-28 ~55 ~31 ~-26 minecraft:deepslate_tiles
fill ~55 ~32 ~-163 ~55 ~33 ~-162 minecraft:deepslate_tiles
fill ~55 ~32 ~-158 ~55 ~32 ~-155 minecraft:deepslate_tiles
fill ~55 ~32 ~-35 ~55 ~33 ~-34 minecraft:deepslate_tiles
fill ~55 ~32 ~-30 ~55 ~32 ~-27 minecraft:deepslate_tiles
fill ~55 ~33 ~-164 ~56 ~33 ~-164 minecraft:deepslate_tiles
fill ~55 ~33 ~-161 ~55 ~33 ~-156 minecraft:deepslate_tiles
fill ~55 ~33 ~-36 ~56 ~33 ~-36 minecraft:deepslate_tiles
fill ~55 ~33 ~-33 ~55 ~33 ~-28 minecraft:deepslate_tiles
fill ~55 ~34 ~-162 ~56 ~34 ~-161 minecraft:deepslate_tiles
fill ~55 ~34 ~-160 ~55 ~34 ~-158 minecraft:deepslate_tiles
fill ~55 ~34 ~-34 ~56 ~34 ~-33 minecraft:deepslate_tiles
fill ~55 ~34 ~-32 ~55 ~34 ~-30 minecraft:deepslate_tiles
fill ~56 ~31 ~-167 ~57 ~31 ~-167 minecraft:deepslate_tiles
fill ~56 ~31 ~-154 ~56 ~32 ~-154 minecraft:deepslate_tiles
fill ~56 ~31 ~-26 ~56 ~31 ~-25 minecraft:deepslate_tiles
fill ~56 ~32 ~-166 ~57 ~32 ~-166 minecraft:deepslate_tiles
fill ~56 ~32 ~-165 ~56 ~33 ~-165 minecraft:deepslate_tiles
fill ~56 ~32 ~-155 ~56 ~32 ~-154 minecraft:deepslate_tiles
fill ~56 ~32 ~-38 ~56 ~32 ~-37 minecraft:deepslate_tiles
fill ~56 ~32 ~-27 ~56 ~32 ~-26 minecraft:deepslate_tiles
fill ~56 ~33 ~-156 ~56 ~33 ~-155 minecraft:deepslate_tiles
fill ~56 ~33 ~-37 ~57 ~33 ~-37 minecraft:deepslate_tiles
fill ~56 ~33 ~-28 ~56 ~33 ~-27 minecraft:deepslate_tiles
fill ~56 ~34 ~-164 ~57 ~34 ~-164 minecraft:deepslate_tiles
fill ~56 ~34 ~-163 ~56 ~35 ~-161 minecraft:deepslate_tiles
fill ~56 ~34 ~-159 ~56 ~34 ~-156 minecraft:deepslate_tiles
fill ~56 ~34 ~-35 ~56 ~35 ~-33 minecraft:deepslate_tiles
fill ~56 ~34 ~-31 ~56 ~34 ~-28 minecraft:deepslate_tiles
fill ~56 ~35 ~-160 ~56 ~35 ~-157 minecraft:deepslate_tiles
fill ~56 ~35 ~-32 ~56 ~35 ~-29 minecraft:deepslate_tiles
fill ~56 ~36 ~-161 ~57 ~36 ~-159 minecraft:deepslate_tiles
fill ~56 ~36 ~-33 ~57 ~36 ~-31 minecraft:deepslate_tiles
fill ~57 ~31 ~-168 ~58 ~31 ~-168 minecraft:deepslate_tiles
fill ~57 ~31 ~-25 ~57 ~31 ~-24 minecraft:deepslate_tiles
fill ~57 ~32 ~-167 ~58 ~32 ~-167 minecraft:deepslate_tiles
fill ~57 ~32 ~-26 ~57 ~32 ~-25 minecraft:deepslate_tiles
fill ~57 ~33 ~-166 ~57 ~34 ~-165 minecraft:deepslate_tiles
fill ~57 ~33 ~-155 ~57 ~34 ~-154 minecraft:deepslate_tiles
fill ~57 ~33 ~-38 ~57 ~34 ~-37 minecraft:deepslate_tiles
fill ~57 ~33 ~-27 ~57 ~34 ~-26 minecraft:deepslate_tiles
fill ~57 ~34 ~-156 ~57 ~34 ~-154 minecraft:deepslate_tiles
fill ~57 ~34 ~-36 ~57 ~36 ~-36 minecraft:deepslate_tiles
fill ~57 ~34 ~-28 ~57 ~34 ~-26 minecraft:deepslate_tiles
fill ~57 ~35 ~-165 ~58 ~35 ~-165 minecraft:deepslate_tiles
fill ~57 ~35 ~-164 ~57 ~36 ~-163 minecraft:deepslate_tiles
fill ~57 ~35 ~-157 ~57 ~35 ~-155 minecraft:deepslate_tiles
fill ~57 ~35 ~-37 ~58 ~35 ~-37 minecraft:deepslate_tiles
fill ~57 ~35 ~-35 ~57 ~37 ~-35 minecraft:deepslate_tiles
fill ~57 ~35 ~-29 ~57 ~35 ~-27 minecraft:deepslate_tiles
fill ~57 ~36 ~-162 ~57 ~36 ~-156 minecraft:deepslate_tiles
fill ~57 ~36 ~-34 ~57 ~36 ~-28 minecraft:deepslate_tiles
fill ~57 ~37 ~-163 ~58 ~37 ~-163 minecraft:deepslate_tiles
fill ~57 ~37 ~-162 ~57 ~37 ~-157 minecraft:deepslate_tiles
fill ~57 ~37 ~-34 ~57 ~37 ~-29 minecraft:deepslate_tiles
fill ~57 ~38 ~-161 ~58 ~38 ~-159 minecraft:deepslate_tiles
fill ~57 ~38 ~-33 ~58 ~38 ~-31 minecraft:deepslate_tiles
fill ~58 ~27 ~-99 ~59 ~27 ~-99 minecraft:deepslate_tiles
fill ~58 ~27 ~-98 ~58 ~28 ~-98 minecraft:deepslate_tiles
fill ~58 ~27 ~-94 ~58 ~27 ~-93 minecraft:deepslate_tiles
fill ~58 ~28 ~-94 ~59 ~28 ~-94 minecraft:deepslate_tiles
fill ~58 ~31 ~-169 ~60 ~31 ~-169 minecraft:deepslate_tiles
fill ~58 ~31 ~-152 ~58 ~31 ~-151 minecraft:deepslate_tiles
fill ~58 ~31 ~-41 ~60 ~31 ~-41 minecraft:deepslate_tiles
fill ~58 ~31 ~-40 ~58 ~32 ~-40 minecraft:deepslate_tiles
fill ~58 ~31 ~-24 ~58 ~31 ~-23 minecraft:deepslate_tiles
fill ~58 ~32 ~-168 ~59 ~32 ~-168 minecraft:deepslate_tiles
fill ~58 ~32 ~-25 ~58 ~32 ~-24 minecraft:deepslate_tiles
fill ~58 ~33 ~-167 ~59 ~34 ~-167 minecraft:deepslate_tiles
fill ~58 ~33 ~-153 ~59 ~34 ~-153 minecraft:deepslate_tiles
fill ~58 ~33 ~-39 ~59 ~34 ~-39 minecraft:deepslate_tiles
fill ~58 ~33 ~-25 ~59 ~34 ~-25 minecraft:deepslate_tiles
fill ~58 ~34 ~-166 ~58 ~35 ~-166 minecraft:deepslate_tiles
fill ~58 ~34 ~-154 ~58 ~34 ~-153 minecraft:deepslate_tiles
fill ~58 ~34 ~-38 ~58 ~35 ~-38 minecraft:deepslate_tiles
fill ~58 ~34 ~-26 ~58 ~34 ~-25 minecraft:deepslate_tiles
fill ~58 ~35 ~-155 ~58 ~35 ~-154 minecraft:deepslate_tiles
fill ~58 ~35 ~-26 ~59 ~35 ~-26 minecraft:deepslate_tiles
fill ~58 ~36 ~-165 ~59 ~36 ~-165 minecraft:deepslate_tiles
fill ~58 ~36 ~-164 ~58 ~37 ~-164 minecraft:deepslate_tiles
fill ~58 ~36 ~-156 ~58 ~36 ~-155 minecraft:deepslate_tiles
fill ~58 ~36 ~-37 ~59 ~36 ~-37 minecraft:deepslate_tiles
fill ~58 ~36 ~-36 ~58 ~37 ~-36 minecraft:deepslate_tiles
fill ~58 ~36 ~-28 ~58 ~36 ~-27 minecraft:deepslate_tiles
fill ~58 ~37 ~-157 ~58 ~37 ~-156 minecraft:deepslate_tiles
fill ~58 ~37 ~-35 ~58 ~38 ~-35 minecraft:deepslate_tiles
fill ~58 ~37 ~-29 ~58 ~37 ~-28 minecraft:deepslate_tiles
fill ~58 ~38 ~-163 ~59 ~38 ~-163 minecraft:deepslate_tiles
fill ~58 ~38 ~-162 ~58 ~38 ~-157 minecraft:deepslate_tiles
fill ~58 ~38 ~-34 ~58 ~38 ~-29 minecraft:deepslate_tiles
fill ~58 ~39 ~-162 ~59 ~39 ~-162 minecraft:deepslate_tiles
fill ~58 ~39 ~-161 ~58 ~39 ~-158 minecraft:deepslate_tiles
fill ~58 ~39 ~-34 ~59 ~39 ~-34 minecraft:deepslate_tiles
fill ~58 ~39 ~-33 ~58 ~39 ~-30 minecraft:deepslate_tiles
fill ~58 ~40 ~-160 ~59 ~40 ~-160 minecraft:deepslate_tiles
fill ~58 ~40 ~-32 ~59 ~40 ~-32 minecraft:deepslate_tiles
fill ~59 ~27 ~-100 ~59 ~28 ~-99 minecraft:deepslate_tiles
fill ~59 ~27 ~-93 ~59 ~28 ~-92 minecraft:deepslate_tiles
fill ~59 ~28 ~-98 ~59 ~29 ~-98 minecraft:deepslate_tiles
fill ~59 ~29 ~-99 ~60 ~29 ~-99 minecraft:deepslate_tiles
fill ~59 ~29 ~-97 ~59 ~29 ~-93 minecraft:deepslate_tiles
fill ~59 ~30 ~-97 ~60 ~30 ~-97 minecraft:deepslate_tiles
fill ~59 ~30 ~-96 ~59 ~30 ~-95 minecraft:deepslate_tiles
fill ~59 ~31 ~-151 ~60 ~32 ~-151 minecraft:deepslate_tiles
fill ~59 ~31 ~-23 ~60 ~32 ~-23 minecraft:deepslate_tiles
fill ~59 ~32 ~-169 ~62 ~32 ~-169 minecraft:deepslate_tiles
fill ~59 ~32 ~-152 ~59 ~32 ~-151 minecraft:deepslate_tiles
fill ~59 ~32 ~-41 ~62 ~32 ~-41 minecraft:deepslate_tiles
fill ~59 ~32 ~-40 ~59 ~33 ~-40 minecraft:deepslate_tiles
fill ~59 ~32 ~-24 ~59 ~32 ~-23 minecraft:deepslate_tiles
fill ~59 ~33 ~-168 ~60 ~33 ~-168 minecraft:deepslate_tiles
fill ~59 ~33 ~-152 ~60 ~33 ~-152 minecraft:deepslate_tiles
fill ~59 ~33 ~-24 ~60 ~33 ~-24 minecraft:deepslate_tiles
fill ~59 ~35 ~-167 ~61 ~35 ~-167 minecraft:deepslate_tiles
fill ~59 ~35 ~-166 ~59 ~36 ~-166 minecraft:deepslate_tiles
fill ~59 ~35 ~-154 ~59 ~35 ~-153 minecraft:deepslate_tiles
fill ~59 ~35 ~-39 ~61 ~35 ~-39 minecraft:deepslate_tiles
fill ~59 ~35 ~-38 ~59 ~36 ~-38 minecraft:deepslate_tiles
fill ~59 ~35 ~-25 ~61 ~35 ~-25 minecraft:deepslate_tiles
fill ~59 ~36 ~-155 ~59 ~36 ~-154 minecraft:deepslate_tiles
fill ~59 ~36 ~-27 ~59 ~36 ~-26 minecraft:deepslate_tiles
fill ~59 ~37 ~-165 ~60 ~38 ~-165 minecraft:deepslate_tiles
fill ~59 ~37 ~-164 ~59 ~39 ~-164 minecraft:deepslate_tiles
fill ~59 ~37 ~-156 ~59 ~38 ~-155 minecraft:deepslate_tiles
fill ~59 ~37 ~-37 ~60 ~38 ~-37 minecraft:deepslate_tiles
fill ~59 ~37 ~-36 ~59 ~39 ~-36 minecraft:deepslate_tiles
fill ~59 ~37 ~-28 ~59 ~38 ~-27 minecraft:deepslate_tiles
fill ~59 ~38 ~-157 ~59 ~38 ~-155 minecraft:deepslate_tiles
fill ~59 ~38 ~-35 ~59 ~40 ~-35 minecraft:deepslate_tiles
fill ~59 ~38 ~-29 ~59 ~38 ~-27 minecraft:deepslate_tiles
fill ~59 ~39 ~-163 ~59 ~40 ~-162 minecraft:deepslate_tiles
fill ~59 ~39 ~-158 ~59 ~39 ~-156 minecraft:deepslate_tiles
fill ~59 ~39 ~-30 ~59 ~39 ~-28 minecraft:deepslate_tiles
fill ~59 ~40 ~-161 ~59 ~40 ~-157 minecraft:deepslate_tiles
fill ~59 ~40 ~-34 ~59 ~40 ~-29 minecraft:deepslate_tiles
fill ~59 ~41 ~-162 ~60 ~41 ~-162 minecraft:deepslate_tiles
fill ~59 ~41 ~-161 ~59 ~41 ~-158 minecraft:deepslate_tiles
fill ~59 ~41 ~-34 ~60 ~41 ~-34 minecraft:deepslate_tiles
fill ~59 ~41 ~-33 ~59 ~41 ~-30 minecraft:deepslate_tiles
fill ~60 ~27 ~-101 ~61 ~28 ~-101 minecraft:deepslate_tiles
fill ~60 ~27 ~-91 ~61 ~28 ~-91 minecraft:deepslate_tiles
fill ~60 ~28 ~-100 ~60 ~29 ~-100 minecraft:deepslate_tiles
fill ~60 ~28 ~-92 ~60 ~28 ~-91 minecraft:deepslate_tiles
fill ~60 ~29 ~-93 ~60 ~29 ~-92 minecraft:deepslate_tiles
fill ~60 ~30 ~-99 ~61 ~30 ~-99 minecraft:deepslate_tiles
fill ~60 ~30 ~-98 ~60 ~31 ~-97 minecraft:deepslate_tiles
fill ~60 ~30 ~-95 ~60 ~30 ~-93 minecraft:deepslate_tiles
fill ~60 ~31 ~-170 ~68 ~31 ~-170 minecraft:deepslate_tiles
fill ~60 ~31 ~-150 ~68 ~31 ~-150 minecraft:deepslate_tiles
fill ~60 ~31 ~-96 ~60 ~31 ~-94 minecraft:deepslate_tiles
fill ~60 ~31 ~-42 ~68 ~31 ~-42 minecraft:deepslate_tiles
fill ~60 ~31 ~-22 ~68 ~31 ~-22 minecraft:deepslate_tiles
fill ~60 ~32 ~-97 ~61 ~32 ~-95 minecraft:deepslate_tiles
fill ~60 ~33 ~-169 ~68 ~33 ~-169 minecraft:deepslate_tiles
fill ~60 ~33 ~-151 ~68 ~33 ~-151 minecraft:deepslate_tiles
fill ~60 ~33 ~-41 ~68 ~33 ~-41 minecraft:deepslate_tiles
fill ~60 ~33 ~-40 ~60 ~34 ~-40 minecraft:deepslate_tiles
fill ~60 ~33 ~-23 ~68 ~33 ~-23 minecraft:deepslate_tiles
fill ~60 ~34 ~-168 ~63 ~34 ~-168 minecraft:deepslate_tiles
fill ~60 ~34 ~-167 ~60 ~36 ~-167 minecraft:deepslate_tiles
fill ~60 ~34 ~-153 ~60 ~34 ~-152 minecraft:deepslate_tiles
fill ~60 ~34 ~-39 ~60 ~36 ~-39 minecraft:deepslate_tiles
fill ~60 ~34 ~-25 ~60 ~34 ~-24 minecraft:deepslate_tiles
fill ~60 ~35 ~-153 ~61 ~36 ~-153 minecraft:deepslate_tiles
fill ~60 ~36 ~-166 ~60 ~37 ~-166 minecraft:deepslate_tiles
fill ~60 ~36 ~-154 ~60 ~36 ~-153 minecraft:deepslate_tiles
fill ~60 ~36 ~-38 ~60 ~37 ~-38 minecraft:deepslate_tiles
fill ~60 ~36 ~-26 ~60 ~36 ~-25 minecraft:deepslate_tiles
fill ~60 ~37 ~-155 ~60 ~37 ~-154 minecraft:deepslate_tiles
fill ~60 ~37 ~-27 ~60 ~37 ~-26 minecraft:deepslate_tiles
fill ~60 ~38 ~-155 ~61 ~39 ~-155 minecraft:deepslate_tiles
fill ~60 ~38 ~-27 ~61 ~39 ~-27 minecraft:deepslate_tiles
fill ~60 ~39 ~-165 ~62 ~39 ~-165 minecraft:deepslate_tiles
fill ~60 ~39 ~-164 ~60 ~40 ~-164 minecraft:deepslate_tiles
fill ~60 ~39 ~-156 ~60 ~39 ~-155 minecraft:deepslate_tiles
fill ~60 ~39 ~-37 ~62 ~39 ~-37 minecraft:deepslate_tiles
fill ~60 ~39 ~-36 ~60 ~40 ~-36 minecraft:deepslate_tiles
fill ~60 ~39 ~-28 ~60 ~39 ~-27 minecraft:deepslate_tiles
fill ~60 ~40 ~-163 ~60 ~41 ~-163 minecraft:deepslate_tiles
fill ~60 ~40 ~-157 ~60 ~40 ~-156 minecraft:deepslate_tiles
fill ~60 ~40 ~-35 ~60 ~41 ~-35 minecraft:deepslate_tiles
fill ~60 ~40 ~-29 ~60 ~40 ~-28 minecraft:deepslate_tiles
fill ~60 ~41 ~-158 ~60 ~41 ~-157 minecraft:deepslate_tiles
fill ~60 ~41 ~-29 ~61 ~41 ~-29 minecraft:deepslate_tiles
fill ~60 ~42 ~-162 ~60 ~42 ~-158 minecraft:deepslate_tiles
fill ~60 ~42 ~-34 ~60 ~42 ~-30 minecraft:deepslate_tiles
fill ~60 ~43 ~-161 ~61 ~43 ~-161 minecraft:deepslate_tiles
fill ~60 ~43 ~-160 ~60 ~43 ~-159 minecraft:deepslate_tiles
fill ~60 ~43 ~-33 ~61 ~43 ~-33 minecraft:deepslate_tiles
fill ~60 ~43 ~-32 ~60 ~43 ~-31 minecraft:deepslate_tiles
fill ~61 ~27 ~-102 ~67 ~27 ~-102 minecraft:deepslate_tiles
fill ~61 ~27 ~-90 ~67 ~27 ~-90 minecraft:deepslate_tiles
fill ~61 ~29 ~-101 ~67 ~29 ~-101 minecraft:deepslate_tiles
fill ~61 ~29 ~-100 ~61 ~30 ~-100 minecraft:deepslate_tiles
fill ~61 ~29 ~-92 ~61 ~29 ~-91 minecraft:deepslate_tiles
fill ~61 ~30 ~-93 ~61 ~30 ~-92 minecraft:deepslate_tiles
fill ~61 ~31 ~-99 ~62 ~31 ~-99 minecraft:deepslate_tiles
fill ~61 ~31 ~-98 ~61 ~33 ~-98 minecraft:deepslate_tiles
fill ~61 ~31 ~-94 ~61 ~31 ~-93 minecraft:deepslate_tiles
fill ~61 ~32 ~-151 ~62 ~33 ~-151 minecraft:deepslate_tiles
fill ~61 ~32 ~-94 ~61 ~33 ~-94 minecraft:deepslate_tiles
fill ~61 ~32 ~-23 ~62 ~33 ~-23 minecraft:deepslate_tiles
fill ~61 ~33 ~-97 ~61 ~33 ~-94 minecraft:deepslate_tiles
fill ~61 ~34 ~-152 ~63 ~35 ~-152 minecraft:deepslate_tiles
fill ~61 ~34 ~-96 ~62 ~34 ~-96 minecraft:deepslate_tiles
fill ~61 ~34 ~-40 ~63 ~35 ~-40 minecraft:deepslate_tiles
fill ~61 ~34 ~-24 ~63 ~35 ~-24 minecraft:deepslate_tiles
fill ~61 ~35 ~-168 ~67 ~35 ~-168 minecraft:deepslate_tiles
fill ~61 ~36 ~-167 ~68 ~36 ~-167 minecraft:deepslate_tiles
fill ~61 ~36 ~-39 ~68 ~36 ~-39 minecraft:deepslate_tiles
fill ~61 ~36 ~-25 ~68 ~36 ~-25 minecraft:deepslate_tiles
fill ~61 ~37 ~-166 ~61 ~38 ~-166 minecraft:deepslate_tiles
fill ~61 ~37 ~-154 ~61 ~37 ~-153 minecraft:deepslate_tiles
fill ~61 ~37 ~-39 ~67 ~37 ~-39 minecraft:deepslate_tiles
fill ~61 ~37 ~-38 ~61 ~38 ~-38 minecraft:deepslate_tiles
fill ~61 ~37 ~-26 ~61 ~37 ~-25 minecraft:deepslate_tiles
fill ~61 ~38 ~-165 ~61 ~40 ~-165 minecraft:deepslate_tiles
fill ~61 ~38 ~-154 ~67 ~38 ~-154 minecraft:deepslate_tiles
fill ~61 ~38 ~-37 ~61 ~40 ~-37 minecraft:deepslate_tiles
fill ~61 ~38 ~-26 ~67 ~38 ~-26 minecraft:deepslate_tiles
fill ~61 ~40 ~-164 ~61 ~41 ~-164 minecraft:deepslate_tiles
fill ~61 ~40 ~-156 ~61 ~40 ~-155 minecraft:deepslate_tiles
fill ~61 ~40 ~-36 ~61 ~41 ~-36 minecraft:deepslate_tiles
fill ~61 ~40 ~-28 ~61 ~40 ~-27 minecraft:deepslate_tiles
fill ~61 ~41 ~-163 ~61 ~43 ~-163 minecraft:deepslate_tiles
fill ~61 ~41 ~-157 ~61 ~41 ~-156 minecraft:deepslate_tiles
fill ~61 ~41 ~-35 ~61 ~43 ~-35 minecraft:deepslate_tiles
fill ~61 ~41 ~-28 ~62 ~41 ~-28 minecraft:deepslate_tiles
fill ~61 ~42 ~-157 ~61 ~43 ~-157 minecraft:deepslate_tiles
fill ~61 ~42 ~-29 ~61 ~43 ~-29 minecraft:deepslate_tiles
fill ~61 ~43 ~-162 ~61 ~44 ~-161 minecraft:deepslate_tiles
fill ~61 ~43 ~-159 ~61 ~43 ~-157 minecraft:deepslate_tiles
fill ~61 ~43 ~-34 ~61 ~44 ~-33 minecraft:deepslate_tiles
fill ~61 ~43 ~-31 ~61 ~43 ~-29 minecraft:deepslate_tiles
fill ~61 ~44 ~-160 ~61 ~44 ~-158 minecraft:deepslate_tiles
fill ~61 ~44 ~-32 ~61 ~44 ~-30 minecraft:deepslate_tiles
fill ~61 ~45 ~-161 ~62 ~45 ~-159 minecraft:deepslate_tiles
fill ~61 ~45 ~-33 ~62 ~45 ~-31 minecraft:deepslate_tiles
fill ~62 ~28 ~-102 ~66 ~28 ~-102 minecraft:deepslate_tiles
fill ~62 ~28 ~-101 ~62 ~29 ~-101 minecraft:deepslate_tiles
fill ~62 ~28 ~-91 ~62 ~28 ~-90 minecraft:deepslate_tiles
fill ~62 ~29 ~-91 ~67 ~29 ~-91 minecraft:deepslate_tiles
fill ~62 ~30 ~-100 ~63 ~31 ~-100 minecraft:deepslate_tiles
fill ~62 ~30 ~-92 ~63 ~31 ~-92 minecraft:deepslate_tiles
fill ~62 ~31 ~-93 ~62 ~31 ~-92 minecraft:deepslate_tiles
fill ~62 ~32 ~-170 ~66 ~32 ~-170 minecraft:deepslate_tiles
fill ~62 ~32 ~-150 ~66 ~32 ~-150 minecraft:deepslate_tiles
fill ~62 ~32 ~-99 ~66 ~33 ~-99 minecraft:deepslate_tiles
fill ~62 ~32 ~-93 ~66 ~33 ~-93 minecraft:deepslate_tiles
fill ~62 ~32 ~-42 ~66 ~32 ~-42 minecraft:deepslate_tiles
fill ~62 ~32 ~-22 ~66 ~32 ~-22 minecraft:deepslate_tiles
fill ~62 ~33 ~-98 ~62 ~34 ~-98 minecraft:deepslate_tiles
fill ~62 ~33 ~-94 ~62 ~33 ~-93 minecraft:deepslate_tiles
fill ~62 ~34 ~-169 ~66 ~34 ~-169 minecraft:deepslate_tiles
fill ~62 ~34 ~-151 ~66 ~34 ~-151 minecraft:deepslate_tiles
fill ~62 ~34 ~-97 ~62 ~34 ~-94 minecraft:deepslate_tiles
fill ~62 ~34 ~-41 ~66 ~34 ~-41 minecraft:deepslate_tiles
fill ~62 ~34 ~-23 ~66 ~34 ~-23 minecraft:deepslate_tiles
fill ~62 ~35 ~-97 ~63 ~35 ~-97 minecraft:deepslate_tiles
fill ~62 ~35 ~-96 ~62 ~35 ~-95 minecraft:deepslate_tiles
fill ~62 ~36 ~-153 ~68 ~36 ~-153 minecraft:deepslate_tiles
fill ~62 ~37 ~-167 ~67 ~37 ~-167 minecraft:deepslate_tiles
fill ~62 ~37 ~-153 ~67 ~37 ~-153 minecraft:deepslate_tiles
fill ~62 ~37 ~-25 ~67 ~37 ~-25 minecraft:deepslate_tiles
fill ~62 ~38 ~-166 ~67 ~38 ~-166 minecraft:deepslate_tiles
fill ~62 ~38 ~-38 ~67 ~38 ~-38 minecraft:deepslate_tiles
fill ~62 ~39 ~-166 ~66 ~39 ~-166 minecraft:deepslate_tiles
fill ~62 ~39 ~-155 ~62 ~39 ~-154 minecraft:deepslate_tiles
fill ~62 ~39 ~-38 ~66 ~39 ~-38 minecraft:deepslate_tiles
fill ~62 ~39 ~-27 ~62 ~39 ~-26 minecraft:deepslate_tiles
fill ~62 ~40 ~-155 ~67 ~40 ~-155 minecraft:deepslate_tiles
fill ~62 ~40 ~-37 ~67 ~40 ~-37 minecraft:deepslate_tiles
fill ~62 ~40 ~-27 ~67 ~40 ~-27 minecraft:deepslate_tiles
fill ~62 ~41 ~-165 ~66 ~41 ~-165 minecraft:deepslate_tiles
fill ~62 ~41 ~-164 ~62 ~42 ~-164 minecraft:deepslate_tiles
fill ~62 ~41 ~-156 ~62 ~41 ~-155 minecraft:deepslate_tiles
fill ~62 ~41 ~-37 ~66 ~41 ~-37 minecraft:deepslate_tiles
fill ~62 ~41 ~-36 ~62 ~42 ~-36 minecraft:deepslate_tiles
fill ~62 ~41 ~-27 ~66 ~41 ~-27 minecraft:deepslate_tiles
fill ~62 ~42 ~-156 ~66 ~42 ~-156 minecraft:deepslate_tiles
fill ~62 ~42 ~-28 ~66 ~42 ~-28 minecraft:deepslate_tiles
fill ~62 ~43 ~-163 ~63 ~44 ~-163 minecraft:deepslate_tiles
fill ~62 ~43 ~-157 ~63 ~44 ~-157 minecraft:deepslate_tiles
fill ~62 ~43 ~-35 ~63 ~44 ~-35 minecraft:deepslate_tiles
fill ~62 ~43 ~-29 ~63 ~44 ~-29 minecraft:deepslate_tiles
fill ~62 ~44 ~-158 ~62 ~44 ~-157 minecraft:deepslate_tiles
fill ~62 ~44 ~-34 ~62 ~45 ~-34 minecraft:deepslate_tiles
fill ~62 ~44 ~-30 ~62 ~44 ~-29 minecraft:deepslate_tiles
fill ~62 ~45 ~-162 ~66 ~45 ~-162 minecraft:deepslate_tiles
fill ~62 ~45 ~-158 ~66 ~45 ~-158 minecraft:deepslate_tiles
fill ~62 ~45 ~-30 ~66 ~45 ~-30 minecraft:deepslate_tiles
fill ~62 ~46 ~-161 ~63 ~46 ~-161 minecraft:deepslate_tiles
fill ~62 ~46 ~-160 ~62 ~46 ~-159 minecraft:deepslate_tiles
fill ~62 ~46 ~-33 ~63 ~46 ~-33 minecraft:deepslate_tiles
fill ~62 ~46 ~-32 ~62 ~46 ~-31 minecraft:deepslate_tiles
fill ~62 ~47 ~-160 ~63 ~47 ~-160 minecraft:deepslate_tiles
fill ~62 ~47 ~-32 ~63 ~47 ~-32 minecraft:deepslate_tiles
fill ~63 ~28 ~-90 ~66 ~28 ~-90 minecraft:deepslate_tiles
fill ~63 ~30 ~-101 ~65 ~30 ~-101 minecraft:deepslate_tiles
fill ~63 ~30 ~-91 ~65 ~30 ~-91 minecraft:deepslate_tiles
fill ~63 ~32 ~-100 ~65 ~32 ~-99 minecraft:deepslate_tiles
fill ~63 ~32 ~-92 ~65 ~32 ~-92 minecraft:deepslate_tiles
fill ~63 ~34 ~-98 ~66 ~34 ~-98 minecraft:deepslate_tiles
fill ~63 ~34 ~-94 ~66 ~34 ~-94 minecraft:deepslate_tiles
fill ~63 ~35 ~-98 ~65 ~35 ~-98 minecraft:deepslate_tiles
fill ~63 ~35 ~-95 ~63 ~35 ~-94 minecraft:deepslate_tiles
fill ~63 ~36 ~-168 ~65 ~36 ~-167 minecraft:deepslate_tiles
fill ~63 ~36 ~-152 ~65 ~36 ~-152 minecraft:deepslate_tiles
fill ~63 ~36 ~-97 ~65 ~37 ~-97 minecraft:deepslate_tiles
fill ~63 ~36 ~-96 ~63 ~37 ~-95 minecraft:deepslate_tiles
fill ~63 ~36 ~-40 ~65 ~36 ~-39 minecraft:deepslate_tiles
fill ~63 ~36 ~-24 ~65 ~36 ~-24 minecraft:deepslate_tiles
fill ~63 ~38 ~-167 ~65 ~38 ~-166 minecraft:deepslate_tiles
fill ~63 ~38 ~-153 ~65 ~38 ~-153 minecraft:deepslate_tiles
fill ~63 ~38 ~-39 ~65 ~38 ~-38 minecraft:deepslate_tiles
fill ~63 ~38 ~-25 ~65 ~38 ~-25 minecraft:deepslate_tiles
fill ~63 ~39 ~-26 ~66 ~39 ~-26 minecraft:deepslate_tiles
fill ~63 ~40 ~-165 ~67 ~40 ~-165 minecraft:deepslate_tiles
fill ~63 ~41 ~-155 ~66 ~41 ~-155 minecraft:deepslate_tiles
fill ~63 ~42 ~-164 ~66 ~42 ~-164 minecraft:deepslate_tiles
fill ~63 ~42 ~-36 ~66 ~42 ~-36 minecraft:deepslate_tiles
fill ~63 ~43 ~-164 ~65 ~43 ~-164 minecraft:deepslate_tiles
fill ~63 ~43 ~-156 ~65 ~43 ~-156 minecraft:deepslate_tiles
fill ~63 ~43 ~-36 ~65 ~43 ~-36 minecraft:deepslate_tiles
fill ~63 ~43 ~-28 ~65 ~43 ~-28 minecraft:deepslate_tiles
fill ~63 ~45 ~-163 ~65 ~45 ~-162 minecraft:deepslate_tiles
fill ~63 ~45 ~-157 ~65 ~45 ~-157 minecraft:deepslate_tiles
fill ~63 ~45 ~-35 ~65 ~45 ~-34 minecraft:deepslate_tiles
fill ~63 ~45 ~-29 ~65 ~45 ~-29 minecraft:deepslate_tiles
fill ~63 ~46 ~-162 ~65 ~46 ~-162 minecraft:deepslate_tiles
fill ~63 ~46 ~-159 ~63 ~46 ~-158 minecraft:deepslate_tiles
fill ~63 ~46 ~-31 ~63 ~46 ~-30 minecraft:deepslate_tiles
fill ~63 ~47 ~-161 ~65 ~48 ~-161 minecraft:deepslate_tiles
fill ~63 ~47 ~-159 ~65 ~48 ~-159 minecraft:deepslate_tiles
fill ~63 ~47 ~-33 ~65 ~48 ~-33 minecraft:deepslate_tiles
fill ~63 ~47 ~-31 ~65 ~48 ~-31 minecraft:deepslate_tiles
fill ~63 ~48 ~-160 ~65 ~48 ~-159 minecraft:deepslate_tiles
fill ~63 ~48 ~-32 ~65 ~48 ~-31 minecraft:deepslate_tiles
fill ~64 ~31 ~-100 ~66 ~31 ~-100 minecraft:deepslate_tiles
fill ~64 ~31 ~-92 ~66 ~31 ~-92 minecraft:deepslate_tiles
fill ~64 ~34 ~-99 ~64 ~34 ~-98 minecraft:deepslate_tiles
setblock ~64 ~34 ~-93 minecraft:deepslate_tiles
fill ~64 ~35 ~-152 ~67 ~35 ~-152 minecraft:deepslate_tiles
fill ~64 ~35 ~-94 ~65 ~35 ~-94 minecraft:deepslate_tiles
fill ~64 ~35 ~-40 ~67 ~35 ~-40 minecraft:deepslate_tiles
fill ~64 ~35 ~-24 ~67 ~35 ~-24 minecraft:deepslate_tiles
fill ~64 ~36 ~-95 ~65 ~37 ~-95 minecraft:deepslate_tiles
fill ~64 ~37 ~-96 ~65 ~37 ~-95 minecraft:deepslate_tiles
fill ~64 ~38 ~-96 ~64 ~40 ~-96 minecraft:deepslate_tiles
fill ~64 ~39 ~-154 ~66 ~39 ~-154 minecraft:deepslate_tiles
fill ~64 ~40 ~-166 ~64 ~40 ~-165 minecraft:deepslate_tiles
setblock ~64 ~40 ~-154 minecraft:deepslate_tiles
fill ~64 ~40 ~-38 ~64 ~40 ~-37 minecraft:deepslate_tiles
setblock ~64 ~40 ~-26 minecraft:deepslate_tiles
fill ~64 ~44 ~-163 ~66 ~44 ~-163 minecraft:deepslate_tiles
fill ~64 ~44 ~-157 ~66 ~44 ~-157 minecraft:deepslate_tiles
fill ~64 ~44 ~-35 ~66 ~44 ~-35 minecraft:deepslate_tiles
fill ~64 ~44 ~-29 ~66 ~44 ~-29 minecraft:deepslate_tiles
fill ~64 ~46 ~-158 ~65 ~46 ~-158 minecraft:deepslate_tiles
fill ~64 ~46 ~-34 ~65 ~46 ~-34 minecraft:deepslate_tiles
fill ~64 ~46 ~-30 ~65 ~46 ~-30 minecraft:deepslate_tiles
fill ~64 ~47 ~-162 ~64 ~47 ~-161 minecraft:deepslate_tiles
setblock ~64 ~47 ~-158 minecraft:deepslate_tiles
fill ~64 ~47 ~-34 ~64 ~47 ~-33 minecraft:deepslate_tiles
setblock ~64 ~47 ~-30 minecraft:deepslate_tiles
fill ~64 ~49 ~-160 ~64 ~52 ~-160 minecraft:deepslate_tiles
fill ~64 ~49 ~-32 ~64 ~52 ~-32 minecraft:deepslate_tiles
fill ~65 ~30 ~-100 ~67 ~30 ~-100 minecraft:deepslate_tiles
fill ~65 ~30 ~-92 ~67 ~30 ~-92 minecraft:deepslate_tiles
fill ~65 ~34 ~-168 ~68 ~34 ~-168 minecraft:deepslate_tiles
fill ~65 ~34 ~-152 ~68 ~34 ~-152 minecraft:deepslate_tiles
fill ~65 ~34 ~-40 ~68 ~34 ~-40 minecraft:deepslate_tiles
fill ~65 ~34 ~-24 ~68 ~34 ~-24 minecraft:deepslate_tiles
fill ~65 ~35 ~-97 ~66 ~35 ~-97 minecraft:deepslate_tiles
fill ~65 ~35 ~-95 ~66 ~35 ~-95 minecraft:deepslate_tiles
fill ~65 ~36 ~-96 ~65 ~37 ~-95 minecraft:deepslate_tiles
fill ~65 ~43 ~-163 ~67 ~43 ~-163 minecraft:deepslate_tiles
fill ~65 ~43 ~-157 ~67 ~43 ~-157 minecraft:deepslate_tiles
fill ~65 ~43 ~-35 ~67 ~43 ~-35 minecraft:deepslate_tiles
fill ~65 ~43 ~-29 ~67 ~43 ~-29 minecraft:deepslate_tiles
fill ~65 ~46 ~-161 ~66 ~46 ~-161 minecraft:deepslate_tiles
fill ~65 ~46 ~-159 ~66 ~46 ~-159 minecraft:deepslate_tiles
fill ~65 ~46 ~-33 ~66 ~46 ~-33 minecraft:deepslate_tiles
fill ~65 ~46 ~-31 ~66 ~46 ~-31 minecraft:deepslate_tiles
fill ~65 ~47 ~-160 ~66 ~47 ~-160 minecraft:deepslate_tiles
fill ~65 ~47 ~-32 ~66 ~47 ~-32 minecraft:deepslate_tiles
fill ~66 ~28 ~-101 ~68 ~28 ~-101 minecraft:deepslate_tiles
fill ~66 ~28 ~-91 ~68 ~28 ~-91 minecraft:deepslate_tiles
fill ~66 ~31 ~-99 ~67 ~31 ~-99 minecraft:deepslate_tiles
fill ~66 ~31 ~-93 ~67 ~31 ~-93 minecraft:deepslate_tiles
fill ~66 ~32 ~-169 ~69 ~32 ~-169 minecraft:deepslate_tiles
fill ~66 ~32 ~-151 ~69 ~32 ~-151 minecraft:deepslate_tiles
fill ~66 ~32 ~-41 ~69 ~32 ~-41 minecraft:deepslate_tiles
fill ~66 ~32 ~-23 ~69 ~32 ~-23 minecraft:deepslate_tiles
fill ~66 ~33 ~-98 ~67 ~33 ~-98 minecraft:deepslate_tiles
fill ~66 ~33 ~-94 ~67 ~33 ~-94 minecraft:deepslate_tiles
fill ~66 ~34 ~-96 ~67 ~34 ~-96 minecraft:deepslate_tiles
fill ~66 ~34 ~-95 ~66 ~34 ~-94 minecraft:deepslate_tiles
fill ~66 ~35 ~-96 ~66 ~35 ~-95 minecraft:deepslate_tiles
fill ~66 ~39 ~-165 ~68 ~39 ~-165 minecraft:deepslate_tiles
fill ~66 ~39 ~-155 ~68 ~39 ~-155 minecraft:deepslate_tiles
fill ~66 ~39 ~-37 ~68 ~39 ~-37 minecraft:deepslate_tiles
fill ~66 ~39 ~-27 ~68 ~39 ~-27 minecraft:deepslate_tiles
fill ~66 ~41 ~-164 ~67 ~41 ~-164 minecraft:deepslate_tiles
fill ~66 ~41 ~-156 ~67 ~41 ~-156 minecraft:deepslate_tiles
fill ~66 ~41 ~-36 ~67 ~41 ~-36 minecraft:deepslate_tiles
fill ~66 ~41 ~-28 ~67 ~41 ~-28 minecraft:deepslate_tiles
fill ~66 ~44 ~-162 ~67 ~44 ~-162 minecraft:deepslate_tiles
fill ~66 ~44 ~-158 ~67 ~44 ~-158 minecraft:deepslate_tiles
fill ~66 ~44 ~-34 ~67 ~44 ~-34 minecraft:deepslate_tiles
fill ~66 ~45 ~-161 ~67 ~45 ~-159 minecraft:deepslate_tiles
fill ~66 ~45 ~-34 ~66 ~45 ~-30 minecraft:deepslate_tiles
fill ~66 ~46 ~-160 ~66 ~46 ~-159 minecraft:deepslate_tiles
fill ~66 ~46 ~-32 ~66 ~46 ~-31 minecraft:deepslate_tiles
fill ~67 ~27 ~-101 ~68 ~28 ~-101 minecraft:deepslate_tiles
fill ~67 ~27 ~-91 ~68 ~28 ~-91 minecraft:deepslate_tiles
fill ~67 ~29 ~-100 ~68 ~29 ~-100 minecraft:deepslate_tiles
fill ~67 ~29 ~-92 ~68 ~29 ~-92 minecraft:deepslate_tiles
fill ~67 ~30 ~-99 ~68 ~30 ~-99 minecraft:deepslate_tiles
fill ~67 ~30 ~-93 ~68 ~30 ~-93 minecraft:deepslate_tiles
fill ~67 ~31 ~-98 ~68 ~31 ~-98 minecraft:deepslate_tiles
fill ~67 ~31 ~-94 ~68 ~31 ~-94 minecraft:deepslate_tiles
fill ~67 ~32 ~-98 ~67 ~33 ~-94 minecraft:deepslate_tiles
fill ~67 ~35 ~-167 ~69 ~35 ~-167 minecraft:deepslate_tiles
fill ~67 ~35 ~-153 ~69 ~35 ~-153 minecraft:deepslate_tiles
fill ~67 ~35 ~-39 ~69 ~35 ~-39 minecraft:deepslate_tiles
fill ~67 ~35 ~-25 ~69 ~35 ~-25 minecraft:deepslate_tiles
fill ~67 ~37 ~-166 ~68 ~37 ~-166 minecraft:deepslate_tiles
fill ~67 ~37 ~-154 ~68 ~37 ~-154 minecraft:deepslate_tiles
fill ~67 ~37 ~-38 ~68 ~37 ~-38 minecraft:deepslate_tiles
fill ~67 ~37 ~-26 ~68 ~37 ~-26 minecraft:deepslate_tiles
fill ~67 ~38 ~-165 ~69 ~38 ~-165 minecraft:deepslate_tiles
fill ~67 ~38 ~-155 ~69 ~38 ~-155 minecraft:deepslate_tiles
fill ~67 ~38 ~-37 ~69 ~38 ~-37 minecraft:deepslate_tiles
fill ~67 ~38 ~-27 ~69 ~38 ~-27 minecraft:deepslate_tiles
fill ~67 ~40 ~-164 ~68 ~40 ~-164 minecraft:deepslate_tiles
fill ~67 ~40 ~-156 ~68 ~40 ~-156 minecraft:deepslate_tiles
fill ~67 ~40 ~-36 ~68 ~40 ~-36 minecraft:deepslate_tiles
fill ~67 ~41 ~-163 ~68 ~41 ~-163 minecraft:deepslate_tiles
fill ~67 ~41 ~-157 ~68 ~41 ~-157 minecraft:deepslate_tiles
fill ~67 ~41 ~-35 ~68 ~41 ~-35 minecraft:deepslate_tiles
fill ~67 ~41 ~-29 ~68 ~41 ~-29 minecraft:deepslate_tiles
fill ~67 ~42 ~-163 ~67 ~43 ~-163 minecraft:deepslate_tiles
fill ~67 ~42 ~-157 ~67 ~43 ~-157 minecraft:deepslate_tiles
fill ~67 ~42 ~-35 ~67 ~43 ~-35 minecraft:deepslate_tiles
fill ~67 ~42 ~-29 ~67 ~43 ~-29 minecraft:deepslate_tiles
fill ~67 ~43 ~-162 ~67 ~44 ~-161 minecraft:deepslate_tiles
fill ~67 ~43 ~-159 ~68 ~43 ~-159 minecraft:deepslate_tiles
fill ~67 ~43 ~-158 ~67 ~43 ~-157 minecraft:deepslate_tiles
fill ~67 ~43 ~-34 ~67 ~44 ~-33 minecraft:deepslate_tiles
fill ~67 ~43 ~-31 ~68 ~43 ~-31 minecraft:deepslate_tiles
fill ~67 ~43 ~-30 ~67 ~43 ~-29 minecraft:deepslate_tiles
fill ~67 ~44 ~-160 ~67 ~44 ~-158 minecraft:deepslate_tiles
fill ~67 ~44 ~-32 ~67 ~44 ~-30 minecraft:deepslate_tiles
fill ~67 ~45 ~-33 ~67 ~45 ~-31 minecraft:deepslate_tiles
fill ~68 ~28 ~-100 ~69 ~28 ~-100 minecraft:deepslate_tiles
fill ~68 ~28 ~-92 ~69 ~28 ~-92 minecraft:deepslate_tiles
fill ~68 ~29 ~-99 ~69 ~29 ~-99 minecraft:deepslate_tiles
fill ~68 ~29 ~-93 ~69 ~29 ~-93 minecraft:deepslate_tiles
fill ~68 ~30 ~-98 ~68 ~31 ~-97 minecraft:deepslate_tiles
fill ~68 ~30 ~-95 ~69 ~30 ~-95 minecraft:deepslate_tiles
fill ~68 ~30 ~-94 ~68 ~30 ~-93 minecraft:deepslate_tiles
fill ~68 ~31 ~-169 ~70 ~31 ~-169 minecraft:deepslate_tiles
fill ~68 ~31 ~-151 ~70 ~31 ~-151 minecraft:deepslate_tiles
fill ~68 ~31 ~-96 ~68 ~31 ~-94 minecraft:deepslate_tiles
fill ~68 ~31 ~-41 ~70 ~31 ~-41 minecraft:deepslate_tiles
fill ~68 ~31 ~-23 ~70 ~31 ~-23 minecraft:deepslate_tiles
fill ~68 ~32 ~-97 ~68 ~32 ~-95 minecraft:deepslate_tiles
fill ~68 ~33 ~-168 ~69 ~33 ~-168 minecraft:deepslate_tiles
fill ~68 ~33 ~-152 ~69 ~33 ~-152 minecraft:deepslate_tiles
fill ~68 ~33 ~-40 ~69 ~33 ~-40 minecraft:deepslate_tiles
fill ~68 ~33 ~-24 ~69 ~33 ~-24 minecraft:deepslate_tiles
fill ~68 ~34 ~-167 ~70 ~34 ~-167 minecraft:deepslate_tiles
fill ~68 ~34 ~-153 ~70 ~34 ~-153 minecraft:deepslate_tiles
fill ~68 ~34 ~-39 ~70 ~34 ~-39 minecraft:deepslate_tiles
fill ~68 ~34 ~-25 ~70 ~34 ~-25 minecraft:deepslate_tiles
fill ~68 ~36 ~-166 ~69 ~36 ~-166 minecraft:deepslate_tiles
fill ~68 ~36 ~-154 ~69 ~36 ~-154 minecraft:deepslate_tiles
fill ~68 ~36 ~-38 ~69 ~36 ~-38 minecraft:deepslate_tiles
fill ~68 ~36 ~-26 ~69 ~36 ~-26 minecraft:deepslate_tiles
fill ~68 ~37 ~-165 ~69 ~38 ~-165 minecraft:deepslate_tiles
fill ~68 ~37 ~-155 ~69 ~38 ~-155 minecraft:deepslate_tiles
fill ~68 ~37 ~-37 ~69 ~38 ~-37 minecraft:deepslate_tiles
fill ~68 ~37 ~-27 ~69 ~38 ~-27 minecraft:deepslate_tiles
fill ~68 ~39 ~-164 ~69 ~39 ~-164 minecraft:deepslate_tiles
fill ~68 ~39 ~-156 ~69 ~39 ~-156 minecraft:deepslate_tiles
fill ~68 ~39 ~-36 ~69 ~39 ~-36 minecraft:deepslate_tiles
fill ~68 ~39 ~-28 ~69 ~39 ~-28 minecraft:deepslate_tiles
fill ~68 ~40 ~-163 ~69 ~40 ~-163 minecraft:deepslate_tiles
fill ~68 ~40 ~-35 ~69 ~40 ~-35 minecraft:deepslate_tiles
fill ~68 ~40 ~-29 ~69 ~40 ~-29 minecraft:deepslate_tiles
setblock ~68 ~40 ~-28 minecraft:deepslate_tiles
fill ~68 ~41 ~-162 ~69 ~41 ~-162 minecraft:deepslate_tiles
fill ~68 ~41 ~-158 ~69 ~41 ~-158 minecraft:deepslate_tiles
fill ~68 ~41 ~-34 ~69 ~41 ~-34 minecraft:deepslate_tiles
fill ~68 ~41 ~-30 ~69 ~41 ~-30 minecraft:deepslate_tiles
fill ~68 ~42 ~-162 ~68 ~42 ~-158 minecraft:deepslate_tiles
fill ~68 ~42 ~-34 ~68 ~42 ~-30 minecraft:deepslate_tiles
fill ~68 ~43 ~-161 ~68 ~43 ~-159 minecraft:deepslate_tiles
fill ~68 ~43 ~-33 ~68 ~43 ~-31 minecraft:deepslate_tiles
fill ~69 ~27 ~-100 ~69 ~28 ~-99 minecraft:deepslate_tiles
fill ~69 ~27 ~-93 ~70 ~27 ~-93 minecraft:deepslate_tiles
fill ~69 ~28 ~-98 ~70 ~28 ~-98 minecraft:deepslate_tiles
fill ~69 ~28 ~-94 ~70 ~28 ~-94 minecraft:deepslate_tiles
fill ~69 ~28 ~-93 ~69 ~28 ~-92 minecraft:deepslate_tiles
fill ~69 ~29 ~-98 ~69 ~29 ~-93 minecraft:deepslate_tiles
fill ~69 ~30 ~-97 ~69 ~30 ~-95 minecraft:deepslate_tiles
fill ~69 ~32 ~-168 ~70 ~32 ~-168 minecraft:deepslate_tiles
fill ~69 ~32 ~-152 ~70 ~32 ~-152 minecraft:deepslate_tiles
fill ~69 ~32 ~-40 ~70 ~32 ~-40 minecraft:deepslate_tiles
fill ~69 ~32 ~-24 ~70 ~32 ~-24 minecraft:deepslate_tiles
fill ~69 ~33 ~-167 ~70 ~34 ~-167 minecraft:deepslate_tiles
fill ~69 ~33 ~-153 ~70 ~34 ~-153 minecraft:deepslate_tiles
fill ~69 ~33 ~-39 ~70 ~34 ~-39 minecraft:deepslate_tiles
fill ~69 ~33 ~-25 ~70 ~34 ~-25 minecraft:deepslate_tiles
fill ~69 ~35 ~-166 ~70 ~35 ~-166 minecraft:deepslate_tiles
fill ~69 ~35 ~-154 ~70 ~35 ~-154 minecraft:deepslate_tiles
fill ~69 ~35 ~-38 ~70 ~35 ~-38 minecraft:deepslate_tiles
fill ~69 ~35 ~-26 ~70 ~35 ~-26 minecraft:deepslate_tiles
fill ~69 ~36 ~-165 ~70 ~36 ~-165 minecraft:deepslate_tiles
fill ~69 ~36 ~-155 ~70 ~36 ~-155 minecraft:deepslate_tiles
fill ~69 ~36 ~-37 ~70 ~36 ~-37 minecraft:deepslate_tiles
fill ~69 ~36 ~-27 ~70 ~36 ~-27 minecraft:deepslate_tiles
fill ~69 ~37 ~-164 ~70 ~37 ~-164 minecraft:deepslate_tiles
fill ~69 ~37 ~-156 ~70 ~37 ~-156 minecraft:deepslate_tiles
fill ~69 ~37 ~-36 ~70 ~37 ~-36 minecraft:deepslate_tiles
fill ~69 ~37 ~-28 ~70 ~37 ~-28 minecraft:deepslate_tiles
fill ~69 ~38 ~-164 ~69 ~39 ~-163 minecraft:deepslate_tiles
fill ~69 ~38 ~-157 ~70 ~38 ~-157 minecraft:deepslate_tiles
fill ~69 ~38 ~-156 ~69 ~38 ~-155 minecraft:deepslate_tiles
fill ~69 ~38 ~-36 ~69 ~39 ~-35 minecraft:deepslate_tiles
fill ~69 ~38 ~-29 ~70 ~38 ~-29 minecraft:deepslate_tiles
fill ~69 ~38 ~-28 ~69 ~38 ~-27 minecraft:deepslate_tiles
fill ~69 ~39 ~-162 ~70 ~39 ~-162 minecraft:deepslate_tiles
fill ~69 ~39 ~-158 ~70 ~39 ~-158 minecraft:deepslate_tiles
fill ~69 ~39 ~-157 ~69 ~39 ~-156 minecraft:deepslate_tiles
fill ~69 ~39 ~-34 ~70 ~39 ~-34 minecraft:deepslate_tiles
fill ~69 ~39 ~-30 ~70 ~39 ~-30 minecraft:deepslate_tiles
fill ~69 ~39 ~-29 ~69 ~39 ~-28 minecraft:deepslate_tiles
fill ~69 ~40 ~-162 ~69 ~40 ~-157 minecraft:deepslate_tiles
fill ~69 ~40 ~-34 ~69 ~40 ~-29 minecraft:deepslate_tiles
fill ~69 ~41 ~-161 ~69 ~41 ~-158 minecraft:deepslate_tiles
fill ~69 ~41 ~-33 ~69 ~41 ~-30 minecraft:deepslate_tiles
fill ~70 ~27 ~-99 ~70 ~27 ~-93 minecraft:deepslate_tiles
fill ~70 ~28 ~-97 ~70 ~28 ~-94 minecraft:deepslate_tiles
fill ~70 ~31 ~-168 ~71 ~31 ~-168 minecraft:deepslate_tiles
fill ~70 ~31 ~-152 ~71 ~31 ~-152 minecraft:deepslate_tiles
fill ~70 ~31 ~-40 ~71 ~31 ~-40 minecraft:deepslate_tiles
fill ~70 ~31 ~-24 ~71 ~31 ~-24 minecraft:deepslate_tiles
fill ~70 ~32 ~-167 ~71 ~32 ~-167 minecraft:deepslate_tiles
fill ~70 ~32 ~-153 ~71 ~32 ~-153 minecraft:deepslate_tiles
fill ~70 ~32 ~-39 ~71 ~32 ~-39 minecraft:deepslate_tiles
fill ~70 ~32 ~-25 ~71 ~32 ~-25 minecraft:deepslate_tiles
fill ~70 ~34 ~-166 ~71 ~34 ~-166 minecraft:deepslate_tiles
fill ~70 ~34 ~-154 ~71 ~34 ~-154 minecraft:deepslate_tiles
fill ~70 ~34 ~-38 ~71 ~34 ~-38 minecraft:deepslate_tiles
fill ~70 ~34 ~-26 ~71 ~34 ~-26 minecraft:deepslate_tiles
fill ~70 ~35 ~-165 ~71 ~35 ~-165 minecraft:deepslate_tiles
fill ~70 ~35 ~-155 ~71 ~35 ~-155 minecraft:deepslate_tiles
fill ~70 ~35 ~-37 ~71 ~35 ~-37 minecraft:deepslate_tiles
fill ~70 ~35 ~-27 ~71 ~35 ~-27 minecraft:deepslate_tiles
fill ~70 ~36 ~-164 ~71 ~36 ~-164 minecraft:deepslate_tiles
fill ~70 ~36 ~-156 ~71 ~36 ~-156 minecraft:deepslate_tiles
fill ~70 ~36 ~-36 ~71 ~36 ~-36 minecraft:deepslate_tiles
fill ~70 ~36 ~-28 ~71 ~36 ~-28 minecraft:deepslate_tiles
fill ~70 ~37 ~-163 ~71 ~37 ~-163 minecraft:deepslate_tiles
fill ~70 ~37 ~-35 ~71 ~37 ~-35 minecraft:deepslate_tiles
fill ~70 ~37 ~-29 ~71 ~37 ~-29 minecraft:deepslate_tiles
fill ~70 ~38 ~-163 ~70 ~38 ~-157 minecraft:deepslate_tiles
fill ~70 ~38 ~-35 ~70 ~38 ~-29 minecraft:deepslate_tiles
fill ~70 ~39 ~-161 ~70 ~39 ~-158 minecraft:deepslate_tiles
fill ~70 ~39 ~-33 ~70 ~39 ~-30 minecraft:deepslate_tiles
setblock ~70 ~40 ~-160 minecraft:deepslate_tiles
setblock ~70 ~40 ~-32 minecraft:deepslate_tiles
fill ~71 ~31 ~-167 ~72 ~31 ~-167 minecraft:deepslate_tiles
fill ~71 ~31 ~-153 ~72 ~31 ~-153 minecraft:deepslate_tiles
fill ~71 ~31 ~-39 ~72 ~31 ~-39 minecraft:deepslate_tiles
fill ~71 ~31 ~-25 ~72 ~31 ~-25 minecraft:deepslate_tiles
fill ~71 ~32 ~-166 ~72 ~32 ~-166 minecraft:deepslate_tiles
fill ~71 ~32 ~-154 ~72 ~32 ~-154 minecraft:deepslate_tiles
fill ~71 ~32 ~-38 ~72 ~32 ~-38 minecraft:deepslate_tiles
fill ~71 ~32 ~-26 ~72 ~32 ~-26 minecraft:deepslate_tiles
fill ~71 ~33 ~-166 ~71 ~34 ~-165 minecraft:deepslate_tiles
fill ~71 ~33 ~-155 ~72 ~33 ~-155 minecraft:deepslate_tiles
fill ~71 ~33 ~-154 ~71 ~34 ~-154 minecraft:deepslate_tiles
fill ~71 ~33 ~-38 ~71 ~34 ~-37 minecraft:deepslate_tiles
fill ~71 ~33 ~-27 ~72 ~33 ~-27 minecraft:deepslate_tiles
fill ~71 ~33 ~-26 ~71 ~34 ~-26 minecraft:deepslate_tiles
fill ~71 ~34 ~-164 ~72 ~34 ~-164 minecraft:deepslate_tiles
fill ~71 ~34 ~-156 ~72 ~34 ~-156 minecraft:deepslate_tiles
fill ~71 ~34 ~-155 ~71 ~34 ~-154 minecraft:deepslate_tiles
fill ~71 ~34 ~-36 ~72 ~34 ~-36 minecraft:deepslate_tiles
fill ~71 ~34 ~-28 ~72 ~34 ~-28 minecraft:deepslate_tiles
fill ~71 ~34 ~-27 ~71 ~34 ~-26 minecraft:deepslate_tiles
fill ~71 ~35 ~-164 ~71 ~36 ~-163 minecraft:deepslate_tiles
fill ~71 ~35 ~-157 ~72 ~35 ~-157 minecraft:deepslate_tiles
fill ~71 ~35 ~-156 ~71 ~35 ~-155 minecraft:deepslate_tiles
fill ~71 ~35 ~-36 ~71 ~36 ~-35 minecraft:deepslate_tiles
fill ~71 ~35 ~-29 ~72 ~35 ~-29 minecraft:deepslate_tiles
fill ~71 ~35 ~-28 ~71 ~35 ~-27 minecraft:deepslate_tiles
fill ~71 ~36 ~-162 ~71 ~36 ~-156 minecraft:deepslate_tiles
fill ~71 ~36 ~-34 ~71 ~36 ~-28 minecraft:deepslate_tiles
fill ~71 ~37 ~-162 ~71 ~37 ~-157 minecraft:deepslate_tiles
fill ~71 ~37 ~-34 ~71 ~37 ~-29 minecraft:deepslate_tiles
fill ~71 ~38 ~-161 ~71 ~38 ~-159 minecraft:deepslate_tiles
fill ~71 ~38 ~-33 ~71 ~38 ~-31 minecraft:deepslate_tiles
fill ~72 ~31 ~-166 ~73 ~31 ~-166 minecraft:deepslate_tiles
fill ~72 ~31 ~-154 ~73 ~31 ~-154 minecraft:deepslate_tiles
fill ~72 ~31 ~-38 ~73 ~31 ~-38 minecraft:deepslate_tiles
fill ~72 ~31 ~-26 ~73 ~31 ~-26 minecraft:deepslate_tiles
fill ~72 ~32 ~-165 ~73 ~32 ~-165 minecraft:deepslate_tiles
fill ~72 ~32 ~-155 ~73 ~32 ~-155 minecraft:deepslate_tiles
fill ~72 ~32 ~-37 ~73 ~32 ~-37 minecraft:deepslate_tiles
fill ~72 ~32 ~-27 ~73 ~32 ~-27 minecraft:deepslate_tiles
fill ~72 ~33 ~-165 ~72 ~33 ~-164 minecraft:deepslate_tiles
fill ~72 ~33 ~-156 ~73 ~33 ~-156 minecraft:deepslate_tiles
fill ~72 ~33 ~-37 ~72 ~33 ~-36 minecraft:deepslate_tiles
fill ~72 ~34 ~-162 ~73 ~34 ~-161 minecraft:deepslate_tiles
fill ~72 ~34 ~-159 ~73 ~34 ~-158 minecraft:deepslate_tiles
fill ~72 ~34 ~-157 ~72 ~34 ~-156 minecraft:deepslate_tiles
fill ~72 ~34 ~-35 ~72 ~35 ~-33 minecraft:deepslate_tiles
fill ~72 ~34 ~-31 ~73 ~34 ~-30 minecraft:deepslate_tiles
fill ~72 ~34 ~-29 ~72 ~34 ~-28 minecraft:deepslate_tiles
fill ~72 ~35 ~-163 ~72 ~35 ~-157 minecraft:deepslate_tiles
fill ~72 ~35 ~-32 ~72 ~35 ~-29 minecraft:deepslate_tiles
fill ~72 ~36 ~-161 ~72 ~36 ~-159 minecraft:deepslate_tiles
fill ~72 ~36 ~-33 ~72 ~36 ~-31 minecraft:deepslate_tiles
fill ~73 ~31 ~-165 ~73 ~32 ~-164 minecraft:deepslate_tiles
fill ~73 ~31 ~-156 ~74 ~31 ~-156 minecraft:deepslate_tiles
fill ~73 ~31 ~-155 ~73 ~31 ~-154 minecraft:deepslate_tiles
fill ~73 ~31 ~-37 ~73 ~32 ~-36 minecraft:deepslate_tiles
fill ~73 ~31 ~-28 ~75 ~31 ~-28 minecraft:deepslate_tiles
fill ~73 ~31 ~-27 ~73 ~31 ~-26 minecraft:deepslate_tiles
fill ~73 ~32 ~-163 ~73 ~33 ~-162 minecraft:deepslate_tiles
fill ~73 ~32 ~-158 ~74 ~32 ~-158 minecraft:deepslate_tiles
fill ~73 ~32 ~-157 ~73 ~32 ~-155 minecraft:deepslate_tiles
fill ~73 ~32 ~-35 ~73 ~33 ~-34 minecraft:deepslate_tiles
fill ~73 ~32 ~-30 ~74 ~32 ~-30 minecraft:deepslate_tiles
fill ~73 ~32 ~-29 ~73 ~32 ~-27 minecraft:deepslate_tiles
fill ~73 ~33 ~-164 ~73 ~33 ~-156 minecraft:deepslate_tiles
fill ~73 ~33 ~-36 ~73 ~33 ~-28 minecraft:deepslate_tiles
fill ~73 ~34 ~-160 ~73 ~34 ~-158 minecraft:deepslate_tiles
fill ~73 ~34 ~-34 ~73 ~34 ~-30 minecraft:deepslate_tiles
fill ~74 ~31 ~-163 ~74 ~31 ~-156 minecraft:deepslate_tiles
fill ~74 ~31 ~-36 ~74 ~31 ~-28 minecraft:deepslate_tiles
fill ~74 ~32 ~-162 ~74 ~32 ~-158 minecraft:deepslate_tiles
fill ~74 ~32 ~-34 ~74 ~32 ~-30 minecraft:deepslate_tiles
fill ~-55 ~18 ~-129 ~-35 ~19 ~-129 minecraft:dark_oak_planks
fill ~-47 ~15 ~-85 ~-47 ~16 ~-65 minecraft:dark_oak_planks
fill ~-45 ~17 ~-113 ~-45 ~18 ~-91 minecraft:dark_oak_planks
fill ~-24 ~22 ~-144 ~24 ~22 ~-104 minecraft:dark_oak_planks
fill ~-24 ~33 ~-144 ~24 ~33 ~-104 minecraft:dark_oak_planks
fill ~-11 ~11 ~-144 ~24 ~11 ~-104 minecraft:dark_oak_planks
fill ~-6 ~-26 ~-144 ~10 ~-19 ~-133 minecraft:dark_oak_planks
fill ~35 ~18 ~-129 ~55 ~19 ~-129 minecraft:dark_oak_planks
fill ~46 ~16 ~-113 ~46 ~17 ~-91 minecraft:dark_oak_planks
fill ~-76 ~ ~-163 ~-76 ~2 ~-157 minecraft:cobblestone
fill ~-76 ~ ~-35 ~-76 ~2 ~-29 minecraft:cobblestone
fill ~-75 ~ ~-164 ~-75 ~2 ~-164 minecraft:cobblestone
fill ~-75 ~ ~-155 ~-75 ~2 ~-155 minecraft:cobblestone
fill ~-75 ~ ~-37 ~-75 ~2 ~-36 minecraft:cobblestone
fill ~-75 ~ ~-28 ~-75 ~2 ~-27 minecraft:cobblestone
fill ~-75 ~1 ~-156 ~-75 ~2 ~-155 minecraft:cobblestone
fill ~-75 ~2 ~-165 ~-75 ~2 ~-164 minecraft:cobblestone
fill ~-74 ~ ~-154 ~-74 ~2 ~-153 minecraft:cobblestone
fill ~-74 ~ ~-38 ~-74 ~2 ~-38 minecraft:cobblestone
fill ~-74 ~ ~-26 ~-74 ~2 ~-25 minecraft:cobblestone
fill ~-74 ~1 ~-39 ~-74 ~2 ~-38 minecraft:cobblestone
fill ~-74 ~2 ~-167 ~-74 ~2 ~-166 minecraft:cobblestone
fill ~-73 ~ ~-168 ~-73 ~2 ~-168 minecraft:cobblestone
fill ~-73 ~ ~-152 ~-73 ~2 ~-152 minecraft:cobblestone
fill ~-73 ~1 ~-40 ~-73 ~2 ~-40 minecraft:cobblestone
setblock ~-73 ~2 ~-24 minecraft:cobblestone
fill ~-72 ~ ~-169 ~-72 ~2 ~-169 minecraft:cobblestone
fill ~-72 ~ ~-151 ~-72 ~2 ~-151 minecraft:cobblestone
fill ~-72 ~ ~-98 ~-72 ~2 ~-94 minecraft:cobblestone
fill ~-72 ~ ~-41 ~-72 ~2 ~-41 minecraft:cobblestone
fill ~-72 ~ ~-23 ~-72 ~2 ~-23 minecraft:cobblestone
fill ~-71 ~ ~-170 ~-70 ~2 ~-170 minecraft:cobblestone
fill ~-71 ~ ~-150 ~-70 ~2 ~-150 minecraft:cobblestone
fill ~-71 ~ ~-100 ~-71 ~2 ~-99 minecraft:cobblestone
fill ~-71 ~ ~-93 ~-71 ~2 ~-92 minecraft:cobblestone
fill ~-71 ~1 ~-42 ~-70 ~2 ~-42 minecraft:cobblestone
fill ~-71 ~1 ~-22 ~-70 ~2 ~-22 minecraft:cobblestone
fill ~-70 ~ ~-102 ~-69 ~2 ~-102 minecraft:cobblestone
fill ~-70 ~ ~-101 ~-70 ~2 ~-101 minecraft:cobblestone
fill ~-70 ~ ~-91 ~-70 ~2 ~-90 minecraft:cobblestone
fill ~-70 ~ ~-42 ~-70 ~2 ~-42 minecraft:cobblestone
fill ~-69 ~ ~-171 ~-68 ~2 ~-171 minecraft:cobblestone
fill ~-69 ~ ~-149 ~-68 ~2 ~-149 minecraft:cobblestone
fill ~-69 ~ ~-90 ~-69 ~2 ~-90 minecraft:cobblestone
fill ~-69 ~ ~-43 ~-68 ~2 ~-43 minecraft:cobblestone
fill ~-69 ~ ~-21 ~-68 ~2 ~-21 minecraft:cobblestone
fill ~-68 ~ ~-103 ~-67 ~2 ~-103 minecraft:cobblestone
fill ~-68 ~1 ~-89 ~-67 ~2 ~-89 minecraft:cobblestone
fill ~-67 ~ ~-172 ~-61 ~2 ~-172 minecraft:cobblestone
fill ~-67 ~ ~-89 ~-67 ~2 ~-89 minecraft:cobblestone
fill ~-67 ~ ~-44 ~-61 ~2 ~-44 minecraft:cobblestone
fill ~-67 ~2 ~-148 ~-61 ~2 ~-148 minecraft:cobblestone
fill ~-67 ~2 ~-20 ~-61 ~2 ~-20 minecraft:cobblestone
fill ~-66 ~ ~-148 ~-61 ~2 ~-148 minecraft:cobblestone
fill ~-66 ~ ~-104 ~-62 ~2 ~-104 minecraft:cobblestone
fill ~-66 ~ ~-88 ~-62 ~2 ~-88 minecraft:cobblestone
fill ~-66 ~1 ~-20 ~-61 ~2 ~-20 minecraft:cobblestone
fill ~-65 ~ ~-146 ~-65 ~2 ~-104 minecraft:cobblestone
fill ~-65 ~ ~-87 ~-65 ~2 ~-44 minecraft:cobblestone
fill ~-65 ~1 ~-147 ~-65 ~2 ~-104 minecraft:cobblestone
fill ~-64 ~ ~-20 ~-61 ~2 ~-20 minecraft:cobblestone
fill ~-61 ~ ~-103 ~-60 ~2 ~-103 minecraft:cobblestone
fill ~-61 ~ ~-89 ~-60 ~2 ~-89 minecraft:cobblestone
fill ~-60 ~ ~-171 ~-59 ~2 ~-171 minecraft:cobblestone
fill ~-60 ~ ~-149 ~-59 ~2 ~-149 minecraft:cobblestone
fill ~-60 ~ ~-43 ~-59 ~2 ~-43 minecraft:cobblestone
fill ~-60 ~ ~-21 ~-59 ~2 ~-21 minecraft:cobblestone
fill ~-59 ~ ~-102 ~-58 ~2 ~-102 minecraft:cobblestone
fill ~-59 ~ ~-90 ~-58 ~2 ~-90 minecraft:cobblestone
fill ~-58 ~ ~-170 ~-57 ~2 ~-170 minecraft:cobblestone
fill ~-58 ~ ~-150 ~-57 ~2 ~-150 minecraft:cobblestone
fill ~-58 ~ ~-101 ~-58 ~2 ~-101 minecraft:cobblestone
fill ~-58 ~ ~-42 ~-57 ~2 ~-42 minecraft:cobblestone
fill ~-58 ~ ~-22 ~-57 ~2 ~-22 minecraft:cobblestone
fill ~-58 ~1 ~-91 ~-58 ~2 ~-90 minecraft:cobblestone
fill ~-57 ~ ~-100 ~-57 ~2 ~-99 minecraft:cobblestone
fill ~-57 ~ ~-93 ~-57 ~2 ~-92 minecraft:cobblestone
fill ~-56 ~ ~-169 ~-56 ~2 ~-169 minecraft:cobblestone
fill ~-56 ~ ~-98 ~-56 ~2 ~-98 minecraft:cobblestone
fill ~-56 ~ ~-23 ~-56 ~2 ~-23 minecraft:cobblestone
fill ~-56 ~1 ~-94 ~-56 ~2 ~-94 minecraft:cobblestone
fill ~-55 ~ ~-168 ~-55 ~2 ~-168 minecraft:cobblestone
fill ~-55 ~ ~-24 ~-55 ~2 ~-24 minecraft:cobblestone
fill ~-54 ~ ~-167 ~-54 ~2 ~-166 minecraft:cobblestone
fill ~-54 ~ ~-154 ~-54 ~2 ~-153 minecraft:cobblestone
fill ~-54 ~ ~-138 ~-36 ~ ~-138 minecraft:cobblestone
fill ~-54 ~ ~-135 ~-51 ~ ~-135 minecraft:cobblestone
fill ~-54 ~ ~-134 ~-54 ~ ~-120 minecraft:cobblestone
fill ~-54 ~ ~-111 ~-54 ~5 ~-92 minecraft:cobblestone
fill ~-54 ~ ~-84 ~-40 ~5 ~-84 minecraft:cobblestone
fill ~-54 ~ ~-82 ~-54 ~5 ~-66 minecraft:cobblestone
fill ~-54 ~ ~-39 ~-54 ~2 ~-38 minecraft:cobblestone
fill ~-54 ~ ~-26 ~-54 ~2 ~-25 minecraft:cobblestone
fill ~-53 ~ ~-165 ~-53 ~2 ~-164 minecraft:cobblestone
fill ~-53 ~ ~-156 ~-53 ~2 ~-155 minecraft:cobblestone
fill ~-53 ~ ~-120 ~-36 ~ ~-120 minecraft:cobblestone
fill ~-53 ~ ~-112 ~-36 ~5 ~-112 minecraft:cobblestone
fill ~-53 ~ ~-92 ~-36 ~5 ~-92 minecraft:cobblestone
fill ~-53 ~ ~-66 ~-40 ~5 ~-66 minecraft:cobblestone
fill ~-53 ~ ~-37 ~-53 ~2 ~-36 minecraft:cobblestone
fill ~-53 ~ ~-28 ~-53 ~2 ~-27 minecraft:cobblestone
fill ~-52 ~ ~-161 ~-8 ~2 ~-161 minecraft:cobblestone
fill ~-52 ~ ~-160 ~-52 ~2 ~-157 minecraft:cobblestone
fill ~-52 ~ ~-35 ~-52 ~2 ~-29 minecraft:cobblestone
fill ~-52 ~1 ~-162 ~-52 ~1 ~-156 minecraft:cobblestone
fill ~-52 ~2 ~-163 ~-52 ~2 ~-157 minecraft:cobblestone
fill ~-51 ~1 ~-31 ~-24 ~2 ~-31 minecraft:cobblestone
fill ~-50 ~ ~-56 ~-43 ~4 ~-56 minecraft:cobblestone
fill ~-50 ~ ~-54 ~-50 ~4 ~-49 minecraft:cobblestone
fill ~-50 ~ ~-31 ~-24 ~2 ~-31 minecraft:cobblestone
fill ~-49 ~ ~-49 ~-43 ~4 ~-49 minecraft:cobblestone
fill ~-43 ~ ~-55 ~-43 ~4 ~-49 minecraft:cobblestone
fill ~-40 ~ ~-82 ~-40 ~5 ~-66 minecraft:cobblestone
fill ~-40 ~ ~-54 ~-40 ~4 ~-49 minecraft:cobblestone
fill ~-39 ~ ~-56 ~-33 ~4 ~-56 minecraft:cobblestone
fill ~-38 ~ ~-49 ~-33 ~4 ~-49 minecraft:cobblestone
fill ~-36 ~ ~-137 ~-36 ~ ~-120 minecraft:cobblestone
fill ~-36 ~ ~-111 ~-36 ~5 ~-92 minecraft:cobblestone
fill ~-33 ~ ~-148 ~-33 ~2 ~-144 minecraft:cobblestone
fill ~-33 ~ ~-104 ~-33 ~2 ~-100 minecraft:cobblestone
fill ~-33 ~ ~-54 ~-33 ~4 ~-49 minecraft:cobblestone
fill ~-32 ~ ~-150 ~-32 ~2 ~-149 minecraft:cobblestone
fill ~-32 ~ ~-143 ~-32 ~2 ~-142 minecraft:cobblestone
fill ~-32 ~ ~-106 ~-32 ~2 ~-105 minecraft:cobblestone
fill ~-32 ~ ~-99 ~-32 ~2 ~-98 minecraft:cobblestone
fill ~-31 ~ ~-151 ~-31 ~2 ~-151 minecraft:cobblestone
fill ~-31 ~ ~-141 ~-31 ~2 ~-141 minecraft:cobblestone
fill ~-31 ~ ~-107 ~-31 ~2 ~-107 minecraft:cobblestone
fill ~-31 ~ ~-97 ~-31 ~2 ~-97 minecraft:cobblestone
fill ~-30 ~ ~-152 ~-29 ~2 ~-152 minecraft:cobblestone
fill ~-30 ~ ~-108 ~-29 ~2 ~-108 minecraft:cobblestone
fill ~-30 ~ ~-96 ~-29 ~2 ~-96 minecraft:cobblestone
fill ~-30 ~2 ~-140 ~-29 ~2 ~-140 minecraft:cobblestone
fill ~-29 ~ ~-140 ~-29 ~2 ~-140 minecraft:cobblestone
fill ~-28 ~ ~-153 ~-24 ~2 ~-153 minecraft:cobblestone
fill ~-28 ~ ~-139 ~-25 ~2 ~-139 minecraft:cobblestone
fill ~-28 ~ ~-109 ~-25 ~2 ~-109 minecraft:cobblestone
fill ~-28 ~2 ~-95 ~-24 ~2 ~-95 minecraft:cobblestone
fill ~-27 ~ ~-137 ~-27 ~2 ~-109 minecraft:cobblestone
fill ~-27 ~ ~-95 ~-24 ~2 ~-95 minecraft:cobblestone
fill ~-27 ~1 ~-138 ~-27 ~2 ~-109 minecraft:cobblestone
fill ~-24 ~ ~-33 ~-23 ~2 ~-33 minecraft:cobblestone
fill ~-24 ~ ~-32 ~-24 ~2 ~-27 minecraft:cobblestone
fill ~-23 ~ ~-96 ~-22 ~2 ~-96 minecraft:cobblestone
fill ~-23 ~ ~-35 ~-22 ~2 ~-35 minecraft:cobblestone
fill ~-23 ~ ~-34 ~-23 ~2 ~-33 minecraft:cobblestone
fill ~-23 ~ ~-27 ~-23 ~2 ~-25 minecraft:cobblestone
fill ~-23 ~1 ~-152 ~-22 ~2 ~-152 minecraft:cobblestone
fill ~-22 ~ ~-152 ~-22 ~2 ~-152 minecraft:cobblestone
fill ~-22 ~ ~-36 ~-22 ~2 ~-35 minecraft:cobblestone
fill ~-22 ~ ~-25 ~-22 ~2 ~-24 minecraft:cobblestone
fill ~-21 ~ ~-151 ~-21 ~2 ~-151 minecraft:cobblestone
fill ~-21 ~ ~-97 ~-21 ~2 ~-97 minecraft:cobblestone
fill ~-21 ~ ~-37 ~-20 ~2 ~-37 minecraft:cobblestone
fill ~-21 ~ ~-23 ~-20 ~2 ~-23 minecraft:cobblestone
fill ~-20 ~ ~-150 ~-20 ~2 ~-149 minecraft:cobblestone
fill ~-20 ~ ~-99 ~-20 ~2 ~-98 minecraft:cobblestone
fill ~-20 ~ ~-38 ~-18 ~2 ~-38 minecraft:cobblestone
fill ~-20 ~ ~-22 ~-18 ~2 ~-22 minecraft:cobblestone
fill ~-19 ~ ~-147 ~19 ~2 ~-147 minecraft:cobblestone
fill ~-19 ~ ~-146 ~-19 ~ ~-144 minecraft:cobblestone
fill ~-19 ~ ~-103 ~-19 ~2 ~-100 minecraft:cobblestone
fill ~-19 ~1 ~-148 ~-19 ~2 ~-145 minecraft:cobblestone
fill ~-18 ~ ~-101 ~-4 ~2 ~-101 minecraft:cobblestone
fill ~-18 ~ ~-39 ~-12 ~2 ~-39 minecraft:cobblestone
fill ~-18 ~ ~-21 ~-12 ~2 ~-21 minecraft:cobblestone
fill ~-12 ~ ~-38 ~-5 ~2 ~-38 minecraft:cobblestone
fill ~-12 ~ ~-22 ~-10 ~2 ~-22 minecraft:cobblestone
fill ~-10 ~ ~-41 ~-5 ~2 ~-37 minecraft:cobblestone
fill ~-10 ~ ~-23 ~-9 ~2 ~-23 minecraft:cobblestone
fill ~-8 ~ ~-162 ~-8 ~2 ~-158 minecraft:cobblestone
fill ~-8 ~ ~-36 ~-5 ~2 ~-35 minecraft:cobblestone
fill ~-8 ~ ~-25 ~-5 ~2 ~-25 minecraft:cobblestone
fill ~-8 ~1 ~-24 ~-8 ~2 ~-24 minecraft:cobblestone
fill ~-7 ~ ~-164 ~-7 ~2 ~-163 minecraft:cobblestone
fill ~-7 ~ ~-157 ~-7 ~2 ~-156 minecraft:cobblestone
fill ~-7 ~ ~-34 ~-5 ~2 ~-33 minecraft:cobblestone
fill ~-7 ~ ~-27 ~-5 ~2 ~-25 minecraft:cobblestone
fill ~-6 ~ ~-166 ~-5 ~2 ~-166 minecraft:cobblestone
fill ~-6 ~ ~-165 ~-6 ~2 ~-165 minecraft:cobblestone
fill ~-6 ~ ~-155 ~-6 ~2 ~-154 minecraft:cobblestone
fill ~-6 ~ ~-32 ~-5 ~2 ~-25 minecraft:cobblestone
fill ~-5 ~1 ~-154 ~-5 ~2 ~-154 minecraft:cobblestone
fill ~-4 ~ ~-167 ~-3 ~2 ~-167 minecraft:cobblestone
fill ~-4 ~ ~-153 ~-3 ~2 ~-153 minecraft:cobblestone
fill ~-2 ~ ~-168 ~2 ~2 ~-168 minecraft:cobblestone
fill ~-2 ~1 ~-152 ~-2 ~2 ~-152 minecraft:cobblestone
fill ~ ~-9 ~-144 ~23 ~-9 ~-104 minecraft:cobblestone
fill ~2 ~ ~-152 ~2 ~2 ~-152 minecraft:cobblestone
fill ~3 ~ ~-167 ~4 ~2 ~-167 minecraft:cobblestone
fill ~3 ~ ~-153 ~4 ~2 ~-153 minecraft:cobblestone
fill ~5 ~ ~-166 ~6 ~2 ~-166 minecraft:cobblestone
fill ~5 ~ ~-154 ~6 ~2 ~-154 minecraft:cobblestone
fill ~5 ~ ~-101 ~19 ~2 ~-101 minecraft:cobblestone
fill ~5 ~ ~-41 ~10 ~2 ~-37 minecraft:cobblestone
fill ~5 ~ ~-35 ~8 ~2 ~-35 minecraft:cobblestone
fill ~5 ~ ~-34 ~7 ~2 ~-33 minecraft:cobblestone
fill ~5 ~ ~-32 ~6 ~2 ~-25 minecraft:cobblestone
fill ~5 ~1 ~-36 ~8 ~2 ~-35 minecraft:cobblestone
fill ~6 ~ ~-165 ~6 ~2 ~-165 minecraft:cobblestone
fill ~6 ~ ~-36 ~8 ~2 ~-35 minecraft:cobblestone
fill ~6 ~1 ~-155 ~6 ~2 ~-154 minecraft:cobblestone
fill ~7 ~ ~-157 ~7 ~2 ~-156 minecraft:cobblestone
fill ~7 ~ ~-27 ~7 ~2 ~-25 minecraft:cobblestone
fill ~7 ~1 ~-164 ~7 ~2 ~-163 minecraft:cobblestone
fill ~8 ~ ~-162 ~8 ~2 ~-158 minecraft:cobblestone
fill ~8 ~ ~-25 ~8 ~2 ~-24 minecraft:cobblestone
fill ~9 ~ ~-161 ~52 ~2 ~-161 minecraft:cobblestone
fill ~9 ~ ~-23 ~10 ~2 ~-23 minecraft:cobblestone
fill ~10 ~ ~-22 ~12 ~2 ~-22 minecraft:cobblestone
fill ~11 ~ ~-38 ~12 ~2 ~-38 minecraft:cobblestone
fill ~12 ~ ~-39 ~18 ~2 ~-39 minecraft:cobblestone
fill ~12 ~1 ~-21 ~18 ~2 ~-21 minecraft:cobblestone
fill ~14 ~ ~-21 ~18 ~2 ~-21 minecraft:cobblestone
fill ~18 ~ ~-38 ~20 ~2 ~-38 minecraft:cobblestone
fill ~18 ~ ~-22 ~20 ~2 ~-22 minecraft:cobblestone
fill ~19 ~ ~-148 ~19 ~2 ~-145 minecraft:cobblestone
fill ~19 ~ ~-103 ~19 ~2 ~-100 minecraft:cobblestone
fill ~20 ~ ~-150 ~20 ~2 ~-149 minecraft:cobblestone
fill ~20 ~ ~-98 ~20 ~2 ~-98 minecraft:cobblestone
fill ~20 ~ ~-37 ~21 ~2 ~-37 minecraft:cobblestone
fill ~20 ~ ~-23 ~21 ~2 ~-23 minecraft:cobblestone
fill ~20 ~2 ~-99 ~20 ~2 ~-98 minecraft:cobblestone
fill ~21 ~ ~-151 ~21 ~2 ~-151 minecraft:cobblestone
fill ~21 ~ ~-97 ~21 ~2 ~-97 minecraft:cobblestone
fill ~22 ~ ~-96 ~23 ~2 ~-96 minecraft:cobblestone
fill ~22 ~ ~-36 ~22 ~2 ~-35 minecraft:cobblestone
fill ~22 ~ ~-25 ~23 ~2 ~-25 minecraft:cobblestone
fill ~22 ~1 ~-152 ~23 ~2 ~-152 minecraft:cobblestone
setblock ~22 ~2 ~-24 minecraft:cobblestone
fill ~23 ~ ~-35 ~23 ~2 ~-33 minecraft:cobblestone
fill ~23 ~ ~-27 ~24 ~2 ~-27 minecraft:cobblestone
fill ~23 ~2 ~-26 ~23 ~2 ~-25 minecraft:cobblestone
fill ~24 ~ ~-95 ~28 ~2 ~-95 minecraft:cobblestone
fill ~24 ~ ~-33 ~24 ~2 ~-27 minecraft:cobblestone
fill ~24 ~1 ~-153 ~28 ~2 ~-153 minecraft:cobblestone
fill ~25 ~ ~-139 ~28 ~2 ~-139 minecraft:cobblestone
fill ~25 ~ ~-109 ~28 ~2 ~-109 minecraft:cobblestone
fill ~25 ~ ~-59 ~29 ~1 ~-59 minecraft:cobblestone
fill ~25 ~ ~-58 ~25 ~1 ~-57 minecraft:cobblestone
fill ~25 ~ ~-31 ~52 ~2 ~-31 minecraft:cobblestone
fill ~26 ~ ~-153 ~28 ~2 ~-153 minecraft:cobblestone
fill ~27 ~ ~-138 ~27 ~2 ~-109 minecraft:cobblestone
fill ~27 ~ ~-58 ~27 ~ ~-57 minecraft:cobblestone
fill ~29 ~ ~-152 ~30 ~2 ~-152 minecraft:cobblestone
fill ~29 ~ ~-140 ~30 ~2 ~-140 minecraft:cobblestone
fill ~29 ~ ~-108 ~30 ~2 ~-108 minecraft:cobblestone
fill ~29 ~ ~-96 ~30 ~2 ~-96 minecraft:cobblestone
fill ~29 ~ ~-58 ~29 ~1 ~-57 minecraft:cobblestone
fill ~31 ~ ~-151 ~31 ~2 ~-151 minecraft:cobblestone
fill ~31 ~ ~-141 ~31 ~2 ~-141 minecraft:cobblestone
fill ~31 ~ ~-107 ~31 ~2 ~-107 minecraft:cobblestone
fill ~31 ~ ~-97 ~31 ~2 ~-97 minecraft:cobblestone
fill ~32 ~ ~-143 ~32 ~2 ~-142 minecraft:cobblestone
fill ~32 ~ ~-106 ~32 ~2 ~-105 minecraft:cobblestone
fill ~32 ~ ~-99 ~32 ~2 ~-98 minecraft:cobblestone
fill ~32 ~ ~-55 ~32 ~4 ~-49 minecraft:cobblestone
fill ~32 ~1 ~-150 ~32 ~2 ~-149 minecraft:cobblestone
fill ~33 ~ ~-148 ~33 ~2 ~-144 minecraft:cobblestone
fill ~33 ~ ~-103 ~33 ~2 ~-100 minecraft:cobblestone
fill ~33 ~1 ~-104 ~33 ~2 ~-100 minecraft:cobblestone
fill ~34 ~ ~-56 ~39 ~4 ~-56 minecraft:cobblestone
fill ~34 ~ ~-49 ~39 ~4 ~-49 minecraft:cobblestone
fill ~36 ~ ~-138 ~54 ~ ~-138 minecraft:cobblestone
fill ~36 ~ ~-137 ~36 ~ ~-120 minecraft:cobblestone
fill ~37 ~ ~-120 ~54 ~ ~-120 minecraft:cobblestone
fill ~38 ~ ~-110 ~38 ~5 ~-92 minecraft:cobblestone
fill ~39 ~ ~-112 ~54 ~5 ~-112 minecraft:cobblestone
fill ~39 ~ ~-92 ~54 ~5 ~-92 minecraft:cobblestone
fill ~39 ~ ~-55 ~39 ~4 ~-49 minecraft:cobblestone
fill ~42 ~ ~-56 ~49 ~4 ~-56 minecraft:cobblestone
fill ~42 ~ ~-55 ~42 ~4 ~-49 minecraft:cobblestone
fill ~43 ~ ~-49 ~49 ~4 ~-49 minecraft:cobblestone
fill ~49 ~ ~-54 ~49 ~4 ~-49 minecraft:cobblestone
fill ~52 ~ ~-160 ~52 ~ ~-156 minecraft:cobblestone
fill ~52 ~ ~-35 ~52 ~2 ~-29 minecraft:cobblestone
fill ~52 ~1 ~-163 ~52 ~2 ~-157 minecraft:cobblestone
fill ~53 ~ ~-165 ~53 ~2 ~-164 minecraft:cobblestone
fill ~53 ~ ~-156 ~53 ~2 ~-155 minecraft:cobblestone
fill ~53 ~ ~-37 ~53 ~2 ~-36 minecraft:cobblestone
fill ~53 ~ ~-28 ~53 ~2 ~-27 minecraft:cobblestone
fill ~54 ~ ~-153 ~54 ~2 ~-153 minecraft:cobblestone
fill ~54 ~ ~-137 ~54 ~ ~-120 minecraft:cobblestone
fill ~54 ~ ~-110 ~54 ~5 ~-92 minecraft:cobblestone
fill ~54 ~ ~-39 ~54 ~2 ~-38 minecraft:cobblestone
fill ~54 ~ ~-26 ~54 ~2 ~-25 minecraft:cobblestone
fill ~54 ~2 ~-154 ~54 ~2 ~-153 minecraft:cobblestone
fill ~55 ~ ~-168 ~55 ~2 ~-168 minecraft:cobblestone
fill ~55 ~1 ~-24 ~55 ~2 ~-24 minecraft:cobblestone
fill ~56 ~ ~-169 ~56 ~2 ~-169 minecraft:cobblestone
fill ~56 ~ ~-98 ~56 ~2 ~-98 minecraft:cobblestone
fill ~56 ~ ~-94 ~56 ~2 ~-94 minecraft:cobblestone
fill ~56 ~ ~-23 ~56 ~2 ~-23 minecraft:cobblestone
fill ~57 ~ ~-170 ~58 ~2 ~-170 minecraft:cobblestone
fill ~57 ~ ~-150 ~58 ~2 ~-150 minecraft:cobblestone
fill ~57 ~ ~-93 ~57 ~2 ~-92 minecraft:cobblestone
fill ~57 ~ ~-42 ~58 ~2 ~-42 minecraft:cobblestone
fill ~57 ~1 ~-100 ~57 ~2 ~-99 minecraft:cobblestone
fill ~58 ~ ~-102 ~59 ~2 ~-102 minecraft:cobblestone
fill ~58 ~ ~-101 ~58 ~2 ~-101 minecraft:cobblestone
fill ~58 ~ ~-91 ~58 ~2 ~-90 minecraft:cobblestone
fill ~58 ~ ~-22 ~58 ~2 ~-22 minecraft:cobblestone
fill ~59 ~ ~-171 ~60 ~2 ~-171 minecraft:cobblestone
fill ~59 ~ ~-149 ~60 ~2 ~-149 minecraft:cobblestone
fill ~59 ~ ~-90 ~59 ~2 ~-90 minecraft:cobblestone
fill ~59 ~ ~-43 ~60 ~2 ~-43 minecraft:cobblestone
fill ~59 ~ ~-21 ~60 ~2 ~-21 minecraft:cobblestone
fill ~60 ~ ~-103 ~61 ~2 ~-103 minecraft:cobblestone
fill ~60 ~ ~-89 ~61 ~2 ~-89 minecraft:cobblestone
fill ~61 ~ ~-148 ~67 ~2 ~-148 minecraft:cobblestone
fill ~61 ~ ~-44 ~67 ~2 ~-44 minecraft:cobblestone
fill ~61 ~ ~-20 ~67 ~2 ~-20 minecraft:cobblestone
fill ~61 ~1 ~-172 ~67 ~2 ~-172 minecraft:cobblestone
fill ~62 ~ ~-172 ~67 ~2 ~-172 minecraft:cobblestone
fill ~62 ~ ~-104 ~66 ~2 ~-104 minecraft:cobblestone
fill ~62 ~ ~-88 ~66 ~2 ~-88 minecraft:cobblestone
fill ~65 ~ ~-146 ~65 ~2 ~-104 minecraft:cobblestone
fill ~65 ~ ~-87 ~65 ~2 ~-44 minecraft:cobblestone
fill ~65 ~1 ~-147 ~65 ~2 ~-104 minecraft:cobblestone
fill ~67 ~ ~-103 ~68 ~2 ~-103 minecraft:cobblestone
fill ~67 ~ ~-89 ~68 ~2 ~-89 minecraft:cobblestone
fill ~68 ~ ~-171 ~69 ~2 ~-171 minecraft:cobblestone
fill ~68 ~ ~-43 ~69 ~2 ~-43 minecraft:cobblestone
fill ~68 ~ ~-21 ~69 ~2 ~-21 minecraft:cobblestone
fill ~68 ~2 ~-149 ~69 ~2 ~-149 minecraft:cobblestone
fill ~69 ~ ~-149 ~69 ~2 ~-149 minecraft:cobblestone
fill ~69 ~ ~-90 ~70 ~2 ~-90 minecraft:cobblestone
fill ~69 ~1 ~-102 ~70 ~2 ~-102 minecraft:cobblestone
fill ~70 ~ ~-170 ~71 ~2 ~-170 minecraft:cobblestone
fill ~70 ~ ~-101 ~70 ~2 ~-101 minecraft:cobblestone
fill ~70 ~ ~-91 ~70 ~2 ~-90 minecraft:cobblestone
fill ~70 ~ ~-42 ~71 ~2 ~-42 minecraft:cobblestone
fill ~70 ~1 ~-150 ~71 ~2 ~-150 minecraft:cobblestone
fill ~70 ~2 ~-22 ~71 ~2 ~-22 minecraft:cobblestone
fill ~71 ~ ~-150 ~71 ~2 ~-150 minecraft:cobblestone
fill ~71 ~ ~-100 ~71 ~2 ~-99 minecraft:cobblestone
fill ~71 ~ ~-92 ~71 ~2 ~-92 minecraft:cobblestone
fill ~71 ~ ~-22 ~71 ~2 ~-22 minecraft:cobblestone
fill ~71 ~1 ~-93 ~71 ~2 ~-92 minecraft:cobblestone
fill ~72 ~ ~-151 ~72 ~2 ~-151 minecraft:cobblestone
fill ~72 ~ ~-98 ~72 ~2 ~-94 minecraft:cobblestone
fill ~72 ~ ~-41 ~72 ~2 ~-41 minecraft:cobblestone
fill ~72 ~ ~-23 ~72 ~2 ~-23 minecraft:cobblestone
fill ~72 ~1 ~-169 ~72 ~2 ~-169 minecraft:cobblestone
fill ~73 ~ ~-40 ~73 ~2 ~-40 minecraft:cobblestone
fill ~73 ~ ~-24 ~73 ~2 ~-24 minecraft:cobblestone
fill ~73 ~1 ~-152 ~73 ~2 ~-152 minecraft:cobblestone
setblock ~73 ~2 ~-168 minecraft:cobblestone
fill ~74 ~ ~-167 ~74 ~2 ~-166 minecraft:cobblestone
fill ~74 ~ ~-154 ~74 ~2 ~-153 minecraft:cobblestone
fill ~74 ~ ~-39 ~74 ~2 ~-38 minecraft:cobblestone
fill ~74 ~ ~-26 ~74 ~2 ~-25 minecraft:cobblestone
fill ~75 ~ ~-165 ~75 ~2 ~-164 minecraft:cobblestone
fill ~75 ~ ~-156 ~75 ~2 ~-155 minecraft:cobblestone
fill ~75 ~ ~-37 ~75 ~2 ~-36 minecraft:cobblestone
fill ~75 ~ ~-28 ~75 ~2 ~-27 minecraft:cobblestone
fill ~76 ~ ~-162 ~76 ~2 ~-157 minecraft:cobblestone
fill ~76 ~ ~-35 ~76 ~2 ~-29 minecraft:cobblestone
fill ~76 ~1 ~-163 ~76 ~2 ~-157 minecraft:cobblestone
setblock ~-75 ~3 ~-157 minecraft:cracked_stone_bricks
setblock ~-75 ~3 ~-34 minecraft:cracked_stone_bricks
setblock ~-75 ~5 ~-159 minecraft:cracked_stone_bricks
setblock ~-75 ~7 ~-32 minecraft:cracked_stone_bricks
setblock ~-75 ~10 ~-162 minecraft:cracked_stone_bricks
setblock ~-75 ~11 ~-158 minecraft:cracked_stone_bricks
fill ~-75 ~11 ~-31 ~-75 ~11 ~-30 minecraft:cracked_stone_bricks
setblock ~-75 ~17 ~-158 minecraft:cracked_stone_bricks
fill ~-75 ~17 ~-33 ~-74 ~17 ~-32 minecraft:cracked_stone_bricks
setblock ~-75 ~19 ~-163 minecraft:cracked_stone_bricks
fill ~-75 ~23 ~-35 ~-75 ~23 ~-34 minecraft:cracked_stone_bricks
setblock ~-75 ~24 ~-162 minecraft:cracked_stone_bricks
fill ~-75 ~24 ~-33 ~-75 ~25 ~-33 minecraft:cracked_stone_bricks
setblock ~-75 ~25 ~-29 minecraft:cracked_stone_bricks
setblock ~-75 ~27 ~-31 minecraft:cracked_stone_bricks
setblock ~-75 ~28 ~-30 minecraft:cracked_stone_bricks
setblock ~-75 ~31 ~-165 minecraft:cracked_stone_bricks
setblock ~-74 ~3 ~-28 minecraft:cracked_stone_bricks
setblock ~-74 ~4 ~-162 minecraft:cracked_stone_bricks
setblock ~-74 ~4 ~-31 minecraft:cracked_stone_bricks
setblock ~-74 ~5 ~-30 minecraft:cracked_stone_bricks
setblock ~-74 ~9 ~-36 minecraft:cracked_stone_bricks
setblock ~-74 ~11 ~-34 minecraft:cracked_stone_bricks
setblock ~-74 ~11 ~-28 minecraft:cracked_stone_bricks
setblock ~-74 ~13 ~-155 minecraft:cracked_stone_bricks
setblock ~-74 ~14 ~-31 minecraft:cracked_stone_bricks
setblock ~-74 ~15 ~-28 minecraft:cracked_stone_bricks
fill ~-74 ~16 ~-161 ~-74 ~16 ~-160 minecraft:cracked_stone_bricks
fill ~-74 ~16 ~-27 ~-74 ~17 ~-27 minecraft:cracked_stone_bricks
setblock ~-74 ~17 ~-31 minecraft:cracked_stone_bricks
setblock ~-74 ~23 ~-164 minecraft:cracked_stone_bricks
setblock ~-74 ~24 ~-28 minecraft:cracked_stone_bricks
setblock ~-74 ~25 ~-35 minecraft:cracked_stone_bricks
setblock ~-74 ~28 ~-165 minecraft:cracked_stone_bricks
setblock ~-74 ~28 ~-35 minecraft:cracked_stone_bricks
setblock ~-74 ~28 ~-29 minecraft:cracked_stone_bricks
setblock ~-74 ~29 ~-161 minecraft:cracked_stone_bricks
setblock ~-74 ~30 ~-155 minecraft:cracked_stone_bricks
setblock ~-74 ~30 ~-153 minecraft:cracked_stone_bricks
setblock ~-74 ~31 ~-26 minecraft:cracked_stone_bricks
fill ~-73 ~4 ~-155 ~-73 ~4 ~-154 minecraft:cracked_stone_bricks
setblock ~-73 ~7 ~-156 minecraft:cracked_stone_bricks
setblock ~-73 ~7 ~-36 minecraft:cracked_stone_bricks
setblock ~-73 ~8 ~-167 minecraft:cracked_stone_bricks
setblock ~-73 ~9 ~-153 minecraft:cracked_stone_bricks
setblock ~-73 ~9 ~-38 minecraft:cracked_stone_bricks
setblock ~-73 ~10 ~-154 minecraft:cracked_stone_bricks
fill ~-73 ~12 ~-39 ~-73 ~12 ~-38 minecraft:cracked_stone_bricks
setblock ~-73 ~15 ~-156 minecraft:cracked_stone_bricks
setblock ~-73 ~16 ~-36 minecraft:cracked_stone_bricks
setblock ~-73 ~17 ~-167 minecraft:cracked_stone_bricks
setblock ~-73 ~18 ~-25 minecraft:cracked_stone_bricks
setblock ~-73 ~23 ~-153 minecraft:cracked_stone_bricks
fill ~-73 ~25 ~-166 ~-72 ~25 ~-166 minecraft:cracked_stone_bricks
setblock ~-73 ~26 ~-164 minecraft:cracked_stone_bricks
fill ~-73 ~27 ~-166 ~-73 ~28 ~-166 minecraft:cracked_stone_bricks
setblock ~-73 ~27 ~-155 minecraft:cracked_stone_bricks
setblock ~-73 ~28 ~-153 minecraft:cracked_stone_bricks
setblock ~-73 ~29 ~-27 minecraft:cracked_stone_bricks
setblock ~-73 ~30 ~-34 minecraft:cracked_stone_bricks
fill ~-73 ~30 ~-32 ~-73 ~30 ~-31 minecraft:cracked_stone_bricks
setblock ~-73 ~30 ~-24 minecraft:cracked_stone_bricks
setblock ~-72 ~2 ~-154 minecraft:cracked_stone_bricks
setblock ~-72 ~3 ~-152 minecraft:cracked_stone_bricks
setblock ~-72 ~5 ~-166 minecraft:cracked_stone_bricks
setblock ~-72 ~12 ~-24 minecraft:cracked_stone_bricks
setblock ~-72 ~13 ~-40 minecraft:cracked_stone_bricks
setblock ~-72 ~13 ~-38 minecraft:cracked_stone_bricks
setblock ~-72 ~20 ~-152 minecraft:cracked_stone_bricks
setblock ~-72 ~20 ~-40 minecraft:cracked_stone_bricks
setblock ~-72 ~24 ~-40 minecraft:cracked_stone_bricks
setblock ~-72 ~26 ~-98 minecraft:cracked_stone_bricks
fill ~-72 ~28 ~-166 ~-72 ~29 ~-166 minecraft:cracked_stone_bricks
setblock ~-72 ~29 ~-154 minecraft:cracked_stone_bricks
setblock ~-72 ~30 ~-164 minecraft:cracked_stone_bricks
setblock ~-71 ~1 ~-153 minecraft:cracked_stone_bricks
fill ~-71 ~2 ~-167 ~-71 ~3 ~-167 minecraft:cracked_stone_bricks
setblock ~-71 ~5 ~-94 minecraft:cracked_stone_bricks
setblock ~-71 ~6 ~-95 minecraft:cracked_stone_bricks
fill ~-71 ~8 ~-169 ~-71 ~9 ~-169 minecraft:cracked_stone_bricks
setblock ~-71 ~9 ~-39 minecraft:cracked_stone_bricks
setblock ~-71 ~11 ~-41 minecraft:cracked_stone_bricks
setblock ~-71 ~13 ~-98 minecraft:cracked_stone_bricks
setblock ~-71 ~13 ~-23 minecraft:cracked_stone_bricks
setblock ~-71 ~18 ~-169 minecraft:cracked_stone_bricks
setblock ~-71 ~19 ~-153 minecraft:cracked_stone_bricks
setblock ~-71 ~19 ~-41 minecraft:cracked_stone_bricks
fill ~-71 ~21 ~-98 ~-71 ~22 ~-98 minecraft:cracked_stone_bricks
fill ~-71 ~21 ~-95 ~-71 ~22 ~-95 minecraft:cracked_stone_bricks
setblock ~-71 ~21 ~-39 minecraft:cracked_stone_bricks
setblock ~-71 ~24 ~-23 minecraft:cracked_stone_bricks
setblock ~-71 ~30 ~-169 minecraft:cracked_stone_bricks
setblock ~-71 ~30 ~-150 minecraft:cracked_stone_bricks
setblock ~-71 ~30 ~-36 minecraft:cracked_stone_bricks
setblock ~-70 ~1 ~-97 minecraft:cracked_stone_bricks
setblock ~-70 ~3 ~-99 minecraft:cracked_stone_bricks
setblock ~-70 ~4 ~-152 minecraft:cracked_stone_bricks
setblock ~-70 ~4 ~-100 minecraft:cracked_stone_bricks
setblock ~-70 ~5 ~-40 minecraft:cracked_stone_bricks
fill ~-70 ~6 ~-99 ~-69 ~6 ~-99 minecraft:cracked_stone_bricks
setblock ~-70 ~6 ~-92 minecraft:cracked_stone_bricks
setblock ~-70 ~8 ~-40 minecraft:cracked_stone_bricks
setblock ~-70 ~9 ~-100 minecraft:cracked_stone_bricks
setblock ~-70 ~10 ~-94 minecraft:cracked_stone_bricks
setblock ~-70 ~10 ~-24 minecraft:cracked_stone_bricks
fill ~-70 ~11 ~-96 ~-70 ~13 ~-96 minecraft:cracked_stone_bricks
setblock ~-70 ~12 ~-93 minecraft:cracked_stone_bricks
setblock ~-70 ~13 ~-100 minecraft:cracked_stone_bricks
fill ~-70 ~13 ~-41 ~-70 ~14 ~-41 minecraft:cracked_stone_bricks
setblock ~-70 ~19 ~-100 minecraft:cracked_stone_bricks
setblock ~-70 ~19 ~-95 minecraft:cracked_stone_bricks
setblock ~-70 ~20 ~-169 minecraft:cracked_stone_bricks
setblock ~-70 ~20 ~-41 minecraft:cracked_stone_bricks
setblock ~-70 ~23 ~-100 minecraft:cracked_stone_bricks
setblock ~-70 ~24 ~-92 minecraft:cracked_stone_bricks
setblock ~-70 ~25 ~-168 minecraft:cracked_stone_bricks
setblock ~-70 ~27 ~-91 minecraft:cracked_stone_bricks
setblock ~-70 ~30 ~-22 minecraft:cracked_stone_bricks
setblock ~-70 ~31 ~-170 minecraft:cracked_stone_bricks
setblock ~-69 ~1 ~-151 minecraft:cracked_stone_bricks
setblock ~-69 ~1 ~-93 minecraft:cracked_stone_bricks
setblock ~-69 ~4 ~-91 minecraft:cracked_stone_bricks
setblock ~-69 ~5 ~-22 minecraft:cracked_stone_bricks
setblock ~-69 ~6 ~-170 minecraft:cracked_stone_bricks
setblock ~-69 ~7 ~-91 minecraft:cracked_stone_bricks
setblock ~-69 ~8 ~-150 minecraft:cracked_stone_bricks
setblock ~-69 ~9 ~-41 minecraft:cracked_stone_bricks
setblock ~-69 ~10 ~-91 minecraft:cracked_stone_bricks
setblock ~-69 ~14 ~-42 minecraft:cracked_stone_bricks
setblock ~-69 ~15 ~-91 minecraft:cracked_stone_bricks
setblock ~-69 ~19 ~-170 minecraft:cracked_stone_bricks
setblock ~-69 ~19 ~-93 minecraft:cracked_stone_bricks
setblock ~-69 ~21 ~-22 minecraft:cracked_stone_bricks
setblock ~-69 ~23 ~-99 minecraft:cracked_stone_bricks
setblock ~-69 ~26 ~-42 minecraft:cracked_stone_bricks
setblock ~-69 ~28 ~-150 minecraft:cracked_stone_bricks
fill ~-69 ~30 ~-35 ~-69 ~30 ~-34 minecraft:cracked_stone_bricks
setblock ~-68 ~ ~-100 minecraft:cracked_stone_bricks
setblock ~-68 ~3 ~-90 minecraft:cracked_stone_bricks
setblock ~-68 ~5 ~-23 minecraft:cracked_stone_bricks
setblock ~-68 ~7 ~-23 minecraft:cracked_stone_bricks
setblock ~-68 ~8 ~-42 minecraft:cracked_stone_bricks
setblock ~-68 ~10 ~-100 minecraft:cracked_stone_bricks
setblock ~-68 ~10 ~-90 minecraft:cracked_stone_bricks
setblock ~-68 ~13 ~-102 minecraft:cracked_stone_bricks
setblock ~-68 ~14 ~-169 minecraft:cracked_stone_bricks
setblock ~-68 ~14 ~-150 minecraft:cracked_stone_bricks
setblock ~-68 ~19 ~-92 minecraft:cracked_stone_bricks
setblock ~-68 ~19 ~-90 minecraft:cracked_stone_bricks
setblock ~-68 ~20 ~-151 minecraft:cracked_stone_bricks
setblock ~-68 ~20 ~-100 minecraft:cracked_stone_bricks
setblock ~-68 ~23 ~-90 minecraft:cracked_stone_bricks
setblock ~-68 ~25 ~-22 minecraft:cracked_stone_bricks
setblock ~-68 ~26 ~-92 minecraft:cracked_stone_bricks
setblock ~-68 ~26 ~-90 minecraft:cracked_stone_bricks
setblock ~-68 ~28 ~-23 minecraft:cracked_stone_bricks
setblock ~-68 ~30 ~-163 minecraft:cracked_stone_bricks
setblock ~-68 ~30 ~-152 minecraft:cracked_stone_bricks
setblock ~-67 ~1 ~-170 minecraft:cracked_stone_bricks
setblock ~-67 ~1 ~-150 minecraft:cracked_stone_bricks
setblock ~-67 ~8 ~-150 minecraft:cracked_stone_bricks
setblock ~-67 ~8 ~-90 minecraft:cracked_stone_bricks
fill ~-67 ~10 ~-171 ~-66 ~10 ~-171 minecraft:cracked_stone_bricks
setblock ~-67 ~11 ~-170 minecraft:cracked_stone_bricks
setblock ~-67 ~14 ~-43 minecraft:cracked_stone_bricks
setblock ~-67 ~17 ~-90 minecraft:cracked_stone_bricks
setblock ~-67 ~19 ~-21 minecraft:cracked_stone_bricks
fill ~-67 ~21 ~-149 ~-66 ~21 ~-149 minecraft:cracked_stone_bricks
setblock ~-67 ~21 ~-102 minecraft:cracked_stone_bricks
setblock ~-67 ~22 ~-170 minecraft:cracked_stone_bricks
setblock ~-67 ~26 ~-170 minecraft:cracked_stone_bricks
setblock ~-67 ~26 ~-99 minecraft:cracked_stone_bricks
setblock ~-67 ~27 ~-149 minecraft:cracked_stone_bricks
setblock ~-67 ~30 ~-39 minecraft:cracked_stone_bricks
setblock ~-67 ~30 ~-36 minecraft:cracked_stone_bricks
setblock ~-67 ~30 ~-20 minecraft:cracked_stone_bricks
setblock ~-66 ~ ~-22 minecraft:cracked_stone_bricks
setblock ~-66 ~4 ~-90 minecraft:cracked_stone_bricks
setblock ~-66 ~4 ~-43 minecraft:cracked_stone_bricks
setblock ~-66 ~10 ~-170 minecraft:cracked_stone_bricks
setblock ~-66 ~11 ~-150 minecraft:cracked_stone_bricks
fill ~-66 ~11 ~-22 ~-65 ~11 ~-22 minecraft:cracked_stone_bricks
setblock ~-66 ~13 ~-170 minecraft:cracked_stone_bricks
setblock ~-66 ~20 ~-171 minecraft:cracked_stone_bricks
setblock ~-66 ~24 ~-102 minecraft:cracked_stone_bricks
setblock ~-66 ~26 ~-97 minecraft:cracked_stone_bricks
setblock ~-66 ~27 ~-171 minecraft:cracked_stone_bricks
fill ~-66 ~30 ~-171 ~-65 ~30 ~-171 minecraft:cracked_stone_bricks
setblock ~-66 ~30 ~-163 minecraft:cracked_stone_bricks
setblock ~-66 ~30 ~-161 minecraft:cracked_stone_bricks
setblock ~-65 ~3 ~-21 minecraft:cracked_stone_bricks
setblock ~-65 ~5 ~-43 minecraft:cracked_stone_bricks
fill ~-65 ~7 ~-103 ~-65 ~7 ~-102 minecraft:cracked_stone_bricks
setblock ~-65 ~8 ~-170 minecraft:cracked_stone_bricks
setblock ~-65 ~16 ~-90 minecraft:cracked_stone_bricks
setblock ~-65 ~17 ~-140 minecraft:cracked_stone_bricks
setblock ~-65 ~17 ~-135 minecraft:cracked_stone_bricks
setblock ~-65 ~17 ~-125 minecraft:cracked_stone_bricks
setblock ~-65 ~17 ~-86 minecraft:cracked_stone_bricks
setblock ~-65 ~17 ~-62 minecraft:cracked_stone_bricks
setblock ~-65 ~17 ~-50 minecraft:cracked_stone_bricks
setblock ~-65 ~18 ~-85 minecraft:cracked_stone_bricks
setblock ~-65 ~18 ~-69 minecraft:cracked_stone_bricks
setblock ~-65 ~18 ~-56 minecraft:cracked_stone_bricks
setblock ~-65 ~19 ~-137 minecraft:cracked_stone_bricks
setblock ~-65 ~19 ~-116 minecraft:cracked_stone_bricks
setblock ~-65 ~19 ~-114 minecraft:cracked_stone_bricks
fill ~-65 ~19 ~-79 ~-65 ~19 ~-78 minecraft:cracked_stone_bricks
setblock ~-65 ~19 ~-75 minecraft:cracked_stone_bricks
setblock ~-65 ~20 ~-170 minecraft:cracked_stone_bricks
fill ~-65 ~20 ~-111 ~-65 ~21 ~-111 minecraft:cracked_stone_bricks
setblock ~-65 ~20 ~-89 minecraft:cracked_stone_bricks
setblock ~-65 ~20 ~-45 minecraft:cracked_stone_bricks
setblock ~-65 ~23 ~-21 minecraft:cracked_stone_bricks
fill ~-65 ~25 ~-149 ~-65 ~26 ~-149 minecraft:cracked_stone_bricks
setblock ~-65 ~25 ~-90 minecraft:cracked_stone_bricks
setblock ~-65 ~26 ~-96 minecraft:cracked_stone_bricks
setblock ~-65 ~26 ~-43 minecraft:cracked_stone_bricks
fill ~-65 ~28 ~-22 ~-65 ~28 ~-21 minecraft:cracked_stone_bricks
setblock ~-65 ~30 ~-156 minecraft:cracked_stone_bricks
setblock ~-65 ~30 ~-29 minecraft:cracked_stone_bricks
setblock ~-64 ~3 ~-141 minecraft:cracked_stone_bricks
setblock ~-64 ~3 ~-126 minecraft:cracked_stone_bricks
setblock ~-64 ~3 ~-116 minecraft:cracked_stone_bricks
setblock ~-64 ~3 ~-107 minecraft:cracked_stone_bricks
setblock ~-64 ~3 ~-87 minecraft:cracked_stone_bricks
setblock ~-64 ~4 ~-84 minecraft:cracked_stone_bricks
fill ~-64 ~4 ~-71 ~-64 ~4 ~-70 minecraft:cracked_stone_bricks
fill ~-64 ~4 ~-61 ~-64 ~5 ~-61 minecraft:cracked_stone_bricks
setblock ~-64 ~5 ~-106 minecraft:cracked_stone_bricks
setblock ~-64 ~5 ~-77 minecraft:cracked_stone_bricks
setblock ~-64 ~5 ~-59 minecraft:cracked_stone_bricks
setblock ~-64 ~6 ~-135 minecraft:cracked_stone_bricks
setblock ~-64 ~6 ~-130 minecraft:cracked_stone_bricks
setblock ~-64 ~6 ~-64 minecraft:cracked_stone_bricks
fill ~-64 ~6 ~-49 ~-64 ~6 ~-48 minecraft:cracked_stone_bricks
setblock ~-64 ~7 ~-147 minecraft:cracked_stone_bricks
setblock ~-64 ~7 ~-78 minecraft:cracked_stone_bricks
setblock ~-64 ~7 ~-71 minecraft:cracked_stone_bricks
setblock ~-64 ~7 ~-66 minecraft:cracked_stone_bricks
setblock ~-64 ~8 ~-110 minecraft:cracked_stone_bricks
setblock ~-64 ~8 ~-55 minecraft:cracked_stone_bricks
setblock ~-64 ~9 ~-145 minecraft:cracked_stone_bricks
setblock ~-64 ~9 ~-77 minecraft:cracked_stone_bricks
setblock ~-64 ~9 ~-50 minecraft:cracked_stone_bricks
setblock ~-64 ~10 ~-133 minecraft:cracked_stone_bricks
setblock ~-64 ~10 ~-129 minecraft:cracked_stone_bricks
fill ~-64 ~10 ~-126 ~-64 ~10 ~-125 minecraft:cracked_stone_bricks
setblock ~-64 ~10 ~-108 minecraft:cracked_stone_bricks
setblock ~-64 ~10 ~-102 minecraft:cracked_stone_bricks
setblock ~-64 ~10 ~-88 minecraft:cracked_stone_bricks
setblock ~-64 ~10 ~-82 minecraft:cracked_stone_bricks
setblock ~-64 ~10 ~-61 minecraft:cracked_stone_bricks
setblock ~-64 ~11 ~-146 minecraft:cracked_stone_bricks
setblock ~-64 ~11 ~-141 minecraft:cracked_stone_bricks
setblock ~-64 ~11 ~-84 minecraft:cracked_stone_bricks
setblock ~-64 ~12 ~-125 minecraft:cracked_stone_bricks
setblock ~-64 ~12 ~-122 minecraft:cracked_stone_bricks
setblock ~-64 ~12 ~-65 minecraft:cracked_stone_bricks
setblock ~-64 ~12 ~-57 minecraft:cracked_stone_bricks
setblock ~-64 ~13 ~-117 minecraft:cracked_stone_bricks
setblock ~-64 ~13 ~-56 minecraft:cracked_stone_bricks
fill ~-64 ~14 ~-123 ~-64 ~14 ~-122 minecraft:cracked_stone_bricks
setblock ~-64 ~14 ~-112 minecraft:cracked_stone_bricks
setblock ~-64 ~14 ~-75 minecraft:cracked_stone_bricks
setblock ~-64 ~15 ~-143 minecraft:cracked_stone_bricks
setblock ~-64 ~15 ~-122 minecraft:cracked_stone_bricks
setblock ~-64 ~15 ~-63 minecraft:cracked_stone_bricks
setblock ~-64 ~15 ~-54 minecraft:cracked_stone_bricks
setblock ~-64 ~15 ~-52 minecraft:cracked_stone_bricks
setblock ~-64 ~15 ~-46 minecraft:cracked_stone_bricks
fill ~-64 ~16 ~-102 ~-63 ~16 ~-102 minecraft:cracked_stone_bricks
setblock ~-64 ~18 ~-136 minecraft:cracked_stone_bricks
setblock ~-64 ~18 ~-124 minecraft:cracked_stone_bricks
setblock ~-64 ~18 ~-78 minecraft:cracked_stone_bricks
setblock ~-64 ~18 ~-59 minecraft:cracked_stone_bricks
setblock ~-64 ~18 ~-47 minecraft:cracked_stone_bricks
setblock ~-64 ~23 ~-103 minecraft:cracked_stone_bricks
setblock ~-64 ~24 ~-21 minecraft:cracked_stone_bricks
setblock ~-64 ~28 ~-21 minecraft:cracked_stone_bricks
setblock ~-64 ~30 ~-148 minecraft:cracked_stone_bricks
setblock ~-63 ~5 ~-42 minecraft:cracked_stone_bricks
setblock ~-63 ~8 ~-171 minecraft:cracked_stone_bricks
setblock ~-63 ~8 ~-124 minecraft:cracked_stone_bricks
setblock ~-63 ~8 ~-68 minecraft:cracked_stone_bricks
setblock ~-63 ~9 ~-170 minecraft:cracked_stone_bricks
setblock ~-63 ~9 ~-150 minecraft:cracked_stone_bricks
setblock ~-63 ~14 ~-150 minecraft:cracked_stone_bricks
setblock ~-63 ~16 ~-170 minecraft:cracked_stone_bricks
setblock ~-63 ~16 ~-22 minecraft:cracked_stone_bricks
setblock ~-63 ~18 ~-150 minecraft:cracked_stone_bricks
setblock ~-63 ~18 ~-135 minecraft:cracked_stone_bricks
setblock ~-63 ~18 ~-108 minecraft:cracked_stone_bricks
setblock ~-63 ~25 ~-171 minecraft:cracked_stone_bricks
setblock ~-63 ~26 ~-93 minecraft:cracked_stone_bricks
setblock ~-63 ~30 ~-163 minecraft:cracked_stone_bricks
setblock ~-63 ~30 ~-157 minecraft:cracked_stone_bricks
setblock ~-63 ~30 ~-39 minecraft:cracked_stone_bricks
fill ~-63 ~30 ~-25 ~-63 ~30 ~-24 minecraft:cracked_stone_bricks
setblock ~-63 ~31 ~-148 minecraft:cracked_stone_bricks
setblock ~-62 ~3 ~-42 minecraft:cracked_stone_bricks
setblock ~-62 ~5 ~-171 minecraft:cracked_stone_bricks
setblock ~-62 ~8 ~-170 minecraft:cracked_stone_bricks
setblock ~-62 ~8 ~-102 minecraft:cracked_stone_bricks
setblock ~-62 ~8 ~-90 minecraft:cracked_stone_bricks
setblock ~-62 ~8 ~-21 minecraft:cracked_stone_bricks
setblock ~-62 ~18 ~-87 minecraft:cracked_stone_bricks
setblock ~-62 ~18 ~-79 minecraft:cracked_stone_bricks
setblock ~-62 ~18 ~-66 minecraft:cracked_stone_bricks
fill ~-62 ~18 ~-51 ~-61 ~18 ~-51 minecraft:cracked_stone_bricks
setblock ~-62 ~18 ~-42 minecraft:cracked_stone_bricks
setblock ~-62 ~22 ~-170 minecraft:cracked_stone_bricks
setblock ~-62 ~24 ~-43 minecraft:cracked_stone_bricks
setblock ~-62 ~25 ~-150 minecraft:cracked_stone_bricks
setblock ~-62 ~26 ~-92 minecraft:cracked_stone_bricks
setblock ~-62 ~26 ~-89 minecraft:cracked_stone_bricks
setblock ~-62 ~27 ~-43 minecraft:cracked_stone_bricks
setblock ~-62 ~30 ~-158 minecraft:cracked_stone_bricks
setblock ~-62 ~30 ~-148 minecraft:cracked_stone_bricks
setblock ~-61 ~2 ~-170 minecraft:cracked_stone_bricks
setblock ~-61 ~4 ~-150 minecraft:cracked_stone_bricks
setblock ~-61 ~8 ~-101 minecraft:cracked_stone_bricks
setblock ~-61 ~12 ~-91 minecraft:cracked_stone_bricks
setblock ~-61 ~13 ~-42 minecraft:cracked_stone_bricks
setblock ~-61 ~16 ~-170 minecraft:cracked_stone_bricks
setblock ~-61 ~18 ~-143 minecraft:cracked_stone_bricks
setblock ~-61 ~18 ~-136 minecraft:cracked_stone_bricks
setblock ~-61 ~18 ~-129 minecraft:cracked_stone_bricks
setblock ~-61 ~18 ~-121 minecraft:cracked_stone_bricks
setblock ~-61 ~18 ~-118 minecraft:cracked_stone_bricks
setblock ~-61 ~18 ~-102 minecraft:cracked_stone_bricks
setblock ~-61 ~18 ~-49 minecraft:cracked_stone_bricks
setblock ~-61 ~22 ~-149 minecraft:cracked_stone_bricks
setblock ~-61 ~24 ~-171 minecraft:cracked_stone_bricks
setblock ~-61 ~24 ~-102 minecraft:cracked_stone_bricks
setblock ~-61 ~24 ~-91 minecraft:cracked_stone_bricks
setblock ~-61 ~25 ~-43 minecraft:cracked_stone_bricks
setblock ~-61 ~26 ~-170 minecraft:cracked_stone_bricks
setblock ~-61 ~26 ~-21 minecraft:cracked_stone_bricks
setblock ~-61 ~27 ~-150 minecraft:cracked_stone_bricks
setblock ~-60 ~ ~-110 minecraft:cracked_stone_bricks
setblock ~-60 ~ ~-77 minecraft:cracked_stone_bricks
fill ~-60 ~1 ~-148 ~-60 ~1 ~-147 minecraft:cracked_stone_bricks
setblock ~-60 ~1 ~-111 minecraft:cracked_stone_bricks
setblock ~-60 ~1 ~-109 minecraft:cracked_stone_bricks
setblock ~-60 ~1 ~-85 minecraft:cracked_stone_bricks
setblock ~-60 ~1 ~-74 minecraft:cracked_stone_bricks
setblock ~-60 ~1 ~-56 minecraft:cracked_stone_bricks
setblock ~-60 ~1 ~-52 minecraft:cracked_stone_bricks
setblock ~-60 ~2 ~-143 minecraft:cracked_stone_bricks
setblock ~-60 ~2 ~-132 minecraft:cracked_stone_bricks
setblock ~-60 ~2 ~-125 minecraft:cracked_stone_bricks
setblock ~-60 ~2 ~-106 minecraft:cracked_stone_bricks
setblock ~-60 ~2 ~-76 minecraft:cracked_stone_bricks
setblock ~-60 ~2 ~-44 minecraft:cracked_stone_bricks
fill ~-60 ~3 ~-138 ~-60 ~4 ~-138 minecraft:cracked_stone_bricks
setblock ~-60 ~3 ~-77 minecraft:cracked_stone_bricks
setblock ~-60 ~3 ~-68 minecraft:cracked_stone_bricks
setblock ~-60 ~4 ~-170 minecraft:cracked_stone_bricks
setblock ~-60 ~4 ~-148 minecraft:cracked_stone_bricks
setblock ~-60 ~4 ~-136 minecraft:cracked_stone_bricks
setblock ~-60 ~4 ~-108 minecraft:cracked_stone_bricks
setblock ~-60 ~4 ~-81 minecraft:cracked_stone_bricks
setblock ~-60 ~4 ~-66 minecraft:cracked_stone_bricks
setblock ~-60 ~5 ~-139 minecraft:cracked_stone_bricks
setblock ~-60 ~5 ~-132 minecraft:cracked_stone_bricks
setblock ~-60 ~5 ~-80 minecraft:cracked_stone_bricks
setblock ~-60 ~5 ~-64 minecraft:cracked_stone_bricks
setblock ~-60 ~5 ~-61 minecraft:cracked_stone_bricks
setblock ~-60 ~6 ~-44 minecraft:cracked_stone_bricks
setblock ~-60 ~7 ~-135 minecraft:cracked_stone_bricks
setblock ~-60 ~7 ~-132 minecraft:cracked_stone_bricks
setblock ~-60 ~7 ~-115 minecraft:cracked_stone_bricks
setblock ~-60 ~7 ~-110 minecraft:cracked_stone_bricks
setblock ~-60 ~7 ~-85 minecraft:cracked_stone_bricks
setblock ~-60 ~7 ~-68 minecraft:cracked_stone_bricks
setblock ~-60 ~8 ~-92 minecraft:cracked_stone_bricks
setblock ~-60 ~8 ~-52 minecraft:cracked_stone_bricks
setblock ~-60 ~8 ~-49 minecraft:cracked_stone_bricks
setblock ~-60 ~9 ~-170 minecraft:cracked_stone_bricks
setblock ~-60 ~9 ~-48 minecraft:cracked_stone_bricks
setblock ~-60 ~10 ~-151 minecraft:cracked_stone_bricks
fill ~-60 ~10 ~-112 ~-60 ~11 ~-112 minecraft:cracked_stone_bricks
setblock ~-60 ~10 ~-75 minecraft:cracked_stone_bricks
setblock ~-60 ~10 ~-68 minecraft:cracked_stone_bricks
fill ~-60 ~10 ~-59 ~-60 ~10 ~-58 minecraft:cracked_stone_bricks
setblock ~-60 ~11 ~-146 minecraft:cracked_stone_bricks
setblock ~-60 ~11 ~-143 minecraft:cracked_stone_bricks
setblock ~-60 ~11 ~-110 minecraft:cracked_stone_bricks
setblock ~-60 ~12 ~-149 minecraft:cracked_stone_bricks
setblock ~-60 ~12 ~-145 minecraft:cracked_stone_bricks
setblock ~-60 ~12 ~-134 minecraft:cracked_stone_bricks
setblock ~-60 ~12 ~-130 minecraft:cracked_stone_bricks
setblock ~-60 ~12 ~-109 minecraft:cracked_stone_bricks
setblock ~-60 ~12 ~-63 minecraft:cracked_stone_bricks
setblock ~-60 ~13 ~-114 minecraft:cracked_stone_bricks
setblock ~-60 ~13 ~-74 minecraft:cracked_stone_bricks
setblock ~-60 ~13 ~-67 minecraft:cracked_stone_bricks
setblock ~-60 ~13 ~-53 minecraft:cracked_stone_bricks
setblock ~-60 ~14 ~-133 minecraft:cracked_stone_bricks
setblock ~-60 ~14 ~-129 minecraft:cracked_stone_bricks
setblock ~-60 ~14 ~-127 minecraft:cracked_stone_bricks
setblock ~-60 ~14 ~-125 minecraft:cracked_stone_bricks
setblock ~-60 ~14 ~-81 minecraft:cracked_stone_bricks
setblock ~-60 ~14 ~-58 minecraft:cracked_stone_bricks
setblock ~-60 ~15 ~-130 minecraft:cracked_stone_bricks
setblock ~-60 ~15 ~-121 minecraft:cracked_stone_bricks
setblock ~-60 ~15 ~-111 minecraft:cracked_stone_bricks
fill ~-60 ~15 ~-77 ~-60 ~15 ~-76 minecraft:cracked_stone_bricks
setblock ~-60 ~15 ~-53 minecraft:cracked_stone_bricks
setblock ~-60 ~15 ~-48 minecraft:cracked_stone_bricks
fill ~-60 ~16 ~-149 ~-60 ~16 ~-148 minecraft:cracked_stone_bricks
setblock ~-60 ~16 ~-54 minecraft:cracked_stone_bricks
setblock ~-60 ~16 ~-51 minecraft:cracked_stone_bricks
setblock ~-60 ~17 ~-132 minecraft:cracked_stone_bricks
setblock ~-60 ~17 ~-84 minecraft:cracked_stone_bricks
setblock ~-60 ~17 ~-72 minecraft:cracked_stone_bricks
setblock ~-60 ~17 ~-58 minecraft:cracked_stone_bricks
fill ~-60 ~18 ~-81 ~-60 ~19 ~-81 minecraft:cracked_stone_bricks
fill ~-60 ~18 ~-67 ~-60 ~19 ~-67 minecraft:cracked_stone_bricks
fill ~-60 ~18 ~-42 ~-59 ~18 ~-42 minecraft:cracked_stone_bricks
setblock ~-60 ~20 ~-22 minecraft:cracked_stone_bricks
setblock ~-60 ~21 ~-42 minecraft:cracked_stone_bricks
setblock ~-60 ~23 ~-22 minecraft:cracked_stone_bricks
setblock ~-60 ~24 ~-42 minecraft:cracked_stone_bricks
setblock ~-60 ~25 ~-150 minecraft:cracked_stone_bricks
setblock ~-60 ~25 ~-100 minecraft:cracked_stone_bricks
setblock ~-60 ~26 ~-169 minecraft:cracked_stone_bricks
setblock ~-60 ~27 ~-89 minecraft:cracked_stone_bricks
setblock ~-60 ~28 ~-170 minecraft:cracked_stone_bricks
setblock ~-60 ~30 ~-152 minecraft:cracked_stone_bricks
setblock ~-60 ~30 ~-30 minecraft:cracked_stone_bricks
setblock ~-59 ~5 ~-151 minecraft:cracked_stone_bricks
setblock ~-59 ~7 ~-150 minecraft:cracked_stone_bricks
setblock ~-59 ~7 ~-41 minecraft:cracked_stone_bricks
fill ~-59 ~7 ~-22 ~-59 ~8 ~-22 minecraft:cracked_stone_bricks
setblock ~-59 ~8 ~-169 minecraft:cracked_stone_bricks
setblock ~-59 ~9 ~-41 minecraft:cracked_stone_bricks
setblock ~-59 ~12 ~-170 minecraft:cracked_stone_bricks
setblock ~-59 ~12 ~-99 minecraft:cracked_stone_bricks
fill ~-59 ~17 ~-91 ~-59 ~18 ~-91 minecraft:cracked_stone_bricks
setblock ~-59 ~18 ~-101 minecraft:cracked_stone_bricks
setblock ~-59 ~19 ~-169 minecraft:cracked_stone_bricks
setblock ~-59 ~20 ~-101 minecraft:cracked_stone_bricks
fill ~-59 ~20 ~-93 ~-59 ~21 ~-93 minecraft:cracked_stone_bricks
setblock ~-59 ~21 ~-99 minecraft:cracked_stone_bricks
setblock ~-59 ~26 ~-41 minecraft:cracked_stone_bricks
setblock ~-59 ~30 ~-157 minecraft:cracked_stone_bricks
setblock ~-59 ~30 ~-150 minecraft:cracked_stone_bricks
setblock ~-59 ~32 ~-171 minecraft:cracked_stone_bricks
setblock ~-58 ~2 ~-152 minecraft:cracked_stone_bricks
setblock ~-58 ~3 ~-94 minecraft:cracked_stone_bricks
setblock ~-58 ~4 ~-169 minecraft:cracked_stone_bricks
setblock ~-58 ~4 ~-96 minecraft:cracked_stone_bricks
setblock ~-58 ~5 ~-95 minecraft:cracked_stone_bricks
setblock ~-58 ~5 ~-23 minecraft:cracked_stone_bricks
setblock ~-58 ~7 ~-96 minecraft:cracked_stone_bricks
setblock ~-58 ~8 ~-41 minecraft:cracked_stone_bricks
fill ~-58 ~10 ~-93 ~-58 ~11 ~-93 minecraft:cracked_stone_bricks
setblock ~-58 ~11 ~-96 minecraft:cracked_stone_bricks
setblock ~-58 ~12 ~-92 minecraft:cracked_stone_bricks
setblock ~-58 ~13 ~-95 minecraft:cracked_stone_bricks
setblock ~-58 ~14 ~-97 minecraft:cracked_stone_bricks
setblock ~-58 ~15 ~-24 minecraft:cracked_stone_bricks
setblock ~-58 ~17 ~-96 minecraft:cracked_stone_bricks
setblock ~-58 ~19 ~-99 minecraft:cracked_stone_bricks
setblock ~-58 ~21 ~-97 minecraft:cracked_stone_bricks
setblock ~-58 ~22 ~-169 minecraft:cracked_stone_bricks
setblock ~-58 ~25 ~-97 minecraft:cracked_stone_bricks
setblock ~-58 ~27 ~-40 minecraft:cracked_stone_bricks
setblock ~-58 ~30 ~-161 minecraft:cracked_stone_bricks
setblock ~-58 ~30 ~-42 minecraft:cracked_stone_bricks
fill ~-57 ~3 ~-153 ~-57 ~4 ~-153 minecraft:cracked_stone_bricks
setblock ~-57 ~3 ~-23 minecraft:cracked_stone_bricks
setblock ~-57 ~4 ~-25 minecraft:cracked_stone_bricks
setblock ~-57 ~9 ~-98 minecraft:cracked_stone_bricks
setblock ~-57 ~11 ~-25 minecraft:cracked_stone_bricks
setblock ~-57 ~12 ~-95 minecraft:cracked_stone_bricks
setblock ~-57 ~14 ~-169 minecraft:cracked_stone_bricks
setblock ~-57 ~14 ~-153 minecraft:cracked_stone_bricks
setblock ~-57 ~15 ~-96 minecraft:cracked_stone_bricks
setblock ~-57 ~17 ~-167 minecraft:cracked_stone_bricks
setblock ~-57 ~17 ~-153 minecraft:cracked_stone_bricks
setblock ~-57 ~20 ~-153 minecraft:cracked_stone_bricks
setblock ~-57 ~21 ~-94 minecraft:cracked_stone_bricks
setblock ~-57 ~24 ~-94 minecraft:cracked_stone_bricks
setblock ~-57 ~27 ~-92 minecraft:cracked_stone_bricks
setblock ~-57 ~28 ~-167 minecraft:cracked_stone_bricks
setblock ~-57 ~30 ~-153 minecraft:cracked_stone_bricks
setblock ~-57 ~31 ~-150 minecraft:cracked_stone_bricks
setblock ~-56 ~5 ~-26 minecraft:cracked_stone_bricks
fill ~-56 ~18 ~-152 ~-56 ~19 ~-152 minecraft:cracked_stone_bricks
setblock ~-56 ~23 ~-152 minecraft:cracked_stone_bricks
setblock ~-56 ~23 ~-26 minecraft:cracked_stone_bricks
setblock ~-56 ~25 ~-24 minecraft:cracked_stone_bricks
setblock ~-56 ~27 ~-154 minecraft:cracked_stone_bricks
setblock ~-56 ~27 ~-152 minecraft:cracked_stone_bricks
setblock ~-56 ~28 ~-98 minecraft:cracked_stone_bricks
setblock ~-55 ~1 ~-164 minecraft:cracked_stone_bricks
setblock ~-55 ~1 ~-27 minecraft:cracked_stone_bricks
setblock ~-55 ~3 ~-25 minecraft:cracked_stone_bricks
setblock ~-55 ~4 ~-166 minecraft:cracked_stone_bricks
setblock ~-55 ~4 ~-36 minecraft:cracked_stone_bricks
fill ~-55 ~4 ~-27 ~-55 ~5 ~-27 minecraft:cracked_stone_bricks
setblock ~-55 ~7 ~-26 minecraft:cracked_stone_bricks
setblock ~-55 ~8 ~-153 minecraft:cracked_stone_bricks
fill ~-55 ~8 ~-25 ~-55 ~9 ~-25 minecraft:cracked_stone_bricks
setblock ~-55 ~9 ~-154 minecraft:cracked_stone_bricks
setblock ~-55 ~10 ~-165 minecraft:cracked_stone_bricks
setblock ~-55 ~14 ~-37 minecraft:cracked_stone_bricks
setblock ~-55 ~15 ~-165 minecraft:cracked_stone_bricks
setblock ~-55 ~16 ~-36 minecraft:cracked_stone_bricks
setblock ~-55 ~17 ~-155 minecraft:cracked_stone_bricks
setblock ~-55 ~19 ~-167 minecraft:cracked_stone_bricks
setblock ~-55 ~21 ~-38 minecraft:cracked_stone_bricks
setblock ~-55 ~21 ~-26 minecraft:cracked_stone_bricks
setblock ~-55 ~22 ~-153 minecraft:cracked_stone_bricks
setblock ~-55 ~25 ~-38 minecraft:cracked_stone_bricks
setblock ~-55 ~27 ~-28 minecraft:cracked_stone_bricks
setblock ~-55 ~28 ~-166 minecraft:cracked_stone_bricks
setblock ~-55 ~30 ~-168 minecraft:cracked_stone_bricks
setblock ~-54 ~ ~-161 minecraft:cracked_stone_bricks
setblock ~-54 ~2 ~-160 minecraft:cracked_stone_bricks
fill ~-54 ~2 ~-132 ~-54 ~4 ~-132 minecraft:cracked_stone_bricks
setblock ~-54 ~2 ~-32 minecraft:cracked_stone_bricks
setblock ~-54 ~4 ~-129 minecraft:cracked_stone_bricks
setblock ~-54 ~5 ~-137 minecraft:cracked_stone_bricks
fill ~-54 ~7 ~-162 ~-53 ~7 ~-162 minecraft:cracked_stone_bricks
setblock ~-54 ~7 ~-129 minecraft:cracked_stone_bricks
fill ~-54 ~7 ~-122 ~-54 ~7 ~-121 minecraft:cracked_stone_bricks
setblock ~-54 ~8 ~-32 minecraft:cracked_stone_bricks
setblock ~-54 ~11 ~-163 minecraft:cracked_stone_bricks
fill ~-54 ~13 ~-162 ~-53 ~13 ~-162 minecraft:cracked_stone_bricks
setblock ~-54 ~14 ~-157 minecraft:cracked_stone_bricks
setblock ~-54 ~15 ~-34 minecraft:cracked_stone_bricks
setblock ~-54 ~17 ~-164 minecraft:cracked_stone_bricks
setblock ~-54 ~19 ~-162 minecraft:cracked_stone_bricks
setblock ~-54 ~19 ~-31 minecraft:cracked_stone_bricks
setblock ~-54 ~21 ~-27 minecraft:cracked_stone_bricks
setblock ~-54 ~22 ~-34 minecraft:cracked_stone_bricks
setblock ~-54 ~23 ~-163 minecraft:cracked_stone_bricks
setblock ~-54 ~25 ~-163 minecraft:cracked_stone_bricks
fill ~-54 ~25 ~-155 ~-54 ~26 ~-155 minecraft:cracked_stone_bricks
setblock ~-54 ~25 ~-33 minecraft:cracked_stone_bricks
setblock ~-54 ~28 ~-161 minecraft:cracked_stone_bricks
setblock ~-54 ~28 ~-158 minecraft:cracked_stone_bricks
setblock ~-54 ~28 ~-30 minecraft:cracked_stone_bricks
setblock ~-54 ~28 ~-28 minecraft:cracked_stone_bricks
setblock ~-54 ~29 ~-163 minecraft:cracked_stone_bricks
setblock ~-54 ~29 ~-159 minecraft:cracked_stone_bricks
setblock ~-54 ~31 ~-38 minecraft:cracked_stone_bricks
setblock ~-53 ~7 ~-30 minecraft:cracked_stone_bricks
setblock ~-53 ~12 ~-36 minecraft:cracked_stone_bricks
setblock ~-53 ~12 ~-31 minecraft:cracked_stone_bricks
fill ~-53 ~13 ~-163 ~-53 ~13 ~-162 minecraft:cracked_stone_bricks
fill ~-53 ~18 ~-159 ~-52 ~18 ~-159 minecraft:cracked_stone_bricks
setblock ~-53 ~19 ~-161 minecraft:cracked_stone_bricks
setblock ~-53 ~21 ~-158 minecraft:cracked_stone_bricks
setblock ~-53 ~22 ~-157 minecraft:cracked_stone_bricks
setblock ~-53 ~22 ~-29 minecraft:cracked_stone_bricks
setblock ~-53 ~30 ~-160 minecraft:cracked_stone_bricks
fill ~-53 ~30 ~-28 ~-53 ~30 ~-27 minecraft:cracked_stone_bricks
setblock ~-52 ~1 ~-156 minecraft:cracked_stone_bricks
setblock ~-52 ~8 ~-32 minecraft:cracked_stone_bricks
setblock ~-52 ~10 ~-32 minecraft:cracked_stone_bricks
setblock ~-52 ~12 ~-32 minecraft:cracked_stone_bricks
setblock ~-52 ~14 ~-156 minecraft:cracked_stone_bricks
setblock ~-52 ~15 ~-32 minecraft:cracked_stone_bricks
setblock ~-52 ~16 ~-156 minecraft:cracked_stone_bricks
fill ~-52 ~19 ~-31 ~-51 ~19 ~-31 minecraft:cracked_stone_bricks
setblock ~-52 ~31 ~-30 minecraft:cracked_stone_bricks
setblock ~-52 ~32 ~-160 minecraft:cracked_stone_bricks
setblock ~-50 ~3 ~-156 minecraft:cracked_stone_bricks
setblock ~-50 ~6 ~-156 minecraft:cracked_stone_bricks
setblock ~-50 ~6 ~-120 minecraft:cracked_stone_bricks
setblock ~-50 ~7 ~-32 minecraft:cracked_stone_bricks
setblock ~-49 ~15 ~-156 minecraft:cracked_stone_bricks
setblock ~-49 ~18 ~-35 minecraft:cracked_stone_bricks
fill ~-49 ~20 ~-31 ~-49 ~21 ~-31 minecraft:cracked_stone_bricks
setblock ~-48 ~3 ~-138 minecraft:cracked_stone_bricks
setblock ~-48 ~5 ~-138 minecraft:cracked_stone_bricks
setblock ~-48 ~7 ~-36 minecraft:cracked_stone_bricks
setblock ~-48 ~11 ~-156 minecraft:cracked_stone_bricks
setblock ~-48 ~18 ~-158 minecraft:cracked_stone_bricks
fill ~-48 ~18 ~-156 ~-48 ~19 ~-156 minecraft:cracked_stone_bricks
setblock ~-47 ~5 ~-36 minecraft:cracked_stone_bricks
setblock ~-47 ~11 ~-32 minecraft:cracked_stone_bricks
setblock ~-47 ~18 ~-33 minecraft:cracked_stone_bricks
fill ~-46 ~1 ~-138 ~-46 ~3 ~-138 minecraft:cracked_stone_bricks
setblock ~-46 ~5 ~-138 minecraft:cracked_stone_bricks
setblock ~-46 ~5 ~-32 minecraft:cracked_stone_bricks
setblock ~-46 ~8 ~-160 minecraft:cracked_stone_bricks
setblock ~-46 ~14 ~-36 minecraft:cracked_stone_bricks
setblock ~-46 ~18 ~-159 minecraft:cracked_stone_bricks
setblock ~-45 ~9 ~-156 minecraft:cracked_stone_bricks
setblock ~-45 ~14 ~-156 minecraft:cracked_stone_bricks
setblock ~-45 ~20 ~-31 minecraft:cracked_stone_bricks
setblock ~-44 ~ ~-36 minecraft:cracked_stone_bricks
setblock ~-44 ~2 ~-36 minecraft:cracked_stone_bricks
setblock ~-44 ~7 ~-138 minecraft:cracked_stone_bricks
fill ~-44 ~10 ~-156 ~-44 ~11 ~-156 minecraft:cracked_stone_bricks
setblock ~-43 ~ ~-156 minecraft:cracked_stone_bricks
