fill ~-87 ~-6 ~-10 ~-87 ~-1 ~-10 minecraft:gravel
fill ~-86 ~-6 ~-173 ~-86 ~-1 ~-173 minecraft:gravel
fill ~-86 ~-6 ~-165 ~-86 ~-1 ~-165 minecraft:gravel
fill ~-86 ~-6 ~-163 ~-86 ~-1 ~-163 minecraft:gravel
fill ~-86 ~-6 ~-160 ~-86 ~-1 ~-160 minecraft:gravel
fill ~-86 ~-6 ~-152 ~-85 ~-1 ~-152 minecraft:gravel
fill ~-86 ~-6 ~-142 ~-85 ~-1 ~-142 minecraft:gravel
fill ~-86 ~-6 ~-135 ~-84 ~-1 ~-135 minecraft:gravel
fill ~-86 ~-6 ~-98 ~-86 ~-1 ~-97 minecraft:gravel
fill ~-86 ~-6 ~-93 ~-84 ~-1 ~-93 minecraft:gravel
fill ~-86 ~-6 ~-87 ~-86 ~-1 ~-87 minecraft:gravel
fill ~-86 ~-6 ~-81 ~-85 ~-1 ~-81 minecraft:gravel
fill ~-86 ~-6 ~-78 ~-86 ~-1 ~-78 minecraft:gravel
fill ~-86 ~-6 ~-74 ~-86 ~-1 ~-73 minecraft:gravel
fill ~-86 ~-6 ~-66 ~-86 ~-1 ~-66 minecraft:gravel
fill ~-86 ~-6 ~-64 ~-86 ~-1 ~-63 minecraft:gravel
fill ~-86 ~-6 ~-61 ~-84 ~-1 ~-61 minecraft:gravel
fill ~-86 ~-6 ~-59 ~-86 ~-1 ~-59 minecraft:gravel
fill ~-86 ~-6 ~-56 ~-86 ~-1 ~-56 minecraft:gravel
fill ~-86 ~-6 ~-51 ~-86 ~-1 ~-49 minecraft:gravel
fill ~-86 ~-6 ~-44 ~-86 ~-1 ~-44 minecraft:gravel
fill ~-86 ~-6 ~-42 ~-86 ~-1 ~-42 minecraft:gravel
fill ~-86 ~-6 ~-32 ~-86 ~-1 ~-32 minecraft:gravel
fill ~-86 ~-6 ~-28 ~-86 ~-1 ~-28 minecraft:gravel
fill ~-86 ~-6 ~-23 ~-86 ~-1 ~-23 minecraft:gravel
fill ~-86 ~-6 ~-19 ~-86 ~-1 ~-19 minecraft:gravel
fill ~-86 ~-6 ~-8 ~-86 ~-1 ~-8 minecraft:gravel
fill ~-85 ~-6 ~-181 ~-85 ~-1 ~-181 minecraft:gravel
fill ~-85 ~-6 ~-174 ~-85 ~-1 ~-174 minecraft:gravel
fill ~-85 ~-6 ~-172 ~-85 ~-1 ~-172 minecraft:gravel
fill ~-85 ~-6 ~-157 ~-85 ~-1 ~-155 minecraft:gravel
fill ~-85 ~-6 ~-153 ~-85 ~-1 ~-152 minecraft:gravel
fill ~-85 ~-6 ~-149 ~-84 ~-1 ~-148 minecraft:gravel
fill ~-85 ~-6 ~-140 ~-85 ~-1 ~-139 minecraft:gravel
fill ~-85 ~-6 ~-137 ~-85 ~-1 ~-137 minecraft:gravel
fill ~-85 ~-6 ~-133 ~-85 ~-1 ~-99 minecraft:gravel
fill ~-85 ~-6 ~-96 ~-85 ~-1 ~-96 minecraft:gravel
fill ~-85 ~-6 ~-91 ~-84 ~-1 ~-91 minecraft:gravel
fill ~-85 ~-6 ~-83 ~-85 ~-1 ~-83 minecraft:gravel
fill ~-85 ~-6 ~-73 ~-85 ~-1 ~-72 minecraft:gravel
fill ~-85 ~-6 ~-70 ~-85 ~-1 ~-70 minecraft:gravel
fill ~-85 ~-6 ~-65 ~-85 ~-1 ~-65 minecraft:gravel
fill ~-85 ~-6 ~-60 ~-85 ~-1 ~-60 minecraft:gravel
fill ~-85 ~-6 ~-55 ~-83 ~-1 ~-55 minecraft:gravel
fill ~-85 ~-6 ~-53 ~-84 ~-1 ~-53 minecraft:gravel
fill ~-85 ~-6 ~-49 ~-85 ~-1 ~-49 minecraft:gravel
fill ~-85 ~-6 ~-41 ~-84 ~-1 ~-41 minecraft:gravel
fill ~-85 ~-6 ~-31 ~-84 ~-1 ~-31 minecraft:gravel
fill ~-85 ~-6 ~-30 ~-85 ~-1 ~-30 minecraft:gravel
fill ~-85 ~-6 ~-22 ~-84 ~-1 ~-22 minecraft:gravel
fill ~-85 ~-6 ~-21 ~-85 ~-1 ~-20 minecraft:gravel
fill ~-85 ~-6 ~-17 ~-84 ~-1 ~-17 minecraft:gravel
fill ~-85 ~-6 ~-16 ~-85 ~-1 ~-14 minecraft:gravel
fill ~-85 ~-6 ~-9 ~-85 ~-1 ~-9 minecraft:gravel
fill ~-84 ~-6 ~-184 ~-84 ~-1 ~-182 minecraft:gravel
fill ~-84 ~-6 ~-179 ~-84 ~-1 ~-178 minecraft:gravel
fill ~-84 ~-6 ~-167 ~-84 ~-1 ~-167 minecraft:gravel
fill ~-84 ~-6 ~-164 ~-84 ~-1 ~-164 minecraft:gravel
fill ~-84 ~-6 ~-161 ~-84 ~-1 ~-161 minecraft:gravel
fill ~-84 ~-6 ~-159 ~-81 ~-1 ~-159 minecraft:gravel
fill ~-84 ~-6 ~-150 ~-83 ~-1 ~-150 minecraft:gravel
fill ~-84 ~-6 ~-147 ~-84 ~-1 ~-147 minecraft:gravel
fill ~-84 ~-6 ~-144 ~-84 ~-1 ~-144 minecraft:gravel
fill ~-84 ~-6 ~-141 ~-84 ~-1 ~-141 minecraft:gravel
fill ~-84 ~-6 ~-134 ~-84 ~-1 ~-134 minecraft:gravel
fill ~-84 ~-6 ~-94 ~-81 ~-1 ~-94 minecraft:gravel
fill ~-84 ~-6 ~-88 ~-84 ~-1 ~-88 minecraft:gravel
fill ~-84 ~-6 ~-85 ~-84 ~-1 ~-85 minecraft:gravel
fill ~-84 ~-6 ~-82 ~-83 ~-1 ~-82 minecraft:gravel
fill ~-84 ~-6 ~-79 ~-83 ~-1 ~-79 minecraft:gravel
fill ~-84 ~-6 ~-77 ~-84 ~-1 ~-76 minecraft:gravel
fill ~-84 ~-6 ~-67 ~-84 ~-1 ~-67 minecraft:gravel
fill ~-84 ~-6 ~-63 ~-84 ~-1 ~-63 minecraft:gravel
fill ~-84 ~-6 ~-58 ~-84 ~-1 ~-58 minecraft:gravel
fill ~-84 ~-6 ~-51 ~-84 ~-1 ~-51 minecraft:gravel
fill ~-84 ~-6 ~-47 ~-84 ~-1 ~-47 minecraft:gravel
fill ~-84 ~-6 ~-35 ~-83 ~-1 ~-35 minecraft:gravel
fill ~-84 ~-6 ~-33 ~-84 ~-1 ~-33 minecraft:gravel
fill ~-84 ~-6 ~-29 ~-84 ~-1 ~-24 minecraft:gravel
fill ~-84 ~-6 ~-20 ~-81 ~-1 ~-20 minecraft:gravel
fill ~-84 ~-6 ~-19 ~-83 ~-1 ~-19 minecraft:gravel
fill ~-84 ~-6 ~-14 ~-84 ~-1 ~-14 minecraft:gravel
fill ~-84 ~-6 ~-7 ~-84 ~-1 ~-7 minecraft:gravel
fill ~-83 ~-6 ~-185 ~-83 ~-1 ~-185 minecraft:gravel
fill ~-83 ~-6 ~-182 ~-83 ~-1 ~-182 minecraft:gravel
fill ~-83 ~-6 ~-178 ~-83 ~-1 ~-178 minecraft:gravel
fill ~-83 ~-6 ~-175 ~-83 ~-1 ~-175 minecraft:gravel
fill ~-83 ~-6 ~-172 ~-83 ~-1 ~-172 minecraft:gravel
fill ~-83 ~-6 ~-170 ~-83 ~-1 ~-170 minecraft:gravel
fill ~-83 ~-6 ~-168 ~-83 ~-1 ~-168 minecraft:gravel
fill ~-83 ~-6 ~-163 ~-83 ~-1 ~-163 minecraft:gravel
fill ~-83 ~-6 ~-158 ~-83 ~-1 ~-158 minecraft:gravel
fill ~-83 ~-6 ~-152 ~-83 ~-1 ~-150 minecraft:gravel
fill ~-83 ~-6 ~-138 ~-81 ~-1 ~-138 minecraft:gravel
fill ~-83 ~-6 ~-137 ~-82 ~-1 ~-137 minecraft:gravel
fill ~-83 ~-6 ~-133 ~-83 ~-1 ~-100 minecraft:gravel
fill ~-83 ~-6 ~-90 ~-83 ~-1 ~-89 minecraft:gravel
fill ~-83 ~-6 ~-74 ~-83 ~-1 ~-73 minecraft:gravel
fill ~-83 ~-6 ~-71 ~-83 ~-1 ~-71 minecraft:gravel
fill ~-83 ~-6 ~-68 ~-82 ~-1 ~-68 minecraft:gravel
fill ~-83 ~-6 ~-66 ~-83 ~-1 ~-65 minecraft:gravel
fill ~-83 ~-6 ~-62 ~-83 ~-1 ~-62 minecraft:gravel
fill ~-83 ~-6 ~-56 ~-81 ~-1 ~-56 minecraft:gravel
fill ~-83 ~-6 ~-52 ~-83 ~-1 ~-52 minecraft:gravel
fill ~-83 ~-6 ~-50 ~-83 ~-1 ~-50 minecraft:gravel
fill ~-83 ~-6 ~-48 ~-81 ~-1 ~-48 minecraft:gravel
fill ~-83 ~-6 ~-45 ~-82 ~-1 ~-45 minecraft:gravel
fill ~-83 ~-6 ~-34 ~-83 ~-1 ~-34 minecraft:gravel
fill ~-83 ~-6 ~-30 ~-81 ~-1 ~-30 minecraft:gravel
fill ~-83 ~-6 ~-26 ~-83 ~-1 ~-26 minecraft:gravel
fill ~-83 ~-6 ~-10 ~-83 ~-1 ~-10 minecraft:gravel
fill ~-83 ~-6 ~-8 ~-83 ~-1 ~-8 minecraft:gravel
fill ~-82 ~-6 ~-183 ~-81 ~-1 ~-183 minecraft:gravel
fill ~-82 ~-6 ~-180 ~-82 ~-1 ~-180 minecraft:gravel
fill ~-82 ~-6 ~-174 ~-82 ~-1 ~-174 minecraft:gravel
fill ~-82 ~-6 ~-166 ~-81 ~-1 ~-166 minecraft:gravel
fill ~-82 ~-6 ~-164 ~-82 ~-1 ~-164 minecraft:gravel
fill ~-82 ~-6 ~-161 ~-82 ~-1 ~-161 minecraft:gravel
fill ~-82 ~-6 ~-142 ~-82 ~-1 ~-142 minecraft:gravel
fill ~-82 ~-6 ~-136 ~-82 ~-1 ~-135 minecraft:gravel
fill ~-82 ~-6 ~-98 ~-82 ~-1 ~-98 minecraft:gravel
fill ~-82 ~-6 ~-96 ~-82 ~-1 ~-96 minecraft:gravel
fill ~-82 ~-6 ~-81 ~-82 ~-1 ~-81 minecraft:gravel
fill ~-82 ~-6 ~-69 ~-82 ~-1 ~-67 minecraft:gravel
fill ~-82 ~-6 ~-63 ~-82 ~-1 ~-63 minecraft:gravel
fill ~-82 ~-6 ~-61 ~-81 ~-1 ~-61 minecraft:gravel
fill ~-82 ~-6 ~-60 ~-82 ~-1 ~-60 minecraft:gravel
fill ~-82 ~-6 ~-42 ~-82 ~-1 ~-42 minecraft:gravel
fill ~-82 ~-6 ~-40 ~-82 ~-1 ~-40 minecraft:gravel
fill ~-82 ~-6 ~-33 ~-82 ~-1 ~-33 minecraft:gravel
fill ~-82 ~-6 ~-22 ~-82 ~-1 ~-20 minecraft:gravel
fill ~-82 ~-6 ~-16 ~-82 ~-1 ~-16 minecraft:gravel
fill ~-82 ~-6 ~-13 ~-82 ~-1 ~-12 minecraft:gravel
fill ~-81 ~-6 ~-182 ~-81 ~-1 ~-182 minecraft:gravel
fill ~-81 ~-6 ~-177 ~-81 ~-1 ~-177 minecraft:gravel
fill ~-81 ~-6 ~-175 ~-80 ~-1 ~-175 minecraft:gravel
fill ~-81 ~-6 ~-169 ~-80 ~-1 ~-169 minecraft:gravel
fill ~-81 ~-6 ~-168 ~-81 ~-1 ~-168 minecraft:gravel
fill ~-81 ~-6 ~-139 ~-81 ~-1 ~-138 minecraft:gravel
fill ~-81 ~-6 ~-135 ~-81 ~-1 ~-100 minecraft:gravel
fill ~-81 ~-6 ~-93 ~-80 ~-1 ~-93 minecraft:gravel
fill ~-81 ~-6 ~-89 ~-80 ~-1 ~-89 minecraft:gravel
fill ~-81 ~-6 ~-86 ~-81 ~-1 ~-86 minecraft:gravel
fill ~-81 ~-6 ~-84 ~-81 ~-1 ~-84 minecraft:gravel
fill ~-81 ~-6 ~-82 ~-81 ~-1 ~-82 minecraft:gravel
fill ~-81 ~-6 ~-79 ~-81 ~-1 ~-79 minecraft:gravel
fill ~-81 ~-6 ~-76 ~-81 ~-1 ~-75 minecraft:gravel
fill ~-81 ~-6 ~-73 ~-81 ~-1 ~-73 minecraft:gravel
fill ~-81 ~-6 ~-70 ~-81 ~-1 ~-70 minecraft:gravel
fill ~-81 ~-6 ~-65 ~-81 ~-1 ~-64 minecraft:gravel
fill ~-81 ~-6 ~-58 ~-81 ~-1 ~-56 minecraft:gravel
fill ~-81 ~-6 ~-51 ~-81 ~-1 ~-50 minecraft:gravel
fill ~-81 ~-6 ~-44 ~-81 ~-1 ~-44 minecraft:gravel
fill ~-81 ~-6 ~-41 ~-81 ~-1 ~-41 minecraft:gravel
fill ~-81 ~-6 ~-39 ~-81 ~-1 ~-38 minecraft:gravel
fill ~-81 ~-6 ~-35 ~-81 ~-1 ~-35 minecraft:gravel
fill ~-81 ~-6 ~-32 ~-81 ~-1 ~-32 minecraft:gravel
fill ~-81 ~-6 ~-21 ~-79 ~-1 ~-21 minecraft:gravel
fill ~-81 ~-6 ~-11 ~-81 ~-1 ~-11 minecraft:gravel
fill ~-81 ~-6 ~-7 ~-81 ~-1 ~-7 minecraft:gravel
fill ~-80 ~-6 ~-185 ~-80 ~-1 ~-185 minecraft:gravel
fill ~-80 ~-6 ~-180 ~-76 ~-1 ~-180 minecraft:gravel
fill ~-80 ~-6 ~-179 ~-80 ~-1 ~-179 minecraft:gravel
fill ~-80 ~-6 ~-176 ~-80 ~-1 ~-171 minecraft:gravel
fill ~-80 ~-6 ~-165 ~-79 ~-1 ~-165 minecraft:gravel
fill ~-80 ~-6 ~-158 ~-80 ~-1 ~-157 minecraft:gravel
fill ~-80 ~-6 ~-152 ~-79 ~-1 ~-152 minecraft:gravel
fill ~-80 ~-6 ~-150 ~-80 ~-1 ~-149 minecraft:gravel
fill ~-80 ~-6 ~-145 ~-80 ~-1 ~-145 minecraft:gravel
fill ~-80 ~-6 ~-141 ~-80 ~-1 ~-141 minecraft:gravel
fill ~-80 ~-6 ~-99 ~-80 ~-1 ~-99 minecraft:gravel
fill ~-80 ~-6 ~-92 ~-80 ~-1 ~-92 minecraft:gravel
fill ~-80 ~-6 ~-88 ~-80 ~-1 ~-88 minecraft:gravel
fill ~-80 ~-6 ~-81 ~-79 ~-1 ~-81 minecraft:gravel
fill ~-80 ~-6 ~-80 ~-80 ~-1 ~-80 minecraft:gravel
fill ~-80 ~-6 ~-75 ~-79 ~-1 ~-75 minecraft:gravel
fill ~-80 ~-6 ~-71 ~-79 ~-1 ~-71 minecraft:gravel
fill ~-80 ~-6 ~-64 ~-79 ~-1 ~-64 minecraft:gravel
fill ~-80 ~-6 ~-50 ~-80 ~-1 ~-50 minecraft:gravel
fill ~-80 ~-6 ~-45 ~-80 ~-1 ~-45 minecraft:gravel
fill ~-80 ~-6 ~-40 ~-80 ~-1 ~-40 minecraft:gravel
fill ~-80 ~-6 ~-37 ~-80 ~-1 ~-36 minecraft:gravel
fill ~-80 ~-6 ~-33 ~-79 ~-1 ~-33 minecraft:gravel
fill ~-80 ~-6 ~-29 ~-80 ~-1 ~-29 minecraft:gravel
fill ~-80 ~-6 ~-24 ~-80 ~-1 ~-24 minecraft:gravel
fill ~-80 ~-6 ~-13 ~-79 ~-1 ~-13 minecraft:gravel
fill ~-80 ~-6 ~-12 ~-80 ~-1 ~-12 minecraft:gravel
fill ~-79 ~-6 ~-181 ~-79 ~-1 ~-180 minecraft:gravel
fill ~-79 ~-6 ~-178 ~-79 ~-1 ~-177 minecraft:gravel
fill ~-79 ~-6 ~-174 ~-79 ~-1 ~-172 minecraft:gravel
fill ~-79 ~-6 ~-168 ~-79 ~-1 ~-168 minecraft:gravel
fill ~-79 ~-6 ~-166 ~-79 ~-1 ~-165 minecraft:gravel
fill ~-79 ~-6 ~-163 ~-79 ~-1 ~-162 minecraft:gravel
fill ~-79 ~-6 ~-159 ~-79 ~-1 ~-159 minecraft:gravel
fill ~-79 ~-6 ~-156 ~-79 ~-1 ~-156 minecraft:gravel
fill ~-79 ~-6 ~-149 ~-79 ~-1 ~-148 minecraft:gravel
fill ~-79 ~-6 ~-134 ~-79 ~-1 ~-128 minecraft:gravel
fill ~-79 ~-6 ~-124 ~-79 ~-1 ~-123 minecraft:gravel
fill ~-79 ~-6 ~-119 ~-79 ~-1 ~-119 minecraft:gravel
fill ~-79 ~-6 ~-117 ~-79 ~-1 ~-117 minecraft:gravel
fill ~-79 ~-6 ~-109 ~-79 ~-1 ~-108 minecraft:gravel
fill ~-79 ~-6 ~-106 ~-79 ~-1 ~-105 minecraft:gravel
fill ~-79 ~-6 ~-97 ~-79 ~-1 ~-96 minecraft:gravel
fill ~-79 ~-6 ~-94 ~-79 ~-1 ~-94 minecraft:gravel
fill ~-79 ~-6 ~-90 ~-79 ~-1 ~-90 minecraft:gravel
fill ~-79 ~-6 ~-87 ~-79 ~-1 ~-85 minecraft:gravel
fill ~-79 ~-6 ~-69 ~-79 ~-1 ~-69 minecraft:gravel
fill ~-79 ~-6 ~-62 ~-79 ~-1 ~-62 minecraft:gravel
fill ~-79 ~-6 ~-59 ~-79 ~-1 ~-59 minecraft:gravel
fill ~-79 ~-6 ~-56 ~-79 ~-1 ~-56 minecraft:gravel
fill ~-79 ~-6 ~-51 ~-79 ~-1 ~-51 minecraft:gravel
fill ~-79 ~-6 ~-49 ~-79 ~-1 ~-49 minecraft:gravel
fill ~-79 ~-6 ~-44 ~-79 ~-1 ~-44 minecraft:gravel
fill ~-79 ~-6 ~-41 ~-79 ~-1 ~-41 minecraft:gravel
fill ~-79 ~-6 ~-39 ~-79 ~-1 ~-39 minecraft:gravel
fill ~-79 ~-6 ~-36 ~-79 ~-1 ~-36 minecraft:gravel
fill ~-79 ~-6 ~-30 ~-79 ~-1 ~-30 minecraft:gravel
fill ~-79 ~-6 ~-27 ~-79 ~-1 ~-27 minecraft:gravel
fill ~-79 ~-6 ~-20 ~-79 ~-1 ~-20 minecraft:gravel
fill ~-79 ~-6 ~-17 ~-77 ~-1 ~-17 minecraft:gravel
fill ~-79 ~-6 ~-16 ~-79 ~-1 ~-16 minecraft:gravel
fill ~-79 ~-6 ~-11 ~-79 ~-1 ~-8 minecraft:gravel
fill ~-78 ~-6 ~-185 ~-78 ~-1 ~-185 minecraft:gravel
fill ~-78 ~-6 ~-182 ~-78 ~-1 ~-182 minecraft:gravel
fill ~-78 ~-6 ~-175 ~-78 ~-1 ~-175 minecraft:gravel
fill ~-78 ~-6 ~-15 ~-78 ~-1 ~-15 minecraft:gravel
fill ~-78 ~-6 ~-10 ~-78 ~-1 ~-7 minecraft:gravel
fill ~-77 ~-6 ~-184 ~-77 ~-1 ~-184 minecraft:gravel
fill ~-77 ~-6 ~-181 ~-75 ~-1 ~-181 minecraft:gravel
fill ~-77 ~-6 ~-14 ~-76 ~-1 ~-14 minecraft:gravel
fill ~-77 ~-6 ~-12 ~-76 ~-1 ~-11 minecraft:gravel
fill ~-77 ~-6 ~-9 ~-77 ~-1 ~-9 minecraft:gravel
fill ~-76 ~-6 ~-179 ~-76 ~-1 ~-179 minecraft:gravel
fill ~-76 ~-6 ~-16 ~-76 ~-1 ~-16 minecraft:gravel
fill ~-76 ~-6 ~-8 ~-75 ~-1 ~-8 minecraft:gravel
fill ~-76 ~-6 ~-7 ~-76 ~-1 ~-7 minecraft:gravel
fill ~-75 ~-6 ~-184 ~-74 ~-1 ~-184 minecraft:gravel
fill ~-75 ~-6 ~-182 ~-75 ~-1 ~-181 minecraft:gravel
fill ~-75 ~-6 ~-176 ~-75 ~-1 ~-175 minecraft:gravel
fill ~-75 ~-6 ~-17 ~-74 ~-1 ~-17 minecraft:gravel
fill ~-75 ~-6 ~-15 ~-75 ~-1 ~-15 minecraft:gravel
fill ~-75 ~-6 ~-11 ~-75 ~-1 ~-8 minecraft:gravel
fill ~-74 ~-6 ~-185 ~-74 ~-1 ~-183 minecraft:gravel
fill ~-74 ~-6 ~-179 ~-72 ~-1 ~-179 minecraft:gravel
fill ~-74 ~-6 ~-12 ~-73 ~-1 ~-12 minecraft:gravel
fill ~-73 ~-6 ~-183 ~-73 ~-1 ~-183 minecraft:gravel
fill ~-73 ~-6 ~-177 ~-72 ~-1 ~-177 minecraft:gravel
fill ~-73 ~-6 ~-176 ~-73 ~-1 ~-175 minecraft:gravel
fill ~-73 ~-6 ~-15 ~-72 ~-1 ~-15 minecraft:gravel
fill ~-73 ~-6 ~-14 ~-73 ~-1 ~-14 minecraft:gravel
fill ~-72 ~-6 ~-178 ~-72 ~-1 ~-177 minecraft:gravel
fill ~-72 ~-6 ~-9 ~-72 ~-1 ~-7 minecraft:gravel
fill ~-71 ~-6 ~-182 ~-71 ~-1 ~-182 minecraft:gravel
fill ~-71 ~-6 ~-180 ~-71 ~-1 ~-180 minecraft:gravel
fill ~-71 ~-6 ~-13 ~-71 ~-1 ~-13 minecraft:gravel
fill ~-71 ~-6 ~-11 ~-70 ~-1 ~-11 minecraft:gravel
fill ~-71 ~-6 ~-8 ~-71 ~-1 ~-8 minecraft:gravel
fill ~-70 ~-6 ~-184 ~-70 ~-1 ~-184 minecraft:gravel
fill ~-70 ~-6 ~-181 ~-70 ~-1 ~-181 minecraft:gravel
fill ~-70 ~-6 ~-175 ~-70 ~-1 ~-175 minecraft:gravel
fill ~-70 ~-6 ~-17 ~-70 ~-1 ~-16 minecraft:gravel
fill ~-70 ~-6 ~-10 ~-70 ~-1 ~-9 minecraft:gravel
fill ~-70 ~-6 ~-7 ~-70 ~-1 ~-7 minecraft:gravel
fill ~-69 ~-6 ~-177 ~-68 ~-1 ~-177 minecraft:gravel
fill ~-69 ~-6 ~-14 ~-68 ~-1 ~-14 minecraft:gravel
fill ~-69 ~-6 ~-12 ~-68 ~-1 ~-12 minecraft:gravel
fill ~-68 ~-6 ~-184 ~-68 ~-1 ~-184 minecraft:gravel
fill ~-68 ~-6 ~-176 ~-67 ~-1 ~-176 minecraft:gravel
fill ~-67 ~-6 ~-185 ~-67 ~-1 ~-185 minecraft:gravel
fill ~-67 ~-6 ~-181 ~-66 ~-1 ~-181 minecraft:gravel
fill ~-67 ~-6 ~-179 ~-65 ~-1 ~-179 minecraft:gravel
fill ~-67 ~-6 ~-13 ~-67 ~-1 ~-13 minecraft:gravel
fill ~-67 ~-6 ~-10 ~-67 ~-1 ~-10 minecraft:gravel
fill ~-67 ~-6 ~-8 ~-67 ~-1 ~-8 minecraft:gravel
fill ~-66 ~-6 ~-180 ~-66 ~-1 ~-179 minecraft:gravel
fill ~-66 ~-6 ~-175 ~-66 ~-1 ~-175 minecraft:gravel
fill ~-66 ~-6 ~-15 ~-66 ~-1 ~-15 minecraft:gravel
fill ~-66 ~-6 ~-7 ~-66 ~-1 ~-7 minecraft:gravel
fill ~-65 ~-6 ~-11 ~-63 ~-1 ~-11 minecraft:gravel
fill ~-64 ~-6 ~-184 ~-64 ~-1 ~-184 minecraft:gravel
fill ~-64 ~-6 ~-175 ~-64 ~-1 ~-175 minecraft:gravel
fill ~-64 ~-6 ~-17 ~-64 ~-1 ~-17 minecraft:gravel
fill ~-64 ~-6 ~-14 ~-61 ~-1 ~-14 minecraft:gravel
fill ~-64 ~-6 ~-9 ~-64 ~-1 ~-9 minecraft:gravel
fill ~-63 ~-6 ~-181 ~-63 ~-1 ~-179 minecraft:gravel
fill ~-63 ~-6 ~-16 ~-63 ~-1 ~-16 minecraft:gravel
fill ~-63 ~-6 ~-13 ~-63 ~-1 ~-13 minecraft:gravel
fill ~-62 ~-6 ~-180 ~-61 ~-1 ~-180 minecraft:gravel
fill ~-62 ~-6 ~-175 ~-62 ~-1 ~-175 minecraft:gravel
fill ~-62 ~-6 ~-17 ~-62 ~-1 ~-17 minecraft:gravel
fill ~-62 ~-6 ~-7 ~-61 ~-1 ~-7 minecraft:gravel
fill ~-61 ~-6 ~-185 ~-61 ~-1 ~-185 minecraft:gravel
fill ~-61 ~-6 ~-10 ~-60 ~-1 ~-10 minecraft:gravel
fill ~-61 ~-6 ~-8 ~-61 ~-1 ~-7 minecraft:gravel
fill ~-60 ~-6 ~-13 ~-59 ~-1 ~-13 minecraft:gravel
fill ~-59 ~-6 ~-185 ~-59 ~-1 ~-185 minecraft:gravel
fill ~-59 ~-6 ~-182 ~-59 ~-1 ~-182 minecraft:gravel
fill ~-59 ~-6 ~-179 ~-59 ~-1 ~-179 minecraft:gravel
fill ~-59 ~-6 ~-177 ~-59 ~-1 ~-177 minecraft:gravel
fill ~-59 ~-6 ~-175 ~-59 ~-1 ~-175 minecraft:gravel
fill ~-59 ~-6 ~-12 ~-59 ~-1 ~-12 minecraft:gravel
fill ~-58 ~-6 ~-183 ~-58 ~-1 ~-183 minecraft:gravel
fill ~-58 ~-6 ~-178 ~-57 ~-1 ~-178 minecraft:gravel
fill ~-58 ~-6 ~-14 ~-57 ~-1 ~-14 minecraft:gravel
fill ~-58 ~-6 ~-10 ~-57 ~-1 ~-10 minecraft:gravel
fill ~-58 ~-6 ~-8 ~-58 ~-1 ~-7 minecraft:gravel
fill ~-57 ~-6 ~-185 ~-57 ~-1 ~-185 minecraft:gravel
fill ~-57 ~-6 ~-180 ~-57 ~-1 ~-178 minecraft:gravel
fill ~-57 ~-6 ~-176 ~-57 ~-1 ~-176 minecraft:gravel
fill ~-57 ~-6 ~-15 ~-57 ~-1 ~-13 minecraft:gravel
fill ~-57 ~-6 ~-9 ~-57 ~-1 ~-9 minecraft:gravel
fill ~-56 ~-6 ~-184 ~-56 ~-1 ~-184 minecraft:gravel
fill ~-56 ~-6 ~-182 ~-56 ~-1 ~-182 minecraft:gravel
fill ~-56 ~-6 ~-175 ~-54 ~-1 ~-175 minecraft:gravel
fill ~-55 ~-6 ~-180 ~-53 ~-1 ~-180 minecraft:gravel
fill ~-55 ~-6 ~-178 ~-55 ~-1 ~-178 minecraft:gravel
fill ~-55 ~-6 ~-11 ~-54 ~-1 ~-11 minecraft:gravel
fill ~-55 ~-6 ~-9 ~-55 ~-1 ~-9 minecraft:gravel
fill ~-55 ~-6 ~-7 ~-55 ~-1 ~-7 minecraft:gravel
fill ~-54 ~-6 ~-183 ~-53 ~-1 ~-183 minecraft:gravel
fill ~-54 ~-6 ~-181 ~-54 ~-1 ~-179 minecraft:gravel
fill ~-53 ~-6 ~-179 ~-52 ~-1 ~-179 minecraft:gravel
fill ~-53 ~-6 ~-177 ~-53 ~-1 ~-177 minecraft:gravel
fill ~-53 ~-6 ~-17 ~-53 ~-1 ~-17 minecraft:gravel
fill ~-53 ~-6 ~-13 ~-53 ~-1 ~-12 minecraft:gravel
fill ~-52 ~-6 ~-185 ~-52 ~-1 ~-185 minecraft:gravel
fill ~-52 ~-6 ~-178 ~-52 ~-1 ~-178 minecraft:gravel
fill ~-52 ~-6 ~-11 ~-52 ~-1 ~-11 minecraft:gravel
fill ~-51 ~-6 ~-177 ~-51 ~-1 ~-177 minecraft:gravel
fill ~-51 ~-6 ~-10 ~-49 ~-1 ~-10 minecraft:gravel
fill ~-51 ~-6 ~-9 ~-51 ~-1 ~-9 minecraft:gravel
fill ~-50 ~-6 ~-182 ~-50 ~-1 ~-182 minecraft:gravel
fill ~-50 ~-6 ~-179 ~-50 ~-1 ~-179 minecraft:gravel
fill ~-50 ~-6 ~-176 ~-50 ~-1 ~-176 minecraft:gravel
fill ~-50 ~-6 ~-16 ~-50 ~-1 ~-15 minecraft:gravel
fill ~-50 ~-6 ~-11 ~-49 ~-1 ~-10 minecraft:gravel
fill ~-49 ~-6 ~-183 ~-49 ~-1 ~-183 minecraft:gravel
fill ~-49 ~-6 ~-178 ~-49 ~-1 ~-178 minecraft:gravel
fill ~-49 ~-6 ~-17 ~-49 ~-1 ~-17 minecraft:gravel
fill ~-49 ~-6 ~-13 ~-49 ~-1 ~-13 minecraft:gravel
fill ~-49 ~-6 ~-9 ~-49 ~-1 ~-7 minecraft:gravel
fill ~-48 ~-6 ~-185 ~-48 ~-1 ~-184 minecraft:gravel
fill ~-48 ~-6 ~-182 ~-48 ~-1 ~-181 minecraft:gravel
fill ~-48 ~-6 ~-179 ~-48 ~-1 ~-179 minecraft:gravel
fill ~-48 ~-6 ~-175 ~-48 ~-1 ~-175 minecraft:gravel
fill ~-48 ~-6 ~-14 ~-47 ~-1 ~-14 minecraft:gravel
fill ~-47 ~-6 ~-178 ~-47 ~-1 ~-178 minecraft:gravel
fill ~-47 ~-6 ~-16 ~-47 ~-1 ~-14 minecraft:gravel
fill ~-47 ~-6 ~-12 ~-46 ~-1 ~-12 minecraft:gravel
fill ~-47 ~-6 ~-11 ~-47 ~-1 ~-11 minecraft:gravel
fill ~-47 ~-6 ~-9 ~-47 ~-1 ~-9 minecraft:gravel
fill ~-46 ~-6 ~-184 ~-46 ~-1 ~-184 minecraft:gravel
fill ~-46 ~-6 ~-179 ~-45 ~-1 ~-179 minecraft:gravel
fill ~-46 ~-6 ~-17 ~-46 ~-1 ~-17 minecraft:gravel
fill ~-46 ~-6 ~-10 ~-46 ~-1 ~-10 minecraft:gravel
fill ~-46 ~-6 ~-7 ~-46 ~-1 ~-7 minecraft:gravel
fill ~-45 ~-6 ~-177 ~-45 ~-1 ~-177 minecraft:gravel
fill ~-45 ~-6 ~-15 ~-45 ~-1 ~-15 minecraft:gravel
fill ~-45 ~-6 ~-8 ~-45 ~-1 ~-8 minecraft:gravel
fill ~-44 ~-6 ~-181 ~-44 ~-1 ~-181 minecraft:gravel
fill ~-44 ~-6 ~-17 ~-43 ~-1 ~-16 minecraft:gravel
fill ~-44 ~-6 ~-14 ~-43 ~-1 ~-14 minecraft:gravel
fill ~-43 ~-6 ~-183 ~-43 ~-1 ~-183 minecraft:gravel
fill ~-43 ~-6 ~-179 ~-43 ~-1 ~-179 minecraft:gravel
fill ~-43 ~-6 ~-9 ~-42 ~-1 ~-9 minecraft:gravel
fill ~-42 ~-6 ~-184 ~-42 ~-1 ~-184 minecraft:gravel
fill ~-42 ~-6 ~-182 ~-41 ~-1 ~-182 minecraft:gravel
fill ~-42 ~-6 ~-180 ~-41 ~-1 ~-180 minecraft:gravel
fill ~-42 ~-6 ~-178 ~-42 ~-1 ~-178 minecraft:gravel
fill ~-42 ~-6 ~-175 ~-42 ~-1 ~-175 minecraft:gravel
fill ~-42 ~-6 ~-16 ~-42 ~-1 ~-16 minecraft:gravel
fill ~-42 ~-6 ~-13 ~-42 ~-1 ~-13 minecraft:gravel
fill ~-42 ~-6 ~-11 ~-42 ~-1 ~-11 minecraft:gravel
fill ~-42 ~-6 ~-7 ~-41 ~-1 ~-7 minecraft:gravel
fill ~-41 ~-6 ~-183 ~-41 ~-1 ~-182 minecraft:gravel
fill ~-41 ~-6 ~-179 ~-41 ~-1 ~-179 minecraft:gravel
fill ~-41 ~-6 ~-17 ~-41 ~-1 ~-17 minecraft:gravel
fill ~-40 ~-6 ~-184 ~-40 ~-1 ~-184 minecraft:gravel
fill ~-40 ~-6 ~-181 ~-38 ~-1 ~-181 minecraft:gravel
fill ~-40 ~-6 ~-178 ~-40 ~-1 ~-178 minecraft:gravel
fill ~-40 ~-6 ~-175 ~-39 ~-1 ~-175 minecraft:gravel
fill ~-40 ~-6 ~-16 ~-40 ~-1 ~-16 minecraft:gravel
fill ~-40 ~-6 ~-14 ~-40 ~-1 ~-13 minecraft:gravel
fill ~-40 ~-6 ~-11 ~-40 ~-1 ~-11 minecraft:gravel
fill ~-39 ~-6 ~-180 ~-37 ~-1 ~-180 minecraft:gravel
fill ~-39 ~-6 ~-176 ~-39 ~-1 ~-175 minecraft:gravel
fill ~-39 ~-6 ~-8 ~-39 ~-1 ~-7 minecraft:gravel
fill ~-38 ~-6 ~-183 ~-38 ~-1 ~-183 minecraft:gravel
fill ~-38 ~-6 ~-16 ~-35 ~-1 ~-16 minecraft:gravel
fill ~-38 ~-6 ~-15 ~-38 ~-1 ~-14 minecraft:gravel
fill ~-38 ~-6 ~-11 ~-38 ~-1 ~-11 minecraft:gravel
fill ~-38 ~-6 ~-7 ~-38 ~-1 ~-7 minecraft:gravel
fill ~-37 ~-6 ~-185 ~-37 ~-1 ~-185 minecraft:gravel
fill ~-37 ~-6 ~-177 ~-37 ~-1 ~-177 minecraft:gravel
fill ~-37 ~-6 ~-13 ~-36 ~-1 ~-13 minecraft:gravel
fill ~-37 ~-6 ~-12 ~-37 ~-1 ~-12 minecraft:gravel
fill ~-37 ~-6 ~-9 ~-37 ~-1 ~-9 minecraft:gravel
fill ~-36 ~-6 ~-183 ~-36 ~-1 ~-183 minecraft:gravel
fill ~-36 ~-6 ~-17 ~-35 ~-1 ~-16 minecraft:gravel
fill ~-36 ~-6 ~-8 ~-36 ~-1 ~-8 minecraft:gravel
fill ~-35 ~-6 ~-185 ~-35 ~-1 ~-185 minecraft:gravel
fill ~-35 ~-6 ~-180 ~-35 ~-1 ~-179 minecraft:gravel
fill ~-35 ~-6 ~-176 ~-35 ~-1 ~-176 minecraft:gravel
fill ~-35 ~-6 ~-15 ~-35 ~-1 ~-15 minecraft:gravel
fill ~-35 ~-6 ~-10 ~-35 ~-1 ~-10 minecraft:gravel
fill ~-35 ~-6 ~-7 ~-35 ~-1 ~-7 minecraft:gravel
fill ~-34 ~-6 ~-183 ~-32 ~-1 ~-183 minecraft:gravel
fill ~-34 ~-6 ~-181 ~-34 ~-1 ~-181 minecraft:gravel
fill ~-34 ~-6 ~-177 ~-34 ~-1 ~-177 minecraft:gravel
fill ~-34 ~-6 ~-14 ~-33 ~-1 ~-14 minecraft:gravel
fill ~-34 ~-6 ~-13 ~-34 ~-1 ~-13 minecraft:gravel
fill ~-33 ~-6 ~-185 ~-33 ~-1 ~-185 minecraft:gravel
fill ~-33 ~-6 ~-178 ~-33 ~-1 ~-178 minecraft:gravel
fill ~-33 ~-6 ~-175 ~-33 ~-1 ~-175 minecraft:gravel
fill ~-33 ~-6 ~-16 ~-33 ~-1 ~-14 minecraft:gravel
fill ~-33 ~-6 ~-9 ~-33 ~-1 ~-9 minecraft:gravel
fill ~-32 ~-6 ~-180 ~-32 ~-1 ~-180 minecraft:gravel
fill ~-32 ~-6 ~-17 ~-32 ~-1 ~-17 minecraft:gravel
fill ~-32 ~-6 ~-13 ~-31 ~-1 ~-13 minecraft:gravel
fill ~-32 ~-6 ~-8 ~-32 ~-1 ~-8 minecraft:gravel
fill ~-31 ~-6 ~-185 ~-31 ~-1 ~-185 minecraft:gravel
fill ~-31 ~-6 ~-177 ~-31 ~-1 ~-177 minecraft:gravel
fill ~-31 ~-6 ~-12 ~-31 ~-1 ~-12 minecraft:gravel
fill ~-31 ~-6 ~-10 ~-31 ~-1 ~-10 minecraft:gravel
fill ~-31 ~-6 ~-7 ~-31 ~-1 ~-7 minecraft:gravel
fill ~-30 ~-6 ~-183 ~-30 ~-1 ~-182 minecraft:gravel
fill ~-30 ~-6 ~-17 ~-29 ~-1 ~-16 minecraft:gravel
fill ~-30 ~-6 ~-14 ~-30 ~-1 ~-14 minecraft:gravel
fill ~-29 ~-6 ~-181 ~-29 ~-1 ~-180 minecraft:gravel
fill ~-29 ~-6 ~-175 ~-29 ~-1 ~-175 minecraft:gravel
fill ~-29 ~-6 ~-15 ~-29 ~-1 ~-15 minecraft:gravel
fill ~-29 ~-6 ~-13 ~-27 ~-1 ~-13 minecraft:gravel
fill ~-29 ~-6 ~-12 ~-29 ~-1 ~-11 minecraft:gravel
fill ~-29 ~-6 ~-9 ~-29 ~-1 ~-9 minecraft:gravel
fill ~-29 ~-6 ~-7 ~-28 ~-1 ~-7 minecraft:gravel
fill ~-28 ~-6 ~-11 ~-28 ~-1 ~-11 minecraft:gravel
fill ~-27 ~-6 ~-185 ~-27 ~-1 ~-185 minecraft:gravel
fill ~-27 ~-6 ~-183 ~-27 ~-1 ~-183 minecraft:gravel
fill ~-27 ~-6 ~-179 ~-24 ~-1 ~-179 minecraft:gravel
fill ~-27 ~-6 ~-178 ~-27 ~-1 ~-178 minecraft:gravel
fill ~-27 ~-6 ~-176 ~-27 ~-1 ~-176 minecraft:gravel
fill ~-27 ~-6 ~-10 ~-26 ~-1 ~-10 minecraft:gravel
fill ~-26 ~-6 ~-180 ~-26 ~-1 ~-179 minecraft:gravel
fill ~-26 ~-6 ~-177 ~-26 ~-1 ~-177 minecraft:gravel
fill ~-26 ~-6 ~-175 ~-26 ~-1 ~-175 minecraft:gravel
fill ~-25 ~-6 ~-176 ~-25 ~-1 ~-176 minecraft:gravel
fill ~-25 ~-6 ~-8 ~-25 ~-1 ~-8 minecraft:gravel
fill ~-24 ~-6 ~-184 ~-24 ~-1 ~-184 minecraft:gravel
fill ~-24 ~-6 ~-181 ~-24 ~-1 ~-179 minecraft:gravel
fill ~-24 ~-6 ~-16 ~-24 ~-1 ~-16 minecraft:gravel
fill ~-24 ~-6 ~-13 ~-24 ~-1 ~-12 minecraft:gravel
fill ~-24 ~-6 ~-10 ~-24 ~-1 ~-10 minecraft:gravel
fill ~-23 ~-6 ~-178 ~-23 ~-1 ~-178 minecraft:gravel
fill ~-23 ~-6 ~-175 ~-22 ~-1 ~-175 minecraft:gravel
fill ~-23 ~-6 ~-14 ~-23 ~-1 ~-14 minecraft:gravel
fill ~-23 ~-6 ~-9 ~-23 ~-1 ~-8 minecraft:gravel
fill ~-22 ~-6 ~-179 ~-21 ~-1 ~-179 minecraft:gravel
fill ~-22 ~-6 ~-16 ~-22 ~-1 ~-15 minecraft:gravel
fill ~-22 ~-6 ~-13 ~-21 ~-1 ~-13 minecraft:gravel
fill ~-22 ~-6 ~-11 ~-22 ~-1 ~-10 minecraft:gravel
fill ~-22 ~-6 ~-8 ~-20 ~-1 ~-8 minecraft:gravel
fill ~-21 ~-6 ~-185 ~-21 ~-1 ~-185 minecraft:gravel
fill ~-21 ~-6 ~-181 ~-21 ~-1 ~-181 minecraft:gravel
fill ~-21 ~-6 ~-177 ~-21 ~-1 ~-177 minecraft:gravel
fill ~-21 ~-6 ~-17 ~-19 ~-1 ~-17 minecraft:gravel
fill ~-21 ~-6 ~-15 ~-20 ~-1 ~-15 minecraft:gravel
fill ~-20 ~-6 ~-182 ~-20 ~-1 ~-182 minecraft:gravel
fill ~-20 ~-6 ~-180 ~-19 ~-1 ~-180 minecraft:gravel
fill ~-20 ~-6 ~-175 ~-20 ~-1 ~-175 minecraft:gravel
fill ~-20 ~-6 ~-16 ~-20 ~-1 ~-15 minecraft:gravel
fill ~-20 ~-6 ~-9 ~-20 ~-1 ~-8 minecraft:gravel
fill ~-19 ~-6 ~-183 ~-19 ~-1 ~-183 minecraft:gravel
fill ~-19 ~-6 ~-181 ~-18 ~-1 ~-181 minecraft:gravel
fill ~-19 ~-6 ~-14 ~-19 ~-1 ~-14 minecraft:gravel
fill ~-19 ~-6 ~-10 ~-18 ~-1 ~-10 minecraft:gravel
fill ~-18 ~-6 ~-185 ~-18 ~-1 ~-184 minecraft:gravel
fill ~-17 ~-6 ~-180 ~-17 ~-1 ~-180 minecraft:gravel
fill ~-17 ~-6 ~-175 ~-16 ~-1 ~-175 minecraft:gravel
fill ~-17 ~-6 ~-15 ~-17 ~-1 ~-14 minecraft:gravel
fill ~-16 ~-6 ~-183 ~-16 ~-1 ~-183 minecraft:gravel
fill ~-16 ~-6 ~-178 ~-16 ~-1 ~-178 minecraft:gravel
fill ~-16 ~-6 ~-12 ~-15 ~-1 ~-12 minecraft:gravel
fill ~-16 ~-6 ~-11 ~-16 ~-1 ~-11 minecraft:gravel
fill ~-16 ~-6 ~-9 ~-16 ~-1 ~-9 minecraft:gravel
fill ~-16 ~-6 ~-7 ~-16 ~-1 ~-7 minecraft:gravel
fill ~-15 ~-6 ~-182 ~-15 ~-1 ~-182 minecraft:gravel
fill ~-15 ~-6 ~-180 ~-15 ~-1 ~-180 minecraft:gravel
fill ~-15 ~-6 ~-10 ~-15 ~-1 ~-10 minecraft:gravel
fill ~-15 ~-6 ~-8 ~-15 ~-1 ~-8 minecraft:gravel
fill ~-14 ~-6 ~-185 ~-14 ~-1 ~-185 minecraft:gravel
fill ~-14 ~-6 ~-175 ~-13 ~-1 ~-175 minecraft:gravel
fill ~-14 ~-6 ~-14 ~-14 ~-1 ~-13 minecraft:gravel
fill ~-14 ~-6 ~-11 ~-11 ~-1 ~-11 minecraft:gravel
fill ~-14 ~-6 ~-9 ~-12 ~-1 ~-9 minecraft:gravel
fill ~-14 ~-6 ~-7 ~-14 ~-1 ~-7 minecraft:gravel
fill ~-13 ~-6 ~-181 ~-13 ~-1 ~-180 minecraft:gravel
fill ~-13 ~-6 ~-178 ~-13 ~-1 ~-177 minecraft:gravel
fill ~-13 ~-6 ~-17 ~-13 ~-1 ~-17 minecraft:gravel
fill ~-13 ~-6 ~-13 ~-13 ~-1 ~-13 minecraft:gravel
fill ~-12 ~-6 ~-184 ~-12 ~-1 ~-183 minecraft:gravel
fill ~-12 ~-6 ~-180 ~-12 ~-1 ~-180 minecraft:gravel
fill ~-12 ~-6 ~-14 ~-11 ~-1 ~-14 minecraft:gravel
fill ~-12 ~-6 ~-8 ~-12 ~-1 ~-8 minecraft:gravel
fill ~-11 ~-6 ~-181 ~-10 ~-1 ~-181 minecraft:gravel
fill ~-11 ~-6 ~-179 ~-11 ~-1 ~-178 minecraft:gravel
fill ~-11 ~-6 ~-176 ~-11 ~-1 ~-175 minecraft:gravel
fill ~-11 ~-6 ~-16 ~-10 ~-1 ~-16 minecraft:gravel
fill ~-10 ~-6 ~-8 ~-10 ~-1 ~-8 minecraft:gravel
fill ~-9 ~-6 ~-185 ~-9 ~-1 ~-185 minecraft:gravel
fill ~-9 ~-6 ~-180 ~-9 ~-1 ~-180 minecraft:gravel
fill ~-9 ~-6 ~-176 ~-9 ~-1 ~-175 minecraft:gravel
fill ~-9 ~-6 ~-17 ~-9 ~-1 ~-17 minecraft:gravel
fill ~-9 ~-6 ~-15 ~-9 ~-1 ~-14 minecraft:gravel
fill ~-9 ~-6 ~-11 ~-7 ~-1 ~-11 minecraft:gravel
fill ~-8 ~-6 ~-183 ~-8 ~-1 ~-183 minecraft:gravel
fill ~-8 ~-6 ~-179 ~-7 ~-1 ~-179 minecraft:gravel
fill ~-8 ~-6 ~-14 ~-8 ~-1 ~-14 minecraft:gravel
fill ~-8 ~-6 ~-10 ~-7 ~-1 ~-10 minecraft:gravel
fill ~-7 ~-6 ~-15 ~-6 ~-1 ~-15 minecraft:gravel
fill ~-6 ~-6 ~-177 ~-5 ~-1 ~-177 minecraft:gravel
fill ~-6 ~-6 ~-176 ~-6 ~-1 ~-176 minecraft:gravel
fill ~-6 ~-6 ~-17 ~-6 ~-1 ~-17 minecraft:gravel
fill ~-6 ~-6 ~-14 ~-5 ~-1 ~-13 minecraft:gravel
fill ~-5 ~-6 ~-185 ~-5 ~-1 ~-185 minecraft:gravel
fill ~-5 ~-6 ~-183 ~-5 ~-1 ~-183 minecraft:gravel
fill ~-5 ~-6 ~-175 ~-5 ~-1 ~-175 minecraft:gravel
fill ~-5 ~-6 ~-12 ~-5 ~ ~-12 minecraft:gravel
fill ~-5 ~-6 ~-9 ~-5 ~ ~-9 minecraft:gravel
fill ~-5 ~-6 ~-7 ~-4 ~-2 ~-7 minecraft:gravel
fill ~-3 ~-6 ~-184 ~-3 ~-1 ~-184 minecraft:gravel
fill ~-3 ~-6 ~-182 ~-1 ~-1 ~-182 minecraft:gravel
fill ~-3 ~-6 ~-180 ~-3 ~-1 ~-180 minecraft:gravel
fill ~-3 ~-6 ~-176 ~-2 ~-1 ~-176 minecraft:gravel
fill ~-3 ~-6 ~-10 ~-3 ~-2 ~-10 minecraft:gravel
fill ~-3 ~-6 ~-8 ~-3 ~-2 ~-8 minecraft:gravel
fill ~-2 ~-6 ~-185 ~-2 ~-1 ~-185 minecraft:gravel
fill ~-2 ~-6 ~-178 ~-1 ~-1 ~-178 minecraft:gravel
fill ~-2 ~-6 ~-175 ~-1 ~-1 ~-175 minecraft:gravel
fill ~-2 ~-6 ~-17 ~-2 ~-2 ~-17 minecraft:gravel
fill ~-2 ~-6 ~-15 ~-2 ~-2 ~-15 minecraft:gravel
fill ~-2 ~-6 ~-13 ~-2 ~-2 ~-13 minecraft:gravel
fill ~-2 ~-6 ~-9 ~ ~-2 ~-9 minecraft:gravel
fill ~-2 ~-6 ~-7 ~-2 ~-2 ~-7 minecraft:gravel
fill ~-1 ~-6 ~-183 ~-1 ~-1 ~-182 minecraft:gravel
fill ~-1 ~-6 ~-11 ~-1 ~-2 ~-11 minecraft:gravel
fill ~ ~-6 ~-180 ~ ~-1 ~-180 minecraft:gravel
fill ~ ~-6 ~-177 ~ ~-1 ~-177 minecraft:gravel
fill ~ ~-6 ~-14 ~ ~-2 ~-14 minecraft:gravel
fill ~ ~-6 ~-8 ~ ~-2 ~-8 minecraft:gravel
fill ~1 ~-6 ~-184 ~1 ~-1 ~-184 minecraft:gravel
fill ~1 ~-6 ~-182 ~2 ~-1 ~-182 minecraft:gravel
fill ~1 ~-6 ~-179 ~1 ~-1 ~-179 minecraft:gravel
fill ~1 ~-6 ~-17 ~1 ~-2 ~-17 minecraft:gravel
fill ~1 ~-6 ~-12 ~1 ~-2 ~-12 minecraft:gravel
fill ~2 ~-6 ~-177 ~3 ~-1 ~-177 minecraft:gravel
fill ~2 ~-6 ~-16 ~2 ~-2 ~-16 minecraft:gravel
fill ~2 ~-6 ~-14 ~3 ~-2 ~-14 minecraft:gravel
fill ~2 ~-6 ~-9 ~2 ~-2 ~-9 minecraft:gravel
fill ~2 ~-6 ~-7 ~3 ~-2 ~-7 minecraft:gravel
fill ~3 ~-6 ~-184 ~3 ~-1 ~-184 minecraft:gravel
fill ~3 ~-6 ~-178 ~3 ~-1 ~-177 minecraft:gravel
fill ~3 ~-6 ~-13 ~3 ~-2 ~-13 minecraft:gravel
fill ~4 ~-6 ~-185 ~4 ~-1 ~-185 minecraft:gravel
fill ~4 ~-6 ~-183 ~4 ~-1 ~-181 minecraft:gravel
fill ~4 ~-6 ~-17 ~4 ~-2 ~-17 minecraft:gravel
fill ~4 ~-6 ~-11 ~4 ~-2 ~-11 minecraft:gravel
fill ~4 ~-6 ~-9 ~4 ~-2 ~-8 minecraft:gravel
fill ~5 ~-6 ~-184 ~5 ~-1 ~-184 minecraft:gravel
fill ~5 ~-6 ~-182 ~5 ~-1 ~-181 minecraft:gravel
fill ~5 ~-6 ~-178 ~5 ~-1 ~-178 minecraft:gravel
fill ~5 ~-6 ~-14 ~5 ~ ~-14 minecraft:gravel
fill ~5 ~-6 ~-8 ~5 ~ ~-8 minecraft:gravel
fill ~6 ~-6 ~-180 ~6 ~-1 ~-180 minecraft:gravel
fill ~6 ~-6 ~-16 ~7 ~-1 ~-16 minecraft:gravel
fill ~6 ~-6 ~-15 ~6 ~-1 ~-15 minecraft:gravel
fill ~6 ~-6 ~-13 ~9 ~-1 ~-13 minecraft:gravel
fill ~6 ~-6 ~-11 ~6 ~-1 ~-11 minecraft:gravel
fill ~7 ~-6 ~-185 ~8 ~-1 ~-185 minecraft:gravel
fill ~7 ~-6 ~-183 ~9 ~-1 ~-183 minecraft:gravel
fill ~7 ~-6 ~-179 ~7 ~-1 ~-179 minecraft:gravel
fill ~7 ~-6 ~-177 ~7 ~-1 ~-176 minecraft:gravel
fill ~7 ~-6 ~-10 ~7 ~-1 ~-10 minecraft:gravel
fill ~8 ~-6 ~-182 ~9 ~-1 ~-182 minecraft:gravel
fill ~8 ~-6 ~-181 ~8 ~-1 ~-180 minecraft:gravel
fill ~8 ~-6 ~-175 ~9 ~-1 ~-175 minecraft:gravel
fill ~8 ~-6 ~-8 ~9 ~-1 ~-8 minecraft:gravel
fill ~9 ~-6 ~-184 ~10 ~-1 ~-184 minecraft:gravel
fill ~9 ~-6 ~-16 ~9 ~-1 ~-16 minecraft:gravel
fill ~9 ~-6 ~-7 ~9 ~-1 ~-7 minecraft:gravel
fill ~10 ~-6 ~-180 ~10 ~-1 ~-179 minecraft:gravel
fill ~10 ~-6 ~-176 ~10 ~-1 ~-176 minecraft:gravel
fill ~10 ~-6 ~-17 ~10 ~-1 ~-17 minecraft:gravel
fill ~11 ~-6 ~-185 ~11 ~-1 ~-185 minecraft:gravel
fill ~11 ~-6 ~-182 ~13 ~-1 ~-182 minecraft:gravel
fill ~11 ~-6 ~-178 ~11 ~-1 ~-178 minecraft:gravel
fill ~11 ~-6 ~-15 ~11 ~-1 ~-15 minecraft:gravel
fill ~11 ~-6 ~-9 ~11 ~-1 ~-8 minecraft:gravel
fill ~12 ~-6 ~-181 ~13 ~-1 ~-181 minecraft:gravel
fill ~12 ~-6 ~-16 ~12 ~-1 ~-16 minecraft:gravel
fill ~12 ~-6 ~-14 ~12 ~-1 ~-13 minecraft:gravel
fill ~13 ~-6 ~-183 ~13 ~-1 ~-180 minecraft:gravel
fill ~13 ~-6 ~-175 ~14 ~-1 ~-175 minecraft:gravel
fill ~13 ~-6 ~-17 ~13 ~-1 ~-17 minecraft:gravel
fill ~13 ~-6 ~-11 ~13 ~-1 ~-11 minecraft:gravel
fill ~13 ~-6 ~-8 ~14 ~-1 ~-8 minecraft:gravel
fill ~14 ~-6 ~-180 ~14 ~-1 ~-180 minecraft:gravel
fill ~14 ~-6 ~-177 ~15 ~-1 ~-177 minecraft:gravel
fill ~14 ~-6 ~-16 ~15 ~-1 ~-16 minecraft:gravel
fill ~14 ~-6 ~-15 ~14 ~-1 ~-14 minecraft:gravel
fill ~14 ~-6 ~-9 ~14 ~-1 ~-8 minecraft:gravel
fill ~16 ~-6 ~-182 ~16 ~-1 ~-182 minecraft:gravel
fill ~16 ~-6 ~-175 ~16 ~-1 ~-175 minecraft:gravel
fill ~16 ~-6 ~-15 ~16 ~-1 ~-14 minecraft:gravel
fill ~16 ~-6 ~-11 ~18 ~-1 ~-11 minecraft:gravel
fill ~17 ~-6 ~-183 ~17 ~-1 ~-183 minecraft:gravel
fill ~17 ~-6 ~-181 ~17 ~-1 ~-181 minecraft:gravel
fill ~17 ~-6 ~-13 ~18 ~-1 ~-13 minecraft:gravel
fill ~18 ~-6 ~-184 ~18 ~-1 ~-184 minecraft:gravel
fill ~18 ~-6 ~-182 ~18 ~-1 ~-182 minecraft:gravel
fill ~18 ~-6 ~-14 ~18 ~-1 ~-10 minecraft:gravel
fill ~19 ~-6 ~-181 ~20 ~-1 ~-181 minecraft:gravel
fill ~19 ~-6 ~-179 ~19 ~-1 ~-179 minecraft:gravel
fill ~19 ~-6 ~-176 ~20 ~-1 ~-175 minecraft:gravel
fill ~19 ~-6 ~-9 ~19 ~-1 ~-8 minecraft:gravel
fill ~20 ~-6 ~-184 ~20 ~-1 ~-184 minecraft:gravel
fill ~20 ~-6 ~-182 ~20 ~-1 ~-181 minecraft:gravel
fill ~20 ~-6 ~-177 ~20 ~-1 ~-175 minecraft:gravel
fill ~21 ~-6 ~-175 ~21 ~-1 ~-175 minecraft:gravel
fill ~21 ~-6 ~-17 ~21 ~-1 ~-17 minecraft:gravel
fill ~21 ~-6 ~-13 ~21 ~-1 ~-13 minecraft:gravel
fill ~21 ~-6 ~-10 ~21 ~-1 ~-9 minecraft:gravel
fill ~21 ~-6 ~-7 ~21 ~-1 ~-7 minecraft:gravel
fill ~22 ~-6 ~-182 ~23 ~-1 ~-182 minecraft:gravel
fill ~22 ~-6 ~-176 ~22 ~-1 ~-176 minecraft:gravel
fill ~22 ~-6 ~-15 ~23 ~-1 ~-15 minecraft:gravel
fill ~22 ~-6 ~-12 ~22 ~-1 ~-12 minecraft:gravel
fill ~23 ~-6 ~-177 ~24 ~-1 ~-177 minecraft:gravel
fill ~23 ~-6 ~-14 ~23 ~-1 ~-14 minecraft:gravel
fill ~23 ~-6 ~-11 ~23 ~-1 ~-11 minecraft:gravel
fill ~23 ~-6 ~-9 ~23 ~-1 ~-8 minecraft:gravel
fill ~24 ~-6 ~-181 ~24 ~-1 ~-181 minecraft:gravel
fill ~24 ~-6 ~-179 ~25 ~-1 ~-179 minecraft:gravel
fill ~24 ~-6 ~-16 ~24 ~-1 ~-16 minecraft:gravel
fill ~24 ~-6 ~-12 ~24 ~-1 ~-12 minecraft:gravel
fill ~24 ~-6 ~-8 ~24 ~-1 ~-8 minecraft:gravel
fill ~25 ~-6 ~-184 ~25 ~-1 ~-184 minecraft:gravel
fill ~25 ~-6 ~-180 ~28 ~-1 ~-180 minecraft:gravel
fill ~25 ~-6 ~-17 ~26 ~-1 ~-17 minecraft:gravel
fill ~25 ~-6 ~-15 ~26 ~-1 ~-15 minecraft:gravel
fill ~25 ~-6 ~-10 ~25 ~-1 ~-9 minecraft:gravel
fill ~26 ~-6 ~-13 ~26 ~-1 ~-13 minecraft:gravel
fill ~26 ~-6 ~-11 ~27 ~-1 ~-11 minecraft:gravel
fill ~27 ~-6 ~-181 ~28 ~-1 ~-180 minecraft:gravel
fill ~27 ~-6 ~-178 ~27 ~-1 ~-178 minecraft:gravel
fill ~27 ~-6 ~-16 ~27 ~-1 ~-16 minecraft:gravel
fill ~27 ~-6 ~-12 ~27 ~-1 ~-11 minecraft:gravel
fill ~27 ~-6 ~-9 ~27 ~-1 ~-9 minecraft:gravel
fill ~28 ~-6 ~-185 ~29 ~-1 ~-183 minecraft:gravel
fill ~28 ~-6 ~-176 ~28 ~-1 ~-176 minecraft:gravel
fill ~29 ~-6 ~-178 ~29 ~-1 ~-178 minecraft:gravel
fill ~29 ~-6 ~-12 ~31 ~-1 ~-12 minecraft:gravel
fill ~29 ~-6 ~-11 ~29 ~-1 ~-8 minecraft:gravel
fill ~30 ~-6 ~-179 ~30 ~-1 ~-179 minecraft:gravel
fill ~30 ~-6 ~-175 ~30 ~-1 ~-175 minecraft:gravel
fill ~30 ~-6 ~-7 ~31 ~-1 ~-7 minecraft:gravel
fill ~31 ~-6 ~-184 ~31 ~-1 ~-183 minecraft:gravel
fill ~31 ~-6 ~-181 ~32 ~-1 ~-181 minecraft:gravel
fill ~31 ~-6 ~-177 ~31 ~-1 ~-176 minecraft:gravel
fill ~31 ~-6 ~-11 ~31 ~-1 ~-11 minecraft:gravel
fill ~32 ~-6 ~-179 ~32 ~-1 ~-179 minecraft:gravel
fill ~32 ~-6 ~-176 ~32 ~-1 ~-176 minecraft:gravel
fill ~32 ~-6 ~-16 ~34 ~-1 ~-16 minecraft:gravel
fill ~32 ~-6 ~-10 ~32 ~-1 ~-10 minecraft:gravel
fill ~33 ~-6 ~-185 ~34 ~-1 ~-185 minecraft:gravel
fill ~33 ~-6 ~-177 ~34 ~-1 ~-177 minecraft:gravel
fill ~33 ~-6 ~-13 ~36 ~-1 ~-13 minecraft:gravel
fill ~34 ~-6 ~-181 ~34 ~-1 ~-181 minecraft:gravel
fill ~34 ~-6 ~-12 ~34 ~-1 ~-11 minecraft:gravel
fill ~34 ~-6 ~-9 ~34 ~-1 ~-9 minecraft:gravel
fill ~34 ~-6 ~-7 ~35 ~-1 ~-7 minecraft:gravel
fill ~35 ~-6 ~-182 ~35 ~-1 ~-182 minecraft:gravel
fill ~35 ~-6 ~-176 ~35 ~-1 ~-175 minecraft:gravel
fill ~35 ~-6 ~-17 ~35 ~-1 ~-17 minecraft:gravel
fill ~35 ~-6 ~-14 ~35 ~-1 ~-13 minecraft:gravel
fill ~35 ~-6 ~-11 ~36 ~-1 ~-11 minecraft:gravel
fill ~36 ~-6 ~-183 ~36 ~-1 ~-183 minecraft:gravel
fill ~36 ~-6 ~-180 ~36 ~-1 ~-180 minecraft:gravel
fill ~36 ~-6 ~-16 ~39 ~-1 ~-16 minecraft:gravel
fill ~37 ~-6 ~-182 ~37 ~-1 ~-182 minecraft:gravel
fill ~37 ~-6 ~-10 ~38 ~-1 ~-10 minecraft:gravel
fill ~38 ~-6 ~-184 ~38 ~-1 ~-184 minecraft:gravel
fill ~38 ~-6 ~-178 ~38 ~-1 ~-178 minecraft:gravel
fill ~39 ~-6 ~-185 ~40 ~-1 ~-185 minecraft:gravel
fill ~39 ~-6 ~-183 ~39 ~-1 ~-183 minecraft:gravel
fill ~39 ~-6 ~-179 ~41 ~-1 ~-179 minecraft:gravel
fill ~39 ~-6 ~-176 ~41 ~-1 ~-176 minecraft:gravel
fill ~39 ~-6 ~-17 ~39 ~-1 ~-16 minecraft:gravel
fill ~39 ~-6 ~-13 ~41 ~-1 ~-13 minecraft:gravel
fill ~40 ~-6 ~-181 ~40 ~-1 ~-179 minecraft:gravel
fill ~40 ~-6 ~-175 ~40 ~-1 ~-175 minecraft:gravel
fill ~40 ~-6 ~-12 ~40 ~-1 ~-12 minecraft:gravel
fill ~40 ~-6 ~-9 ~40 ~-1 ~-9 minecraft:gravel
fill ~41 ~-6 ~-177 ~42 ~-1 ~-177 minecraft:gravel
fill ~41 ~-6 ~-16 ~43 ~-1 ~-16 minecraft:gravel
fill ~41 ~-6 ~-14 ~41 ~-1 ~-13 minecraft:gravel
fill ~42 ~-6 ~-184 ~42 ~-1 ~-184 minecraft:gravel
fill ~42 ~-6 ~-181 ~42 ~-1 ~-181 minecraft:gravel
fill ~42 ~-6 ~-178 ~42 ~-1 ~-177 minecraft:gravel
fill ~42 ~-6 ~-10 ~43 ~-1 ~-10 minecraft:gravel
fill ~42 ~-6 ~-7 ~45 ~-1 ~-7 minecraft:gravel
fill ~43 ~-6 ~-185 ~45 ~-1 ~-185 minecraft:gravel
fill ~43 ~-6 ~-183 ~45 ~-1 ~-183 minecraft:gravel
fill ~43 ~-6 ~-182 ~43 ~-1 ~-182 minecraft:gravel
fill ~43 ~-6 ~-175 ~43 ~-1 ~-175 minecraft:gravel
fill ~43 ~-6 ~-15 ~43 ~-1 ~-15 minecraft:gravel
fill ~44 ~-6 ~-176 ~44 ~-1 ~-176 minecraft:gravel
fill ~45 ~-6 ~-184 ~45 ~-1 ~-183 minecraft:gravel
fill ~45 ~-6 ~-177 ~45 ~-1 ~-177 minecraft:gravel
fill ~45 ~-6 ~-175 ~45 ~-1 ~-175 minecraft:gravel
fill ~45 ~-6 ~-17 ~45 ~-1 ~-17 minecraft:gravel
fill ~45 ~-6 ~-13 ~45 ~-1 ~-13 minecraft:gravel
fill ~46 ~-6 ~-182 ~46 ~-1 ~-182 minecraft:gravel
fill ~46 ~-6 ~-9 ~46 ~-1 ~-9 minecraft:gravel
fill ~47 ~-6 ~-185 ~47 ~-1 ~-185 minecraft:gravel
fill ~47 ~-6 ~-180 ~47 ~-1 ~-180 minecraft:gravel
fill ~47 ~-6 ~-16 ~47 ~-1 ~-16 minecraft:gravel
fill ~47 ~-6 ~-14 ~47 ~-1 ~-14 minecraft:gravel
fill ~47 ~-6 ~-12 ~48 ~-1 ~-12 minecraft:gravel
fill ~48 ~-6 ~-179 ~48 ~-1 ~-178 minecraft:gravel
fill ~48 ~-6 ~-15 ~48 ~-1 ~-15 minecraft:gravel
fill ~48 ~-6 ~-13 ~49 ~-1 ~-13 minecraft:gravel
fill ~48 ~-6 ~-11 ~49 ~-1 ~-11 minecraft:gravel
fill ~48 ~-6 ~-10 ~48 ~-1 ~-10 minecraft:gravel
fill ~48 ~-6 ~-8 ~48 ~-1 ~-7 minecraft:gravel
fill ~49 ~-6 ~-185 ~49 ~-1 ~-184 minecraft:gravel
fill ~49 ~-6 ~-182 ~49 ~-1 ~-182 minecraft:gravel
fill ~49 ~-6 ~-180 ~49 ~-1 ~-180 minecraft:gravel
fill ~49 ~-6 ~-176 ~49 ~-1 ~-175 minecraft:gravel
fill ~49 ~-6 ~-17 ~50 ~-1 ~-17 minecraft:gravel
fill ~49 ~-6 ~-14 ~50 ~-1 ~-14 minecraft:gravel
fill ~49 ~-6 ~-9 ~50 ~-1 ~-9 minecraft:gravel
fill ~50 ~-6 ~-184 ~50 ~-1 ~-184 minecraft:gravel
fill ~50 ~-6 ~-177 ~50 ~-1 ~-177 minecraft:gravel
fill ~50 ~-6 ~-175 ~50 ~-1 ~-175 minecraft:gravel
fill ~50 ~-6 ~-15 ~50 ~-1 ~-14 minecraft:gravel
fill ~50 ~-6 ~-8 ~50 ~-1 ~-8 minecraft:gravel
fill ~51 ~-6 ~-179 ~51 ~-1 ~-179 minecraft:gravel
fill ~51 ~-6 ~-13 ~51 ~-1 ~-12 minecraft:gravel
fill ~52 ~-6 ~-183 ~52 ~-1 ~-183 minecraft:gravel
fill ~52 ~-6 ~-181 ~52 ~-1 ~-181 minecraft:gravel
fill ~52 ~-6 ~-178 ~52 ~-1 ~-178 minecraft:gravel
fill ~52 ~-6 ~-176 ~52 ~-1 ~-175 minecraft:gravel
fill ~52 ~-6 ~-12 ~52 ~-1 ~-12 minecraft:gravel
fill ~52 ~-6 ~-9 ~53 ~-1 ~-9 minecraft:gravel
fill ~52 ~-6 ~-7 ~52 ~-1 ~-7 minecraft:gravel
fill ~53 ~-6 ~-185 ~53 ~-1 ~-185 minecraft:gravel
fill ~53 ~-6 ~-17 ~53 ~-1 ~-17 minecraft:gravel
fill ~54 ~-6 ~-184 ~54 ~-1 ~-184 minecraft:gravel
fill ~54 ~-6 ~-181 ~56 ~-1 ~-181 minecraft:gravel
fill ~54 ~-6 ~-180 ~54 ~-1 ~-179 minecraft:gravel
fill ~54 ~-6 ~-15 ~54 ~-1 ~-15 minecraft:gravel
fill ~54 ~-6 ~-12 ~55 ~-1 ~-12 minecraft:gravel
fill ~55 ~-6 ~-176 ~55 ~-1 ~-175 minecraft:gravel
fill ~55 ~-6 ~-16 ~56 ~-1 ~-16 minecraft:gravel
fill ~55 ~-6 ~-11 ~55 ~-1 ~-11 minecraft:gravel
fill ~56 ~-6 ~-185 ~56 ~-1 ~-185 minecraft:gravel
fill ~56 ~-6 ~-179 ~59 ~-1 ~-179 minecraft:gravel
fill ~56 ~-6 ~-178 ~56 ~-1 ~-177 minecraft:gravel
fill ~56 ~-6 ~-175 ~56 ~-1 ~-175 minecraft:gravel
fill ~56 ~-6 ~-9 ~56 ~-1 ~-9 minecraft:gravel
fill ~56 ~-6 ~-7 ~56 ~-1 ~-7 minecraft:gravel
fill ~57 ~-6 ~-182 ~57 ~-1 ~-182 minecraft:gravel
fill ~57 ~-6 ~-176 ~57 ~-1 ~-176 minecraft:gravel
fill ~57 ~-6 ~-17 ~58 ~-1 ~-17 minecraft:gravel
fill ~58 ~-6 ~-178 ~60 ~-1 ~-178 minecraft:gravel
fill ~58 ~-6 ~-15 ~58 ~-1 ~-15 minecraft:gravel
fill ~58 ~-6 ~-13 ~59 ~-1 ~-13 minecraft:gravel
fill ~58 ~-6 ~-11 ~58 ~-1 ~-11 minecraft:gravel
fill ~59 ~-6 ~-185 ~60 ~-1 ~-185 minecraft:gravel
fill ~59 ~-6 ~-182 ~59 ~-1 ~-182 minecraft:gravel
fill ~59 ~-6 ~-14 ~59 ~-1 ~-13 minecraft:gravel
fill ~60 ~-6 ~-180 ~61 ~-1 ~-180 minecraft:gravel
fill ~60 ~-6 ~-175 ~60 ~-1 ~-175 minecraft:gravel
fill ~60 ~-6 ~-17 ~60 ~-1 ~-17 minecraft:gravel
fill ~60 ~-6 ~-12 ~60 ~-1 ~-11 minecraft:gravel
fill ~61 ~-6 ~-176 ~61 ~-1 ~-176 minecraft:gravel
fill ~61 ~-6 ~-14 ~62 ~-1 ~-13 minecraft:gravel
fill ~61 ~-6 ~-11 ~61 ~-1 ~-11 minecraft:gravel
fill ~61 ~-6 ~-9 ~61 ~-1 ~-9 minecraft:gravel
fill ~61 ~-6 ~-7 ~61 ~-1 ~-7 minecraft:gravel
fill ~62 ~-6 ~-182 ~62 ~-1 ~-182 minecraft:gravel
fill ~62 ~-6 ~-179 ~63 ~-1 ~-179 minecraft:gravel
fill ~62 ~-6 ~-10 ~62 ~-1 ~-10 minecraft:gravel
fill ~63 ~-6 ~-184 ~63 ~-1 ~-183 minecraft:gravel
fill ~63 ~-6 ~-180 ~64 ~-1 ~-180 minecraft:gravel
fill ~63 ~-6 ~-177 ~63 ~-1 ~-177 minecraft:gravel
fill ~63 ~-6 ~-12 ~63 ~-1 ~-12 minecraft:gravel
fill ~63 ~-6 ~-8 ~63 ~-1 ~-8 minecraft:gravel
fill ~64 ~-6 ~-185 ~65 ~-1 ~-185 minecraft:gravel
fill ~64 ~-6 ~-183 ~64 ~-1 ~-183 minecraft:gravel
fill ~64 ~-6 ~-181 ~64 ~-1 ~-180 minecraft:gravel
fill ~64 ~-6 ~-178 ~65 ~-1 ~-178 minecraft:gravel
fill ~64 ~-6 ~-176 ~65 ~-1 ~-176 minecraft:gravel
fill ~64 ~-6 ~-13 ~64 ~-1 ~-13 minecraft:gravel
fill ~65 ~-6 ~-12 ~65 ~-1 ~-12 minecraft:gravel
fill ~65 ~-6 ~-8 ~65 ~-1 ~-8 minecraft:gravel
fill ~66 ~-6 ~-179 ~66 ~-1 ~-179 minecraft:gravel
fill ~66 ~-6 ~-11 ~66 ~-1 ~-11 minecraft:gravel
fill ~66 ~-6 ~-9 ~66 ~-1 ~-9 minecraft:gravel
fill ~67 ~-6 ~-181 ~67 ~-1 ~-181 minecraft:gravel
fill ~67 ~-6 ~-178 ~67 ~-1 ~-176 minecraft:gravel
fill ~67 ~-6 ~-13 ~69 ~-1 ~-13 minecraft:gravel
fill ~67 ~-6 ~-8 ~67 ~-1 ~-8 minecraft:gravel
fill ~68 ~-6 ~-184 ~68 ~-1 ~-182 minecraft:gravel
fill ~68 ~-6 ~-179 ~69 ~-1 ~-179 minecraft:gravel
fill ~68 ~-6 ~-14 ~68 ~-1 ~-11 minecraft:gravel
fill ~69 ~-6 ~-178 ~70 ~-1 ~-176 minecraft:gravel
fill ~69 ~-6 ~-175 ~69 ~-1 ~-175 minecraft:gravel
fill ~69 ~-6 ~-17 ~69 ~-1 ~-17 minecraft:gravel
fill ~69 ~-6 ~-11 ~72 ~-1 ~-11 minecraft:gravel
fill ~69 ~-6 ~-10 ~69 ~-1 ~-10 minecraft:gravel
fill ~69 ~-6 ~-7 ~69 ~-1 ~-7 minecraft:gravel
fill ~70 ~-6 ~-183 ~70 ~-1 ~-183 minecraft:gravel
fill ~70 ~-6 ~-181 ~70 ~-1 ~-181 minecraft:gravel
fill ~71 ~-6 ~-185 ~72 ~-1 ~-185 minecraft:gravel
fill ~71 ~-6 ~-182 ~72 ~-1 ~-182 minecraft:gravel
fill ~71 ~-6 ~-177 ~71 ~-1 ~-176 minecraft:gravel
fill ~71 ~-6 ~-16 ~71 ~-1 ~-14 minecraft:gravel
fill ~72 ~-6 ~-183 ~75 ~-1 ~-183 minecraft:gravel
fill ~72 ~-6 ~-181 ~72 ~-1 ~-181 minecraft:gravel
fill ~72 ~-6 ~-175 ~73 ~-1 ~-175 minecraft:gravel
fill ~72 ~-6 ~-17 ~73 ~-1 ~-17 minecraft:gravel
fill ~72 ~-6 ~-15 ~72 ~-1 ~-15 minecraft:gravel
fill ~72 ~-6 ~-13 ~73 ~-1 ~-13 minecraft:gravel
fill ~73 ~-6 ~-8 ~73 ~-1 ~-8 minecraft:gravel
fill ~74 ~-6 ~-181 ~74 ~-1 ~-181 minecraft:gravel
fill ~74 ~-6 ~-11 ~74 ~-1 ~-10 minecraft:gravel
fill ~75 ~-6 ~-180 ~75 ~-1 ~-180 minecraft:gravel
fill ~75 ~-6 ~-176 ~75 ~-1 ~-175 minecraft:gravel
fill ~75 ~-6 ~-17 ~75 ~-1 ~-17 minecraft:gravel
fill ~75 ~-6 ~-13 ~77 ~-1 ~-13 minecraft:gravel
fill ~75 ~-6 ~-9 ~75 ~-1 ~-8 minecraft:gravel
fill ~76 ~-6 ~-182 ~76 ~-1 ~-182 minecraft:gravel
fill ~76 ~-6 ~-177 ~77 ~-1 ~-177 minecraft:gravel
fill ~76 ~-6 ~-15 ~76 ~-1 ~-15 minecraft:gravel
fill ~76 ~-6 ~-8 ~76 ~-1 ~-8 minecraft:gravel
fill ~77 ~-6 ~-185 ~77 ~-1 ~-185 minecraft:gravel
fill ~77 ~-6 ~-179 ~77 ~-1 ~-179 minecraft:gravel
fill ~77 ~-6 ~-175 ~77 ~-1 ~-175 minecraft:gravel
fill ~77 ~-6 ~-14 ~80 ~-1 ~-14 minecraft:gravel
fill ~78 ~-6 ~-183 ~81 ~-1 ~-183 minecraft:gravel
fill ~78 ~-6 ~-180 ~79 ~-1 ~-180 minecraft:gravel
fill ~78 ~-6 ~-10 ~78 ~-1 ~-10 minecraft:gravel
fill ~78 ~-6 ~-8 ~78 ~-1 ~-8 minecraft:gravel
fill ~79 ~-6 ~-179 ~79 ~-1 ~-178 minecraft:gravel
fill ~79 ~-6 ~-175 ~79 ~-1 ~-175 minecraft:gravel
fill ~79 ~-6 ~-167 ~79 ~-1 ~-167 minecraft:gravel
fill ~79 ~-6 ~-158 ~81 ~-1 ~-158 minecraft:gravel
fill ~79 ~-6 ~-157 ~79 ~-1 ~-157 minecraft:gravel
fill ~79 ~-6 ~-155 ~79 ~-1 ~-155 minecraft:gravel
fill ~79 ~-6 ~-151 ~79 ~-1 ~-151 minecraft:gravel
fill ~79 ~-6 ~-149 ~79 ~-1 ~-149 minecraft:gravel
fill ~79 ~-6 ~-147 ~79 ~-1 ~-147 minecraft:gravel
fill ~79 ~-6 ~-144 ~79 ~-1 ~-144 minecraft:gravel
fill ~79 ~-6 ~-142 ~79 ~-1 ~-142 minecraft:gravel
fill ~79 ~-6 ~-140 ~79 ~-1 ~-140 minecraft:gravel
fill ~79 ~-6 ~-138 ~80 ~-1 ~-138 minecraft:gravel
fill ~79 ~-6 ~-132 ~79 ~-1 ~-130 minecraft:gravel
fill ~79 ~-6 ~-121 ~79 ~-1 ~-118 minecraft:gravel
fill ~79 ~-6 ~-115 ~83 ~-1 ~-115 minecraft:gravel
fill ~79 ~-6 ~-112 ~79 ~-1 ~-112 minecraft:gravel
fill ~79 ~-6 ~-109 ~79 ~-1 ~-109 minecraft:gravel
fill ~79 ~-6 ~-106 ~79 ~-1 ~-105 minecraft:gravel
fill ~79 ~-6 ~-99 ~79 ~-1 ~-99 minecraft:gravel
fill ~79 ~-6 ~-96 ~79 ~-1 ~-96 minecraft:gravel
fill ~79 ~-6 ~-92 ~79 ~-1 ~-92 minecraft:gravel
fill ~79 ~-6 ~-82 ~79 ~-1 ~-82 minecraft:gravel
fill ~79 ~-6 ~-74 ~79 ~-1 ~-74 minecraft:gravel
fill ~79 ~-6 ~-68 ~80 ~-1 ~-68 minecraft:gravel
fill ~79 ~-6 ~-65 ~79 ~-1 ~-65 minecraft:gravel
fill ~79 ~-6 ~-63 ~79 ~-1 ~-63 minecraft:gravel
fill ~79 ~-6 ~-59 ~79 ~-1 ~-59 minecraft:gravel
fill ~79 ~-6 ~-57 ~79 ~-1 ~-56 minecraft:gravel
fill ~79 ~-6 ~-51 ~80 ~-1 ~-51 minecraft:gravel
fill ~79 ~-6 ~-50 ~79 ~-1 ~-50 minecraft:gravel
fill ~79 ~-6 ~-48 ~80 ~-1 ~-48 minecraft:gravel
fill ~79 ~-6 ~-40 ~79 ~-1 ~-39 minecraft:gravel
fill ~79 ~-6 ~-29 ~79 ~-1 ~-25 minecraft:gravel
fill ~79 ~-6 ~-22 ~79 ~-1 ~-21 minecraft:gravel
fill ~79 ~-6 ~-15 ~79 ~-1 ~-14 minecraft:gravel
fill ~79 ~-6 ~-7 ~79 ~-1 ~-7 minecraft:gravel
fill ~80 ~-6 ~-185 ~81 ~-1 ~-185 minecraft:gravel
fill ~80 ~-6 ~-181 ~82 ~-1 ~-181 minecraft:gravel
fill ~80 ~-6 ~-176 ~80 ~-1 ~-176 minecraft:gravel
fill ~80 ~-6 ~-174 ~80 ~-1 ~-173 minecraft:gravel
fill ~80 ~-6 ~-162 ~80 ~-1 ~-162 minecraft:gravel
fill ~80 ~-6 ~-159 ~80 ~-1 ~-158 minecraft:gravel
fill ~80 ~-6 ~-154 ~80 ~-1 ~-154 minecraft:gravel
fill ~80 ~-6 ~-150 ~82 ~-1 ~-150 minecraft:gravel
fill ~80 ~-6 ~-148 ~80 ~-1 ~-148 minecraft:gravel
fill ~80 ~-6 ~-146 ~80 ~-1 ~-146 minecraft:gravel
fill ~80 ~-6 ~-139 ~81 ~-1 ~-139 minecraft:gravel
fill ~80 ~-6 ~-137 ~80 ~-1 ~-137 minecraft:gravel
fill ~80 ~-6 ~-134 ~80 ~-1 ~-134 minecraft:gravel
fill ~80 ~-6 ~-130 ~80 ~-1 ~-130 minecraft:gravel
fill ~80 ~-6 ~-128 ~80 ~-1 ~-128 minecraft:gravel
fill ~80 ~-6 ~-126 ~80 ~-1 ~-126 minecraft:gravel
fill ~80 ~-6 ~-122 ~80 ~-1 ~-122 minecraft:gravel
fill ~80 ~-6 ~-119 ~80 ~-1 ~-119 minecraft:gravel
fill ~80 ~-6 ~-117 ~80 ~-1 ~-115 minecraft:gravel
fill ~80 ~-6 ~-113 ~80 ~-1 ~-113 minecraft:gravel
fill ~80 ~-6 ~-111 ~80 ~-1 ~-111 minecraft:gravel
fill ~80 ~-6 ~-105 ~80 ~-1 ~-105 minecraft:gravel
fill ~80 ~-6 ~-103 ~80 ~-1 ~-102 minecraft:gravel
fill ~80 ~-6 ~-95 ~80 ~-1 ~-94 minecraft:gravel
fill ~80 ~-6 ~-88 ~80 ~-1 ~-88 minecraft:gravel
fill ~80 ~-6 ~-86 ~81 ~-1 ~-86 minecraft:gravel
fill ~80 ~-6 ~-79 ~80 ~-1 ~-79 minecraft:gravel
fill ~80 ~-6 ~-77 ~81 ~-1 ~-77 minecraft:gravel
fill ~80 ~-6 ~-70 ~81 ~-1 ~-69 minecraft:gravel
fill ~80 ~-6 ~-64 ~80 ~-1 ~-64 minecraft:gravel
fill ~80 ~-6 ~-52 ~80 ~-1 ~-51 minecraft:gravel
fill ~80 ~-6 ~-47 ~81 ~-1 ~-47 minecraft:gravel
fill ~80 ~-6 ~-43 ~81 ~-1 ~-43 minecraft:gravel
fill ~80 ~-6 ~-41 ~80 ~-1 ~-41 minecraft:gravel
fill ~80 ~-6 ~-27 ~80 ~-1 ~-25 minecraft:gravel
fill ~80 ~-6 ~-20 ~80 ~-1 ~-19 minecraft:gravel
fill ~80 ~-6 ~-12 ~80 ~-1 ~-12 minecraft:gravel
fill ~81 ~-6 ~-182 ~81 ~-1 ~-181 minecraft:gravel
fill ~81 ~-6 ~-171 ~81 ~-1 ~-170 minecraft:gravel
fill ~81 ~-6 ~-168 ~82 ~-1 ~-168 minecraft:gravel
fill ~81 ~-6 ~-166 ~81 ~-1 ~-164 minecraft:gravel
fill ~81 ~-6 ~-157 ~81 ~-1 ~-157 minecraft:gravel
fill ~81 ~-6 ~-149 ~84 ~-1 ~-149 minecraft:gravel
fill ~81 ~-6 ~-145 ~81 ~-1 ~-145 minecraft:gravel
fill ~81 ~-6 ~-143 ~81 ~-1 ~-143 minecraft:gravel
fill ~81 ~-6 ~-136 ~82 ~-1 ~-136 minecraft:gravel
fill ~81 ~-6 ~-132 ~82 ~-1 ~-132 minecraft:gravel
fill ~81 ~-6 ~-129 ~82 ~-1 ~-129 minecraft:gravel
fill ~81 ~-6 ~-127 ~81 ~-1 ~-127 minecraft:gravel
fill ~81 ~-6 ~-120 ~81 ~-1 ~-120 minecraft:gravel
fill ~81 ~-6 ~-109 ~82 ~-1 ~-109 minecraft:gravel
fill ~81 ~-6 ~-107 ~81 ~-1 ~-107 minecraft:gravel
fill ~81 ~-6 ~-98 ~81 ~-1 ~-98 minecraft:gravel
fill ~81 ~-6 ~-96 ~81 ~-1 ~-96 minecraft:gravel
fill ~81 ~-6 ~-94 ~82 ~-1 ~-94 minecraft:gravel
fill ~81 ~-6 ~-87 ~81 ~-1 ~-85 minecraft:gravel
fill ~81 ~-6 ~-83 ~81 ~-1 ~-82 minecraft:gravel
fill ~81 ~-6 ~-72 ~81 ~-1 ~-72 minecraft:gravel
fill ~81 ~-6 ~-67 ~81 ~-1 ~-65 minecraft:gravel
fill ~81 ~-6 ~-60 ~81 ~-1 ~-60 minecraft:gravel
fill ~81 ~-6 ~-57 ~81 ~-1 ~-56 minecraft:gravel
fill ~81 ~-6 ~-49 ~82 ~-1 ~-49 minecraft:gravel
fill ~81 ~-6 ~-45 ~81 ~-1 ~-43 minecraft:gravel
fill ~81 ~-6 ~-35 ~81 ~-1 ~-34 minecraft:gravel
fill ~81 ~-6 ~-31 ~81 ~-1 ~-31 minecraft:gravel
fill ~81 ~-6 ~-28 ~81 ~-1 ~-28 minecraft:gravel
fill ~81 ~-6 ~-26 ~82 ~-1 ~-26 minecraft:gravel
fill ~81 ~-6 ~-22 ~81 ~-1 ~-22 minecraft:gravel
fill ~81 ~-6 ~-19 ~81 ~-1 ~-18 minecraft:gravel
fill ~81 ~-6 ~-16 ~82 ~-1 ~-16 minecraft:gravel
fill ~81 ~-6 ~-9 ~81 ~-1 ~-9 minecraft:gravel
fill ~82 ~-6 ~-184 ~83 ~-1 ~-184 minecraft:gravel
fill ~82 ~-6 ~-180 ~82 ~-1 ~-180 minecraft:gravel
fill ~82 ~-6 ~-177 ~82 ~-1 ~-177 minecraft:gravel
fill ~82 ~-6 ~-175 ~82 ~-1 ~-175 minecraft:gravel
fill ~82 ~-6 ~-165 ~83 ~-1 ~-165 minecraft:gravel
fill ~82 ~-6 ~-163 ~83 ~-1 ~-163 minecraft:gravel
fill ~82 ~-6 ~-162 ~82 ~-1 ~-162 minecraft:gravel
fill ~82 ~-6 ~-153 ~82 ~-1 ~-152 minecraft:gravel
fill ~82 ~-6 ~-147 ~82 ~-1 ~-147 minecraft:gravel
fill ~82 ~-6 ~-142 ~82 ~-1 ~-141 minecraft:gravel
fill ~82 ~-6 ~-121 ~83 ~-1 ~-121 minecraft:gravel
fill ~82 ~-6 ~-114 ~82 ~-1 ~-111 minecraft:gravel
fill ~82 ~-6 ~-105 ~83 ~-1 ~-105 minecraft:gravel
fill ~82 ~-6 ~-104 ~82 ~-1 ~-104 minecraft:gravel
fill ~82 ~-6 ~-100 ~82 ~-1 ~-100 minecraft:gravel
fill ~82 ~-6 ~-92 ~82 ~-1 ~-92 minecraft:gravel
fill ~82 ~-6 ~-85 ~83 ~-1 ~-85 minecraft:gravel
fill ~82 ~-6 ~-80 ~82 ~-1 ~-80 minecraft:gravel
fill ~82 ~-6 ~-78 ~84 ~-1 ~-78 minecraft:gravel
fill ~82 ~-6 ~-73 ~82 ~-1 ~-73 minecraft:gravel
fill ~82 ~-6 ~-66 ~84 ~-1 ~-66 minecraft:gravel
fill ~82 ~-6 ~-64 ~82 ~-1 ~-64 minecraft:gravel
fill ~82 ~-6 ~-62 ~84 ~-1 ~-62 minecraft:gravel
fill ~82 ~-6 ~-61 ~82 ~-1 ~-61 minecraft:gravel
fill ~82 ~-6 ~-53 ~82 ~-1 ~-52 minecraft:gravel
fill ~82 ~-6 ~-46 ~82 ~-1 ~-46 minecraft:gravel
fill ~82 ~-6 ~-44 ~82 ~-1 ~-44 minecraft:gravel
fill ~82 ~-6 ~-42 ~82 ~-1 ~-42 minecraft:gravel
fill ~82 ~-6 ~-40 ~86 ~-1 ~-40 minecraft:gravel
fill ~82 ~-6 ~-38 ~82 ~-1 ~-38 minecraft:gravel
fill ~82 ~-6 ~-36 ~82 ~-1 ~-36 minecraft:gravel
fill ~82 ~-6 ~-33 ~82 ~-1 ~-33 minecraft:gravel
fill ~82 ~-6 ~-29 ~82 ~-1 ~-29 minecraft:gravel
fill ~82 ~-6 ~-24 ~82 ~-1 ~-23 minecraft:gravel
fill ~82 ~-6 ~-21 ~82 ~-1 ~-21 minecraft:gravel
fill ~82 ~-6 ~-15 ~82 ~-1 ~-15 minecraft:gravel
fill ~82 ~-6 ~-12 ~82 ~-1 ~-12 minecraft:gravel
fill ~83 ~-6 ~-173 ~83 ~-1 ~-173 minecraft:gravel
fill ~83 ~-6 ~-159 ~83 ~-1 ~-159 minecraft:gravel
fill ~83 ~-6 ~-152 ~83 ~-1 ~-152 minecraft:gravel
fill ~83 ~-6 ~-145 ~83 ~-1 ~-145 minecraft:gravel
fill ~83 ~-6 ~-137 ~84 ~-1 ~-137 minecraft:gravel
fill ~83 ~-6 ~-131 ~83 ~-1 ~-130 minecraft:gravel
fill ~83 ~-6 ~-123 ~84 ~-1 ~-122 minecraft:gravel
fill ~83 ~-6 ~-118 ~83 ~-1 ~-118 minecraft:gravel
fill ~83 ~-6 ~-111 ~84 ~-1 ~-111 minecraft:gravel
fill ~83 ~-6 ~-108 ~85 ~-1 ~-108 minecraft:gravel
fill ~83 ~-6 ~-103 ~83 ~-1 ~-103 minecraft:gravel
fill ~83 ~-6 ~-99 ~84 ~-1 ~-99 minecraft:gravel
fill ~83 ~-6 ~-96 ~83 ~-1 ~-95 minecraft:gravel
fill ~83 ~-6 ~-88 ~83 ~-1 ~-88 minecraft:gravel
fill ~83 ~-6 ~-82 ~83 ~-1 ~-81 minecraft:gravel
fill ~83 ~-6 ~-74 ~83 ~-1 ~-74 minecraft:gravel
fill ~83 ~-6 ~-70 ~83 ~-1 ~-69 minecraft:gravel
fill ~83 ~-6 ~-58 ~84 ~-1 ~-58 minecraft:gravel
fill ~83 ~-6 ~-56 ~85 ~-1 ~-56 minecraft:gravel
fill ~83 ~-6 ~-50 ~83 ~-1 ~-50 minecraft:gravel
fill ~83 ~-6 ~-48 ~83 ~-1 ~-48 minecraft:gravel
fill ~83 ~-6 ~-45 ~83 ~-1 ~-45 minecraft:gravel
fill ~83 ~-6 ~-41 ~83 ~-1 ~-40 minecraft:gravel
fill ~83 ~-6 ~-32 ~83 ~-1 ~-32 minecraft:gravel
fill ~83 ~-6 ~-27 ~83 ~-1 ~-27 minecraft:gravel
fill ~83 ~-6 ~-20 ~83 ~-1 ~-18 minecraft:gravel
fill ~83 ~-6 ~-14 ~83 ~-1 ~-14 minecraft:gravel
fill ~83 ~-6 ~-10 ~83 ~-1 ~-9 minecraft:gravel
fill ~84 ~-6 ~-181 ~86 ~-1 ~-181 minecraft:gravel
fill ~84 ~-6 ~-178 ~84 ~-1 ~-178 minecraft:gravel
fill ~84 ~-6 ~-170 ~84 ~-1 ~-170 minecraft:gravel
fill ~84 ~-6 ~-167 ~86 ~-1 ~-167 minecraft:gravel
fill ~84 ~-6 ~-166 ~84 ~-1 ~-166 minecraft:gravel
fill ~84 ~-6 ~-162 ~85 ~-1 ~-162 minecraft:gravel
fill ~84 ~-6 ~-161 ~84 ~-1 ~-161 minecraft:gravel
fill ~84 ~-6 ~-157 ~84 ~-1 ~-157 minecraft:gravel
fill ~84 ~-6 ~-147 ~84 ~-1 ~-147 minecraft:gravel
fill ~84 ~-6 ~-144 ~85 ~-1 ~-144 minecraft:gravel
fill ~84 ~-6 ~-132 ~84 ~-1 ~-132 minecraft:gravel
fill ~84 ~-6 ~-110 ~85 ~-1 ~-110 minecraft:gravel
fill ~84 ~-6 ~-107 ~85 ~-1 ~-107 minecraft:gravel
fill ~84 ~-6 ~-98 ~85 ~-1 ~-98 minecraft:gravel
fill ~84 ~-6 ~-97 ~84 ~-1 ~-97 minecraft:gravel
fill ~84 ~-6 ~-93 ~84 ~-1 ~-93 minecraft:gravel
fill ~84 ~-6 ~-91 ~84 ~-1 ~-91 minecraft:gravel
fill ~84 ~-6 ~-79 ~85 ~-1 ~-79 minecraft:gravel
fill ~84 ~-6 ~-77 ~84 ~-1 ~-77 minecraft:gravel
fill ~84 ~-6 ~-73 ~86 ~-1 ~-73 minecraft:gravel
fill ~84 ~-6 ~-60 ~84 ~-1 ~-60 minecraft:gravel
fill ~84 ~-6 ~-57 ~84 ~-1 ~-56 minecraft:gravel
fill ~84 ~-6 ~-54 ~85 ~-1 ~-54 minecraft:gravel
fill ~84 ~-6 ~-43 ~85 ~-1 ~-43 minecraft:gravel
fill ~84 ~-6 ~-31 ~84 ~-1 ~-31 minecraft:gravel
fill ~84 ~-6 ~-28 ~84 ~-1 ~-28 minecraft:gravel
fill ~84 ~-6 ~-21 ~84 ~-1 ~-21 minecraft:gravel
fill ~84 ~-6 ~-19 ~84 ~-1 ~-19 minecraft:gravel
fill ~84 ~-6 ~-17 ~85 ~-1 ~-17 minecraft:gravel
fill ~84 ~-6 ~-16 ~84 ~-1 ~-16 minecraft:gravel
fill ~84 ~-6 ~-8 ~84 ~-1 ~-7 minecraft:gravel
fill ~85 ~-6 ~-184 ~85 ~-1 ~-184 minecraft:gravel
fill ~85 ~-6 ~-177 ~85 ~-1 ~-177 minecraft:gravel
fill ~85 ~-6 ~-164 ~85 ~-1 ~-164 minecraft:gravel
fill ~85 ~-6 ~-159 ~85 ~-1 ~-158 minecraft:gravel
fill ~85 ~-6 ~-155 ~85 ~-1 ~-153 minecraft:gravel
fill ~85 ~-6 ~-151 ~85 ~-1 ~-150 minecraft:gravel
fill ~85 ~-6 ~-145 ~85 ~-1 ~-143 minecraft:gravel
fill ~85 ~-6 ~-138 ~85 ~-1 ~-138 minecraft:gravel
fill ~85 ~-6 ~-134 ~85 ~-1 ~-133 minecraft:gravel
fill ~85 ~-6 ~-127 ~85 ~-1 ~-127 minecraft:gravel
fill ~85 ~-6 ~-124 ~87 ~-1 ~-124 minecraft:gravel
fill ~85 ~-6 ~-120 ~85 ~-1 ~-120 minecraft:gravel
fill ~85 ~-6 ~-118 ~85 ~-1 ~-117 minecraft:gravel
fill ~85 ~-6 ~-114 ~85 ~-1 ~-114 minecraft:gravel
fill ~85 ~-6 ~-109 ~86 ~-1 ~-109 minecraft:gravel
fill ~85 ~-6 ~-105 ~88 ~-1 ~-105 minecraft:gravel
fill ~85 ~-6 ~-102 ~85 ~-1 ~-101 minecraft:gravel
fill ~85 ~-6 ~-87 ~85 ~-1 ~-87 minecraft:gravel
fill ~85 ~-6 ~-85 ~86 ~-1 ~-85 minecraft:gravel
fill ~85 ~-6 ~-83 ~86 ~-1 ~-83 minecraft:gravel
fill ~85 ~-6 ~-81 ~85 ~-1 ~-81 minecraft:gravel
fill ~85 ~-6 ~-70 ~85 ~-1 ~-70 minecraft:gravel
fill ~85 ~-6 ~-68 ~85 ~-1 ~-68 minecraft:gravel
fill ~85 ~-6 ~-65 ~85 ~-1 ~-65 minecraft:gravel
fill ~85 ~-6 ~-63 ~85 ~-1 ~-63 minecraft:gravel
fill ~85 ~-6 ~-55 ~87 ~-1 ~-55 minecraft:gravel
fill ~85 ~-6 ~-50 ~85 ~-1 ~-50 minecraft:gravel
fill ~85 ~-6 ~-47 ~85 ~-1 ~-47 minecraft:gravel
fill ~85 ~-6 ~-45 ~87 ~-1 ~-45 minecraft:gravel
fill ~85 ~-6 ~-34 ~85 ~-1 ~-33 minecraft:gravel
fill ~85 ~-6 ~-30 ~85 ~-1 ~-30 minecraft:gravel
fill ~85 ~-6 ~-14 ~86 ~-1 ~-14 minecraft:gravel
fill ~85 ~-6 ~-10 ~85 ~-1 ~-9 minecraft:gravel
fill ~86 ~-6 ~-185 ~86 ~-1 ~-185 minecraft:gravel
fill ~86 ~-6 ~-173 ~87 ~-1 ~-172 minecraft:gravel
fill ~86 ~-6 ~-169 ~86 ~-1 ~-166 minecraft:gravel
fill ~86 ~-6 ~-163 ~87 ~-1 ~-163 minecraft:gravel
fill ~86 ~-6 ~-160 ~86 ~-1 ~-160 minecraft:gravel
fill ~86 ~-6 ~-158 ~88 ~-1 ~-158 minecraft:gravel
fill ~86 ~-6 ~-157 ~86 ~-1 ~-156 minecraft:gravel
fill ~86 ~-6 ~-152 ~86 ~-1 ~-152 minecraft:gravel
fill ~86 ~-6 ~-149 ~86 ~-1 ~-148 minecraft:gravel
fill ~86 ~-6 ~-146 ~86 ~-1 ~-146 minecraft:gravel
fill ~86 ~-6 ~-132 ~86 ~-1 ~-132 minecraft:gravel
fill ~86 ~-6 ~-123 ~86 ~-1 ~-123 minecraft:gravel
fill ~86 ~-6 ~-113 ~87 ~-1 ~-113 minecraft:gravel
fill ~86 ~-6 ~-106 ~86 ~-1 ~-105 minecraft:gravel
fill ~86 ~-6 ~-75 ~87 ~-1 ~-75 minecraft:gravel
fill ~86 ~-6 ~-72 ~86 ~-1 ~-72 minecraft:gravel
fill ~86 ~-6 ~-66 ~86 ~-1 ~-66 minecraft:gravel
fill ~86 ~-6 ~-61 ~86 ~-1 ~-59 minecraft:gravel
fill ~86 ~-6 ~-44 ~86 ~-1 ~-44 minecraft:gravel
fill ~86 ~-6 ~-41 ~86 ~-1 ~-40 minecraft:gravel
fill ~86 ~-6 ~-37 ~86 ~-1 ~-37 minecraft:gravel
fill ~86 ~-6 ~-31 ~86 ~-1 ~-31 minecraft:gravel
fill ~86 ~-6 ~-22 ~86 ~-1 ~-22 minecraft:gravel
fill ~86 ~-6 ~-18 ~87 ~-1 ~-18 minecraft:gravel
fill ~86 ~-6 ~-15 ~86 ~-1 ~-13 minecraft:gravel
fill ~86 ~-6 ~-8 ~86 ~-1 ~-8 minecraft:gravel
fill ~87 ~-6 ~-180 ~87 ~-1 ~-180 minecraft:gravel
fill ~87 ~-6 ~-177 ~87 ~-1 ~-177 minecraft:gravel
fill ~87 ~-6 ~-175 ~87 ~-1 ~-175 minecraft:gravel
fill ~87 ~-6 ~-166 ~88 ~-1 ~-166 minecraft:gravel
fill ~87 ~-6 ~-159 ~87 ~-1 ~-158 minecraft:gravel
fill ~87 ~-6 ~-156 ~87 ~-1 ~-156 minecraft:gravel
fill ~87 ~-6 ~-144 ~87 ~-1 ~-144 minecraft:gravel
fill ~87 ~-6 ~-142 ~87 ~-1 ~-141 minecraft:gravel
fill ~87 ~-6 ~-137 ~87 ~-1 ~-137 minecraft:gravel
fill ~87 ~-6 ~-134 ~87 ~-1 ~-134 minecraft:gravel
fill ~87 ~-6 ~-131 ~87 ~-1 ~-131 minecraft:gravel
fill ~87 ~-6 ~-126 ~89 ~-1 ~-126 minecraft:gravel
fill ~87 ~-6 ~-125 ~87 ~-1 ~-124 minecraft:gravel
fill ~87 ~-6 ~-122 ~88 ~-1 ~-120 minecraft:gravel
fill ~87 ~-6 ~-118 ~87 ~-1 ~-118 minecraft:gravel
fill ~87 ~-6 ~-108 ~87 ~-1 ~-108 minecraft:gravel
fill ~87 ~-6 ~-99 ~89 ~-1 ~-99 minecraft:gravel
fill ~87 ~-6 ~-95 ~87 ~-1 ~-95 minecraft:gravel
fill ~87 ~-6 ~-88 ~87 ~-1 ~-88 minecraft:gravel
fill ~87 ~-6 ~-82 ~88 ~-1 ~-81 minecraft:gravel
fill ~87 ~-6 ~-78 ~87 ~-1 ~-78 minecraft:gravel
fill ~87 ~-6 ~-76 ~87 ~-1 ~-75 minecraft:gravel
fill ~87 ~-6 ~-71 ~88 ~-1 ~-71 minecraft:gravel
fill ~87 ~-6 ~-69 ~87 ~-1 ~-69 minecraft:gravel
fill ~87 ~-6 ~-63 ~87 ~-1 ~-63 minecraft:gravel
fill ~87 ~-6 ~-59 ~89 ~-1 ~-59 minecraft:gravel
fill ~87 ~-6 ~-50 ~87 ~-1 ~-50 minecraft:gravel
fill ~87 ~-6 ~-43 ~89 ~-1 ~-43 minecraft:gravel
fill ~87 ~-6 ~-42 ~87 ~-1 ~-42 minecraft:gravel
fill ~87 ~-6 ~-38 ~87 ~-1 ~-38 minecraft:gravel
fill ~87 ~-6 ~-35 ~88 ~-1 ~-35 minecraft:gravel
fill ~87 ~-6 ~-28 ~89 ~-1 ~-28 minecraft:gravel
fill ~87 ~-6 ~-27 ~87 ~-1 ~-27 minecraft:gravel
fill ~87 ~-6 ~-24 ~87 ~-1 ~-24 minecraft:gravel
fill ~87 ~-6 ~-17 ~87 ~-1 ~-16 minecraft:gravel
fill ~88 ~-6 ~-181 ~88 ~-1 ~-181 minecraft:gravel
fill ~88 ~-6 ~-179 ~88 ~-1 ~-179 minecraft:gravel
fill ~88 ~-6 ~-176 ~88 ~-1 ~-176 minecraft:gravel
fill ~88 ~-6 ~-174 ~88 ~-1 ~-174 minecraft:gravel
fill ~88 ~-6 ~-170 ~88 ~-1 ~-170 minecraft:gravel
fill ~88 ~-6 ~-165 ~88 ~-1 ~-164 minecraft:gravel
fill ~88 ~-6 ~-157 ~88 ~-1 ~-157 minecraft:gravel
fill ~88 ~-6 ~-150 ~88 ~-1 ~-148 minecraft:gravel
fill ~88 ~-6 ~-146 ~88 ~-1 ~-146 minecraft:gravel
fill ~88 ~-6 ~-139 ~88 ~-1 ~-138 minecraft:gravel
fill ~88 ~-6 ~-130 ~88 ~-1 ~-130 minecraft:gravel
fill ~88 ~-6 ~-123 ~88 ~-1 ~-120 minecraft:gravel
fill ~88 ~-6 ~-115 ~88 ~-1 ~-115 minecraft:gravel
fill ~88 ~-6 ~-111 ~88 ~-1 ~-111 minecraft:gravel
fill ~88 ~-6 ~-101 ~88 ~-1 ~-97 minecraft:gravel
fill ~88 ~-6 ~-92 ~89 ~-1 ~-92 minecraft:gravel
fill ~88 ~-6 ~-85 ~88 ~-1 ~-84 minecraft:gravel
fill ~88 ~-6 ~-79 ~88 ~-1 ~-79 minecraft:gravel
fill ~88 ~-6 ~-67 ~88 ~-1 ~-67 minecraft:gravel
fill ~88 ~-6 ~-60 ~88 ~-1 ~-59 minecraft:gravel
fill ~88 ~-6 ~-53 ~89 ~-1 ~-53 minecraft:gravel
fill ~88 ~-6 ~-44 ~88 ~-1 ~-43 minecraft:gravel
fill ~88 ~-6 ~-40 ~88 ~-1 ~-39 minecraft:gravel
fill ~88 ~-6 ~-32 ~89 ~-1 ~-32 minecraft:gravel
fill ~88 ~-6 ~-30 ~89 ~-1 ~-30 minecraft:gravel
fill ~88 ~-6 ~-25 ~89 ~-1 ~-25 minecraft:gravel
fill ~88 ~-6 ~-19 ~89 ~-1 ~-19 minecraft:gravel
fill ~88 ~-6 ~-7 ~89 ~-1 ~-7 minecraft:gravel
fill ~89 ~-6 ~-183 ~89 ~-1 ~-183 minecraft:gravel
fill ~89 ~-6 ~-172 ~89 ~-1 ~-171 minecraft:gravel
fill ~89 ~-6 ~-163 ~89 ~-1 ~-163 minecraft:gravel
fill ~89 ~-6 ~-160 ~89 ~-1 ~-160 minecraft:gravel
fill ~89 ~-6 ~-156 ~89 ~-1 ~-154 minecraft:gravel
fill ~89 ~-6 ~-151 ~89 ~-1 ~-151 minecraft:gravel
fill ~89 ~-6 ~-147 ~89 ~-1 ~-147 minecraft:gravel
fill ~89 ~-6 ~-144 ~89 ~-1 ~-144 minecraft:gravel
fill ~89 ~-6 ~-141 ~89 ~-1 ~-140 minecraft:gravel
fill ~89 ~-6 ~-129 ~89 ~-1 ~-126 minecraft:gravel
fill ~89 ~-6 ~-124 ~89 ~-1 ~-124 minecraft:gravel
fill ~89 ~-6 ~-121 ~89 ~-1 ~-121 minecraft:gravel
fill ~89 ~-6 ~-116 ~89 ~-1 ~-116 minecraft:gravel
fill ~89 ~-6 ~-110 ~89 ~-1 ~-110 minecraft:gravel
fill ~89 ~-6 ~-106 ~89 ~-1 ~-106 minecraft:gravel
fill ~89 ~-6 ~-100 ~89 ~-1 ~-99 minecraft:gravel
fill ~89 ~-6 ~-96 ~89 ~-1 ~-94 minecraft:gravel
fill ~89 ~-6 ~-88 ~89 ~-1 ~-86 minecraft:gravel
fill ~89 ~-6 ~-83 ~89 ~-1 ~-83 minecraft:gravel
fill ~89 ~-6 ~-77 ~89 ~-1 ~-75 minecraft:gravel
fill ~89 ~-6 ~-73 ~89 ~-1 ~-73 minecraft:gravel
fill ~89 ~-6 ~-64 ~89 ~-1 ~-62 minecraft:gravel
fill ~89 ~-6 ~-58 ~89 ~-1 ~-58 minecraft:gravel
fill ~89 ~-6 ~-50 ~89 ~-1 ~-50 minecraft:gravel
fill ~89 ~-6 ~-48 ~89 ~-1 ~-48 minecraft:gravel
fill ~89 ~-6 ~-46 ~89 ~-1 ~-46 minecraft:gravel
fill ~89 ~-6 ~-33 ~89 ~-1 ~-32 minecraft:gravel
fill ~89 ~-6 ~-21 ~89 ~-1 ~-21 minecraft:gravel
fill ~89 ~-6 ~-11 ~89 ~-1 ~-11 minecraft:gravel
fill ~-90 ~-13 ~-134 ~-78 ~-7 ~-131 minecraft:prismarine_bricks
fill ~-90 ~-13 ~-130 ~-82 ~-13 ~-98 minecraft:prismarine_bricks
fill ~-90 ~-12 ~-130 ~-82 ~-7 ~-124 minecraft:prismarine_bricks
fill ~-90 ~-12 ~-114 ~-78 ~-7 ~-98 minecraft:prismarine_bricks
fill ~-90 ~-8 ~-123 ~-78 ~-7 ~-98 minecraft:prismarine_bricks
fill ~-81 ~-13 ~-125 ~-78 ~-7 ~-98 minecraft:prismarine_bricks
fill ~-79 ~-7 ~-130 ~-78 ~-7 ~-98 minecraft:prismarine_bricks
fill ~-11 ~12 ~-144 ~-11 ~21 ~-104 minecraft:bookshelf
fill ~-10 ~-26 ~-149 ~10 ~-19 ~-145 minecraft:bookshelf
fill ~-10 ~14 ~-144 ~10 ~15 ~-144 minecraft:bookshelf
fill ~-10 ~14 ~-143 ~-10 ~21 ~-104 minecraft:bookshelf
fill ~-10 ~16 ~-144 ~-10 ~21 ~-104 minecraft:bookshelf
fill ~-9 ~12 ~-144 ~10 ~15 ~-144 minecraft:bookshelf
fill ~-6 ~12 ~-143 ~-2 ~15 ~-143 minecraft:bookshelf
fill ~-6 ~12 ~-139 ~-2 ~15 ~-139 minecraft:bookshelf
fill ~-6 ~12 ~-135 ~-2 ~15 ~-135 minecraft:bookshelf
fill ~-6 ~12 ~-131 ~-2 ~15 ~-131 minecraft:bookshelf
fill ~-6 ~12 ~-127 ~-2 ~15 ~-127 minecraft:bookshelf
fill ~-6 ~12 ~-123 ~-2 ~15 ~-123 minecraft:bookshelf
fill ~-6 ~12 ~-119 ~-2 ~15 ~-119 minecraft:bookshelf
fill ~-6 ~12 ~-115 ~-2 ~15 ~-115 minecraft:bookshelf
fill ~-6 ~12 ~-111 ~-2 ~15 ~-111 minecraft:bookshelf
fill ~-6 ~12 ~-107 ~-2 ~15 ~-107 minecraft:bookshelf
fill ~2 ~12 ~-139 ~6 ~15 ~-139 minecraft:bookshelf
fill ~2 ~12 ~-135 ~6 ~15 ~-135 minecraft:bookshelf
fill ~2 ~12 ~-131 ~6 ~15 ~-131 minecraft:bookshelf
fill ~2 ~12 ~-127 ~6 ~15 ~-127 minecraft:bookshelf
fill ~2 ~12 ~-123 ~6 ~15 ~-123 minecraft:bookshelf
fill ~2 ~12 ~-119 ~6 ~15 ~-119 minecraft:bookshelf
fill ~2 ~12 ~-115 ~6 ~15 ~-115 minecraft:bookshelf
fill ~2 ~12 ~-111 ~6 ~15 ~-111 minecraft:bookshelf
fill ~2 ~12 ~-107 ~6 ~15 ~-107 minecraft:bookshelf
fill ~2 ~13 ~-143 ~6 ~15 ~-143 minecraft:bookshelf
fill ~3 ~12 ~-143 ~6 ~15 ~-143 minecraft:bookshelf
fill ~16 ~-26 ~-52 ~43 ~-19 ~-43 minecraft:bookshelf
fill ~-54 ~1 ~-138 ~-54 ~6 ~-138 minecraft:polished_andesite
fill ~-54 ~1 ~-120 ~-54 ~6 ~-120 minecraft:polished_andesite
fill ~-36 ~1 ~-138 ~-36 ~6 ~-138 minecraft:polished_andesite
fill ~-36 ~1 ~-120 ~-36 ~6 ~-120 minecraft:polished_andesite
fill ~-27 ~11 ~-139 ~-27 ~11 ~-109 minecraft:polished_andesite
fill ~-27 ~22 ~-139 ~-27 ~22 ~-109 minecraft:polished_andesite
fill ~-27 ~33 ~-139 ~-27 ~33 ~-109 minecraft:polished_andesite
fill ~-24 ~-1 ~-144 ~-3 ~-1 ~-142 minecraft:polished_andesite
fill ~-24 ~-1 ~-140 ~-22 ~-1 ~-104 minecraft:polished_andesite
fill ~-23 ~-1 ~-141 ~-22 ~-1 ~-104 minecraft:polished_andesite
fill ~-21 ~-1 ~-137 ~-3 ~-1 ~-104 minecraft:polished_andesite
fill ~-20 ~-1 ~-138 ~-3 ~-1 ~-104 minecraft:polished_andesite
fill ~-19 ~11 ~-147 ~19 ~11 ~-147 minecraft:polished_andesite
fill ~-19 ~11 ~-101 ~19 ~11 ~-101 minecraft:polished_andesite
fill ~-19 ~22 ~-147 ~19 ~22 ~-147 minecraft:polished_andesite
fill ~-19 ~22 ~-101 ~19 ~22 ~-101 minecraft:polished_andesite
fill ~-19 ~33 ~-147 ~19 ~33 ~-147 minecraft:polished_andesite
fill ~-19 ~33 ~-101 ~19 ~33 ~-101 minecraft:polished_andesite
fill ~-18 ~-1 ~-140 ~-18 ~-1 ~-104 minecraft:polished_andesite
fill ~-14 ~-1 ~-140 ~-3 ~-1 ~-104 minecraft:polished_andesite
fill ~-13 ~-1 ~-141 ~-3 ~-1 ~-104 minecraft:polished_andesite
fill ~-10 ~9 ~-144 ~-10 ~10 ~-104 minecraft:polished_andesite
fill ~-4 ~-1 ~-41 ~4 ~-1 ~-24 minecraft:polished_andesite
fill ~10 ~9 ~-144 ~10 ~10 ~-104 minecraft:polished_andesite
fill ~27 ~11 ~-139 ~27 ~11 ~-109 minecraft:polished_andesite
fill ~27 ~22 ~-139 ~27 ~22 ~-109 minecraft:polished_andesite
fill ~27 ~33 ~-139 ~27 ~33 ~-109 minecraft:polished_andesite
fill ~-54 ~1 ~-111 ~-54 ~5 ~-92 minecraft:white_terracotta
fill ~-54 ~1 ~-83 ~-54 ~5 ~-66 minecraft:white_terracotta
fill ~-53 ~1 ~-112 ~-36 ~5 ~-112 minecraft:white_terracotta
fill ~-53 ~1 ~-92 ~-36 ~5 ~-92 minecraft:white_terracotta
fill ~-53 ~1 ~-84 ~-40 ~5 ~-84 minecraft:white_terracotta
fill ~-53 ~1 ~-66 ~-40 ~5 ~-66 minecraft:white_terracotta
fill ~-50 ~1 ~-55 ~-50 ~4 ~-49 minecraft:white_terracotta
fill ~-49 ~1 ~-56 ~-43 ~4 ~-56 minecraft:white_terracotta
fill ~-49 ~1 ~-49 ~-43 ~4 ~-49 minecraft:white_terracotta
fill ~-43 ~1 ~-55 ~-43 ~4 ~-49 minecraft:white_terracotta
fill ~-40 ~1 ~-83 ~-40 ~5 ~-66 minecraft:white_terracotta
fill ~-40 ~1 ~-55 ~-40 ~4 ~-49 minecraft:white_terracotta
fill ~-39 ~1 ~-56 ~-33 ~4 ~-56 minecraft:white_terracotta
fill ~-39 ~1 ~-49 ~-33 ~4 ~-49 minecraft:white_terracotta
fill ~-36 ~1 ~-111 ~-36 ~5 ~-92 minecraft:white_terracotta
fill ~-33 ~1 ~-55 ~-33 ~4 ~-49 minecraft:white_terracotta
fill ~32 ~1 ~-55 ~32 ~4 ~-49 minecraft:white_terracotta
fill ~33 ~1 ~-56 ~39 ~4 ~-56 minecraft:white_terracotta
fill ~33 ~1 ~-49 ~39 ~4 ~-49 minecraft:white_terracotta
fill ~38 ~1 ~-111 ~38 ~5 ~-92 minecraft:white_terracotta
fill ~39 ~1 ~-112 ~54 ~5 ~-112 minecraft:white_terracotta
fill ~39 ~1 ~-92 ~54 ~5 ~-92 minecraft:white_terracotta
fill ~39 ~1 ~-55 ~39 ~4 ~-49 minecraft:white_terracotta
fill ~42 ~1 ~-55 ~42 ~4 ~-49 minecraft:white_terracotta
fill ~43 ~1 ~-56 ~49 ~4 ~-56 minecraft:white_terracotta
fill ~43 ~1 ~-49 ~49 ~4 ~-49 minecraft:white_terracotta
fill ~49 ~1 ~-55 ~49 ~4 ~-49 minecraft:white_terracotta
fill ~54 ~1 ~-111 ~54 ~5 ~-92 minecraft:white_terracotta
setblock ~-76 ~ ~-162 minecraft:mossy_cobblestone
fill ~-76 ~ ~-160 ~-76 ~2 ~-160 minecraft:mossy_cobblestone
fill ~-76 ~ ~-33 ~-76 ~ ~-31 minecraft:mossy_cobblestone
setblock ~-76 ~ ~-29 minecraft:mossy_cobblestone
setblock ~-76 ~1 ~-159 minecraft:mossy_cobblestone
setblock ~-76 ~1 ~-157 minecraft:mossy_cobblestone
setblock ~-76 ~1 ~-32 minecraft:mossy_cobblestone
setblock ~-76 ~2 ~-162 minecraft:mossy_cobblestone
setblock ~-76 ~2 ~-34 minecraft:mossy_cobblestone
fill ~-76 ~2 ~-30 ~-76 ~2 ~-29 minecraft:mossy_cobblestone
fill ~-75 ~ ~-165 ~-75 ~1 ~-165 minecraft:mossy_cobblestone
setblock ~-75 ~ ~-156 minecraft:mossy_cobblestone
setblock ~-75 ~1 ~-37 minecraft:mossy_cobblestone
setblock ~-75 ~1 ~-28 minecraft:mossy_cobblestone
setblock ~-75 ~2 ~-156 minecraft:mossy_cobblestone
fill ~-74 ~ ~-167 ~-74 ~1 ~-166 minecraft:mossy_cobblestone
setblock ~-74 ~ ~-39 minecraft:mossy_cobblestone
setblock ~-74 ~1 ~-26 minecraft:mossy_cobblestone
setblock ~-73 ~ ~-40 minecraft:mossy_cobblestone
fill ~-73 ~ ~-24 ~-73 ~1 ~-24 minecraft:mossy_cobblestone
setblock ~-73 ~1 ~-168 minecraft:mossy_cobblestone
setblock ~-73 ~2 ~-152 minecraft:mossy_cobblestone
setblock ~-72 ~ ~-96 minecraft:mossy_cobblestone
setblock ~-72 ~1 ~-41 minecraft:mossy_cobblestone
setblock ~-72 ~2 ~-151 minecraft:mossy_cobblestone
setblock ~-72 ~2 ~-97 minecraft:mossy_cobblestone
setblock ~-71 ~ ~-92 minecraft:mossy_cobblestone
setblock ~-71 ~ ~-42 minecraft:mossy_cobblestone
fill ~-71 ~ ~-22 ~-70 ~ ~-22 minecraft:mossy_cobblestone
setblock ~-71 ~1 ~-170 minecraft:mossy_cobblestone
setblock ~-71 ~1 ~-150 minecraft:mossy_cobblestone
setblock ~-71 ~1 ~-100 minecraft:mossy_cobblestone
setblock ~-70 ~ ~-150 minecraft:mossy_cobblestone
fill ~-70 ~1 ~-91 ~-70 ~1 ~-90 minecraft:mossy_cobblestone
setblock ~-70 ~2 ~-170 minecraft:mossy_cobblestone
setblock ~-70 ~2 ~-42 minecraft:mossy_cobblestone
setblock ~-69 ~ ~-102 minecraft:mossy_cobblestone
setblock ~-69 ~2 ~-171 minecraft:mossy_cobblestone
setblock ~-69 ~2 ~-21 minecraft:mossy_cobblestone
setblock ~-68 ~ ~-89 minecraft:mossy_cobblestone
fill ~-68 ~1 ~-103 ~-67 ~2 ~-103 minecraft:mossy_cobblestone
setblock ~-68 ~2 ~-149 minecraft:mossy_cobblestone
setblock ~-68 ~2 ~-43 minecraft:mossy_cobblestone
fill ~-67 ~ ~-148 ~-67 ~1 ~-148 minecraft:mossy_cobblestone
fill ~-67 ~ ~-20 ~-65 ~ ~-20 minecraft:mossy_cobblestone
setblock ~-67 ~1 ~-172 minecraft:mossy_cobblestone
fill ~-67 ~1 ~-44 ~-66 ~1 ~-44 minecraft:mossy_cobblestone
setblock ~-67 ~1 ~-20 minecraft:mossy_cobblestone
fill ~-66 ~1 ~-148 ~-66 ~2 ~-148 minecraft:mossy_cobblestone
fill ~-66 ~2 ~-88 ~-65 ~2 ~-88 minecraft:mossy_cobblestone
setblock ~-66 ~2 ~-20 minecraft:mossy_cobblestone
fill ~-65 ~ ~-172 ~-65 ~1 ~-172 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-147 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-145 minecraft:mossy_cobblestone
fill ~-65 ~ ~-140 ~-65 ~1 ~-140 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-127 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-120 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-118 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-111 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-107 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-86 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-83 minecraft:mossy_cobblestone
fill ~-65 ~ ~-81 ~-65 ~ ~-80 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-77 minecraft:mossy_cobblestone
fill ~-65 ~ ~-72 ~-65 ~ ~-71 minecraft:mossy_cobblestone
fill ~-65 ~ ~-66 ~-65 ~1 ~-66 minecraft:mossy_cobblestone
fill ~-65 ~ ~-49 ~-65 ~1 ~-49 minecraft:mossy_cobblestone
setblock ~-65 ~ ~-47 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-146 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-142 minecraft:mossy_cobblestone
fill ~-65 ~1 ~-129 ~-65 ~1 ~-128 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-126 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-119 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-110 minecraft:mossy_cobblestone
fill ~-65 ~1 ~-106 ~-65 ~1 ~-105 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-81 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-78 minecraft:mossy_cobblestone
fill ~-65 ~1 ~-76 ~-65 ~1 ~-73 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-71 minecraft:mossy_cobblestone
fill ~-65 ~1 ~-68 ~-65 ~1 ~-66 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-63 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-61 minecraft:mossy_cobblestone
fill ~-65 ~1 ~-57 ~-65 ~2 ~-57 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-55 minecraft:mossy_cobblestone
fill ~-65 ~1 ~-50 ~-65 ~1 ~-49 minecraft:mossy_cobblestone
setblock ~-65 ~1 ~-45 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-145 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-143 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-137 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-131 minecraft:mossy_cobblestone
fill ~-65 ~2 ~-124 ~-65 ~2 ~-123 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-116 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-111 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-107 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-104 minecraft:mossy_cobblestone
fill ~-65 ~2 ~-85 ~-65 ~2 ~-83 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-77 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-75 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-69 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-67 minecraft:mossy_cobblestone
fill ~-65 ~2 ~-65 ~-65 ~2 ~-64 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-56 minecraft:mossy_cobblestone
fill ~-65 ~2 ~-51 ~-65 ~2 ~-50 minecraft:mossy_cobblestone
setblock ~-65 ~2 ~-47 minecraft:mossy_cobblestone
setblock ~-64 ~1 ~-20 minecraft:mossy_cobblestone
fill ~-63 ~ ~-20 ~-62 ~ ~-20 minecraft:mossy_cobblestone
setblock ~-62 ~1 ~-172 minecraft:mossy_cobblestone
setblock ~-61 ~ ~-172 minecraft:mossy_cobblestone
setblock ~-60 ~1 ~-89 minecraft:mossy_cobblestone
setblock ~-59 ~ ~-43 minecraft:mossy_cobblestone
setblock ~-59 ~ ~-21 minecraft:mossy_cobblestone
setblock ~-59 ~1 ~-171 minecraft:mossy_cobblestone
setblock ~-59 ~2 ~-149 minecraft:mossy_cobblestone
setblock ~-58 ~ ~-91 minecraft:mossy_cobblestone
setblock ~-58 ~1 ~-22 minecraft:mossy_cobblestone
setblock ~-57 ~ ~-170 minecraft:mossy_cobblestone
setblock ~-57 ~ ~-99 minecraft:mossy_cobblestone
fill ~-57 ~ ~-42 ~-57 ~1 ~-42 minecraft:mossy_cobblestone
setblock ~-57 ~ ~-22 minecraft:mossy_cobblestone
setblock ~-57 ~2 ~-150 minecraft:mossy_cobblestone
setblock ~-57 ~2 ~-99 minecraft:mossy_cobblestone
setblock ~-57 ~2 ~-92 minecraft:mossy_cobblestone
setblock ~-56 ~ ~-94 minecraft:mossy_cobblestone
setblock ~-56 ~1 ~-23 minecraft:mossy_cobblestone
setblock ~-56 ~2 ~-94 minecraft:mossy_cobblestone
setblock ~-55 ~1 ~-168 minecraft:mossy_cobblestone
setblock ~-54 ~ ~-166 minecraft:mossy_cobblestone
fill ~-54 ~ ~-137 ~-51 ~ ~-136 minecraft:mossy_cobblestone
setblock ~-54 ~ ~-130 minecraft:mossy_cobblestone
fill ~-54 ~ ~-112 ~-54 ~5 ~-112 minecraft:mossy_cobblestone
fill ~-54 ~ ~-107 ~-52 ~ ~-107 minecraft:mossy_cobblestone
fill ~-54 ~ ~-104 ~-52 ~ ~-104 minecraft:mossy_cobblestone
setblock ~-54 ~ ~-100 minecraft:mossy_cobblestone
fill ~-54 ~ ~-98 ~-52 ~ ~-98 minecraft:mossy_cobblestone
setblock ~-54 ~ ~-94 minecraft:mossy_cobblestone
setblock ~-54 ~ ~-83 minecraft:mossy_cobblestone
setblock ~-54 ~ ~-81 minecraft:mossy_cobblestone
setblock ~-54 ~ ~-79 minecraft:mossy_cobblestone
setblock ~-54 ~ ~-76 minecraft:mossy_cobblestone
fill ~-54 ~ ~-73 ~-54 ~ ~-72 minecraft:mossy_cobblestone
fill ~-54 ~ ~-66 ~-54 ~5 ~-66 minecraft:mossy_cobblestone
setblock ~-54 ~ ~-25 minecraft:mossy_cobblestone
fill ~-53 ~ ~-155 ~-53 ~1 ~-155 minecraft:mossy_cobblestone
fill ~-53 ~ ~-138 ~-53 ~ ~-135 minecraft:mossy_cobblestone
setblock ~-53 ~1 ~-27 minecraft:mossy_cobblestone
setblock ~-53 ~2 ~-28 minecraft:mossy_cobblestone
fill ~-52 ~ ~-163 ~-52 ~ ~-162 minecraft:mossy_cobblestone
setblock ~-52 ~ ~-29 minecraft:mossy_cobblestone
setblock ~-52 ~1 ~-163 minecraft:mossy_cobblestone
fill ~-52 ~1 ~-30 ~-52 ~2 ~-30 minecraft:mossy_cobblestone
setblock ~-51 ~ ~-161 minecraft:mossy_cobblestone
setblock ~-51 ~ ~-92 minecraft:mossy_cobblestone
setblock ~-51 ~ ~-84 minecraft:mossy_cobblestone
fill ~-51 ~ ~-66 ~-50 ~ ~-66 minecraft:mossy_cobblestone
setblock ~-51 ~ ~-31 minecraft:mossy_cobblestone
setblock ~-51 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~-50 ~ ~-138 minecraft:mossy_cobblestone
fill ~-50 ~ ~-120 ~-48 ~ ~-120 minecraft:mossy_cobblestone
setblock ~-50 ~ ~-55 minecraft:mossy_cobblestone
fill ~-50 ~ ~-51 ~-50 ~ ~-50 minecraft:mossy_cobblestone
setblock ~-50 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~-50 ~1 ~-31 minecraft:mossy_cobblestone
fill ~-49 ~ ~-161 ~-48 ~ ~-161 minecraft:mossy_cobblestone
setblock ~-49 ~ ~-84 minecraft:mossy_cobblestone
setblock ~-49 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~-49 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~-48 ~ ~-138 minecraft:mossy_cobblestone
fill ~-48 ~ ~-112 ~-47 ~ ~-112 minecraft:mossy_cobblestone
setblock ~-47 ~ ~-84 minecraft:mossy_cobblestone
fill ~-47 ~1 ~-31 ~-46 ~1 ~-31 minecraft:mossy_cobblestone
setblock ~-47 ~2 ~-161 minecraft:mossy_cobblestone
fill ~-46 ~ ~-161 ~-41 ~ ~-161 minecraft:mossy_cobblestone
setblock ~-46 ~ ~-49 minecraft:mossy_cobblestone
fill ~-46 ~ ~-31 ~-45 ~ ~-31 minecraft:mossy_cobblestone
setblock ~-46 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~-45 ~ ~-138 minecraft:mossy_cobblestone
setblock ~-45 ~ ~-112 minecraft:mossy_cobblestone
fill ~-45 ~ ~-92 ~-43 ~ ~-92 minecraft:mossy_cobblestone
setblock ~-45 ~ ~-84 minecraft:mossy_cobblestone
fill ~-45 ~2 ~-161 ~-44 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~-44 ~ ~-120 minecraft:mossy_cobblestone
setblock ~-44 ~ ~-66 minecraft:mossy_cobblestone
setblock ~-44 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~-43 ~ ~-112 minecraft:mossy_cobblestone
setblock ~-43 ~ ~-84 minecraft:mossy_cobblestone
setblock ~-43 ~ ~-51 minecraft:mossy_cobblestone
fill ~-43 ~ ~-31 ~-41 ~ ~-31 minecraft:mossy_cobblestone
setblock ~-43 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~-41 ~ ~-138 minecraft:mossy_cobblestone
setblock ~-41 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~-40 ~ ~-83 minecraft:mossy_cobblestone
setblock ~-40 ~ ~-79 minecraft:mossy_cobblestone
fill ~-40 ~ ~-75 ~-40 ~ ~-74 minecraft:mossy_cobblestone
setblock ~-40 ~ ~-71 minecraft:mossy_cobblestone
setblock ~-40 ~ ~-68 minecraft:mossy_cobblestone
fill ~-40 ~ ~-56 ~-40 ~ ~-55 minecraft:mossy_cobblestone
setblock ~-40 ~ ~-53 minecraft:mossy_cobblestone
setblock ~-40 ~1 ~-31 minecraft:mossy_cobblestone
setblock ~-39 ~ ~-49 minecraft:mossy_cobblestone
setblock ~-39 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~-38 ~ ~-31 minecraft:mossy_cobblestone
setblock ~-37 ~ ~-112 minecraft:mossy_cobblestone
setblock ~-37 ~ ~-92 minecraft:mossy_cobblestone
setblock ~-37 ~1 ~-161 minecraft:mossy_cobblestone
fill ~-36 ~ ~-132 ~-36 ~ ~-131 minecraft:mossy_cobblestone
setblock ~-36 ~ ~-127 minecraft:mossy_cobblestone
fill ~-36 ~ ~-123 ~-36 ~ ~-122 minecraft:mossy_cobblestone
setblock ~-36 ~ ~-103 minecraft:mossy_cobblestone
setblock ~-36 ~ ~-100 minecraft:mossy_cobblestone
fill ~-36 ~ ~-96 ~-36 ~ ~-95 minecraft:mossy_cobblestone
setblock ~-36 ~ ~-93 minecraft:mossy_cobblestone
setblock ~-36 ~ ~-49 minecraft:mossy_cobblestone
setblock ~-35 ~ ~-56 minecraft:mossy_cobblestone
fill ~-35 ~ ~-31 ~-35 ~1 ~-31 minecraft:mossy_cobblestone
setblock ~-34 ~ ~-161 minecraft:mossy_cobblestone
setblock ~-34 ~ ~-49 minecraft:mossy_cobblestone
fill ~-34 ~2 ~-31 ~-33 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~-33 ~ ~-55 minecraft:mossy_cobblestone
setblock ~-33 ~1 ~-146 minecraft:mossy_cobblestone
setblock ~-33 ~1 ~-144 minecraft:mossy_cobblestone
setblock ~-33 ~1 ~-103 minecraft:mossy_cobblestone
fill ~-33 ~2 ~-161 ~-32 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~-33 ~2 ~-104 minecraft:mossy_cobblestone
setblock ~-33 ~2 ~-102 minecraft:mossy_cobblestone
fill ~-32 ~ ~-161 ~-31 ~ ~-161 minecraft:mossy_cobblestone
fill ~-32 ~ ~-149 ~-32 ~1 ~-149 minecraft:mossy_cobblestone
setblock ~-32 ~ ~-98 minecraft:mossy_cobblestone
fill ~-32 ~1 ~-150 ~-32 ~1 ~-149 minecraft:mossy_cobblestone
setblock ~-32 ~1 ~-143 minecraft:mossy_cobblestone
setblock ~-32 ~2 ~-105 minecraft:mossy_cobblestone
setblock ~-31 ~1 ~-151 minecraft:mossy_cobblestone
setblock ~-31 ~1 ~-141 minecraft:mossy_cobblestone
setblock ~-31 ~1 ~-107 minecraft:mossy_cobblestone
setblock ~-31 ~1 ~-97 minecraft:mossy_cobblestone
fill ~-31 ~1 ~-31 ~-30 ~1 ~-31 minecraft:mossy_cobblestone
fill ~-30 ~ ~-140 ~-30 ~1 ~-140 minecraft:mossy_cobblestone
fill ~-30 ~1 ~-161 ~-29 ~1 ~-161 minecraft:mossy_cobblestone
fill ~-30 ~1 ~-108 ~-30 ~2 ~-108 minecraft:mossy_cobblestone
setblock ~-29 ~ ~-152 minecraft:mossy_cobblestone
setblock ~-29 ~2 ~-96 minecraft:mossy_cobblestone
setblock ~-28 ~ ~-161 minecraft:mossy_cobblestone
fill ~-28 ~ ~-95 ~-28 ~1 ~-95 minecraft:mossy_cobblestone
fill ~-27 ~ ~-153 ~-27 ~1 ~-153 minecraft:mossy_cobblestone
setblock ~-27 ~ ~-138 minecraft:mossy_cobblestone
setblock ~-27 ~ ~-132 minecraft:mossy_cobblestone
setblock ~-27 ~ ~-125 minecraft:mossy_cobblestone
setblock ~-27 ~ ~-116 minecraft:mossy_cobblestone
setblock ~-27 ~ ~-114 minecraft:mossy_cobblestone
setblock ~-27 ~1 ~-135 minecraft:mossy_cobblestone
setblock ~-27 ~1 ~-129 minecraft:mossy_cobblestone
setblock ~-27 ~1 ~-118 minecraft:mossy_cobblestone
setblock ~-27 ~1 ~-115 minecraft:mossy_cobblestone
setblock ~-27 ~1 ~-112 minecraft:mossy_cobblestone
setblock ~-27 ~2 ~-161 minecraft:mossy_cobblestone
fill ~-27 ~2 ~-139 ~-27 ~2 ~-138 minecraft:mossy_cobblestone
fill ~-27 ~2 ~-125 ~-27 ~2 ~-124 minecraft:mossy_cobblestone
setblock ~-27 ~2 ~-116 minecraft:mossy_cobblestone
setblock ~-27 ~2 ~-95 minecraft:mossy_cobblestone
fill ~-26 ~ ~-95 ~-24 ~ ~-95 minecraft:mossy_cobblestone
setblock ~-26 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~-26 ~1 ~-153 minecraft:mossy_cobblestone
setblock ~-26 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~-25 ~ ~-109 minecraft:mossy_cobblestone
setblock ~-25 ~1 ~-139 minecraft:mossy_cobblestone
setblock ~-25 ~2 ~-153 minecraft:mossy_cobblestone
setblock ~-24 ~ ~-161 minecraft:mossy_cobblestone
fill ~-24 ~1 ~-27 ~-24 ~2 ~-27 minecraft:mossy_cobblestone
setblock ~-24 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~-23 ~ ~-152 minecraft:mossy_cobblestone
fill ~-23 ~1 ~-96 ~-23 ~2 ~-96 minecraft:mossy_cobblestone
setblock ~-23 ~2 ~-26 minecraft:mossy_cobblestone
setblock ~-22 ~ ~-161 minecraft:mossy_cobblestone
setblock ~-22 ~ ~-96 minecraft:mossy_cobblestone
setblock ~-22 ~2 ~-152 minecraft:mossy_cobblestone
setblock ~-20 ~ ~-161 minecraft:mossy_cobblestone
fill ~-20 ~1 ~-22 ~-19 ~1 ~-22 minecraft:mossy_cobblestone
setblock ~-20 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~-20 ~2 ~-150 minecraft:mossy_cobblestone
setblock ~-20 ~2 ~-38 minecraft:mossy_cobblestone
setblock ~-19 ~ ~-148 minecraft:mossy_cobblestone
fill ~-19 ~1 ~-161 ~-18 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~-19 ~1 ~-38 minecraft:mossy_cobblestone
setblock ~-19 ~2 ~-103 minecraft:mossy_cobblestone
setblock ~-19 ~2 ~-100 minecraft:mossy_cobblestone
fill ~-18 ~1 ~-147 ~-18 ~2 ~-147 minecraft:mossy_cobblestone
fill ~-18 ~1 ~-101 ~-18 ~2 ~-101 minecraft:mossy_cobblestone
fill ~-18 ~1 ~-21 ~-18 ~2 ~-21 minecraft:mossy_cobblestone
fill ~-18 ~2 ~-22 ~-18 ~2 ~-21 minecraft:mossy_cobblestone
fill ~-17 ~ ~-147 ~-16 ~ ~-147 minecraft:mossy_cobblestone
setblock ~-17 ~ ~-39 minecraft:mossy_cobblestone
setblock ~-16 ~ ~-101 minecraft:mossy_cobblestone
fill ~-16 ~2 ~-147 ~-16 ~2 ~-146 minecraft:mossy_cobblestone
setblock ~-16 ~2 ~-39 minecraft:mossy_cobblestone
fill ~-15 ~ ~-21 ~-15 ~1 ~-21 minecraft:mossy_cobblestone
fill ~-15 ~1 ~-161 ~-14 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~-15 ~1 ~-39 minecraft:mossy_cobblestone
fill ~-15 ~2 ~-101 ~-14 ~2 ~-101 minecraft:mossy_cobblestone
fill ~-14 ~2 ~-21 ~-13 ~2 ~-21 minecraft:mossy_cobblestone
setblock ~-13 ~1 ~-101 minecraft:mossy_cobblestone
fill ~-13 ~1 ~-21 ~-12 ~1 ~-21 minecraft:mossy_cobblestone
setblock ~-12 ~ ~-161 minecraft:mossy_cobblestone
fill ~-12 ~ ~-21 ~-12 ~1 ~-21 minecraft:mossy_cobblestone
fill ~-12 ~2 ~-101 ~-11 ~2 ~-101 minecraft:mossy_cobblestone
setblock ~-11 ~ ~-38 minecraft:mossy_cobblestone
setblock ~-11 ~ ~-22 minecraft:mossy_cobblestone
setblock ~-11 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~-11 ~1 ~-147 minecraft:mossy_cobblestone
setblock ~-10 ~ ~-40 minecraft:mossy_cobblestone
setblock ~-10 ~1 ~-101 minecraft:mossy_cobblestone
setblock ~-10 ~1 ~-39 minecraft:mossy_cobblestone
setblock ~-10 ~2 ~-41 minecraft:mossy_cobblestone
setblock ~-10 ~2 ~-37 minecraft:mossy_cobblestone
setblock ~-9 ~ ~-23 minecraft:mossy_cobblestone
setblock ~-9 ~2 ~-147 minecraft:mossy_cobblestone
setblock ~-8 ~ ~-24 minecraft:mossy_cobblestone
setblock ~-8 ~2 ~-162 minecraft:mossy_cobblestone
setblock ~-7 ~1 ~-164 minecraft:mossy_cobblestone
fill ~-7 ~1 ~-25 ~-7 ~2 ~-25 minecraft:mossy_cobblestone
setblock ~-7 ~2 ~-147 minecraft:mossy_cobblestone
fill ~-6 ~ ~-154 ~-5 ~ ~-154 minecraft:mossy_cobblestone
setblock ~-6 ~ ~-41 minecraft:mossy_cobblestone
setblock ~-6 ~1 ~-166 minecraft:mossy_cobblestone
setblock ~-5 ~ ~-166 minecraft:mossy_cobblestone
setblock ~-5 ~ ~-35 minecraft:mossy_cobblestone
fill ~-5 ~ ~-33 ~-5 ~2 ~-33 minecraft:mossy_cobblestone
fill ~-5 ~ ~-29 ~-5 ~ ~-27 minecraft:mossy_cobblestone
setblock ~-5 ~1 ~-147 minecraft:mossy_cobblestone
setblock ~-5 ~1 ~-38 minecraft:mossy_cobblestone
fill ~-5 ~1 ~-36 ~-5 ~2 ~-36 minecraft:mossy_cobblestone
setblock ~-5 ~1 ~-31 minecraft:mossy_cobblestone
fill ~-5 ~2 ~-34 ~-5 ~2 ~-32 minecraft:mossy_cobblestone
setblock ~-5 ~2 ~-26 minecraft:mossy_cobblestone
setblock ~-3 ~1 ~-167 minecraft:mossy_cobblestone
setblock ~-3 ~2 ~-147 minecraft:mossy_cobblestone
setblock ~-2 ~ ~-152 minecraft:mossy_cobblestone
setblock ~-2 ~2 ~-168 minecraft:mossy_cobblestone
setblock ~-1 ~ ~-168 minecraft:mossy_cobblestone
setblock ~-1 ~ ~-147 minecraft:mossy_cobblestone
fill ~ ~-9 ~-142 ~ ~-3 ~-142 minecraft:mossy_cobblestone
fill ~ ~-9 ~-139 ~ ~-3 ~-139 minecraft:mossy_cobblestone
fill ~ ~-9 ~-124 ~ ~-3 ~-124 minecraft:mossy_cobblestone
fill ~ ~-9 ~-121 ~ ~-3 ~-120 minecraft:mossy_cobblestone
fill ~ ~-9 ~-109 ~1 ~-3 ~-109 minecraft:mossy_cobblestone
fill ~ ~-9 ~-106 ~1 ~-3 ~-106 minecraft:mossy_cobblestone
fill ~1 ~-9 ~-141 ~1 ~-3 ~-141 minecraft:mossy_cobblestone
fill ~1 ~-9 ~-134 ~2 ~-3 ~-134 minecraft:mossy_cobblestone
fill ~1 ~-9 ~-129 ~1 ~-3 ~-129 minecraft:mossy_cobblestone
fill ~1 ~-9 ~-120 ~2 ~-3 ~-120 minecraft:mossy_cobblestone
fill ~1 ~-9 ~-119 ~1 ~-3 ~-119 minecraft:mossy_cobblestone
fill ~1 ~-9 ~-114 ~1 ~-3 ~-113 minecraft:mossy_cobblestone
fill ~1 ~-9 ~-111 ~1 ~-3 ~-111 minecraft:mossy_cobblestone
fill ~1 ~-9 ~-108 ~1 ~-3 ~-108 minecraft:mossy_cobblestone
fill ~1 ~1 ~-147 ~1 ~2 ~-147 minecraft:mossy_cobblestone
fill ~2 ~-9 ~-140 ~2 ~-3 ~-140 minecraft:mossy_cobblestone
fill ~2 ~-9 ~-131 ~3 ~-3 ~-131 minecraft:mossy_cobblestone
fill ~2 ~-9 ~-124 ~2 ~-3 ~-124 minecraft:mossy_cobblestone
fill ~2 ~-9 ~-122 ~2 ~-3 ~-122 minecraft:mossy_cobblestone
fill ~2 ~-9 ~-113 ~2 ~-3 ~-113 minecraft:mossy_cobblestone
setblock ~2 ~1 ~-152 minecraft:mossy_cobblestone
fill ~3 ~-9 ~-139 ~3 ~-3 ~-139 minecraft:mossy_cobblestone
fill ~3 ~-9 ~-118 ~4 ~-3 ~-118 minecraft:mossy_cobblestone
fill ~3 ~-9 ~-115 ~3 ~-3 ~-115 minecraft:mossy_cobblestone
fill ~3 ~-9 ~-111 ~4 ~-3 ~-111 minecraft:mossy_cobblestone
fill ~3 ~-9 ~-107 ~3 ~-3 ~-107 minecraft:mossy_cobblestone
fill ~3 ~-9 ~-105 ~3 ~-3 ~-104 minecraft:mossy_cobblestone
setblock ~3 ~2 ~-147 minecraft:mossy_cobblestone
fill ~4 ~-9 ~-144 ~4 ~-3 ~-142 minecraft:mossy_cobblestone
fill ~4 ~-9 ~-140 ~4 ~-3 ~-140 minecraft:mossy_cobblestone
fill ~4 ~-9 ~-135 ~4 ~-3 ~-135 minecraft:mossy_cobblestone
fill ~4 ~-9 ~-133 ~4 ~-3 ~-133 minecraft:mossy_cobblestone
fill ~4 ~-9 ~-121 ~4 ~-3 ~-117 minecraft:mossy_cobblestone
fill ~4 ~ ~-167 ~4 ~1 ~-167 minecraft:mossy_cobblestone
setblock ~4 ~ ~-147 minecraft:mossy_cobblestone
setblock ~4 ~2 ~-153 minecraft:mossy_cobblestone
fill ~5 ~-9 ~-137 ~5 ~-3 ~-137 minecraft:mossy_cobblestone
fill ~5 ~-9 ~-115 ~5 ~-3 ~-115 minecraft:mossy_cobblestone
fill ~5 ~-9 ~-113 ~5 ~-3 ~-113 minecraft:mossy_cobblestone
fill ~5 ~ ~-38 ~5 ~1 ~-38 minecraft:mossy_cobblestone
setblock ~5 ~ ~-36 minecraft:mossy_cobblestone
setblock ~5 ~ ~-27 minecraft:mossy_cobblestone
setblock ~5 ~1 ~-147 minecraft:mossy_cobblestone
fill ~5 ~1 ~-101 ~5 ~2 ~-101 minecraft:mossy_cobblestone
setblock ~5 ~1 ~-40 minecraft:mossy_cobblestone
setblock ~5 ~1 ~-35 minecraft:mossy_cobblestone
fill ~5 ~1 ~-28 ~5 ~2 ~-28 minecraft:mossy_cobblestone
fill ~5 ~1 ~-26 ~5 ~1 ~-25 minecraft:mossy_cobblestone
setblock ~5 ~2 ~-39 minecraft:mossy_cobblestone
setblock ~5 ~2 ~-36 minecraft:mossy_cobblestone
setblock ~5 ~2 ~-33 minecraft:mossy_cobblestone
fill ~5 ~2 ~-27 ~5 ~2 ~-26 minecraft:mossy_cobblestone
fill ~6 ~-9 ~-143 ~6 ~-3 ~-143 minecraft:mossy_cobblestone
fill ~6 ~-9 ~-138 ~7 ~-3 ~-138 minecraft:mossy_cobblestone
fill ~6 ~-9 ~-136 ~7 ~-3 ~-136 minecraft:mossy_cobblestone
fill ~6 ~-9 ~-130 ~7 ~-3 ~-130 minecraft:mossy_cobblestone
fill ~6 ~-9 ~-122 ~6 ~-3 ~-122 minecraft:mossy_cobblestone
fill ~6 ~-9 ~-120 ~6 ~-3 ~-120 minecraft:mossy_cobblestone
fill ~6 ~ ~-155 ~6 ~ ~-154 minecraft:mossy_cobblestone
setblock ~6 ~ ~-147 minecraft:mossy_cobblestone
fill ~6 ~ ~-41 ~6 ~2 ~-41 minecraft:mossy_cobblestone
setblock ~6 ~ ~-25 minecraft:mossy_cobblestone
setblock ~6 ~1 ~-154 minecraft:mossy_cobblestone
fill ~6 ~2 ~-147 ~6 ~2 ~-146 minecraft:mossy_cobblestone
setblock ~6 ~2 ~-101 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-142 ~7 ~-3 ~-142 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-139 ~9 ~-3 ~-139 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-133 ~7 ~-3 ~-133 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-129 ~9 ~-3 ~-129 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-128 ~8 ~-3 ~-128 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-124 ~7 ~-3 ~-124 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-121 ~7 ~-3 ~-121 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-118 ~8 ~-3 ~-117 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-115 ~9 ~-3 ~-115 minecraft:mossy_cobblestone
fill ~7 ~-9 ~-111 ~7 ~-3 ~-111 minecraft:mossy_cobblestone
fill ~7 ~ ~-164 ~7 ~ ~-163 minecraft:mossy_cobblestone
setblock ~7 ~ ~-156 minecraft:mossy_cobblestone
setblock ~7 ~ ~-101 minecraft:mossy_cobblestone
setblock ~7 ~1 ~-25 minecraft:mossy_cobblestone
setblock ~7 ~2 ~-41 minecraft:mossy_cobblestone
fill ~8 ~-9 ~-141 ~8 ~-3 ~-139 minecraft:mossy_cobblestone
fill ~8 ~-9 ~-131 ~9 ~-3 ~-131 minecraft:mossy_cobblestone
fill ~8 ~-9 ~-126 ~8 ~-3 ~-125 minecraft:mossy_cobblestone
fill ~8 ~-9 ~-122 ~9 ~-3 ~-122 minecraft:mossy_cobblestone
fill ~8 ~-9 ~-119 ~8 ~-3 ~-117 minecraft:mossy_cobblestone
setblock ~8 ~ ~-41 minecraft:mossy_cobblestone
fill ~8 ~1 ~-162 ~8 ~2 ~-162 minecraft:mossy_cobblestone
setblock ~8 ~2 ~-161 minecraft:mossy_cobblestone
fill ~9 ~-9 ~-133 ~9 ~-3 ~-133 minecraft:mossy_cobblestone
fill ~9 ~-9 ~-124 ~9 ~-3 ~-124 minecraft:mossy_cobblestone
fill ~9 ~-9 ~-116 ~9 ~-3 ~-115 minecraft:mossy_cobblestone
fill ~9 ~-9 ~-111 ~9 ~-3 ~-110 minecraft:mossy_cobblestone
fill ~9 ~-9 ~-104 ~9 ~-3 ~-104 minecraft:mossy_cobblestone
fill ~10 ~-9 ~-137 ~10 ~-3 ~-137 minecraft:mossy_cobblestone
fill ~10 ~-9 ~-135 ~10 ~-3 ~-135 minecraft:mossy_cobblestone
fill ~10 ~-9 ~-128 ~10 ~-3 ~-128 minecraft:mossy_cobblestone
fill ~10 ~-9 ~-126 ~10 ~-3 ~-126 minecraft:mossy_cobblestone
fill ~10 ~-9 ~-120 ~10 ~-3 ~-119 minecraft:mossy_cobblestone
fill ~10 ~-9 ~-108 ~10 ~-3 ~-107 minecraft:mossy_cobblestone
fill ~10 ~-9 ~-105 ~12 ~-3 ~-105 minecraft:mossy_cobblestone
setblock ~10 ~1 ~-41 minecraft:mossy_cobblestone
fill ~10 ~1 ~-39 ~10 ~2 ~-39 minecraft:mossy_cobblestone
fill ~10 ~2 ~-38 ~10 ~2 ~-37 minecraft:mossy_cobblestone
fill ~11 ~-9 ~-142 ~11 ~-3 ~-142 minecraft:mossy_cobblestone
fill ~11 ~-9 ~-138 ~11 ~-3 ~-138 minecraft:mossy_cobblestone
fill ~11 ~-9 ~-127 ~11 ~-3 ~-127 minecraft:mossy_cobblestone
fill ~11 ~-9 ~-119 ~11 ~-3 ~-119 minecraft:mossy_cobblestone
fill ~11 ~-9 ~-114 ~11 ~-3 ~-111 minecraft:mossy_cobblestone
fill ~11 ~-9 ~-109 ~12 ~-3 ~-109 minecraft:mossy_cobblestone
fill ~11 ~-9 ~-104 ~11 ~-3 ~-104 minecraft:mossy_cobblestone
setblock ~11 ~ ~-147 minecraft:mossy_cobblestone
setblock ~11 ~2 ~-22 minecraft:mossy_cobblestone
fill ~12 ~-9 ~-136 ~12 ~-3 ~-136 minecraft:mossy_cobblestone
fill ~12 ~-9 ~-132 ~13 ~-3 ~-132 minecraft:mossy_cobblestone
fill ~12 ~-9 ~-130 ~12 ~-3 ~-130 minecraft:mossy_cobblestone
fill ~12 ~ ~-161 ~12 ~1 ~-161 minecraft:mossy_cobblestone
fill ~12 ~ ~-21 ~13 ~ ~-21 minecraft:mossy_cobblestone
setblock ~12 ~1 ~-147 minecraft:mossy_cobblestone
fill ~13 ~-9 ~-139 ~14 ~-3 ~-139 minecraft:mossy_cobblestone
fill ~13 ~-9 ~-128 ~13 ~-3 ~-128 minecraft:mossy_cobblestone
fill ~13 ~-9 ~-125 ~13 ~-3 ~-125 minecraft:mossy_cobblestone
fill ~13 ~-9 ~-117 ~14 ~-3 ~-117 minecraft:mossy_cobblestone
fill ~13 ~-9 ~-114 ~13 ~-3 ~-114 minecraft:mossy_cobblestone
fill ~13 ~-9 ~-110 ~13 ~-3 ~-110 minecraft:mossy_cobblestone
fill ~13 ~-9 ~-104 ~14 ~-3 ~-104 minecraft:mossy_cobblestone
setblock ~13 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~13 ~2 ~-21 minecraft:mossy_cobblestone
fill ~14 ~-9 ~-142 ~14 ~-3 ~-142 minecraft:mossy_cobblestone
fill ~14 ~-9 ~-133 ~15 ~-3 ~-133 minecraft:mossy_cobblestone
fill ~14 ~-9 ~-129 ~14 ~-3 ~-129 minecraft:mossy_cobblestone
fill ~14 ~-9 ~-123 ~14 ~-3 ~-123 minecraft:mossy_cobblestone
fill ~14 ~-9 ~-120 ~14 ~-3 ~-120 minecraft:mossy_cobblestone
fill ~14 ~-9 ~-115 ~14 ~-3 ~-115 minecraft:mossy_cobblestone
fill ~14 ~-9 ~-112 ~14 ~-3 ~-111 minecraft:mossy_cobblestone
setblock ~14 ~ ~-101 minecraft:mossy_cobblestone
setblock ~14 ~1 ~-39 minecraft:mossy_cobblestone
fill ~15 ~-9 ~-137 ~15 ~-3 ~-133 minecraft:mossy_cobblestone
fill ~15 ~-9 ~-131 ~15 ~-3 ~-131 minecraft:mossy_cobblestone
fill ~15 ~-9 ~-107 ~15 ~-3 ~-107 minecraft:mossy_cobblestone
fill ~15 ~-9 ~-105 ~15 ~-3 ~-105 minecraft:mossy_cobblestone
setblock ~15 ~1 ~-147 minecraft:mossy_cobblestone
fill ~15 ~2 ~-39 ~16 ~2 ~-39 minecraft:mossy_cobblestone
fill ~16 ~-9 ~-143 ~16 ~-3 ~-143 minecraft:mossy_cobblestone
fill ~16 ~-9 ~-139 ~16 ~-3 ~-139 minecraft:mossy_cobblestone
fill ~16 ~-9 ~-134 ~16 ~-3 ~-134 minecraft:mossy_cobblestone
fill ~16 ~-9 ~-130 ~17 ~-3 ~-130 minecraft:mossy_cobblestone
fill ~16 ~-9 ~-128 ~16 ~-3 ~-127 minecraft:mossy_cobblestone
fill ~16 ~-9 ~-125 ~17 ~-3 ~-125 minecraft:mossy_cobblestone
fill ~16 ~-9 ~-112 ~17 ~-3 ~-112 minecraft:mossy_cobblestone
fill ~16 ~-9 ~-108 ~16 ~-3 ~-108 minecraft:mossy_cobblestone
setblock ~16 ~ ~-39 minecraft:mossy_cobblestone
fill ~16 ~ ~-21 ~17 ~ ~-21 minecraft:mossy_cobblestone
fill ~16 ~1 ~-101 ~16 ~2 ~-101 minecraft:mossy_cobblestone
fill ~16 ~2 ~-161 ~19 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~16 ~2 ~-147 minecraft:mossy_cobblestone
setblock ~16 ~2 ~-21 minecraft:mossy_cobblestone
fill ~17 ~-9 ~-136 ~17 ~-3 ~-136 minecraft:mossy_cobblestone
fill ~17 ~-9 ~-131 ~17 ~-3 ~-130 minecraft:mossy_cobblestone
fill ~17 ~-9 ~-127 ~17 ~-3 ~-125 minecraft:mossy_cobblestone
fill ~17 ~-9 ~-123 ~17 ~-3 ~-122 minecraft:mossy_cobblestone
fill ~17 ~-9 ~-119 ~17 ~-3 ~-119 minecraft:mossy_cobblestone
fill ~17 ~-9 ~-111 ~17 ~-3 ~-111 minecraft:mossy_cobblestone
fill ~17 ~-9 ~-106 ~17 ~-3 ~-106 minecraft:mossy_cobblestone
setblock ~17 ~ ~-101 minecraft:mossy_cobblestone
fill ~17 ~1 ~-161 ~17 ~2 ~-161 minecraft:mossy_cobblestone
fill ~18 ~-9 ~-144 ~19 ~-3 ~-144 minecraft:mossy_cobblestone
fill ~18 ~-9 ~-133 ~18 ~-3 ~-133 minecraft:mossy_cobblestone
fill ~18 ~-9 ~-129 ~19 ~-3 ~-129 minecraft:mossy_cobblestone
fill ~18 ~-9 ~-120 ~18 ~-3 ~-120 minecraft:mossy_cobblestone
fill ~18 ~-9 ~-115 ~18 ~-3 ~-115 minecraft:mossy_cobblestone
fill ~18 ~-9 ~-108 ~18 ~-3 ~-108 minecraft:mossy_cobblestone
fill ~18 ~1 ~-21 ~18 ~2 ~-21 minecraft:mossy_cobblestone
setblock ~18 ~2 ~-39 minecraft:mossy_cobblestone
fill ~19 ~-9 ~-142 ~19 ~-3 ~-142 minecraft:mossy_cobblestone
fill ~19 ~-9 ~-135 ~19 ~-3 ~-134 minecraft:mossy_cobblestone
fill ~19 ~-9 ~-126 ~20 ~-3 ~-126 minecraft:mossy_cobblestone
fill ~19 ~-9 ~-124 ~19 ~-3 ~-123 minecraft:mossy_cobblestone
fill ~19 ~-9 ~-117 ~19 ~-3 ~-117 minecraft:mossy_cobblestone
fill ~19 ~-9 ~-114 ~19 ~-3 ~-114 minecraft:mossy_cobblestone
fill ~19 ~-9 ~-112 ~19 ~-3 ~-112 minecraft:mossy_cobblestone
fill ~19 ~-9 ~-107 ~20 ~-3 ~-107 minecraft:mossy_cobblestone
fill ~19 ~-9 ~-104 ~19 ~-3 ~-104 minecraft:mossy_cobblestone
setblock ~19 ~ ~-145 minecraft:mossy_cobblestone
fill ~19 ~ ~-38 ~20 ~1 ~-38 minecraft:mossy_cobblestone
setblock ~19 ~1 ~-148 minecraft:mossy_cobblestone
setblock ~19 ~1 ~-103 minecraft:mossy_cobblestone
setblock ~19 ~1 ~-100 minecraft:mossy_cobblestone
fill ~19 ~2 ~-22 ~20 ~2 ~-22 minecraft:mossy_cobblestone
fill ~20 ~-9 ~-137 ~20 ~-3 ~-137 minecraft:mossy_cobblestone
fill ~20 ~-9 ~-133 ~22 ~-3 ~-133 minecraft:mossy_cobblestone
fill ~20 ~-9 ~-132 ~20 ~-3 ~-130 minecraft:mossy_cobblestone
fill ~20 ~-9 ~-127 ~20 ~-3 ~-125 minecraft:mossy_cobblestone
fill ~20 ~-9 ~-122 ~20 ~-3 ~-122 minecraft:mossy_cobblestone
fill ~20 ~-9 ~-119 ~20 ~-3 ~-118 minecraft:mossy_cobblestone
fill ~20 ~-9 ~-111 ~20 ~-3 ~-109 minecraft:mossy_cobblestone
fill ~20 ~-9 ~-105 ~20 ~-3 ~-105 minecraft:mossy_cobblestone
fill ~20 ~ ~-99 ~20 ~1 ~-99 minecraft:mossy_cobblestone
setblock ~20 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~20 ~2 ~-149 minecraft:mossy_cobblestone
setblock ~20 ~2 ~-98 minecraft:mossy_cobblestone
fill ~21 ~-9 ~-141 ~22 ~-3 ~-140 minecraft:mossy_cobblestone
fill ~21 ~-9 ~-136 ~21 ~-3 ~-136 minecraft:mossy_cobblestone
fill ~21 ~-9 ~-125 ~21 ~-3 ~-125 minecraft:mossy_cobblestone
fill ~21 ~-9 ~-118 ~21 ~-3 ~-117 minecraft:mossy_cobblestone
fill ~21 ~-9 ~-115 ~23 ~-3 ~-115 minecraft:mossy_cobblestone
fill ~21 ~-9 ~-114 ~21 ~-3 ~-114 minecraft:mossy_cobblestone
fill ~21 ~-9 ~-106 ~21 ~-3 ~-106 minecraft:mossy_cobblestone
fill ~22 ~-9 ~-119 ~22 ~-3 ~-119 minecraft:mossy_cobblestone
fill ~22 ~-9 ~-117 ~22 ~-3 ~-115 minecraft:mossy_cobblestone
fill ~22 ~-9 ~-111 ~23 ~-3 ~-111 minecraft:mossy_cobblestone
fill ~22 ~-9 ~-104 ~22 ~-3 ~-104 minecraft:mossy_cobblestone
fill ~22 ~ ~-161 ~24 ~ ~-161 minecraft:mossy_cobblestone
fill ~22 ~ ~-152 ~23 ~ ~-152 minecraft:mossy_cobblestone
fill ~22 ~ ~-24 ~22 ~1 ~-24 minecraft:mossy_cobblestone
setblock ~22 ~1 ~-161 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-140 ~23 ~-3 ~-139 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-134 ~23 ~-3 ~-134 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-130 ~23 ~-3 ~-130 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-128 ~23 ~-3 ~-128 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-123 ~23 ~-3 ~-123 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-120 ~23 ~-3 ~-120 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-118 ~23 ~-3 ~-118 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-113 ~23 ~-3 ~-113 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-110 ~23 ~-3 ~-110 minecraft:mossy_cobblestone
fill ~23 ~-9 ~-108 ~23 ~-3 ~-108 minecraft:mossy_cobblestone
fill ~23 ~ ~-26 ~23 ~ ~-25 minecraft:mossy_cobblestone
setblock ~23 ~1 ~-152 minecraft:mossy_cobblestone
setblock ~23 ~1 ~-26 minecraft:mossy_cobblestone
setblock ~23 ~2 ~-25 minecraft:mossy_cobblestone
fill ~24 ~ ~-153 ~25 ~ ~-153 minecraft:mossy_cobblestone
setblock ~24 ~1 ~-29 minecraft:mossy_cobblestone
setblock ~24 ~2 ~-161 minecraft:mossy_cobblestone
fill ~24 ~2 ~-31 ~25 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~24 ~2 ~-27 minecraft:mossy_cobblestone
setblock ~25 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~25 ~1 ~-139 minecraft:mossy_cobblestone
fill ~25 ~1 ~-59 ~25 ~1 ~-58 minecraft:mossy_cobblestone
setblock ~25 ~2 ~-153 minecraft:mossy_cobblestone
setblock ~25 ~2 ~-109 minecraft:mossy_cobblestone
fill ~26 ~ ~-95 ~27 ~1 ~-95 minecraft:mossy_cobblestone
setblock ~26 ~1 ~-153 minecraft:mossy_cobblestone
setblock ~26 ~1 ~-31 minecraft:mossy_cobblestone
fill ~27 ~ ~-161 ~28 ~ ~-161 minecraft:mossy_cobblestone
setblock ~27 ~ ~-136 minecraft:mossy_cobblestone
setblock ~27 ~ ~-123 minecraft:mossy_cobblestone
setblock ~27 ~ ~-118 minecraft:mossy_cobblestone
fill ~27 ~ ~-113 ~27 ~ ~-111 minecraft:mossy_cobblestone
setblock ~27 ~ ~-57 minecraft:mossy_cobblestone
setblock ~27 ~ ~-31 minecraft:mossy_cobblestone
setblock ~27 ~1 ~-137 minecraft:mossy_cobblestone
setblock ~27 ~1 ~-134 minecraft:mossy_cobblestone
fill ~27 ~1 ~-130 ~27 ~1 ~-129 minecraft:mossy_cobblestone
setblock ~27 ~1 ~-126 minecraft:mossy_cobblestone
fill ~27 ~1 ~-119 ~27 ~2 ~-119 minecraft:mossy_cobblestone
setblock ~27 ~1 ~-113 minecraft:mossy_cobblestone
setblock ~27 ~1 ~-58 minecraft:mossy_cobblestone
setblock ~27 ~2 ~-161 minecraft:mossy_cobblestone
fill ~27 ~2 ~-153 ~28 ~2 ~-153 minecraft:mossy_cobblestone
setblock ~27 ~2 ~-139 minecraft:mossy_cobblestone
setblock ~27 ~2 ~-136 minecraft:mossy_cobblestone
setblock ~27 ~2 ~-133 minecraft:mossy_cobblestone
setblock ~27 ~2 ~-123 minecraft:mossy_cobblestone
fill ~27 ~2 ~-120 ~27 ~2 ~-119 minecraft:mossy_cobblestone
setblock ~27 ~2 ~-117 minecraft:mossy_cobblestone
setblock ~27 ~2 ~-114 minecraft:mossy_cobblestone
setblock ~27 ~2 ~-112 minecraft:mossy_cobblestone
setblock ~28 ~ ~-153 minecraft:mossy_cobblestone
fill ~28 ~ ~-139 ~28 ~1 ~-139 minecraft:mossy_cobblestone
fill ~29 ~1 ~-108 ~30 ~1 ~-108 minecraft:mossy_cobblestone
setblock ~29 ~1 ~-58 minecraft:mossy_cobblestone
setblock ~29 ~2 ~-108 minecraft:mossy_cobblestone
setblock ~30 ~ ~-152 minecraft:mossy_cobblestone
fill ~30 ~ ~-108 ~30 ~1 ~-108 minecraft:mossy_cobblestone
setblock ~30 ~ ~-31 minecraft:mossy_cobblestone
fill ~30 ~1 ~-161 ~31 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~31 ~2 ~-107 minecraft:mossy_cobblestone
setblock ~31 ~2 ~-31 minecraft:mossy_cobblestone
fill ~32 ~ ~-150 ~32 ~ ~-149 minecraft:mossy_cobblestone
fill ~32 ~ ~-142 ~32 ~1 ~-142 minecraft:mossy_cobblestone
fill ~32 ~ ~-56 ~33 ~ ~-56 minecraft:mossy_cobblestone
setblock ~32 ~ ~-54 minecraft:mossy_cobblestone
fill ~32 ~ ~-52 ~32 ~ ~-51 minecraft:mossy_cobblestone
fill ~32 ~ ~-49 ~33 ~ ~-49 minecraft:mossy_cobblestone
setblock ~32 ~1 ~-31 minecraft:mossy_cobblestone
setblock ~32 ~2 ~-149 minecraft:mossy_cobblestone
setblock ~33 ~ ~-161 minecraft:mossy_cobblestone
setblock ~33 ~ ~-147 minecraft:mossy_cobblestone
fill ~33 ~ ~-145 ~33 ~1 ~-145 minecraft:mossy_cobblestone
setblock ~33 ~ ~-104 minecraft:mossy_cobblestone
setblock ~33 ~ ~-102 minecraft:mossy_cobblestone
fill ~33 ~ ~-100 ~33 ~1 ~-100 minecraft:mossy_cobblestone
setblock ~33 ~1 ~-144 minecraft:mossy_cobblestone
setblock ~33 ~2 ~-147 minecraft:mossy_cobblestone
setblock ~33 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~34 ~ ~-31 minecraft:mossy_cobblestone
setblock ~35 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~36 ~ ~-134 minecraft:mossy_cobblestone
fill ~36 ~ ~-129 ~36 ~2 ~-129 minecraft:mossy_cobblestone
setblock ~36 ~ ~-126 minecraft:mossy_cobblestone
setblock ~36 ~ ~-124 minecraft:mossy_cobblestone
setblock ~36 ~ ~-122 minecraft:mossy_cobblestone
fill ~36 ~ ~-120 ~36 ~6 ~-120 minecraft:mossy_cobblestone
setblock ~36 ~ ~-56 minecraft:mossy_cobblestone
fill ~37 ~ ~-161 ~37 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~37 ~ ~-49 minecraft:mossy_cobblestone
setblock ~37 ~2 ~-31 minecraft:mossy_cobblestone
fill ~38 ~ ~-112 ~38 ~ ~-111 minecraft:mossy_cobblestone
setblock ~38 ~ ~-108 minecraft:mossy_cobblestone
fill ~38 ~ ~-102 ~38 ~2 ~-102 minecraft:mossy_cobblestone
setblock ~38 ~ ~-99 minecraft:mossy_cobblestone
setblock ~38 ~ ~-93 minecraft:mossy_cobblestone
setblock ~38 ~ ~-56 minecraft:mossy_cobblestone
setblock ~38 ~1 ~-31 minecraft:mossy_cobblestone
fill ~39 ~ ~-120 ~40 ~ ~-120 minecraft:mossy_cobblestone
setblock ~39 ~ ~-53 minecraft:mossy_cobblestone
setblock ~40 ~ ~-161 minecraft:mossy_cobblestone
setblock ~42 ~ ~-138 minecraft:mossy_cobblestone
fill ~42 ~1 ~-31 ~43 ~1 ~-31 minecraft:mossy_cobblestone
setblock ~42 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~42 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~44 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~45 ~ ~-161 minecraft:mossy_cobblestone
fill ~45 ~ ~-56 ~45 ~2 ~-56 minecraft:mossy_cobblestone
fill ~45 ~2 ~-161 ~46 ~2 ~-161 minecraft:mossy_cobblestone
setblock ~46 ~ ~-92 minecraft:mossy_cobblestone
setblock ~47 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~48 ~ ~-120 minecraft:mossy_cobblestone
fill ~48 ~ ~-92 ~50 ~ ~-92 minecraft:mossy_cobblestone
setblock ~49 ~ ~-138 minecraft:mossy_cobblestone
setblock ~49 ~ ~-55 minecraft:mossy_cobblestone
fill ~49 ~ ~-49 ~49 ~4 ~-49 minecraft:mossy_cobblestone
fill ~49 ~ ~-31 ~50 ~ ~-31 minecraft:mossy_cobblestone
setblock ~49 ~1 ~-161 minecraft:mossy_cobblestone
setblock ~50 ~ ~-112 minecraft:mossy_cobblestone
fill ~52 ~ ~-163 ~52 ~ ~-162 minecraft:mossy_cobblestone
setblock ~52 ~ ~-120 minecraft:mossy_cobblestone
setblock ~52 ~2 ~-163 minecraft:mossy_cobblestone
setblock ~52 ~2 ~-31 minecraft:mossy_cobblestone
setblock ~53 ~ ~-164 minecraft:mossy_cobblestone
setblock ~53 ~1 ~-165 minecraft:mossy_cobblestone
setblock ~53 ~2 ~-164 minecraft:mossy_cobblestone
setblock ~53 ~2 ~-155 minecraft:mossy_cobblestone
fill ~54 ~ ~-167 ~54 ~2 ~-166 minecraft:mossy_cobblestone
fill ~54 ~ ~-154 ~54 ~1 ~-154 minecraft:mossy_cobblestone
setblock ~54 ~ ~-136 minecraft:mossy_cobblestone
setblock ~54 ~ ~-133 minecraft:mossy_cobblestone
setblock ~54 ~ ~-130 minecraft:mossy_cobblestone
setblock ~54 ~ ~-124 minecraft:mossy_cobblestone
setblock ~54 ~ ~-111 minecraft:mossy_cobblestone
setblock ~54 ~ ~-107 minecraft:mossy_cobblestone
fill ~54 ~ ~-104 ~54 ~ ~-102 minecraft:mossy_cobblestone
setblock ~54 ~ ~-96 minecraft:mossy_cobblestone
fill ~54 ~ ~-92 ~54 ~5 ~-92 minecraft:mossy_cobblestone
fill ~54 ~1 ~-153 ~54 ~2 ~-153 minecraft:mossy_cobblestone
setblock ~54 ~1 ~-38 minecraft:mossy_cobblestone
setblock ~54 ~2 ~-39 minecraft:mossy_cobblestone
setblock ~55 ~ ~-24 minecraft:mossy_cobblestone
setblock ~56 ~1 ~-98 minecraft:mossy_cobblestone
setblock ~56 ~1 ~-94 minecraft:mossy_cobblestone
setblock ~56 ~2 ~-169 minecraft:mossy_cobblestone
fill ~57 ~ ~-100 ~57 ~ ~-99 minecraft:mossy_cobblestone
fill ~57 ~ ~-22 ~57 ~2 ~-22 minecraft:mossy_cobblestone
setblock ~57 ~1 ~-170 minecraft:mossy_cobblestone
fill ~57 ~1 ~-92 ~57 ~2 ~-92 minecraft:mossy_cobblestone
setblock ~57 ~2 ~-150 minecraft:mossy_cobblestone
setblock ~57 ~2 ~-100 minecraft:mossy_cobblestone
setblock ~58 ~ ~-170 minecraft:mossy_cobblestone
setblock ~58 ~1 ~-150 minecraft:mossy_cobblestone
setblock ~58 ~2 ~-90 minecraft:mossy_cobblestone
setblock ~58 ~2 ~-22 minecraft:mossy_cobblestone
setblock ~59 ~1 ~-102 minecraft:mossy_cobblestone
setblock ~59 ~1 ~-90 minecraft:mossy_cobblestone
setblock ~60 ~ ~-21 minecraft:mossy_cobblestone
setblock ~60 ~2 ~-89 minecraft:mossy_cobblestone
setblock ~60 ~2 ~-21 minecraft:mossy_cobblestone
setblock ~61 ~ ~-172 minecraft:mossy_cobblestone
setblock ~62 ~1 ~-172 minecraft:mossy_cobblestone
setblock ~62 ~1 ~-20 minecraft:mossy_cobblestone
setblock ~64 ~2 ~-172 minecraft:mossy_cobblestone
setblock ~65 ~ ~-172 minecraft:mossy_cobblestone
setblock ~65 ~ ~-147 minecraft:mossy_cobblestone
fill ~65 ~ ~-145 ~65 ~ ~-144 minecraft:mossy_cobblestone
setblock ~65 ~ ~-141 minecraft:mossy_cobblestone
setblock ~65 ~ ~-138 minecraft:mossy_cobblestone
setblock ~65 ~ ~-134 minecraft:mossy_cobblestone
setblock ~65 ~ ~-130 minecraft:mossy_cobblestone
fill ~65 ~ ~-123 ~65 ~1 ~-123 minecraft:mossy_cobblestone
fill ~65 ~ ~-118 ~65 ~ ~-116 minecraft:mossy_cobblestone
setblock ~65 ~ ~-79 minecraft:mossy_cobblestone
setblock ~65 ~ ~-71 minecraft:mossy_cobblestone
setblock ~65 ~ ~-64 minecraft:mossy_cobblestone
setblock ~65 ~ ~-60 minecraft:mossy_cobblestone
setblock ~65 ~ ~-57 minecraft:mossy_cobblestone
setblock ~65 ~ ~-51 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-143 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-140 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-135 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-131 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-129 minecraft:mossy_cobblestone
fill ~65 ~1 ~-116 ~65 ~1 ~-114 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-111 minecraft:mossy_cobblestone
fill ~65 ~1 ~-109 ~65 ~1 ~-108 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-106 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-87 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-81 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-75 minecraft:mossy_cobblestone
fill ~65 ~1 ~-56 ~65 ~2 ~-56 minecraft:mossy_cobblestone
fill ~65 ~1 ~-52 ~65 ~2 ~-52 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-49 minecraft:mossy_cobblestone
fill ~65 ~1 ~-47 ~65 ~2 ~-47 minecraft:mossy_cobblestone
setblock ~65 ~1 ~-20 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-147 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-145 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-138 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-136 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-134 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-127 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-119 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-117 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-105 minecraft:mossy_cobblestone
fill ~65 ~2 ~-86 ~65 ~2 ~-84 minecraft:mossy_cobblestone
fill ~65 ~2 ~-80 ~65 ~2 ~-78 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-72 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-68 minecraft:mossy_cobblestone
fill ~65 ~2 ~-66 ~65 ~2 ~-64 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-62 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-60 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-58 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-54 minecraft:mossy_cobblestone
setblock ~65 ~2 ~-50 minecraft:mossy_cobblestone
fill ~66 ~ ~-148 ~67 ~ ~-148 minecraft:mossy_cobblestone
fill ~66 ~ ~-88 ~66 ~1 ~-88 minecraft:mossy_cobblestone
setblock ~66 ~ ~-44 minecraft:mossy_cobblestone
setblock ~67 ~2 ~-148 minecraft:mossy_cobblestone
fill ~68 ~ ~-149 ~68 ~1 ~-149 minecraft:mossy_cobblestone
setblock ~68 ~1 ~-171 minecraft:mossy_cobblestone
setblock ~68 ~1 ~-21 minecraft:mossy_cobblestone
fill ~69 ~ ~-102 ~70 ~ ~-102 minecraft:mossy_cobblestone
fill ~69 ~1 ~-90 ~70 ~1 ~-90 minecraft:mossy_cobblestone
setblock ~69 ~2 ~-171 minecraft:mossy_cobblestone
setblock ~69 ~2 ~-149 minecraft:mossy_cobblestone
setblock ~70 ~ ~-150 minecraft:mossy_cobblestone
fill ~70 ~ ~-22 ~70 ~1 ~-22 minecraft:mossy_cobblestone
fill ~70 ~2 ~-150 ~71 ~2 ~-150 minecraft:mossy_cobblestone
setblock ~71 ~ ~-93 minecraft:mossy_cobblestone
fill ~71 ~1 ~-170 ~71 ~2 ~-170 minecraft:mossy_cobblestone
setblock ~71 ~1 ~-99 minecraft:mossy_cobblestone
setblock ~71 ~1 ~-22 minecraft:mossy_cobblestone
setblock ~72 ~ ~-169 minecraft:mossy_cobblestone
setblock ~72 ~2 ~-151 minecraft:mossy_cobblestone
fill ~73 ~ ~-168 ~73 ~1 ~-168 minecraft:mossy_cobblestone
setblock ~73 ~ ~-152 minecraft:mossy_cobblestone
setblock ~73 ~2 ~-40 minecraft:mossy_cobblestone
setblock ~74 ~ ~-166 minecraft:mossy_cobblestone
setblock ~74 ~1 ~-167 minecraft:mossy_cobblestone
setblock ~74 ~1 ~-154 minecraft:mossy_cobblestone
fill ~74 ~1 ~-39 ~74 ~1 ~-38 minecraft:mossy_cobblestone
setblock ~74 ~1 ~-25 minecraft:mossy_cobblestone
setblock ~74 ~2 ~-166 minecraft:mossy_cobblestone
setblock ~74 ~2 ~-153 minecraft:mossy_cobblestone
setblock ~74 ~2 ~-26 minecraft:mossy_cobblestone
fill ~75 ~ ~-164 ~75 ~2 ~-164 minecraft:mossy_cobblestone
fill ~75 ~1 ~-165 ~75 ~1 ~-164 minecraft:mossy_cobblestone
setblock ~75 ~1 ~-37 minecraft:mossy_cobblestone
setblock ~75 ~2 ~-155 minecraft:mossy_cobblestone
setblock ~76 ~ ~-163 minecraft:mossy_cobblestone
setblock ~76 ~ ~-159 minecraft:mossy_cobblestone
setblock ~76 ~ ~-157 minecraft:mossy_cobblestone
fill ~76 ~1 ~-162 ~76 ~2 ~-162 minecraft:mossy_cobblestone
fill ~76 ~2 ~-163 ~76 ~2 ~-161 minecraft:mossy_cobblestone
fill ~76 ~2 ~-159 ~76 ~2 ~-157 minecraft:mossy_cobblestone
setblock ~76 ~2 ~-35 minecraft:mossy_cobblestone
setblock ~76 ~2 ~-30 minecraft:mossy_cobblestone
fill ~-76 ~29 ~-163 ~-76 ~29 ~-157 minecraft:chiseled_stone_bricks
fill ~-76 ~29 ~-35 ~-76 ~29 ~-29 minecraft:chiseled_stone_bricks
fill ~-75 ~29 ~-165 ~-75 ~29 ~-164 minecraft:chiseled_stone_bricks
fill ~-75 ~29 ~-156 ~-75 ~29 ~-155 minecraft:chiseled_stone_bricks
fill ~-75 ~29 ~-37 ~-75 ~29 ~-36 minecraft:chiseled_stone_bricks
fill ~-75 ~29 ~-28 ~-75 ~29 ~-27 minecraft:chiseled_stone_bricks
fill ~-74 ~29 ~-167 ~-74 ~29 ~-166 minecraft:chiseled_stone_bricks
fill ~-74 ~29 ~-154 ~-74 ~29 ~-153 minecraft:chiseled_stone_bricks
fill ~-74 ~29 ~-39 ~-74 ~29 ~-38 minecraft:chiseled_stone_bricks
fill ~-74 ~29 ~-26 ~-74 ~29 ~-25 minecraft:chiseled_stone_bricks
setblock ~-73 ~29 ~-168 minecraft:chiseled_stone_bricks
setblock ~-73 ~29 ~-152 minecraft:chiseled_stone_bricks
setblock ~-73 ~29 ~-40 minecraft:chiseled_stone_bricks
setblock ~-73 ~29 ~-24 minecraft:chiseled_stone_bricks
fill ~-72 ~25 ~-98 ~-72 ~25 ~-94 minecraft:chiseled_stone_bricks
setblock ~-72 ~29 ~-169 minecraft:chiseled_stone_bricks
setblock ~-72 ~29 ~-151 minecraft:chiseled_stone_bricks
setblock ~-72 ~29 ~-41 minecraft:chiseled_stone_bricks
setblock ~-72 ~29 ~-23 minecraft:chiseled_stone_bricks
fill ~-71 ~25 ~-100 ~-71 ~25 ~-99 minecraft:chiseled_stone_bricks
fill ~-71 ~25 ~-93 ~-71 ~25 ~-92 minecraft:chiseled_stone_bricks
fill ~-71 ~29 ~-170 ~-70 ~29 ~-170 minecraft:chiseled_stone_bricks
fill ~-71 ~29 ~-150 ~-70 ~29 ~-150 minecraft:chiseled_stone_bricks
fill ~-71 ~29 ~-42 ~-70 ~29 ~-42 minecraft:chiseled_stone_bricks
fill ~-71 ~29 ~-22 ~-70 ~29 ~-22 minecraft:chiseled_stone_bricks
fill ~-70 ~25 ~-102 ~-69 ~25 ~-102 minecraft:chiseled_stone_bricks
setblock ~-70 ~25 ~-101 minecraft:chiseled_stone_bricks
fill ~-70 ~25 ~-91 ~-70 ~25 ~-90 minecraft:chiseled_stone_bricks
setblock ~-69 ~25 ~-90 minecraft:chiseled_stone_bricks
fill ~-69 ~29 ~-171 ~-68 ~29 ~-171 minecraft:chiseled_stone_bricks
fill ~-69 ~29 ~-149 ~-68 ~29 ~-149 minecraft:chiseled_stone_bricks
fill ~-69 ~29 ~-43 ~-68 ~29 ~-43 minecraft:chiseled_stone_bricks
fill ~-69 ~29 ~-21 ~-68 ~29 ~-21 minecraft:chiseled_stone_bricks
fill ~-68 ~25 ~-103 ~-67 ~25 ~-103 minecraft:chiseled_stone_bricks
fill ~-68 ~25 ~-89 ~-67 ~25 ~-89 minecraft:chiseled_stone_bricks
fill ~-67 ~29 ~-172 ~-61 ~29 ~-172 minecraft:chiseled_stone_bricks
fill ~-67 ~29 ~-148 ~-61 ~29 ~-148 minecraft:chiseled_stone_bricks
fill ~-67 ~29 ~-44 ~-61 ~29 ~-44 minecraft:chiseled_stone_bricks
fill ~-67 ~29 ~-20 ~-61 ~29 ~-20 minecraft:chiseled_stone_bricks
fill ~-66 ~25 ~-104 ~-62 ~25 ~-104 minecraft:chiseled_stone_bricks
fill ~-66 ~25 ~-88 ~-62 ~25 ~-88 minecraft:chiseled_stone_bricks
fill ~-61 ~25 ~-103 ~-60 ~25 ~-103 minecraft:chiseled_stone_bricks
fill ~-61 ~25 ~-89 ~-60 ~25 ~-89 minecraft:chiseled_stone_bricks
fill ~-60 ~29 ~-171 ~-59 ~29 ~-171 minecraft:chiseled_stone_bricks
fill ~-60 ~29 ~-149 ~-59 ~29 ~-149 minecraft:chiseled_stone_bricks
fill ~-60 ~29 ~-43 ~-59 ~29 ~-43 minecraft:chiseled_stone_bricks
fill ~-60 ~29 ~-21 ~-59 ~29 ~-21 minecraft:chiseled_stone_bricks
fill ~-59 ~25 ~-102 ~-58 ~25 ~-102 minecraft:chiseled_stone_bricks
fill ~-59 ~25 ~-90 ~-58 ~25 ~-90 minecraft:chiseled_stone_bricks
setblock ~-58 ~25 ~-101 minecraft:chiseled_stone_bricks
fill ~-58 ~25 ~-91 ~-58 ~25 ~-90 minecraft:chiseled_stone_bricks
fill ~-58 ~29 ~-170 ~-57 ~29 ~-170 minecraft:chiseled_stone_bricks
fill ~-58 ~29 ~-150 ~-57 ~29 ~-150 minecraft:chiseled_stone_bricks
fill ~-58 ~29 ~-42 ~-57 ~29 ~-42 minecraft:chiseled_stone_bricks
fill ~-58 ~29 ~-22 ~-57 ~29 ~-22 minecraft:chiseled_stone_bricks
fill ~-57 ~25 ~-100 ~-57 ~25 ~-99 minecraft:chiseled_stone_bricks
fill ~-57 ~25 ~-93 ~-57 ~25 ~-92 minecraft:chiseled_stone_bricks
fill ~-56 ~25 ~-98 ~-56 ~25 ~-94 minecraft:chiseled_stone_bricks
setblock ~-56 ~29 ~-169 minecraft:chiseled_stone_bricks
setblock ~-56 ~29 ~-151 minecraft:chiseled_stone_bricks
setblock ~-56 ~29 ~-41 minecraft:chiseled_stone_bricks
setblock ~-56 ~29 ~-23 minecraft:chiseled_stone_bricks
setblock ~-55 ~29 ~-168 minecraft:chiseled_stone_bricks
setblock ~-55 ~29 ~-152 minecraft:chiseled_stone_bricks
setblock ~-55 ~29 ~-40 minecraft:chiseled_stone_bricks
setblock ~-55 ~29 ~-24 minecraft:chiseled_stone_bricks
fill ~-54 ~29 ~-167 ~-54 ~29 ~-166 minecraft:chiseled_stone_bricks
fill ~-54 ~29 ~-154 ~-54 ~29 ~-153 minecraft:chiseled_stone_bricks
fill ~-54 ~29 ~-39 ~-54 ~29 ~-38 minecraft:chiseled_stone_bricks
fill ~-54 ~29 ~-26 ~-54 ~29 ~-25 minecraft:chiseled_stone_bricks
fill ~-53 ~29 ~-165 ~-53 ~29 ~-164 minecraft:chiseled_stone_bricks
fill ~-53 ~29 ~-156 ~-53 ~29 ~-155 minecraft:chiseled_stone_bricks
fill ~-53 ~29 ~-37 ~-53 ~29 ~-36 minecraft:chiseled_stone_bricks
fill ~-53 ~29 ~-28 ~-53 ~29 ~-27 minecraft:chiseled_stone_bricks
fill ~-52 ~29 ~-163 ~-52 ~29 ~-157 minecraft:chiseled_stone_bricks
fill ~-52 ~29 ~-35 ~-52 ~29 ~-29 minecraft:chiseled_stone_bricks
fill ~-33 ~51 ~-148 ~-33 ~51 ~-144 minecraft:chiseled_stone_bricks
fill ~-33 ~51 ~-104 ~-33 ~51 ~-100 minecraft:chiseled_stone_bricks
fill ~-32 ~51 ~-150 ~-32 ~51 ~-149 minecraft:chiseled_stone_bricks
fill ~-32 ~51 ~-143 ~-32 ~51 ~-142 minecraft:chiseled_stone_bricks
fill ~-32 ~51 ~-106 ~-32 ~51 ~-105 minecraft:chiseled_stone_bricks
fill ~-32 ~51 ~-99 ~-32 ~51 ~-98 minecraft:chiseled_stone_bricks
setblock ~-31 ~51 ~-151 minecraft:chiseled_stone_bricks
setblock ~-31 ~51 ~-141 minecraft:chiseled_stone_bricks
setblock ~-31 ~51 ~-107 minecraft:chiseled_stone_bricks
setblock ~-31 ~51 ~-97 minecraft:chiseled_stone_bricks
fill ~-30 ~51 ~-152 ~-29 ~51 ~-152 minecraft:chiseled_stone_bricks
fill ~-30 ~51 ~-140 ~-29 ~51 ~-140 minecraft:chiseled_stone_bricks
fill ~-30 ~51 ~-108 ~-29 ~51 ~-108 minecraft:chiseled_stone_bricks
fill ~-30 ~51 ~-96 ~-29 ~51 ~-96 minecraft:chiseled_stone_bricks
fill ~-28 ~51 ~-153 ~-24 ~51 ~-153 minecraft:chiseled_stone_bricks
fill ~-28 ~51 ~-139 ~-24 ~51 ~-139 minecraft:chiseled_stone_bricks
fill ~-28 ~51 ~-109 ~-24 ~51 ~-109 minecraft:chiseled_stone_bricks
fill ~-28 ~51 ~-95 ~-24 ~51 ~-95 minecraft:chiseled_stone_bricks
fill ~-27 ~43 ~-139 ~-27 ~43 ~-109 minecraft:chiseled_stone_bricks
fill ~-24 ~29 ~-33 ~-23 ~29 ~-33 minecraft:chiseled_stone_bricks
fill ~-24 ~29 ~-32 ~-24 ~29 ~-27 minecraft:chiseled_stone_bricks
fill ~-23 ~29 ~-35 ~-22 ~29 ~-35 minecraft:chiseled_stone_bricks
fill ~-23 ~29 ~-34 ~-23 ~29 ~-33 minecraft:chiseled_stone_bricks
fill ~-23 ~29 ~-27 ~-23 ~29 ~-25 minecraft:chiseled_stone_bricks
fill ~-23 ~51 ~-152 ~-22 ~51 ~-152 minecraft:chiseled_stone_bricks
fill ~-23 ~51 ~-140 ~-22 ~51 ~-140 minecraft:chiseled_stone_bricks
fill ~-23 ~51 ~-108 ~-22 ~51 ~-108 minecraft:chiseled_stone_bricks
fill ~-23 ~51 ~-96 ~-22 ~51 ~-96 minecraft:chiseled_stone_bricks
fill ~-22 ~29 ~-36 ~-22 ~29 ~-35 minecraft:chiseled_stone_bricks
fill ~-22 ~29 ~-25 ~-22 ~29 ~-24 minecraft:chiseled_stone_bricks
fill ~-21 ~29 ~-37 ~-20 ~29 ~-37 minecraft:chiseled_stone_bricks
fill ~-21 ~29 ~-23 ~-20 ~29 ~-23 minecraft:chiseled_stone_bricks
setblock ~-21 ~51 ~-151 minecraft:chiseled_stone_bricks
setblock ~-21 ~51 ~-141 minecraft:chiseled_stone_bricks
setblock ~-21 ~51 ~-107 minecraft:chiseled_stone_bricks
setblock ~-21 ~51 ~-97 minecraft:chiseled_stone_bricks
fill ~-20 ~29 ~-38 ~-18 ~29 ~-38 minecraft:chiseled_stone_bricks
fill ~-20 ~29 ~-22 ~-18 ~29 ~-22 minecraft:chiseled_stone_bricks
fill ~-20 ~51 ~-150 ~-20 ~51 ~-149 minecraft:chiseled_stone_bricks
fill ~-20 ~51 ~-143 ~-20 ~51 ~-142 minecraft:chiseled_stone_bricks
fill ~-20 ~51 ~-106 ~-20 ~51 ~-105 minecraft:chiseled_stone_bricks
fill ~-20 ~51 ~-99 ~-20 ~51 ~-98 minecraft:chiseled_stone_bricks
fill ~-19 ~43 ~-147 ~19 ~43 ~-147 minecraft:chiseled_stone_bricks
fill ~-19 ~43 ~-101 ~19 ~43 ~-101 minecraft:chiseled_stone_bricks
fill ~-19 ~51 ~-148 ~-19 ~51 ~-144 minecraft:chiseled_stone_bricks
fill ~-19 ~51 ~-104 ~-19 ~51 ~-100 minecraft:chiseled_stone_bricks
fill ~-18 ~29 ~-39 ~-12 ~29 ~-39 minecraft:chiseled_stone_bricks
fill ~-18 ~29 ~-21 ~-12 ~29 ~-21 minecraft:chiseled_stone_bricks
fill ~-12 ~29 ~-38 ~-10 ~29 ~-38 minecraft:chiseled_stone_bricks
fill ~-12 ~29 ~-22 ~-10 ~29 ~-22 minecraft:chiseled_stone_bricks
fill ~-11 ~65 ~-127 ~-11 ~65 ~-121 minecraft:chiseled_stone_bricks
fill ~-10 ~29 ~-37 ~-9 ~29 ~-37 minecraft:chiseled_stone_bricks
fill ~-10 ~29 ~-23 ~-9 ~29 ~-23 minecraft:chiseled_stone_bricks
fill ~-10 ~65 ~-129 ~-10 ~65 ~-128 minecraft:chiseled_stone_bricks
fill ~-10 ~65 ~-120 ~-10 ~65 ~-119 minecraft:chiseled_stone_bricks
fill ~-9 ~65 ~-131 ~-8 ~65 ~-131 minecraft:chiseled_stone_bricks
setblock ~-9 ~65 ~-130 minecraft:chiseled_stone_bricks
fill ~-9 ~65 ~-118 ~-9 ~65 ~-117 minecraft:chiseled_stone_bricks
fill ~-8 ~25 ~-162 ~-8 ~25 ~-158 minecraft:chiseled_stone_bricks
fill ~-8 ~29 ~-36 ~-8 ~29 ~-35 minecraft:chiseled_stone_bricks
fill ~-8 ~29 ~-25 ~-7 ~29 ~-25 minecraft:chiseled_stone_bricks
setblock ~-8 ~29 ~-24 minecraft:chiseled_stone_bricks
fill ~-8 ~65 ~-132 ~-7 ~65 ~-132 minecraft:chiseled_stone_bricks
fill ~-8 ~65 ~-117 ~-8 ~65 ~-116 minecraft:chiseled_stone_bricks
fill ~-7 ~25 ~-164 ~-7 ~25 ~-163 minecraft:chiseled_stone_bricks
fill ~-7 ~25 ~-157 ~-7 ~25 ~-156 minecraft:chiseled_stone_bricks
fill ~-7 ~29 ~-35 ~-7 ~29 ~-33 minecraft:chiseled_stone_bricks
fill ~-7 ~29 ~-27 ~-6 ~29 ~-27 minecraft:chiseled_stone_bricks
fill ~-7 ~29 ~-26 ~-7 ~29 ~-25 minecraft:chiseled_stone_bricks
fill ~-7 ~65 ~-133 ~-6 ~65 ~-133 minecraft:chiseled_stone_bricks
fill ~-7 ~65 ~-116 ~-7 ~65 ~-115 minecraft:chiseled_stone_bricks
fill ~-6 ~25 ~-166 ~-5 ~25 ~-166 minecraft:chiseled_stone_bricks
setblock ~-6 ~25 ~-165 minecraft:chiseled_stone_bricks
fill ~-6 ~25 ~-155 ~-6 ~25 ~-154 minecraft:chiseled_stone_bricks
fill ~-6 ~29 ~-33 ~-6 ~29 ~-27 minecraft:chiseled_stone_bricks
setblock ~-6 ~65 ~-115 minecraft:chiseled_stone_bricks
setblock ~-5 ~25 ~-154 minecraft:chiseled_stone_bricks
fill ~-5 ~65 ~-134 ~-4 ~65 ~-134 minecraft:chiseled_stone_bricks
fill ~-5 ~65 ~-114 ~-4 ~65 ~-114 minecraft:chiseled_stone_bricks
fill ~-4 ~ ~-101 ~-4 ~7 ~-101 minecraft:chiseled_stone_bricks
fill ~-4 ~25 ~-167 ~-3 ~25 ~-167 minecraft:chiseled_stone_bricks
fill ~-4 ~25 ~-153 ~-3 ~25 ~-153 minecraft:chiseled_stone_bricks
fill ~-3 ~65 ~-135 ~3 ~65 ~-135 minecraft:chiseled_stone_bricks
fill ~-3 ~65 ~-113 ~3 ~65 ~-113 minecraft:chiseled_stone_bricks
fill ~-2 ~25 ~-168 ~2 ~25 ~-168 minecraft:chiseled_stone_bricks
fill ~-2 ~25 ~-152 ~2 ~25 ~-152 minecraft:chiseled_stone_bricks
fill ~-1 ~11 ~-25 ~1 ~15 ~-25 minecraft:chiseled_stone_bricks
fill ~3 ~25 ~-167 ~4 ~25 ~-167 minecraft:chiseled_stone_bricks
fill ~3 ~25 ~-153 ~4 ~25 ~-153 minecraft:chiseled_stone_bricks
fill ~4 ~ ~-101 ~4 ~7 ~-101 minecraft:chiseled_stone_bricks
fill ~4 ~65 ~-134 ~5 ~65 ~-134 minecraft:chiseled_stone_bricks
fill ~4 ~65 ~-114 ~5 ~65 ~-114 minecraft:chiseled_stone_bricks
fill ~5 ~25 ~-166 ~6 ~25 ~-166 minecraft:chiseled_stone_bricks
fill ~5 ~25 ~-154 ~6 ~25 ~-154 minecraft:chiseled_stone_bricks
setblock ~6 ~25 ~-165 minecraft:chiseled_stone_bricks
fill ~6 ~25 ~-155 ~6 ~25 ~-154 minecraft:chiseled_stone_bricks
fill ~6 ~29 ~-33 ~7 ~29 ~-33 minecraft:chiseled_stone_bricks
fill ~6 ~29 ~-32 ~6 ~29 ~-27 minecraft:chiseled_stone_bricks
fill ~6 ~65 ~-133 ~7 ~65 ~-133 minecraft:chiseled_stone_bricks
fill ~6 ~65 ~-115 ~7 ~65 ~-115 minecraft:chiseled_stone_bricks
fill ~7 ~25 ~-164 ~7 ~25 ~-163 minecraft:chiseled_stone_bricks
fill ~7 ~25 ~-157 ~7 ~25 ~-156 minecraft:chiseled_stone_bricks
fill ~7 ~29 ~-35 ~8 ~29 ~-35 minecraft:chiseled_stone_bricks
fill ~7 ~29 ~-34 ~7 ~29 ~-33 minecraft:chiseled_stone_bricks
fill ~7 ~29 ~-27 ~7 ~29 ~-25 minecraft:chiseled_stone_bricks
fill ~7 ~65 ~-132 ~8 ~65 ~-132 minecraft:chiseled_stone_bricks
fill ~7 ~65 ~-116 ~8 ~65 ~-116 minecraft:chiseled_stone_bricks
fill ~8 ~25 ~-162 ~8 ~25 ~-158 minecraft:chiseled_stone_bricks
fill ~8 ~29 ~-36 ~8 ~29 ~-35 minecraft:chiseled_stone_bricks
fill ~8 ~29 ~-25 ~8 ~29 ~-24 minecraft:chiseled_stone_bricks
fill ~8 ~65 ~-131 ~9 ~65 ~-131 minecraft:chiseled_stone_bricks
fill ~8 ~65 ~-117 ~9 ~65 ~-117 minecraft:chiseled_stone_bricks
fill ~9 ~29 ~-37 ~10 ~29 ~-37 minecraft:chiseled_stone_bricks
fill ~9 ~29 ~-23 ~10 ~29 ~-23 minecraft:chiseled_stone_bricks
setblock ~9 ~65 ~-130 minecraft:chiseled_stone_bricks
fill ~9 ~65 ~-118 ~9 ~65 ~-117 minecraft:chiseled_stone_bricks
fill ~10 ~29 ~-38 ~12 ~29 ~-38 minecraft:chiseled_stone_bricks
fill ~10 ~29 ~-22 ~12 ~29 ~-22 minecraft:chiseled_stone_bricks
fill ~10 ~65 ~-129 ~10 ~65 ~-128 minecraft:chiseled_stone_bricks
fill ~10 ~65 ~-120 ~10 ~65 ~-119 minecraft:chiseled_stone_bricks
fill ~11 ~65 ~-127 ~11 ~65 ~-121 minecraft:chiseled_stone_bricks
fill ~12 ~29 ~-39 ~18 ~29 ~-39 minecraft:chiseled_stone_bricks
fill ~12 ~29 ~-21 ~18 ~29 ~-21 minecraft:chiseled_stone_bricks
fill ~18 ~29 ~-38 ~20 ~29 ~-38 minecraft:chiseled_stone_bricks
fill ~18 ~29 ~-22 ~20 ~29 ~-22 minecraft:chiseled_stone_bricks
fill ~19 ~51 ~-148 ~19 ~51 ~-144 minecraft:chiseled_stone_bricks
fill ~19 ~51 ~-104 ~19 ~51 ~-100 minecraft:chiseled_stone_bricks
fill ~20 ~29 ~-37 ~21 ~29 ~-37 minecraft:chiseled_stone_bricks
fill ~20 ~29 ~-23 ~21 ~29 ~-23 minecraft:chiseled_stone_bricks
fill ~20 ~51 ~-150 ~20 ~51 ~-149 minecraft:chiseled_stone_bricks
fill ~20 ~51 ~-143 ~20 ~51 ~-142 minecraft:chiseled_stone_bricks
fill ~20 ~51 ~-106 ~20 ~51 ~-105 minecraft:chiseled_stone_bricks
fill ~20 ~51 ~-99 ~20 ~51 ~-98 minecraft:chiseled_stone_bricks
setblock ~21 ~51 ~-151 minecraft:chiseled_stone_bricks
setblock ~21 ~51 ~-141 minecraft:chiseled_stone_bricks
setblock ~21 ~51 ~-107 minecraft:chiseled_stone_bricks
setblock ~21 ~51 ~-97 minecraft:chiseled_stone_bricks
fill ~22 ~29 ~-36 ~22 ~29 ~-35 minecraft:chiseled_stone_bricks
fill ~22 ~29 ~-25 ~23 ~29 ~-25 minecraft:chiseled_stone_bricks
setblock ~22 ~29 ~-24 minecraft:chiseled_stone_bricks
fill ~22 ~51 ~-152 ~23 ~51 ~-152 minecraft:chiseled_stone_bricks
fill ~22 ~51 ~-140 ~23 ~51 ~-140 minecraft:chiseled_stone_bricks
fill ~22 ~51 ~-108 ~23 ~51 ~-108 minecraft:chiseled_stone_bricks
fill ~22 ~51 ~-96 ~23 ~51 ~-96 minecraft:chiseled_stone_bricks
fill ~23 ~29 ~-35 ~23 ~29 ~-33 minecraft:chiseled_stone_bricks
fill ~23 ~29 ~-27 ~24 ~29 ~-27 minecraft:chiseled_stone_bricks
fill ~23 ~29 ~-26 ~23 ~29 ~-25 minecraft:chiseled_stone_bricks
fill ~24 ~29 ~-33 ~24 ~29 ~-27 minecraft:chiseled_stone_bricks
fill ~24 ~51 ~-153 ~28 ~51 ~-153 minecraft:chiseled_stone_bricks
fill ~24 ~51 ~-139 ~28 ~51 ~-139 minecraft:chiseled_stone_bricks
fill ~24 ~51 ~-109 ~28 ~51 ~-109 minecraft:chiseled_stone_bricks
fill ~24 ~51 ~-95 ~28 ~51 ~-95 minecraft:chiseled_stone_bricks
fill ~27 ~43 ~-139 ~27 ~43 ~-109 minecraft:chiseled_stone_bricks
fill ~29 ~51 ~-152 ~30 ~51 ~-152 minecraft:chiseled_stone_bricks
fill ~29 ~51 ~-140 ~30 ~51 ~-140 minecraft:chiseled_stone_bricks
fill ~29 ~51 ~-108 ~30 ~51 ~-108 minecraft:chiseled_stone_bricks
fill ~29 ~51 ~-96 ~30 ~51 ~-96 minecraft:chiseled_stone_bricks
setblock ~31 ~51 ~-151 minecraft:chiseled_stone_bricks
setblock ~31 ~51 ~-141 minecraft:chiseled_stone_bricks
setblock ~31 ~51 ~-107 minecraft:chiseled_stone_bricks
setblock ~31 ~51 ~-97 minecraft:chiseled_stone_bricks
fill ~32 ~51 ~-150 ~32 ~51 ~-149 minecraft:chiseled_stone_bricks
fill ~32 ~51 ~-143 ~32 ~51 ~-142 minecraft:chiseled_stone_bricks
fill ~32 ~51 ~-106 ~32 ~51 ~-105 minecraft:chiseled_stone_bricks
fill ~32 ~51 ~-99 ~32 ~51 ~-98 minecraft:chiseled_stone_bricks
fill ~33 ~51 ~-148 ~33 ~51 ~-144 minecraft:chiseled_stone_bricks
fill ~33 ~51 ~-104 ~33 ~51 ~-100 minecraft:chiseled_stone_bricks
fill ~52 ~29 ~-163 ~52 ~29 ~-157 minecraft:chiseled_stone_bricks
fill ~52 ~29 ~-35 ~52 ~29 ~-29 minecraft:chiseled_stone_bricks
fill ~53 ~29 ~-165 ~53 ~29 ~-164 minecraft:chiseled_stone_bricks
fill ~53 ~29 ~-156 ~53 ~29 ~-155 minecraft:chiseled_stone_bricks
fill ~53 ~29 ~-37 ~53 ~29 ~-36 minecraft:chiseled_stone_bricks
fill ~53 ~29 ~-28 ~53 ~29 ~-27 minecraft:chiseled_stone_bricks
fill ~54 ~29 ~-167 ~54 ~29 ~-166 minecraft:chiseled_stone_bricks
fill ~54 ~29 ~-154 ~54 ~29 ~-153 minecraft:chiseled_stone_bricks
fill ~54 ~29 ~-39 ~54 ~29 ~-38 minecraft:chiseled_stone_bricks
fill ~54 ~29 ~-26 ~54 ~29 ~-25 minecraft:chiseled_stone_bricks
setblock ~55 ~29 ~-168 minecraft:chiseled_stone_bricks
setblock ~55 ~29 ~-152 minecraft:chiseled_stone_bricks
setblock ~55 ~29 ~-40 minecraft:chiseled_stone_bricks
setblock ~55 ~29 ~-24 minecraft:chiseled_stone_bricks
fill ~56 ~25 ~-98 ~56 ~25 ~-94 minecraft:chiseled_stone_bricks
setblock ~56 ~29 ~-169 minecraft:chiseled_stone_bricks
setblock ~56 ~29 ~-151 minecraft:chiseled_stone_bricks
setblock ~56 ~29 ~-41 minecraft:chiseled_stone_bricks
setblock ~56 ~29 ~-23 minecraft:chiseled_stone_bricks
fill ~57 ~25 ~-100 ~57 ~25 ~-99 minecraft:chiseled_stone_bricks
fill ~57 ~25 ~-93 ~57 ~25 ~-92 minecraft:chiseled_stone_bricks
fill ~57 ~29 ~-170 ~58 ~29 ~-170 minecraft:chiseled_stone_bricks
fill ~57 ~29 ~-150 ~58 ~29 ~-150 minecraft:chiseled_stone_bricks
fill ~57 ~29 ~-42 ~58 ~29 ~-42 minecraft:chiseled_stone_bricks
fill ~57 ~29 ~-22 ~58 ~29 ~-22 minecraft:chiseled_stone_bricks
fill ~58 ~25 ~-102 ~59 ~25 ~-102 minecraft:chiseled_stone_bricks
setblock ~58 ~25 ~-101 minecraft:chiseled_stone_bricks
fill ~58 ~25 ~-91 ~58 ~25 ~-90 minecraft:chiseled_stone_bricks
setblock ~59 ~25 ~-90 minecraft:chiseled_stone_bricks
fill ~59 ~29 ~-171 ~60 ~29 ~-171 minecraft:chiseled_stone_bricks
fill ~59 ~29 ~-149 ~60 ~29 ~-149 minecraft:chiseled_stone_bricks
fill ~59 ~29 ~-43 ~60 ~29 ~-43 minecraft:chiseled_stone_bricks
fill ~59 ~29 ~-21 ~60 ~29 ~-21 minecraft:chiseled_stone_bricks
fill ~60 ~25 ~-103 ~61 ~25 ~-103 minecraft:chiseled_stone_bricks
fill ~60 ~25 ~-89 ~61 ~25 ~-89 minecraft:chiseled_stone_bricks
fill ~61 ~29 ~-172 ~67 ~29 ~-172 minecraft:chiseled_stone_bricks
fill ~61 ~29 ~-148 ~67 ~29 ~-148 minecraft:chiseled_stone_bricks
fill ~61 ~29 ~-44 ~67 ~29 ~-44 minecraft:chiseled_stone_bricks
fill ~61 ~29 ~-20 ~67 ~29 ~-20 minecraft:chiseled_stone_bricks
fill ~62 ~25 ~-104 ~66 ~25 ~-104 minecraft:chiseled_stone_bricks
fill ~62 ~25 ~-88 ~66 ~25 ~-88 minecraft:chiseled_stone_bricks
fill ~67 ~25 ~-103 ~68 ~25 ~-103 minecraft:chiseled_stone_bricks
fill ~67 ~25 ~-89 ~68 ~25 ~-89 minecraft:chiseled_stone_bricks
fill ~68 ~29 ~-171 ~69 ~29 ~-171 minecraft:chiseled_stone_bricks
fill ~68 ~29 ~-149 ~69 ~29 ~-149 minecraft:chiseled_stone_bricks
fill ~68 ~29 ~-43 ~69 ~29 ~-43 minecraft:chiseled_stone_bricks
fill ~68 ~29 ~-21 ~69 ~29 ~-21 minecraft:chiseled_stone_bricks
fill ~69 ~25 ~-102 ~70 ~25 ~-102 minecraft:chiseled_stone_bricks
fill ~69 ~25 ~-90 ~70 ~25 ~-90 minecraft:chiseled_stone_bricks
setblock ~70 ~25 ~-101 minecraft:chiseled_stone_bricks
fill ~70 ~25 ~-91 ~70 ~25 ~-90 minecraft:chiseled_stone_bricks
fill ~70 ~29 ~-170 ~71 ~29 ~-170 minecraft:chiseled_stone_bricks
fill ~70 ~29 ~-150 ~71 ~29 ~-150 minecraft:chiseled_stone_bricks
fill ~70 ~29 ~-42 ~71 ~29 ~-42 minecraft:chiseled_stone_bricks
fill ~70 ~29 ~-22 ~71 ~29 ~-22 minecraft:chiseled_stone_bricks
fill ~71 ~25 ~-100 ~71 ~25 ~-99 minecraft:chiseled_stone_bricks
fill ~71 ~25 ~-93 ~71 ~25 ~-92 minecraft:chiseled_stone_bricks
fill ~72 ~25 ~-98 ~72 ~25 ~-94 minecraft:chiseled_stone_bricks
setblock ~72 ~29 ~-169 minecraft:chiseled_stone_bricks
setblock ~72 ~29 ~-151 minecraft:chiseled_stone_bricks
setblock ~72 ~29 ~-41 minecraft:chiseled_stone_bricks
setblock ~72 ~29 ~-23 minecraft:chiseled_stone_bricks
setblock ~73 ~29 ~-168 minecraft:chiseled_stone_bricks
setblock ~73 ~29 ~-152 minecraft:chiseled_stone_bricks
setblock ~73 ~29 ~-40 minecraft:chiseled_stone_bricks
setblock ~73 ~29 ~-24 minecraft:chiseled_stone_bricks
fill ~74 ~29 ~-167 ~74 ~29 ~-166 minecraft:chiseled_stone_bricks
fill ~74 ~29 ~-154 ~74 ~29 ~-153 minecraft:chiseled_stone_bricks
fill ~74 ~29 ~-39 ~74 ~29 ~-38 minecraft:chiseled_stone_bricks
fill ~74 ~29 ~-26 ~74 ~29 ~-25 minecraft:chiseled_stone_bricks
fill ~75 ~29 ~-165 ~75 ~29 ~-164 minecraft:chiseled_stone_bricks
fill ~75 ~29 ~-156 ~75 ~29 ~-155 minecraft:chiseled_stone_bricks
fill ~75 ~29 ~-37 ~75 ~29 ~-36 minecraft:chiseled_stone_bricks
fill ~75 ~29 ~-28 ~75 ~29 ~-27 minecraft:chiseled_stone_bricks
fill ~76 ~29 ~-163 ~76 ~29 ~-157 minecraft:chiseled_stone_bricks
fill ~76 ~29 ~-35 ~76 ~29 ~-29 minecraft:chiseled_stone_bricks
setblock ~-24 ~-1 ~-143 minecraft:polished_diorite
setblock ~-24 ~-1 ~-141 minecraft:polished_diorite
setblock ~-24 ~-1 ~-139 minecraft:polished_diorite
setblock ~-24 ~-1 ~-137 minecraft:polished_diorite
fill ~-24 ~-1 ~-135 ~-24 ~ ~-135 minecraft:polished_diorite
fill ~-24 ~-1 ~-133 ~-24 ~ ~-133 minecraft:polished_diorite
fill ~-24 ~-1 ~-131 ~-24 ~ ~-131 minecraft:polished_diorite
fill ~-24 ~-1 ~-129 ~-24 ~ ~-129 minecraft:polished_diorite
setblock ~-24 ~-1 ~-127 minecraft:polished_diorite
setblock ~-24 ~-1 ~-125 minecraft:polished_diorite
setblock ~-24 ~-1 ~-123 minecraft:polished_diorite
setblock ~-24 ~-1 ~-121 minecraft:polished_diorite
setblock ~-24 ~-1 ~-119 minecraft:polished_diorite
setblock ~-24 ~-1 ~-117 minecraft:polished_diorite
setblock ~-24 ~-1 ~-115 minecraft:polished_diorite
setblock ~-24 ~-1 ~-113 minecraft:polished_diorite
setblock ~-24 ~-1 ~-111 minecraft:polished_diorite
setblock ~-24 ~-1 ~-109 minecraft:polished_diorite
setblock ~-24 ~-1 ~-107 minecraft:polished_diorite
setblock ~-24 ~-1 ~-105 minecraft:polished_diorite
fill ~-23 ~-1 ~-144 ~-23 ~ ~-144 minecraft:polished_diorite
setblock ~-23 ~-1 ~-142 minecraft:polished_diorite
setblock ~-23 ~-1 ~-140 minecraft:polished_diorite
setblock ~-23 ~-1 ~-138 minecraft:polished_diorite
setblock ~-23 ~-1 ~-136 minecraft:polished_diorite
setblock ~-23 ~-1 ~-134 minecraft:polished_diorite
setblock ~-23 ~-1 ~-132 minecraft:polished_diorite
setblock ~-23 ~-1 ~-130 minecraft:polished_diorite
setblock ~-23 ~-1 ~-128 minecraft:polished_diorite
setblock ~-23 ~-1 ~-126 minecraft:polished_diorite
setblock ~-23 ~-1 ~-124 minecraft:polished_diorite
setblock ~-23 ~-1 ~-122 minecraft:polished_diorite
setblock ~-23 ~-1 ~-120 minecraft:polished_diorite
setblock ~-23 ~-1 ~-118 minecraft:polished_diorite
setblock ~-23 ~-1 ~-116 minecraft:polished_diorite
setblock ~-23 ~-1 ~-114 minecraft:polished_diorite
setblock ~-23 ~-1 ~-112 minecraft:polished_diorite
setblock ~-23 ~-1 ~-110 minecraft:polished_diorite
setblock ~-23 ~-1 ~-108 minecraft:polished_diorite
setblock ~-23 ~-1 ~-106 minecraft:polished_diorite
setblock ~-23 ~-1 ~-104 minecraft:polished_diorite
setblock ~-22 ~-1 ~-143 minecraft:polished_diorite
setblock ~-22 ~-1 ~-141 minecraft:polished_diorite
setblock ~-22 ~-1 ~-139 minecraft:polished_diorite
setblock ~-22 ~-1 ~-137 minecraft:polished_diorite
setblock ~-22 ~-1 ~-135 minecraft:polished_diorite
setblock ~-22 ~-1 ~-133 minecraft:polished_diorite
setblock ~-22 ~-1 ~-131 minecraft:polished_diorite
setblock ~-22 ~-1 ~-129 minecraft:polished_diorite
setblock ~-22 ~-1 ~-127 minecraft:polished_diorite
setblock ~-22 ~-1 ~-125 minecraft:polished_diorite
setblock ~-22 ~-1 ~-123 minecraft:polished_diorite
setblock ~-22 ~-1 ~-121 minecraft:polished_diorite
setblock ~-22 ~-1 ~-119 minecraft:polished_diorite
setblock ~-22 ~-1 ~-117 minecraft:polished_diorite
fill ~-22 ~-1 ~-115 ~-22 ~ ~-115 minecraft:polished_diorite
fill ~-22 ~-1 ~-113 ~-22 ~ ~-113 minecraft:polished_diorite
setblock ~-22 ~-1 ~-111 minecraft:polished_diorite
setblock ~-22 ~-1 ~-109 minecraft:polished_diorite
setblock ~-22 ~-1 ~-107 minecraft:polished_diorite
setblock ~-22 ~-1 ~-105 minecraft:polished_diorite
fill ~-21 ~-1 ~-144 ~-21 ~ ~-144 minecraft:polished_diorite
setblock ~-21 ~-1 ~-142 minecraft:polished_diorite
setblock ~-21 ~-1 ~-138 minecraft:polished_diorite
setblock ~-21 ~-1 ~-136 minecraft:polished_diorite
setblock ~-21 ~-1 ~-134 minecraft:polished_diorite
setblock ~-21 ~-1 ~-132 minecraft:polished_diorite
setblock ~-21 ~-1 ~-130 minecraft:polished_diorite
setblock ~-21 ~-1 ~-128 minecraft:polished_diorite
setblock ~-21 ~-1 ~-126 minecraft:polished_diorite
setblock ~-21 ~-1 ~-124 minecraft:polished_diorite
