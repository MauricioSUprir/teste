fill ~-35 ~-1 ~-138 ~-28 ~-1 ~-110 minecraft:grass_block
fill ~-35 ~-1 ~-109 ~-29 ~-1 ~-109 minecraft:grass_block
fill ~-35 ~-1 ~-108 ~-31 ~-1 ~-108 minecraft:grass_block
fill ~-35 ~-1 ~-107 ~-32 ~-1 ~-107 minecraft:grass_block
fill ~-35 ~-1 ~-106 ~-33 ~-1 ~-105 minecraft:grass_block
fill ~-35 ~-1 ~-104 ~-34 ~-1 ~-57 minecraft:grass_block
fill ~-33 ~-1 ~-143 ~-33 ~-1 ~-105 minecraft:grass_block
fill ~-33 ~-1 ~-99 ~-33 ~-1 ~-57 minecraft:grass_block
fill ~-32 ~-1 ~-141 ~-32 ~-1 ~-107 minecraft:grass_block
fill ~-32 ~-1 ~-97 ~-32 ~-1 ~-39 minecraft:grass_block
fill ~-31 ~-1 ~-140 ~-31 ~-1 ~-108 minecraft:grass_block
fill ~-31 ~-1 ~-96 ~-31 ~-1 ~-39 minecraft:grass_block
fill ~-30 ~-1 ~-139 ~-29 ~-1 ~-109 minecraft:grass_block
fill ~-30 ~-1 ~-95 ~-29 ~-1 ~-39 minecraft:grass_block
fill ~-28 ~-1 ~-94 ~-9 ~-1 ~-94 minecraft:grass_block
fill ~-28 ~-1 ~-93 ~-14 ~-1 ~-93 minecraft:grass_block
fill ~-28 ~-1 ~-92 ~-19 ~-1 ~-90 minecraft:grass_block
fill ~-28 ~-1 ~-56 ~31 ~-1 ~-42 minecraft:grass_block
fill ~-23 ~-1 ~-153 ~-5 ~-1 ~-153 minecraft:grass_block
fill ~-23 ~-1 ~-95 ~-18 ~-1 ~-93 minecraft:grass_block
fill ~-21 ~-1 ~-152 ~-3 ~-1 ~-152 minecraft:grass_block
fill ~-21 ~-1 ~-96 ~-13 ~-1 ~-96 minecraft:grass_block
fill ~-20 ~-1 ~-151 ~20 ~-1 ~-151 minecraft:grass_block
fill ~-20 ~-1 ~-97 ~20 ~-1 ~-97 minecraft:grass_block
fill ~-19 ~-1 ~-150 ~19 ~-1 ~-149 minecraft:grass_block
fill ~-19 ~-1 ~-99 ~19 ~-1 ~-97 minecraft:grass_block
fill ~-19 ~-1 ~-88 ~-11 ~-1 ~-88 minecraft:grass_block
fill ~-19 ~-1 ~-87 ~-16 ~-1 ~-40 minecraft:grass_block
fill ~-18 ~-1 ~-148 ~18 ~-1 ~-148 minecraft:grass_block
fill ~-18 ~-1 ~-100 ~18 ~-1 ~-97 minecraft:grass_block
fill ~-18 ~-1 ~-89 ~8 ~-1 ~-89 minecraft:grass_block
fill ~-17 ~-1 ~-92 ~9 ~-1 ~-92 minecraft:grass_block
fill ~-16 ~-1 ~-95 ~10 ~-1 ~-95 minecraft:grass_block
fill ~-15 ~-1 ~-86 ~7 ~-1 ~-75 minecraft:grass_block
fill ~-14 ~-1 ~-87 ~12 ~-1 ~-87 minecraft:grass_block
fill ~-13 ~-1 ~-90 ~13 ~-1 ~-90 minecraft:grass_block
fill ~-12 ~-1 ~-93 ~14 ~-1 ~-93 minecraft:grass_block
fill ~-11 ~-1 ~-96 ~15 ~-1 ~-96 minecraft:grass_block
setblock ~-11 ~-1 ~-39 minecraft:grass_block
fill ~-11 ~-1 ~-21 ~-5 ~-1 ~4 minecraft:grass_block
fill ~-9 ~-1 ~-88 ~17 ~-1 ~-88 minecraft:grass_block
fill ~-9 ~-1 ~-22 ~-5 ~-1 ~4 minecraft:grass_block
fill ~-8 ~-1 ~-91 ~18 ~-1 ~-91 minecraft:grass_block
fill ~-8 ~-1 ~-23 ~-5 ~-1 ~4 minecraft:grass_block
fill ~-7 ~-1 ~-155 ~-7 ~-1 ~-148 minecraft:grass_block
fill ~-7 ~-1 ~-94 ~37 ~-1 ~-94 minecraft:grass_block
fill ~-7 ~-1 ~-24 ~7 ~-1 ~-24 minecraft:grass_block
fill ~-4 ~-1 ~-3 ~100 ~-1 ~4 minecraft:grass_block
fill ~-3 ~-1 ~-103 ~-3 ~-1 ~-24 minecraft:grass_block
fill ~-1 ~-1 ~-154 ~1 ~-1 ~-148 minecraft:grass_block
fill ~3 ~-1 ~-168 ~54 ~-1 ~-168 minecraft:grass_block
fill ~3 ~-1 ~-152 ~21 ~-1 ~-152 minecraft:grass_block
fill ~3 ~-1 ~-101 ~3 ~-1 ~-24 minecraft:grass_block
fill ~5 ~-1 ~-167 ~53 ~-1 ~-167 minecraft:grass_block
fill ~5 ~-1 ~-153 ~23 ~-1 ~-153 minecraft:grass_block
fill ~6 ~-1 ~-23 ~8 ~-1 ~4 minecraft:grass_block
fill ~7 ~-1 ~-166 ~53 ~-1 ~-166 minecraft:grass_block
fill ~7 ~-1 ~-165 ~52 ~-1 ~-165 minecraft:grass_block
fill ~7 ~-1 ~-155 ~47 ~-1 ~-154 minecraft:grass_block
fill ~8 ~-1 ~-164 ~52 ~-1 ~-164 minecraft:grass_block
fill ~8 ~-1 ~-163 ~51 ~-1 ~-163 minecraft:grass_block
fill ~8 ~-1 ~-85 ~59 ~-1 ~-75 minecraft:grass_block
fill ~9 ~-1 ~-162 ~51 ~-1 ~-162 minecraft:grass_block
fill ~9 ~-1 ~-86 ~59 ~-1 ~-75 minecraft:grass_block
fill ~9 ~-1 ~-22 ~9 ~-1 ~4 minecraft:grass_block
fill ~10 ~-1 ~-89 ~59 ~-1 ~-89 minecraft:grass_block
fill ~10 ~-1 ~-21 ~11 ~-1 ~4 minecraft:grass_block
fill ~11 ~-1 ~-92 ~37 ~-1 ~-92 minecraft:grass_block
fill ~11 ~-1 ~-41 ~56 ~-1 ~-40 minecraft:grass_block
setblock ~11 ~-1 ~-39 minecraft:grass_block
fill ~12 ~-1 ~-95 ~23 ~-1 ~-94 minecraft:grass_block
fill ~12 ~-1 ~-20 ~60 ~-1 ~4 minecraft:grass_block
fill ~13 ~-1 ~-74 ~59 ~-1 ~-60 minecraft:grass_block
fill ~14 ~-1 ~-87 ~59 ~-1 ~-60 minecraft:grass_block
fill ~15 ~-1 ~-90 ~57 ~-1 ~-89 minecraft:grass_block
fill ~16 ~-1 ~-93 ~37 ~-1 ~-92 minecraft:grass_block
fill ~17 ~-1 ~-96 ~21 ~-1 ~-92 minecraft:grass_block
fill ~19 ~-1 ~-88 ~59 ~-1 ~-60 minecraft:grass_block
fill ~19 ~-1 ~-39 ~47 ~-1 ~-39 minecraft:grass_block
fill ~19 ~-1 ~-21 ~58 ~-1 ~4 minecraft:grass_block
fill ~20 ~-1 ~-91 ~57 ~-1 ~-60 minecraft:grass_block
fill ~21 ~-1 ~-22 ~56 ~-1 ~4 minecraft:grass_block
fill ~22 ~-1 ~-23 ~55 ~-1 ~4 minecraft:grass_block
fill ~23 ~-1 ~-24 ~54 ~-1 ~4 minecraft:grass_block
fill ~24 ~-1 ~-26 ~53 ~-1 ~4 minecraft:grass_block
fill ~25 ~-1 ~-30 ~51 ~-1 ~4 minecraft:grass_block
fill ~28 ~-1 ~-138 ~35 ~-1 ~-110 minecraft:grass_block
fill ~29 ~-1 ~-153 ~53 ~-1 ~-153 minecraft:grass_block
fill ~29 ~-1 ~-139 ~59 ~-1 ~-139 minecraft:grass_block
fill ~29 ~-1 ~-109 ~37 ~-1 ~-109 minecraft:grass_block
fill ~29 ~-1 ~-95 ~37 ~-1 ~-60 minecraft:grass_block
fill ~30 ~-1 ~-59 ~59 ~-1 ~-57 minecraft:grass_block
fill ~31 ~-1 ~-152 ~57 ~-1 ~-152 minecraft:grass_block
fill ~31 ~-1 ~-140 ~59 ~-1 ~-139 minecraft:grass_block
fill ~31 ~-1 ~-108 ~37 ~-1 ~-108 minecraft:grass_block
fill ~31 ~-1 ~-96 ~37 ~-1 ~-57 minecraft:grass_block
fill ~32 ~-1 ~-151 ~56 ~-1 ~-151 minecraft:grass_block
fill ~32 ~-1 ~-141 ~59 ~-1 ~-139 minecraft:grass_block
fill ~32 ~-1 ~-107 ~37 ~-1 ~-107 minecraft:grass_block
fill ~32 ~-1 ~-97 ~37 ~-1 ~-57 minecraft:grass_block
fill ~33 ~-1 ~-150 ~56 ~-1 ~-149 minecraft:grass_block
fill ~33 ~-1 ~-143 ~59 ~-1 ~-139 minecraft:grass_block
fill ~33 ~-1 ~-106 ~37 ~-1 ~-105 minecraft:grass_block
fill ~33 ~-1 ~-99 ~37 ~-1 ~-57 minecraft:grass_block
fill ~33 ~-1 ~-38 ~53 ~-1 ~-38 minecraft:grass_block
fill ~33 ~-1 ~-37 ~52 ~-1 ~-37 minecraft:grass_block
fill ~34 ~-1 ~-148 ~59 ~-1 ~-139 minecraft:grass_block
fill ~34 ~-1 ~-104 ~37 ~-1 ~-57 minecraft:grass_block
fill ~36 ~-1 ~-119 ~59 ~-1 ~-113 minecraft:grass_block
fill ~36 ~-1 ~-112 ~37 ~-1 ~-57 minecraft:grass_block
fill ~40 ~-1 ~-56 ~41 ~-1 ~-37 minecraft:grass_block
fill ~48 ~-1 ~-154 ~53 ~-1 ~-139 minecraft:grass_block
fill ~49 ~-1 ~-155 ~52 ~-1 ~-139 minecraft:grass_block
fill ~49 ~-1 ~-39 ~53 ~-1 ~-38 minecraft:grass_block
fill ~50 ~-1 ~-56 ~59 ~-1 ~-44 minecraft:grass_block
fill ~52 ~-1 ~-28 ~52 ~-1 ~4 minecraft:grass_block
fill ~55 ~-1 ~-138 ~59 ~-1 ~-103 minecraft:grass_block
fill ~55 ~-1 ~-102 ~57 ~-1 ~-101 minecraft:grass_block
fill ~55 ~-1 ~-100 ~56 ~-1 ~-99 minecraft:grass_block
fill ~55 ~-1 ~-98 ~55 ~-1 ~-40 minecraft:grass_block
fill ~56 ~-1 ~-153 ~57 ~-1 ~-152 minecraft:grass_block
fill ~56 ~-1 ~-97 ~58 ~-1 ~-95 minecraft:grass_block
fill ~56 ~-1 ~-93 ~56 ~-1 ~-39 minecraft:grass_block
fill ~57 ~-1 ~-149 ~58 ~-1 ~-103 minecraft:grass_block
fill ~57 ~-1 ~-40 ~57 ~-1 ~-39 minecraft:grass_block
fill ~61 ~-1 ~-19 ~100 ~-1 ~4 minecraft:grass_block
fill ~66 ~-1 ~-147 ~100 ~-1 ~-105 minecraft:grass_block
fill ~66 ~-1 ~-87 ~100 ~-1 ~-45 minecraft:grass_block
fill ~67 ~-1 ~-104 ~100 ~-1 ~-104 minecraft:grass_block
fill ~67 ~-1 ~-88 ~100 ~-1 ~-45 minecraft:grass_block
fill ~68 ~-1 ~-172 ~100 ~-1 ~-172 minecraft:grass_block
fill ~68 ~-1 ~-148 ~100 ~-1 ~-104 minecraft:grass_block
fill ~68 ~-1 ~-44 ~100 ~-1 ~-44 minecraft:grass_block
fill ~68 ~-1 ~-20 ~100 ~-1 ~4 minecraft:grass_block
fill ~69 ~-1 ~-103 ~100 ~-1 ~-103 minecraft:grass_block
fill ~69 ~-1 ~-89 ~100 ~-1 ~-44 minecraft:grass_block
fill ~70 ~-1 ~-171 ~100 ~-1 ~-171 minecraft:grass_block
fill ~70 ~-1 ~-149 ~100 ~-1 ~-103 minecraft:grass_block
fill ~70 ~-1 ~-43 ~100 ~-1 ~-43 minecraft:grass_block
fill ~70 ~-1 ~-21 ~100 ~-1 ~4 minecraft:grass_block
fill ~71 ~-1 ~-102 ~100 ~-1 ~-101 minecraft:grass_block
fill ~71 ~-1 ~-91 ~100 ~-1 ~-43 minecraft:grass_block
fill ~72 ~-1 ~-170 ~100 ~-1 ~-170 minecraft:grass_block
fill ~72 ~-1 ~-150 ~100 ~-1 ~-99 minecraft:grass_block
fill ~72 ~-1 ~-93 ~100 ~-1 ~-42 minecraft:grass_block
fill ~72 ~-1 ~-22 ~100 ~-1 ~4 minecraft:grass_block
fill ~73 ~-1 ~-169 ~100 ~-1 ~-169 minecraft:grass_block
fill ~73 ~-1 ~-151 ~100 ~-1 ~-41 minecraft:grass_block
fill ~73 ~-1 ~-23 ~100 ~-1 ~4 minecraft:grass_block
fill ~74 ~-1 ~-168 ~100 ~-1 ~-168 minecraft:grass_block
fill ~74 ~-1 ~-152 ~100 ~-1 ~-40 minecraft:grass_block
fill ~74 ~-1 ~-24 ~100 ~-1 ~4 minecraft:grass_block
fill ~75 ~-1 ~-167 ~100 ~-1 ~-166 minecraft:grass_block
fill ~75 ~-1 ~-154 ~100 ~-1 ~-38 minecraft:grass_block
fill ~75 ~-1 ~-26 ~100 ~-1 ~4 minecraft:grass_block
fill ~76 ~-1 ~-165 ~100 ~-1 ~-164 minecraft:grass_block
fill ~76 ~-1 ~-156 ~100 ~-1 ~-36 minecraft:grass_block
fill ~76 ~-1 ~-28 ~100 ~-1 ~4 minecraft:grass_block
fill ~77 ~-1 ~-163 ~100 ~-1 ~4 minecraft:grass_block
fill ~-99 ~-12 ~-123 ~-78 ~-10 ~-117 minecraft:deepslate_bricks
fill ~-99 ~-9 ~-123 ~-78 ~-9 ~-121 minecraft:deepslate_bricks
fill ~-99 ~-9 ~-117 ~-78 ~-9 ~-117 minecraft:deepslate_bricks
fill ~-96 ~-9 ~-120 ~-78 ~-9 ~-117 minecraft:deepslate_bricks
fill ~-93 ~-12 ~-116 ~-78 ~-9 ~-115 minecraft:deepslate_bricks
fill ~-32 ~-28 ~-150 ~32 ~-28 ~-131 minecraft:deepslate_bricks
fill ~-32 ~-28 ~-116 ~31 ~-18 ~-100 minecraft:deepslate_bricks
fill ~-32 ~-27 ~-150 ~32 ~-18 ~-142 minecraft:deepslate_bricks
fill ~-32 ~-27 ~-141 ~-22 ~-18 ~-131 minecraft:deepslate_bricks
fill ~-32 ~-27 ~-125 ~31 ~-18 ~-123 minecraft:deepslate_bricks
fill ~-32 ~-27 ~-122 ~-26 ~-27 ~-100 minecraft:deepslate_bricks
fill ~-32 ~-26 ~-122 ~-27 ~-18 ~-100 minecraft:deepslate_bricks
fill ~-32 ~-21 ~-130 ~32 ~-18 ~-100 minecraft:deepslate_bricks
fill ~-29 ~-28 ~-130 ~29 ~-18 ~-127 minecraft:deepslate_bricks
fill ~-27 ~3 ~-138 ~-27 ~43 ~-138 minecraft:deepslate_bricks
fill ~-27 ~3 ~-130 ~-26 ~6 ~-130 minecraft:deepslate_bricks
fill ~-27 ~3 ~-122 ~-27 ~43 ~-122 minecraft:deepslate_bricks
fill ~-27 ~3 ~-114 ~-27 ~43 ~-114 minecraft:deepslate_bricks
fill ~-27 ~7 ~-130 ~-27 ~43 ~-130 minecraft:deepslate_bricks
fill ~-21 ~-23 ~-132 ~32 ~-18 ~-131 minecraft:deepslate_bricks
fill ~-21 ~-18 ~-138 ~32 ~-18 ~-100 minecraft:deepslate_bricks
fill ~-18 ~-26 ~-132 ~32 ~-18 ~-131 minecraft:deepslate_bricks
fill ~-18 ~-18 ~-141 ~-18 ~-18 ~-100 minecraft:deepslate_bricks
fill ~-18 ~3 ~-147 ~-18 ~43 ~-147 minecraft:deepslate_bricks
fill ~-18 ~3 ~-101 ~-18 ~43 ~-101 minecraft:deepslate_bricks
fill ~-14 ~-18 ~-141 ~32 ~-18 ~-100 minecraft:deepslate_bricks
fill ~-11 ~-26 ~-141 ~32 ~-18 ~-131 minecraft:deepslate_bricks
fill ~-10 ~3 ~-147 ~-10 ~6 ~-146 minecraft:deepslate_bricks
fill ~-10 ~3 ~-101 ~-10 ~43 ~-101 minecraft:deepslate_bricks
fill ~-10 ~7 ~-147 ~-10 ~43 ~-147 minecraft:deepslate_bricks
fill ~-2 ~3 ~-147 ~-2 ~9 ~-146 minecraft:deepslate_bricks
fill ~-2 ~7 ~-101 ~-2 ~43 ~-101 minecraft:deepslate_bricks
fill ~-2 ~10 ~-147 ~-2 ~43 ~-147 minecraft:deepslate_bricks
fill ~ ~-26 ~-122 ~31 ~-18 ~-100 minecraft:deepslate_bricks
fill ~1 ~-28 ~-126 ~29 ~-18 ~-100 minecraft:deepslate_bricks
fill ~6 ~3 ~-147 ~6 ~6 ~-146 minecraft:deepslate_bricks
fill ~6 ~3 ~-101 ~6 ~43 ~-101 minecraft:deepslate_bricks
fill ~6 ~7 ~-147 ~6 ~43 ~-147 minecraft:deepslate_bricks
fill ~14 ~3 ~-147 ~14 ~43 ~-147 minecraft:deepslate_bricks
fill ~14 ~3 ~-101 ~14 ~43 ~-101 minecraft:deepslate_bricks
fill ~27 ~3 ~-138 ~27 ~43 ~-138 minecraft:deepslate_bricks
fill ~27 ~3 ~-130 ~27 ~43 ~-130 minecraft:deepslate_bricks
fill ~27 ~3 ~-122 ~27 ~43 ~-122 minecraft:deepslate_bricks
fill ~27 ~3 ~-114 ~27 ~44 ~-114 minecraft:deepslate_bricks
fill ~30 ~-28 ~-125 ~31 ~-18 ~-100 minecraft:deepslate_bricks
fill ~32 ~-27 ~-141 ~32 ~-18 ~-131 minecraft:deepslate_bricks
setblock ~-76 ~30 ~-161 minecraft:mossy_stone_bricks
setblock ~-76 ~31 ~-32 minecraft:mossy_stone_bricks
setblock ~-76 ~31 ~-30 minecraft:mossy_stone_bricks
fill ~-75 ~3 ~-35 ~-75 ~3 ~-34 minecraft:mossy_stone_bricks
fill ~-75 ~4 ~-163 ~-75 ~4 ~-162 minecraft:mossy_stone_bricks
fill ~-75 ~4 ~-31 ~-74 ~4 ~-31 minecraft:mossy_stone_bricks
setblock ~-75 ~5 ~-163 minecraft:mossy_stone_bricks
setblock ~-75 ~6 ~-162 minecraft:mossy_stone_bricks
setblock ~-75 ~6 ~-31 minecraft:mossy_stone_bricks
fill ~-75 ~7 ~-160 ~-74 ~7 ~-160 minecraft:mossy_stone_bricks
setblock ~-75 ~7 ~-29 minecraft:mossy_stone_bricks
fill ~-75 ~9 ~-162 ~-75 ~10 ~-162 minecraft:mossy_stone_bricks
fill ~-75 ~11 ~-29 ~-75 ~12 ~-29 minecraft:mossy_stone_bricks
setblock ~-75 ~15 ~-158 minecraft:mossy_stone_bricks
fill ~-75 ~16 ~-161 ~-74 ~16 ~-160 minecraft:mossy_stone_bricks
setblock ~-75 ~17 ~-30 minecraft:mossy_stone_bricks
setblock ~-75 ~18 ~-161 minecraft:mossy_stone_bricks
fill ~-75 ~18 ~-35 ~-75 ~18 ~-34 minecraft:mossy_stone_bricks
fill ~-75 ~19 ~-160 ~-75 ~22 ~-160 minecraft:mossy_stone_bricks
setblock ~-75 ~20 ~-158 minecraft:mossy_stone_bricks
fill ~-75 ~24 ~-34 ~-75 ~25 ~-33 minecraft:mossy_stone_bricks
fill ~-75 ~25 ~-163 ~-74 ~25 ~-163 minecraft:mossy_stone_bricks
setblock ~-75 ~26 ~-158 minecraft:mossy_stone_bricks
fill ~-75 ~27 ~-161 ~-75 ~27 ~-159 minecraft:mossy_stone_bricks
setblock ~-75 ~30 ~-35 minecraft:mossy_stone_bricks
setblock ~-75 ~30 ~-31 minecraft:mossy_stone_bricks
setblock ~-74 ~1 ~-35 minecraft:mossy_stone_bricks
setblock ~-74 ~1 ~-30 minecraft:mossy_stone_bricks
setblock ~-74 ~2 ~-31 minecraft:mossy_stone_bricks
setblock ~-74 ~3 ~-36 minecraft:mossy_stone_bricks
setblock ~-74 ~3 ~-34 minecraft:mossy_stone_bricks
setblock ~-74 ~5 ~-160 minecraft:mossy_stone_bricks
setblock ~-74 ~6 ~-164 minecraft:mossy_stone_bricks
setblock ~-74 ~8 ~-165 minecraft:mossy_stone_bricks
setblock ~-74 ~8 ~-35 minecraft:mossy_stone_bricks
fill ~-74 ~10 ~-163 ~-74 ~10 ~-162 minecraft:mossy_stone_bricks
setblock ~-74 ~10 ~-29 minecraft:mossy_stone_bricks
setblock ~-74 ~11 ~-33 minecraft:mossy_stone_bricks
setblock ~-74 ~11 ~-31 minecraft:mossy_stone_bricks
setblock ~-74 ~12 ~-165 minecraft:mossy_stone_bricks
setblock ~-74 ~13 ~-158 minecraft:mossy_stone_bricks
setblock ~-74 ~14 ~-157 minecraft:mossy_stone_bricks
setblock ~-74 ~14 ~-155 minecraft:mossy_stone_bricks
fill ~-74 ~18 ~-37 ~-74 ~18 ~-36 minecraft:mossy_stone_bricks
setblock ~-74 ~20 ~-31 minecraft:mossy_stone_bricks
setblock ~-74 ~22 ~-36 minecraft:mossy_stone_bricks
setblock ~-74 ~23 ~-161 minecraft:mossy_stone_bricks
setblock ~-74 ~23 ~-37 minecraft:mossy_stone_bricks
setblock ~-74 ~25 ~-34 minecraft:mossy_stone_bricks
setblock ~-74 ~25 ~-29 minecraft:mossy_stone_bricks
setblock ~-74 ~26 ~-27 minecraft:mossy_stone_bricks
setblock ~-74 ~27 ~-158 minecraft:mossy_stone_bricks
setblock ~-74 ~30 ~-166 minecraft:mossy_stone_bricks
setblock ~-74 ~30 ~-38 minecraft:mossy_stone_bricks
fill ~-74 ~31 ~-154 ~-72 ~31 ~-154 minecraft:mossy_stone_bricks
setblock ~-73 ~2 ~-156 minecraft:mossy_stone_bricks
setblock ~-73 ~3 ~-167 minecraft:mossy_stone_bricks
setblock ~-73 ~4 ~-37 minecraft:mossy_stone_bricks
setblock ~-73 ~8 ~-36 minecraft:mossy_stone_bricks
setblock ~-73 ~9 ~-164 minecraft:mossy_stone_bricks
setblock ~-73 ~11 ~-167 minecraft:mossy_stone_bricks
setblock ~-73 ~12 ~-26 minecraft:mossy_stone_bricks
setblock ~-73 ~14 ~-25 minecraft:mossy_stone_bricks
fill ~-73 ~15 ~-155 ~-73 ~16 ~-155 minecraft:mossy_stone_bricks
fill ~-73 ~16 ~-156 ~-73 ~16 ~-154 minecraft:mossy_stone_bricks
setblock ~-73 ~17 ~-166 minecraft:mossy_stone_bricks
fill ~-73 ~19 ~-154 ~-73 ~20 ~-154 minecraft:mossy_stone_bricks
setblock ~-73 ~20 ~-165 minecraft:mossy_stone_bricks
setblock ~-73 ~20 ~-37 minecraft:mossy_stone_bricks
fill ~-73 ~22 ~-153 ~-73 ~23 ~-153 minecraft:mossy_stone_bricks
setblock ~-73 ~22 ~-38 minecraft:mossy_stone_bricks
setblock ~-73 ~23 ~-164 minecraft:mossy_stone_bricks
setblock ~-73 ~23 ~-26 minecraft:mossy_stone_bricks
fill ~-73 ~26 ~-36 ~-73 ~27 ~-36 minecraft:mossy_stone_bricks
fill ~-73 ~27 ~-167 ~-73 ~27 ~-166 minecraft:mossy_stone_bricks
setblock ~-73 ~27 ~-25 minecraft:mossy_stone_bricks
fill ~-73 ~28 ~-156 ~-73 ~29 ~-156 minecraft:mossy_stone_bricks
setblock ~-73 ~30 ~-160 minecraft:mossy_stone_bricks
setblock ~-72 ~3 ~-40 minecraft:mossy_stone_bricks
setblock ~-72 ~4 ~-38 minecraft:mossy_stone_bricks
setblock ~-72 ~8 ~-24 minecraft:mossy_stone_bricks
setblock ~-72 ~9 ~-166 minecraft:mossy_stone_bricks
setblock ~-72 ~9 ~-38 minecraft:mossy_stone_bricks
setblock ~-72 ~11 ~-166 minecraft:mossy_stone_bricks
setblock ~-72 ~11 ~-26 minecraft:mossy_stone_bricks
setblock ~-72 ~13 ~-154 minecraft:mossy_stone_bricks
setblock ~-72 ~15 ~-38 minecraft:mossy_stone_bricks
setblock ~-72 ~16 ~-168 minecraft:mossy_stone_bricks
setblock ~-72 ~20 ~-24 minecraft:mossy_stone_bricks
setblock ~-72 ~21 ~-154 minecraft:mossy_stone_bricks
setblock ~-72 ~22 ~-168 minecraft:mossy_stone_bricks
setblock ~-72 ~22 ~-26 minecraft:mossy_stone_bricks
setblock ~-72 ~23 ~-166 minecraft:mossy_stone_bricks
setblock ~-72 ~30 ~-151 minecraft:mossy_stone_bricks
setblock ~-71 ~ ~-167 minecraft:mossy_stone_bricks
fill ~-71 ~4 ~-167 ~-71 ~5 ~-167 minecraft:mossy_stone_bricks
setblock ~-71 ~4 ~-95 minecraft:mossy_stone_bricks
setblock ~-71 ~5 ~-41 minecraft:mossy_stone_bricks
setblock ~-71 ~7 ~-39 minecraft:mossy_stone_bricks
setblock ~-71 ~9 ~-98 minecraft:mossy_stone_bricks
fill ~-71 ~10 ~-94 ~-70 ~10 ~-94 minecraft:mossy_stone_bricks
setblock ~-71 ~10 ~-39 minecraft:mossy_stone_bricks
setblock ~-71 ~14 ~-153 minecraft:mossy_stone_bricks
setblock ~-71 ~15 ~-98 minecraft:mossy_stone_bricks
setblock ~-71 ~16 ~-151 minecraft:mossy_stone_bricks
setblock ~-71 ~19 ~-96 minecraft:mossy_stone_bricks
setblock ~-71 ~22 ~-151 minecraft:mossy_stone_bricks
setblock ~-71 ~23 ~-167 minecraft:mossy_stone_bricks
fill ~-71 ~23 ~-97 ~-71 ~24 ~-96 minecraft:mossy_stone_bricks
fill ~-71 ~28 ~-169 ~-70 ~28 ~-169 minecraft:mossy_stone_bricks
setblock ~-71 ~28 ~-153 minecraft:mossy_stone_bricks
setblock ~-71 ~29 ~-167 minecraft:mossy_stone_bricks
setblock ~-71 ~30 ~-161 minecraft:mossy_stone_bricks
setblock ~-70 ~1 ~-168 minecraft:mossy_stone_bricks
fill ~-70 ~1 ~-98 ~-70 ~1 ~-97 minecraft:mossy_stone_bricks
fill ~-70 ~3 ~-152 ~-70 ~3 ~-151 minecraft:mossy_stone_bricks
fill ~-70 ~3 ~-100 ~-70 ~3 ~-99 minecraft:mossy_stone_bricks
fill ~-70 ~6 ~-97 ~-70 ~6 ~-96 minecraft:mossy_stone_bricks
setblock ~-70 ~8 ~-95 minecraft:mossy_stone_bricks
setblock ~-70 ~9 ~-152 minecraft:mossy_stone_bricks
fill ~-70 ~10 ~-98 ~-70 ~10 ~-97 minecraft:mossy_stone_bricks
fill ~-70 ~10 ~-95 ~-70 ~10 ~-94 minecraft:mossy_stone_bricks
setblock ~-70 ~11 ~-23 minecraft:mossy_stone_bricks
setblock ~-70 ~12 ~-99 minecraft:mossy_stone_bricks
fill ~-70 ~14 ~-99 ~-69 ~14 ~-99 minecraft:mossy_stone_bricks
setblock ~-70 ~14 ~-23 minecraft:mossy_stone_bricks
setblock ~-70 ~16 ~-94 minecraft:mossy_stone_bricks
fill ~-70 ~17 ~-41 ~-70 ~17 ~-40 minecraft:mossy_stone_bricks
setblock ~-70 ~18 ~-169 minecraft:mossy_stone_bricks
setblock ~-70 ~18 ~-93 minecraft:mossy_stone_bricks
fill ~-70 ~21 ~-92 ~-70 ~22 ~-92 minecraft:mossy_stone_bricks
setblock ~-70 ~22 ~-23 minecraft:mossy_stone_bricks
setblock ~-70 ~23 ~-169 minecraft:mossy_stone_bricks
fill ~-70 ~23 ~-95 ~-70 ~24 ~-95 minecraft:mossy_stone_bricks
fill ~-70 ~23 ~-41 ~-70 ~24 ~-41 minecraft:mossy_stone_bricks
setblock ~-70 ~25 ~-96 minecraft:mossy_stone_bricks
setblock ~-70 ~27 ~-40 minecraft:mossy_stone_bricks
setblock ~-70 ~28 ~-90 minecraft:mossy_stone_bricks
setblock ~-70 ~30 ~-164 minecraft:mossy_stone_bricks
setblock ~-70 ~30 ~-27 minecraft:mossy_stone_bricks
setblock ~-69 ~ ~-23 minecraft:mossy_stone_bricks
setblock ~-69 ~5 ~-42 minecraft:mossy_stone_bricks
setblock ~-69 ~7 ~-101 minecraft:mossy_stone_bricks
setblock ~-69 ~8 ~-169 minecraft:mossy_stone_bricks
setblock ~-69 ~8 ~-91 minecraft:mossy_stone_bricks
setblock ~-69 ~10 ~-151 minecraft:mossy_stone_bricks
setblock ~-69 ~10 ~-22 minecraft:mossy_stone_bricks
setblock ~-69 ~11 ~-170 minecraft:mossy_stone_bricks
setblock ~-69 ~11 ~-91 minecraft:mossy_stone_bricks
setblock ~-69 ~11 ~-42 minecraft:mossy_stone_bricks
setblock ~-69 ~12 ~-93 minecraft:mossy_stone_bricks
fill ~-69 ~13 ~-42 ~-69 ~14 ~-42 minecraft:mossy_stone_bricks
setblock ~-69 ~14 ~-22 minecraft:mossy_stone_bricks
setblock ~-69 ~17 ~-170 minecraft:mossy_stone_bricks
setblock ~-69 ~19 ~-151 minecraft:mossy_stone_bricks
setblock ~-69 ~20 ~-170 minecraft:mossy_stone_bricks
setblock ~-69 ~20 ~-101 minecraft:mossy_stone_bricks
setblock ~-69 ~20 ~-42 minecraft:mossy_stone_bricks
fill ~-69 ~21 ~-23 ~-69 ~21 ~-22 minecraft:mossy_stone_bricks
setblock ~-69 ~23 ~-151 minecraft:mossy_stone_bricks
setblock ~-69 ~25 ~-23 minecraft:mossy_stone_bricks
fill ~-69 ~26 ~-150 ~-69 ~28 ~-150 minecraft:mossy_stone_bricks
fill ~-69 ~26 ~-90 ~-68 ~26 ~-90 minecraft:mossy_stone_bricks
setblock ~-69 ~26 ~-41 minecraft:mossy_stone_bricks
setblock ~-69 ~27 ~-169 minecraft:mossy_stone_bricks
setblock ~-69 ~30 ~-159 minecraft:mossy_stone_bricks
setblock ~-69 ~30 ~-156 minecraft:mossy_stone_bricks
setblock ~-69 ~30 ~-39 minecraft:mossy_stone_bricks
fill ~-69 ~30 ~-24 ~-68 ~30 ~-24 minecraft:mossy_stone_bricks
setblock ~-68 ~4 ~-150 minecraft:mossy_stone_bricks
fill ~-68 ~4 ~-23 ~-68 ~5 ~-23 minecraft:mossy_stone_bricks
setblock ~-68 ~6 ~-92 minecraft:mossy_stone_bricks
setblock ~-68 ~11 ~-41 minecraft:mossy_stone_bricks
fill ~-68 ~12 ~-102 ~-68 ~13 ~-102 minecraft:mossy_stone_bricks
setblock ~-68 ~12 ~-92 minecraft:mossy_stone_bricks
setblock ~-68 ~15 ~-23 minecraft:mossy_stone_bricks
setblock ~-68 ~16 ~-170 minecraft:mossy_stone_bricks
setblock ~-68 ~17 ~-150 minecraft:mossy_stone_bricks
fill ~-68 ~17 ~-102 ~-67 ~17 ~-102 minecraft:mossy_stone_bricks
setblock ~-68 ~21 ~-92 minecraft:mossy_stone_bricks
setblock ~-68 ~23 ~-102 minecraft:mossy_stone_bricks
fill ~-68 ~25 ~-42 ~-68 ~25 ~-41 minecraft:mossy_stone_bricks
setblock ~-68 ~26 ~-23 minecraft:mossy_stone_bricks
fill ~-68 ~27 ~-22 ~-66 ~27 ~-22 minecraft:mossy_stone_bricks
setblock ~-68 ~30 ~-168 minecraft:mossy_stone_bricks
setblock ~-67 ~2 ~-42 minecraft:mossy_stone_bricks
fill ~-67 ~5 ~-91 ~-67 ~6 ~-91 minecraft:mossy_stone_bricks
setblock ~-67 ~5 ~-42 minecraft:mossy_stone_bricks
setblock ~-67 ~10 ~-90 minecraft:mossy_stone_bricks
fill ~-67 ~13 ~-149 ~-67 ~14 ~-149 minecraft:mossy_stone_bricks
setblock ~-67 ~14 ~-91 minecraft:mossy_stone_bricks
setblock ~-67 ~15 ~-170 minecraft:mossy_stone_bricks
setblock ~-67 ~15 ~-102 minecraft:mossy_stone_bricks
fill ~-67 ~16 ~-90 ~-67 ~17 ~-90 minecraft:mossy_stone_bricks
setblock ~-67 ~16 ~-43 minecraft:mossy_stone_bricks
fill ~-67 ~17 ~-91 ~-67 ~17 ~-90 minecraft:mossy_stone_bricks
setblock ~-67 ~18 ~-171 minecraft:mossy_stone_bricks
fill ~-67 ~19 ~-90 ~-67 ~20 ~-90 minecraft:mossy_stone_bricks
setblock ~-67 ~22 ~-22 minecraft:mossy_stone_bricks
setblock ~-67 ~24 ~-90 minecraft:mossy_stone_bricks
fill ~-67 ~26 ~-100 ~-67 ~26 ~-99 minecraft:mossy_stone_bricks
fill ~-67 ~26 ~-89 ~-66 ~26 ~-89 minecraft:mossy_stone_bricks
setblock ~-67 ~26 ~-21 minecraft:mossy_stone_bricks
setblock ~-67 ~30 ~-166 minecraft:mossy_stone_bricks
setblock ~-67 ~30 ~-44 minecraft:mossy_stone_bricks
fill ~-66 ~3 ~-21 ~-65 ~3 ~-21 minecraft:mossy_stone_bricks
setblock ~-66 ~4 ~-21 minecraft:mossy_stone_bricks
setblock ~-66 ~8 ~-171 minecraft:mossy_stone_bricks
setblock ~-66 ~9 ~-150 minecraft:mossy_stone_bricks
setblock ~-66 ~9 ~-42 minecraft:mossy_stone_bricks
setblock ~-66 ~12 ~-103 minecraft:mossy_stone_bricks
setblock ~-66 ~14 ~-22 minecraft:mossy_stone_bricks
setblock ~-66 ~15 ~-90 minecraft:mossy_stone_bricks
setblock ~-66 ~15 ~-43 minecraft:mossy_stone_bricks
setblock ~-66 ~16 ~-102 minecraft:mossy_stone_bricks
setblock ~-66 ~17 ~-149 minecraft:mossy_stone_bricks
setblock ~-66 ~18 ~-89 minecraft:mossy_stone_bricks
setblock ~-66 ~19 ~-149 minecraft:mossy_stone_bricks
setblock ~-66 ~26 ~-88 minecraft:mossy_stone_bricks
setblock ~-66 ~30 ~-26 minecraft:mossy_stone_bricks
setblock ~-65 ~1 ~-102 minecraft:mossy_stone_bricks
setblock ~-65 ~4 ~-170 minecraft:mossy_stone_bricks
setblock ~-65 ~4 ~-89 minecraft:mossy_stone_bricks
setblock ~-65 ~5 ~-102 minecraft:mossy_stone_bricks
setblock ~-65 ~5 ~-21 minecraft:mossy_stone_bricks
fill ~-65 ~6 ~-103 ~-65 ~7 ~-103 minecraft:mossy_stone_bricks
setblock ~-65 ~8 ~-43 minecraft:mossy_stone_bricks
setblock ~-65 ~10 ~-43 minecraft:mossy_stone_bricks
setblock ~-65 ~15 ~-150 minecraft:mossy_stone_bricks
fill ~-65 ~17 ~-148 ~-65 ~18 ~-148 minecraft:mossy_stone_bricks
setblock ~-65 ~17 ~-118 minecraft:mossy_stone_bricks
setblock ~-65 ~17 ~-116 minecraft:mossy_stone_bricks
fill ~-65 ~17 ~-87 ~-65 ~17 ~-86 minecraft:mossy_stone_bricks
setblock ~-65 ~17 ~-82 minecraft:mossy_stone_bricks
setblock ~-65 ~17 ~-78 minecraft:mossy_stone_bricks
setblock ~-65 ~17 ~-76 minecraft:mossy_stone_bricks
setblock ~-65 ~17 ~-42 minecraft:mossy_stone_bricks
setblock ~-65 ~17 ~-21 minecraft:mossy_stone_bricks
fill ~-65 ~18 ~-130 ~-64 ~18 ~-130 minecraft:mossy_stone_bricks
setblock ~-65 ~18 ~-67 minecraft:mossy_stone_bricks
fill ~-65 ~19 ~-170 ~-65 ~20 ~-170 minecraft:mossy_stone_bricks
setblock ~-65 ~19 ~-126 minecraft:mossy_stone_bricks
setblock ~-65 ~19 ~-123 minecraft:mossy_stone_bricks
setblock ~-65 ~19 ~-118 minecraft:mossy_stone_bricks
setblock ~-65 ~19 ~-59 minecraft:mossy_stone_bricks
setblock ~-65 ~19 ~-56 minecraft:mossy_stone_bricks
setblock ~-65 ~19 ~-52 minecraft:mossy_stone_bricks
setblock ~-65 ~20 ~-125 minecraft:mossy_stone_bricks
fill ~-65 ~20 ~-71 ~-65 ~21 ~-71 minecraft:mossy_stone_bricks
setblock ~-65 ~22 ~-149 minecraft:mossy_stone_bricks
setblock ~-65 ~22 ~-22 minecraft:mossy_stone_bricks
fill ~-65 ~25 ~-150 ~-65 ~25 ~-149 minecraft:mossy_stone_bricks
setblock ~-65 ~30 ~-33 minecraft:mossy_stone_bricks
setblock ~-65 ~30 ~-31 minecraft:mossy_stone_bricks
setblock ~-65 ~31 ~-44 minecraft:mossy_stone_bricks
fill ~-64 ~3 ~-84 ~-64 ~4 ~-84 minecraft:mossy_stone_bricks
setblock ~-64 ~3 ~-73 minecraft:mossy_stone_bricks
fill ~-64 ~3 ~-71 ~-64 ~4 ~-71 minecraft:mossy_stone_bricks
setblock ~-64 ~4 ~-137 minecraft:mossy_stone_bricks
setblock ~-64 ~4 ~-129 minecraft:mossy_stone_bricks
setblock ~-64 ~4 ~-124 minecraft:mossy_stone_bricks
setblock ~-64 ~4 ~-88 minecraft:mossy_stone_bricks
setblock ~-64 ~4 ~-48 minecraft:mossy_stone_bricks
setblock ~-64 ~4 ~-45 minecraft:mossy_stone_bricks
setblock ~-64 ~5 ~-150 minecraft:mossy_stone_bricks
setblock ~-64 ~5 ~-147 minecraft:mossy_stone_bricks
fill ~-64 ~5 ~-127 ~-64 ~5 ~-126 minecraft:mossy_stone_bricks
fill ~-64 ~5 ~-60 ~-64 ~5 ~-59 minecraft:mossy_stone_bricks
setblock ~-64 ~5 ~-50 minecraft:mossy_stone_bricks
setblock ~-64 ~6 ~-171 minecraft:mossy_stone_bricks
setblock ~-64 ~6 ~-145 minecraft:mossy_stone_bricks
setblock ~-64 ~6 ~-126 minecraft:mossy_stone_bricks
setblock ~-64 ~6 ~-120 minecraft:mossy_stone_bricks
setblock ~-64 ~6 ~-110 minecraft:mossy_stone_bricks
setblock ~-64 ~7 ~-135 minecraft:mossy_stone_bricks
setblock ~-64 ~7 ~-115 minecraft:mossy_stone_bricks
setblock ~-64 ~7 ~-109 minecraft:mossy_stone_bricks
setblock ~-64 ~7 ~-88 minecraft:mossy_stone_bricks
setblock ~-64 ~8 ~-148 minecraft:mossy_stone_bricks
setblock ~-64 ~8 ~-102 minecraft:mossy_stone_bricks
setblock ~-64 ~8 ~-54 minecraft:mossy_stone_bricks
setblock ~-64 ~8 ~-51 minecraft:mossy_stone_bricks
setblock ~-64 ~9 ~-120 minecraft:mossy_stone_bricks
setblock ~-64 ~9 ~-105 minecraft:mossy_stone_bricks
setblock ~-64 ~9 ~-73 minecraft:mossy_stone_bricks
fill ~-64 ~9 ~-61 ~-64 ~10 ~-61 minecraft:mossy_stone_bricks
setblock ~-64 ~9 ~-55 minecraft:mossy_stone_bricks
setblock ~-64 ~9 ~-44 minecraft:mossy_stone_bricks
setblock ~-64 ~10 ~-150 minecraft:mossy_stone_bricks
fill ~-64 ~10 ~-119 ~-64 ~10 ~-118 minecraft:mossy_stone_bricks
setblock ~-64 ~10 ~-86 minecraft:mossy_stone_bricks
fill ~-64 ~10 ~-83 ~-64 ~10 ~-82 minecraft:mossy_stone_bricks
setblock ~-64 ~10 ~-71 minecraft:mossy_stone_bricks
setblock ~-64 ~10 ~-69 minecraft:mossy_stone_bricks
setblock ~-64 ~10 ~-42 minecraft:mossy_stone_bricks
setblock ~-64 ~10 ~-21 minecraft:mossy_stone_bricks
setblock ~-64 ~11 ~-143 minecraft:mossy_stone_bricks
setblock ~-64 ~11 ~-135 minecraft:mossy_stone_bricks
setblock ~-64 ~11 ~-123 minecraft:mossy_stone_bricks
fill ~-64 ~11 ~-110 ~-64 ~12 ~-110 minecraft:mossy_stone_bricks
setblock ~-64 ~11 ~-104 minecraft:mossy_stone_bricks
setblock ~-64 ~11 ~-80 minecraft:mossy_stone_bricks
fill ~-64 ~11 ~-68 ~-64 ~12 ~-68 minecraft:mossy_stone_bricks
setblock ~-64 ~11 ~-66 minecraft:mossy_stone_bricks
setblock ~-64 ~11 ~-58 minecraft:mossy_stone_bricks
setblock ~-64 ~11 ~-44 minecraft:mossy_stone_bricks
setblock ~-64 ~12 ~-127 minecraft:mossy_stone_bricks
setblock ~-64 ~12 ~-71 minecraft:mossy_stone_bricks
fill ~-64 ~13 ~-145 ~-64 ~14 ~-145 minecraft:mossy_stone_bricks
setblock ~-64 ~13 ~-140 minecraft:mossy_stone_bricks
fill ~-64 ~13 ~-137 ~-64 ~13 ~-136 minecraft:mossy_stone_bricks
setblock ~-64 ~13 ~-111 minecraft:mossy_stone_bricks
setblock ~-64 ~13 ~-108 minecraft:mossy_stone_bricks
setblock ~-64 ~13 ~-85 minecraft:mossy_stone_bricks
setblock ~-64 ~13 ~-79 minecraft:mossy_stone_bricks
fill ~-64 ~13 ~-75 ~-64 ~14 ~-75 minecraft:mossy_stone_bricks
setblock ~-64 ~13 ~-54 minecraft:mossy_stone_bricks
setblock ~-64 ~13 ~-48 minecraft:mossy_stone_bricks
fill ~-64 ~14 ~-121 ~-64 ~14 ~-118 minecraft:mossy_stone_bricks
setblock ~-64 ~14 ~-116 minecraft:mossy_stone_bricks
setblock ~-64 ~14 ~-102 minecraft:mossy_stone_bricks
setblock ~-64 ~14 ~-69 minecraft:mossy_stone_bricks
setblock ~-64 ~14 ~-67 minecraft:mossy_stone_bricks
setblock ~-64 ~14 ~-62 minecraft:mossy_stone_bricks
setblock ~-64 ~14 ~-58 minecraft:mossy_stone_bricks
fill ~-64 ~14 ~-42 ~-64 ~15 ~-42 minecraft:mossy_stone_bricks
setblock ~-64 ~15 ~-57 minecraft:mossy_stone_bricks
setblock ~-64 ~15 ~-44 minecraft:mossy_stone_bricks
setblock ~-64 ~18 ~-145 minecraft:mossy_stone_bricks
setblock ~-64 ~18 ~-143 minecraft:mossy_stone_bricks
setblock ~-64 ~18 ~-141 minecraft:mossy_stone_bricks
setblock ~-64 ~18 ~-129 minecraft:mossy_stone_bricks
setblock ~-64 ~18 ~-116 minecraft:mossy_stone_bricks
setblock ~-64 ~18 ~-110 minecraft:mossy_stone_bricks
setblock ~-64 ~18 ~-87 minecraft:mossy_stone_bricks
setblock ~-64 ~18 ~-73 minecraft:mossy_stone_bricks
setblock ~-64 ~18 ~-68 minecraft:mossy_stone_bricks
fill ~-64 ~18 ~-51 ~-61 ~18 ~-51 minecraft:mossy_stone_bricks
fill ~-64 ~18 ~-42 ~-62 ~18 ~-42 minecraft:mossy_stone_bricks
fill ~-64 ~22 ~-171 ~-64 ~23 ~-171 minecraft:mossy_stone_bricks
setblock ~-64 ~23 ~-150 minecraft:mossy_stone_bricks
setblock ~-64 ~23 ~-43 minecraft:mossy_stone_bricks
setblock ~-64 ~26 ~-150 minecraft:mossy_stone_bricks
setblock ~-64 ~26 ~-95 minecraft:mossy_stone_bricks
setblock ~-64 ~26 ~-89 minecraft:mossy_stone_bricks
fill ~-64 ~28 ~-43 ~-64 ~28 ~-42 minecraft:mossy_stone_bricks
fill ~-63 ~3 ~-42 ~-62 ~3 ~-42 minecraft:mossy_stone_bricks
setblock ~-63 ~4 ~-21 minecraft:mossy_stone_bricks
setblock ~-63 ~6 ~-140 minecraft:mossy_stone_bricks
setblock ~-63 ~6 ~-52 minecraft:mossy_stone_bricks
setblock ~-63 ~12 ~-90 minecraft:mossy_stone_bricks
setblock ~-63 ~16 ~-42 minecraft:mossy_stone_bricks
setblock ~-63 ~18 ~-149 minecraft:mossy_stone_bricks
fill ~-63 ~18 ~-136 ~-63 ~18 ~-135 minecraft:mossy_stone_bricks
setblock ~-63 ~18 ~-125 minecraft:mossy_stone_bricks
setblock ~-63 ~18 ~-121 minecraft:mossy_stone_bricks
setblock ~-63 ~18 ~-119 minecraft:mossy_stone_bricks
setblock ~-63 ~18 ~-117 minecraft:mossy_stone_bricks
setblock ~-63 ~18 ~-104 minecraft:mossy_stone_bricks
setblock ~-63 ~18 ~-102 minecraft:mossy_stone_bricks
fill ~-63 ~18 ~-61 ~-62 ~18 ~-61 minecraft:mossy_stone_bricks
setblock ~-63 ~19 ~-21 minecraft:mossy_stone_bricks
setblock ~-63 ~22 ~-149 minecraft:mossy_stone_bricks
fill ~-63 ~22 ~-90 ~-63 ~23 ~-90 minecraft:mossy_stone_bricks
setblock ~-63 ~23 ~-171 minecraft:mossy_stone_bricks
setblock ~-63 ~23 ~-22 minecraft:mossy_stone_bricks
setblock ~-63 ~25 ~-149 minecraft:mossy_stone_bricks
fill ~-63 ~26 ~-104 ~-63 ~26 ~-103 minecraft:mossy_stone_bricks
setblock ~-63 ~26 ~-98 minecraft:mossy_stone_bricks
setblock ~-63 ~29 ~-150 minecraft:mossy_stone_bricks
setblock ~-63 ~30 ~-153 minecraft:mossy_stone_bricks
setblock ~-63 ~30 ~-41 minecraft:mossy_stone_bricks
setblock ~-63 ~30 ~-21 minecraft:mossy_stone_bricks
setblock ~-62 ~ ~-102 minecraft:mossy_stone_bricks
setblock ~-62 ~1 ~-22 minecraft:mossy_stone_bricks
setblock ~-62 ~2 ~-102 minecraft:mossy_stone_bricks
fill ~-62 ~4 ~-102 ~-62 ~5 ~-102 minecraft:mossy_stone_bricks
setblock ~-62 ~10 ~-21 minecraft:mossy_stone_bricks
setblock ~-62 ~11 ~-150 minecraft:mossy_stone_bricks
setblock ~-62 ~11 ~-102 minecraft:mossy_stone_bricks
setblock ~-62 ~14 ~-171 minecraft:mossy_stone_bricks
setblock ~-62 ~16 ~-102 minecraft:mossy_stone_bricks
setblock ~-62 ~18 ~-142 minecraft:mossy_stone_bricks
setblock ~-62 ~18 ~-126 minecraft:mossy_stone_bricks
setblock ~-62 ~18 ~-120 minecraft:mossy_stone_bricks
setblock ~-62 ~18 ~-103 minecraft:mossy_stone_bricks
fill ~-62 ~18 ~-76 ~-61 ~18 ~-76 minecraft:mossy_stone_bricks
setblock ~-62 ~18 ~-57 minecraft:mossy_stone_bricks
fill ~-62 ~22 ~-42 ~-62 ~23 ~-42 minecraft:mossy_stone_bricks
setblock ~-62 ~23 ~-89 minecraft:mossy_stone_bricks
setblock ~-62 ~25 ~-21 minecraft:mossy_stone_bricks
setblock ~-62 ~26 ~-101 minecraft:mossy_stone_bricks
setblock ~-62 ~26 ~-42 minecraft:mossy_stone_bricks
setblock ~-62 ~30 ~-167 minecraft:mossy_stone_bricks
fill ~-62 ~30 ~-162 ~-61 ~30 ~-162 minecraft:mossy_stone_bricks
setblock ~-62 ~30 ~-161 minecraft:mossy_stone_bricks
setblock ~-62 ~30 ~-38 minecraft:mossy_stone_bricks
setblock ~-62 ~30 ~-30 minecraft:mossy_stone_bricks
setblock ~-62 ~30 ~-23 minecraft:mossy_stone_bricks
setblock ~-61 ~2 ~-91 minecraft:mossy_stone_bricks
fill ~-61 ~4 ~-170 ~-60 ~4 ~-170 minecraft:mossy_stone_bricks
setblock ~-61 ~9 ~-150 minecraft:mossy_stone_bricks
setblock ~-61 ~13 ~-101 minecraft:mossy_stone_bricks
fill ~-61 ~15 ~-170 ~-61 ~16 ~-170 minecraft:mossy_stone_bricks
setblock ~-61 ~15 ~-21 minecraft:mossy_stone_bricks
setblock ~-61 ~18 ~-89 minecraft:mossy_stone_bricks
setblock ~-61 ~18 ~-71 minecraft:mossy_stone_bricks
setblock ~-61 ~18 ~-68 minecraft:mossy_stone_bricks
fill ~-61 ~18 ~-55 ~-60 ~18 ~-55 minecraft:mossy_stone_bricks
setblock ~-61 ~22 ~-90 minecraft:mossy_stone_bricks
fill ~-61 ~23 ~-102 ~-61 ~24 ~-102 minecraft:mossy_stone_bricks
setblock ~-61 ~23 ~-42 minecraft:mossy_stone_bricks
setblock ~-61 ~25 ~-171 minecraft:mossy_stone_bricks
fill ~-61 ~26 ~-98 ~-60 ~26 ~-98 minecraft:mossy_stone_bricks
fill ~-61 ~26 ~-97 ~-61 ~26 ~-96 minecraft:mossy_stone_bricks
setblock ~-61 ~26 ~-94 minecraft:mossy_stone_bricks
setblock ~-61 ~26 ~-92 minecraft:mossy_stone_bricks
setblock ~-61 ~30 ~-166 minecraft:mossy_stone_bricks
setblock ~-61 ~30 ~-164 minecraft:mossy_stone_bricks
fill ~-61 ~30 ~-160 ~-60 ~30 ~-160 minecraft:mossy_stone_bricks
setblock ~-61 ~30 ~-35 minecraft:mossy_stone_bricks
setblock ~-61 ~30 ~-32 minecraft:mossy_stone_bricks
setblock ~-61 ~30 ~-25 minecraft:mossy_stone_bricks
setblock ~-61 ~31 ~-148 minecraft:mossy_stone_bricks
setblock ~-61 ~31 ~-20 minecraft:mossy_stone_bricks
setblock ~-60 ~ ~-144 minecraft:mossy_stone_bricks
setblock ~-60 ~ ~-132 minecraft:mossy_stone_bricks
setblock ~-60 ~ ~-129 minecraft:mossy_stone_bricks
setblock ~-60 ~ ~-87 minecraft:mossy_stone_bricks
fill ~-60 ~ ~-78 ~-60 ~ ~-77 minecraft:mossy_stone_bricks
setblock ~-60 ~ ~-57 minecraft:mossy_stone_bricks
setblock ~-60 ~ ~-55 minecraft:mossy_stone_bricks
setblock ~-60 ~ ~-53 minecraft:mossy_stone_bricks
setblock ~-60 ~1 ~-116 minecraft:mossy_stone_bricks
fill ~-60 ~1 ~-112 ~-60 ~1 ~-111 minecraft:mossy_stone_bricks
setblock ~-60 ~1 ~-82 minecraft:mossy_stone_bricks
fill ~-60 ~1 ~-76 ~-60 ~2 ~-76 minecraft:mossy_stone_bricks
setblock ~-60 ~2 ~-145 minecraft:mossy_stone_bricks
fill ~-60 ~2 ~-140 ~-60 ~2 ~-139 minecraft:mossy_stone_bricks
setblock ~-60 ~2 ~-130 minecraft:mossy_stone_bricks
setblock ~-60 ~2 ~-73 minecraft:mossy_stone_bricks
fill ~-60 ~2 ~-68 ~-60 ~3 ~-68 minecraft:mossy_stone_bricks
setblock ~-60 ~3 ~-129 minecraft:mossy_stone_bricks
setblock ~-60 ~3 ~-127 minecraft:mossy_stone_bricks
setblock ~-60 ~3 ~-105 minecraft:mossy_stone_bricks
setblock ~-60 ~3 ~-102 minecraft:mossy_stone_bricks
setblock ~-60 ~3 ~-85 minecraft:mossy_stone_bricks
setblock ~-60 ~3 ~-46 minecraft:mossy_stone_bricks
setblock ~-60 ~4 ~-143 minecraft:mossy_stone_bricks
setblock ~-60 ~4 ~-140 minecraft:mossy_stone_bricks
setblock ~-60 ~4 ~-134 minecraft:mossy_stone_bricks
setblock ~-60 ~4 ~-122 minecraft:mossy_stone_bricks
setblock ~-60 ~4 ~-90 minecraft:mossy_stone_bricks
setblock ~-60 ~4 ~-88 minecraft:mossy_stone_bricks
setblock ~-60 ~4 ~-45 minecraft:mossy_stone_bricks
fill ~-60 ~4 ~-41 ~-60 ~5 ~-41 minecraft:mossy_stone_bricks
fill ~-60 ~5 ~-169 ~-59 ~5 ~-169 minecraft:mossy_stone_bricks
setblock ~-60 ~5 ~-112 minecraft:mossy_stone_bricks
setblock ~-60 ~5 ~-108 minecraft:mossy_stone_bricks
setblock ~-60 ~5 ~-82 minecraft:mossy_stone_bricks
setblock ~-60 ~5 ~-71 minecraft:mossy_stone_bricks
setblock ~-60 ~5 ~-55 minecraft:mossy_stone_bricks
setblock ~-60 ~5 ~-47 minecraft:mossy_stone_bricks
fill ~-60 ~5 ~-44 ~-60 ~6 ~-44 minecraft:mossy_stone_bricks
setblock ~-60 ~6 ~-120 minecraft:mossy_stone_bricks
fill ~-60 ~6 ~-115 ~-60 ~7 ~-115 minecraft:mossy_stone_bricks
setblock ~-60 ~6 ~-86 minecraft:mossy_stone_bricks
setblock ~-60 ~6 ~-72 minecraft:mossy_stone_bricks
setblock ~-60 ~7 ~-129 minecraft:mossy_stone_bricks
setblock ~-60 ~7 ~-123 minecraft:mossy_stone_bricks
fill ~-60 ~7 ~-107 ~-60 ~8 ~-107 minecraft:mossy_stone_bricks
setblock ~-60 ~7 ~-102 minecraft:mossy_stone_bricks
setblock ~-60 ~7 ~-74 minecraft:mossy_stone_bricks
setblock ~-60 ~7 ~-65 minecraft:mossy_stone_bricks
setblock ~-60 ~7 ~-57 minecraft:mossy_stone_bricks
setblock ~-60 ~7 ~-23 minecraft:mossy_stone_bricks
setblock ~-60 ~8 ~-121 minecraft:mossy_stone_bricks
fill ~-60 ~8 ~-108 ~-60 ~8 ~-107 minecraft:mossy_stone_bricks
setblock ~-60 ~8 ~-105 minecraft:mossy_stone_bricks
setblock ~-60 ~8 ~-73 minecraft:mossy_stone_bricks
setblock ~-60 ~8 ~-58 minecraft:mossy_stone_bricks
fill ~-60 ~8 ~-54 ~-60 ~9 ~-54 minecraft:mossy_stone_bricks
fill ~-60 ~8 ~-50 ~-60 ~8 ~-49 minecraft:mossy_stone_bricks
setblock ~-60 ~8 ~-43 minecraft:mossy_stone_bricks
setblock ~-60 ~9 ~-124 minecraft:mossy_stone_bricks
fill ~-60 ~9 ~-55 ~-60 ~9 ~-54 minecraft:mossy_stone_bricks
setblock ~-60 ~10 ~-125 minecraft:mossy_stone_bricks
setblock ~-60 ~10 ~-111 minecraft:mossy_stone_bricks
setblock ~-60 ~10 ~-104 minecraft:mossy_stone_bricks
fill ~-60 ~10 ~-88 ~-60 ~11 ~-88 minecraft:mossy_stone_bricks
fill ~-60 ~10 ~-80 ~-60 ~11 ~-80 minecraft:mossy_stone_bricks
setblock ~-60 ~10 ~-72 minecraft:mossy_stone_bricks
setblock ~-60 ~10 ~-62 minecraft:mossy_stone_bricks
setblock ~-60 ~10 ~-43 minecraft:mossy_stone_bricks
setblock ~-60 ~11 ~-136 minecraft:mossy_stone_bricks
setblock ~-60 ~11 ~-123 minecraft:mossy_stone_bricks
fill ~-60 ~11 ~-113 ~-60 ~11 ~-112 minecraft:mossy_stone_bricks
setblock ~-60 ~11 ~-100 minecraft:mossy_stone_bricks
setblock ~-60 ~11 ~-78 minecraft:mossy_stone_bricks
setblock ~-60 ~11 ~-73 minecraft:mossy_stone_bricks
setblock ~-60 ~11 ~-47 minecraft:mossy_stone_bricks
fill ~-60 ~12 ~-139 ~-60 ~12 ~-138 minecraft:mossy_stone_bricks
setblock ~-60 ~12 ~-121 minecraft:mossy_stone_bricks
fill ~-60 ~12 ~-114 ~-60 ~13 ~-114 minecraft:mossy_stone_bricks
setblock ~-60 ~12 ~-107 minecraft:mossy_stone_bricks
setblock ~-60 ~12 ~-89 minecraft:mossy_stone_bricks
setblock ~-60 ~12 ~-79 minecraft:mossy_stone_bricks
setblock ~-60 ~12 ~-77 minecraft:mossy_stone_bricks
setblock ~-60 ~12 ~-56 minecraft:mossy_stone_bricks
setblock ~-60 ~12 ~-46 minecraft:mossy_stone_bricks
setblock ~-60 ~13 ~-170 minecraft:mossy_stone_bricks
setblock ~-60 ~13 ~-147 minecraft:mossy_stone_bricks
setblock ~-60 ~13 ~-141 minecraft:mossy_stone_bricks
setblock ~-60 ~13 ~-138 minecraft:mossy_stone_bricks
fill ~-60 ~13 ~-136 ~-60 ~14 ~-136 minecraft:mossy_stone_bricks
setblock ~-60 ~13 ~-111 minecraft:mossy_stone_bricks
setblock ~-60 ~13 ~-87 minecraft:mossy_stone_bricks
setblock ~-60 ~13 ~-80 minecraft:mossy_stone_bricks
setblock ~-60 ~13 ~-73 minecraft:mossy_stone_bricks
setblock ~-60 ~13 ~-70 minecraft:mossy_stone_bricks
setblock ~-60 ~14 ~-140 minecraft:mossy_stone_bricks
fill ~-60 ~14 ~-109 ~-60 ~14 ~-108 minecraft:mossy_stone_bricks
setblock ~-60 ~14 ~-92 minecraft:mossy_stone_bricks
setblock ~-60 ~14 ~-64 minecraft:mossy_stone_bricks
fill ~-60 ~14 ~-61 ~-60 ~14 ~-60 minecraft:mossy_stone_bricks
setblock ~-60 ~15 ~-144 minecraft:mossy_stone_bricks
setblock ~-60 ~15 ~-124 minecraft:mossy_stone_bricks
setblock ~-60 ~15 ~-118 minecraft:mossy_stone_bricks
setblock ~-60 ~15 ~-109 minecraft:mossy_stone_bricks
setblock ~-60 ~15 ~-106 minecraft:mossy_stone_bricks
setblock ~-60 ~15 ~-103 minecraft:mossy_stone_bricks
setblock ~-60 ~15 ~-44 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-146 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-133 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-131 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-114 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-111 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-87 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-76 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-71 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-43 minecraft:mossy_stone_bricks
setblock ~-60 ~16 ~-22 minecraft:mossy_stone_bricks
setblock ~-60 ~17 ~-140 minecraft:mossy_stone_bricks
setblock ~-60 ~17 ~-129 minecraft:mossy_stone_bricks
setblock ~-60 ~17 ~-119 minecraft:mossy_stone_bricks
setblock ~-60 ~17 ~-103 minecraft:mossy_stone_bricks
setblock ~-60 ~17 ~-63 minecraft:mossy_stone_bricks
setblock ~-60 ~17 ~-54 minecraft:mossy_stone_bricks
fill ~-60 ~17 ~-49 ~-60 ~19 ~-49 minecraft:mossy_stone_bricks
fill ~-60 ~17 ~-46 ~-60 ~19 ~-46 minecraft:mossy_stone_bricks
fill ~-60 ~18 ~-148 ~-60 ~19 ~-148 minecraft:mossy_stone_bricks
fill ~-60 ~18 ~-125 ~-60 ~19 ~-125 minecraft:mossy_stone_bricks
fill ~-60 ~18 ~-120 ~-60 ~19 ~-120 minecraft:mossy_stone_bricks
setblock ~-60 ~18 ~-92 minecraft:mossy_stone_bricks
fill ~-60 ~18 ~-82 ~-60 ~19 ~-81 minecraft:mossy_stone_bricks
fill ~-60 ~20 ~-23 ~-60 ~20 ~-22 minecraft:mossy_stone_bricks
fill ~-60 ~21 ~-23 ~-60 ~22 ~-23 minecraft:mossy_stone_bricks
setblock ~-60 ~23 ~-169 minecraft:mossy_stone_bricks
setblock ~-60 ~24 ~-170 minecraft:mossy_stone_bricks
fill ~-60 ~24 ~-22 ~-59 ~24 ~-22 minecraft:mossy_stone_bricks
fill ~-60 ~28 ~-169 ~-58 ~28 ~-169 minecraft:mossy_stone_bricks
setblock ~-60 ~29 ~-169 minecraft:mossy_stone_bricks
fill ~-60 ~30 ~-157 ~-59 ~30 ~-157 minecraft:mossy_stone_bricks
setblock ~-59 ~3 ~-93 minecraft:mossy_stone_bricks
setblock ~-59 ~3 ~-42 minecraft:mossy_stone_bricks
setblock ~-59 ~6 ~-42 minecraft:mossy_stone_bricks
setblock ~-59 ~8 ~-91 minecraft:mossy_stone_bricks
fill ~-59 ~8 ~-23 ~-59 ~8 ~-22 minecraft:mossy_stone_bricks
setblock ~-59 ~9 ~-151 minecraft:mossy_stone_bricks
setblock ~-59 ~12 ~-91 minecraft:mossy_stone_bricks
setblock ~-59 ~14 ~-93 minecraft:mossy_stone_bricks
setblock ~-59 ~16 ~-169 minecraft:mossy_stone_bricks
setblock ~-59 ~16 ~-93 minecraft:mossy_stone_bricks
setblock ~-59 ~19 ~-150 minecraft:mossy_stone_bricks
setblock ~-59 ~19 ~-92 minecraft:mossy_stone_bricks
setblock ~-59 ~19 ~-41 minecraft:mossy_stone_bricks
fill ~-59 ~20 ~-99 ~-59 ~22 ~-99 minecraft:mossy_stone_bricks
setblock ~-59 ~21 ~-170 minecraft:mossy_stone_bricks
fill ~-59 ~23 ~-93 ~-59 ~24 ~-93 minecraft:mossy_stone_bricks
setblock ~-59 ~23 ~-41 minecraft:mossy_stone_bricks
setblock ~-59 ~23 ~-23 minecraft:mossy_stone_bricks
fill ~-59 ~25 ~-41 ~-59 ~27 ~-41 minecraft:mossy_stone_bricks
setblock ~-59 ~26 ~-23 minecraft:mossy_stone_bricks
setblock ~-59 ~30 ~-166 minecraft:mossy_stone_bricks
fill ~-59 ~30 ~-42 ~-58 ~30 ~-42 minecraft:mossy_stone_bricks
setblock ~-59 ~30 ~-33 minecraft:mossy_stone_bricks
fill ~-59 ~30 ~-31 ~-59 ~30 ~-30 minecraft:mossy_stone_bricks
setblock ~-59 ~30 ~-25 minecraft:mossy_stone_bricks
fill ~-58 ~3 ~-169 ~-58 ~4 ~-169 minecraft:mossy_stone_bricks
setblock ~-58 ~3 ~-41 minecraft:mossy_stone_bricks
setblock ~-58 ~3 ~-24 minecraft:mossy_stone_bricks
setblock ~-58 ~6 ~-151 minecraft:mossy_stone_bricks
setblock ~-58 ~6 ~-100 minecraft:mossy_stone_bricks
fill ~-58 ~7 ~-97 ~-58 ~7 ~-96 minecraft:mossy_stone_bricks
fill ~-58 ~7 ~-41 ~-58 ~10 ~-41 minecraft:mossy_stone_bricks
setblock ~-58 ~9 ~-152 minecraft:mossy_stone_bricks
setblock ~-58 ~9 ~-99 minecraft:mossy_stone_bricks
fill ~-58 ~9 ~-93 ~-58 ~11 ~-93 minecraft:mossy_stone_bricks
fill ~-58 ~10 ~-96 ~-58 ~11 ~-96 minecraft:mossy_stone_bricks
fill ~-58 ~11 ~-92 ~-58 ~12 ~-92 minecraft:mossy_stone_bricks
setblock ~-58 ~13 ~-151 minecraft:mossy_stone_bricks
setblock ~-58 ~15 ~-97 minecraft:mossy_stone_bricks
setblock ~-58 ~18 ~-92 minecraft:mossy_stone_bricks
setblock ~-58 ~21 ~-100 minecraft:mossy_stone_bricks
setblock ~-58 ~24 ~-169 minecraft:mossy_stone_bricks
setblock ~-58 ~24 ~-95 minecraft:mossy_stone_bricks
setblock ~-58 ~26 ~-97 minecraft:mossy_stone_bricks
setblock ~-58 ~26 ~-41 minecraft:mossy_stone_bricks
setblock ~-58 ~28 ~-41 minecraft:mossy_stone_bricks
setblock ~-58 ~29 ~-152 minecraft:mossy_stone_bricks
setblock ~-58 ~29 ~-40 minecraft:mossy_stone_bricks
setblock ~-58 ~30 ~-160 minecraft:mossy_stone_bricks
fill ~-57 ~1 ~-151 ~-57 ~1 ~-150 minecraft:mossy_stone_bricks
setblock ~-57 ~3 ~-152 minecraft:mossy_stone_bricks
setblock ~-57 ~3 ~-98 minecraft:mossy_stone_bricks
setblock ~-57 ~8 ~-25 minecraft:mossy_stone_bricks
setblock ~-57 ~10 ~-169 minecraft:mossy_stone_bricks
setblock ~-57 ~10 ~-97 minecraft:mossy_stone_bricks
setblock ~-57 ~10 ~-23 minecraft:mossy_stone_bricks
setblock ~-57 ~11 ~-153 minecraft:mossy_stone_bricks
fill ~-57 ~12 ~-97 ~-57 ~13 ~-97 minecraft:mossy_stone_bricks
setblock ~-57 ~13 ~-39 minecraft:mossy_stone_bricks
setblock ~-57 ~15 ~-23 minecraft:mossy_stone_bricks
setblock ~-57 ~17 ~-23 minecraft:mossy_stone_bricks
fill ~-57 ~18 ~-151 ~-57 ~19 ~-151 minecraft:mossy_stone_bricks
setblock ~-57 ~20 ~-95 minecraft:mossy_stone_bricks
setblock ~-57 ~20 ~-41 minecraft:mossy_stone_bricks
setblock ~-57 ~21 ~-167 minecraft:mossy_stone_bricks
setblock ~-57 ~26 ~-94 minecraft:mossy_stone_bricks
setblock ~-57 ~27 ~-41 minecraft:mossy_stone_bricks
setblock ~-57 ~28 ~-151 minecraft:mossy_stone_bricks
setblock ~-57 ~30 ~-166 minecraft:mossy_stone_bricks
fill ~-56 ~3 ~-154 ~-56 ~4 ~-154 minecraft:mossy_stone_bricks
setblock ~-56 ~6 ~-40 minecraft:mossy_stone_bricks
setblock ~-56 ~7 ~-152 minecraft:mossy_stone_bricks
setblock ~-56 ~11 ~-166 minecraft:mossy_stone_bricks
setblock ~-56 ~11 ~-24 minecraft:mossy_stone_bricks
setblock ~-56 ~13 ~-152 minecraft:mossy_stone_bricks
fill ~-56 ~13 ~-26 ~-56 ~14 ~-26 minecraft:mossy_stone_bricks
fill ~-56 ~15 ~-154 ~-56 ~16 ~-154 minecraft:mossy_stone_bricks
setblock ~-56 ~17 ~-166 minecraft:mossy_stone_bricks
setblock ~-56 ~20 ~-168 minecraft:mossy_stone_bricks
setblock ~-56 ~21 ~-154 minecraft:mossy_stone_bricks
setblock ~-56 ~23 ~-24 minecraft:mossy_stone_bricks
fill ~-56 ~24 ~-40 ~-56 ~25 ~-40 minecraft:mossy_stone_bricks
fill ~-56 ~28 ~-166 ~-55 ~28 ~-166 minecraft:mossy_stone_bricks
setblock ~-56 ~30 ~-169 minecraft:mossy_stone_bricks
setblock ~-56 ~30 ~-160 minecraft:mossy_stone_bricks
setblock ~-56 ~30 ~-152 minecraft:mossy_stone_bricks
setblock ~-55 ~3 ~-39 minecraft:mossy_stone_bricks
setblock ~-55 ~4 ~-156 minecraft:mossy_stone_bricks
setblock ~-55 ~5 ~-36 minecraft:mossy_stone_bricks
setblock ~-55 ~6 ~-167 minecraft:mossy_stone_bricks
setblock ~-55 ~6 ~-38 minecraft:mossy_stone_bricks
setblock ~-55 ~8 ~-37 minecraft:mossy_stone_bricks
setblock ~-55 ~10 ~-156 minecraft:mossy_stone_bricks
setblock ~-55 ~10 ~-153 minecraft:mossy_stone_bricks
fill ~-55 ~10 ~-37 ~-55 ~10 ~-36 minecraft:mossy_stone_bricks
setblock ~-55 ~11 ~-165 minecraft:mossy_stone_bricks
setblock ~-55 ~12 ~-154 minecraft:mossy_stone_bricks
setblock ~-55 ~15 ~-37 minecraft:mossy_stone_bricks
setblock ~-55 ~15 ~-25 minecraft:mossy_stone_bricks
setblock ~-55 ~16 ~-39 minecraft:mossy_stone_bricks
setblock ~-55 ~19 ~-27 minecraft:mossy_stone_bricks
setblock ~-55 ~20 ~-165 minecraft:mossy_stone_bricks
fill ~-55 ~20 ~-37 ~-54 ~20 ~-37 minecraft:mossy_stone_bricks
setblock ~-55 ~23 ~-28 minecraft:mossy_stone_bricks
setblock ~-55 ~24 ~-153 minecraft:mossy_stone_bricks
setblock ~-55 ~25 ~-167 minecraft:mossy_stone_bricks
setblock ~-55 ~26 ~-166 minecraft:mossy_stone_bricks
fill ~-55 ~26 ~-36 ~-55 ~27 ~-36 minecraft:mossy_stone_bricks
fill ~-55 ~28 ~-167 ~-55 ~28 ~-166 minecraft:mossy_stone_bricks
fill ~-55 ~28 ~-28 ~-54 ~28 ~-28 minecraft:mossy_stone_bricks
setblock ~-55 ~29 ~-36 minecraft:mossy_stone_bricks
setblock ~-55 ~30 ~-32 minecraft:mossy_stone_bricks
setblock ~-54 ~ ~-157 minecraft:mossy_stone_bricks
setblock ~-54 ~1 ~-162 minecraft:mossy_stone_bricks
setblock ~-54 ~1 ~-137 minecraft:mossy_stone_bricks
setblock ~-54 ~2 ~-159 minecraft:mossy_stone_bricks
setblock ~-54 ~2 ~-157 minecraft:mossy_stone_bricks
setblock ~-54 ~2 ~-135 minecraft:mossy_stone_bricks
fill ~-54 ~3 ~-121 ~-54 ~3 ~-120 minecraft:mossy_stone_bricks
setblock ~-54 ~3 ~-32 minecraft:mossy_stone_bricks
setblock ~-54 ~3 ~-28 minecraft:mossy_stone_bricks
setblock ~-54 ~4 ~-163 minecraft:mossy_stone_bricks
setblock ~-54 ~4 ~-31 minecraft:mossy_stone_bricks
fill ~-54 ~6 ~-129 ~-54 ~7 ~-129 minecraft:mossy_stone_bricks
fill ~-54 ~7 ~-161 ~-53 ~7 ~-161 minecraft:mossy_stone_bricks
setblock ~-54 ~7 ~-29 minecraft:mossy_stone_bricks
setblock ~-54 ~9 ~-159 minecraft:mossy_stone_bricks
setblock ~-54 ~9 ~-35 minecraft:mossy_stone_bricks
fill ~-54 ~10 ~-164 ~-54 ~10 ~-163 minecraft:mossy_stone_bricks
setblock ~-54 ~10 ~-157 minecraft:mossy_stone_bricks
setblock ~-54 ~10 ~-32 minecraft:mossy_stone_bricks
fill ~-54 ~13 ~-158 ~-54 ~14 ~-158 minecraft:mossy_stone_bricks
setblock ~-54 ~13 ~-28 minecraft:mossy_stone_bricks
setblock ~-54 ~14 ~-161 minecraft:mossy_stone_bricks
setblock ~-54 ~15 ~-164 minecraft:mossy_stone_bricks
setblock ~-54 ~15 ~-159 minecraft:mossy_stone_bricks
setblock ~-54 ~16 ~-162 minecraft:mossy_stone_bricks
fill ~-54 ~16 ~-35 ~-54 ~17 ~-35 minecraft:mossy_stone_bricks
setblock ~-54 ~18 ~-160 minecraft:mossy_stone_bricks
setblock ~-54 ~18 ~-155 minecraft:mossy_stone_bricks
fill ~-54 ~21 ~-161 ~-53 ~21 ~-161 minecraft:mossy_stone_bricks
fill ~-54 ~21 ~-159 ~-54 ~21 ~-158 minecraft:mossy_stone_bricks
setblock ~-54 ~21 ~-30 minecraft:mossy_stone_bricks
setblock ~-54 ~23 ~-161 minecraft:mossy_stone_bricks
setblock ~-54 ~23 ~-31 minecraft:mossy_stone_bricks
setblock ~-54 ~24 ~-28 minecraft:mossy_stone_bricks
fill ~-54 ~25 ~-164 ~-54 ~25 ~-163 minecraft:mossy_stone_bricks
setblock ~-54 ~25 ~-158 minecraft:mossy_stone_bricks
setblock ~-54 ~25 ~-36 minecraft:mossy_stone_bricks
fill ~-54 ~25 ~-30 ~-53 ~25 ~-30 minecraft:mossy_stone_bricks
setblock ~-54 ~26 ~-163 minecraft:mossy_stone_bricks
setblock ~-54 ~26 ~-33 minecraft:mossy_stone_bricks
setblock ~-54 ~26 ~-30 minecraft:mossy_stone_bricks
setblock ~-54 ~27 ~-159 minecraft:mossy_stone_bricks
setblock ~-54 ~28 ~-37 minecraft:mossy_stone_bricks
fill ~-54 ~28 ~-29 ~-54 ~28 ~-28 minecraft:mossy_stone_bricks
setblock ~-54 ~30 ~-25 minecraft:mossy_stone_bricks
fill ~-54 ~31 ~-26 ~-54 ~32 ~-26 minecraft:mossy_stone_bricks
setblock ~-53 ~4 ~-156 minecraft:mossy_stone_bricks
fill ~-53 ~5 ~-162 ~-53 ~5 ~-161 minecraft:mossy_stone_bricks
setblock ~-53 ~5 ~-30 minecraft:mossy_stone_bricks
setblock ~-53 ~6 ~-163 minecraft:mossy_stone_bricks
setblock ~-53 ~6 ~-156 minecraft:mossy_stone_bricks
fill ~-53 ~6 ~-138 ~-52 ~6 ~-138 minecraft:mossy_stone_bricks
setblock ~-53 ~8 ~-163 minecraft:mossy_stone_bricks
fill ~-53 ~11 ~-31 ~-53 ~12 ~-31 minecraft:mossy_stone_bricks
setblock ~-53 ~15 ~-163 minecraft:mossy_stone_bricks
setblock ~-53 ~15 ~-31 minecraft:mossy_stone_bricks
setblock ~-53 ~17 ~-162 minecraft:mossy_stone_bricks
setblock ~-53 ~17 ~-156 minecraft:mossy_stone_bricks
fill ~-53 ~22 ~-160 ~-53 ~23 ~-160 minecraft:mossy_stone_bricks
setblock ~-53 ~22 ~-35 minecraft:mossy_stone_bricks
setblock ~-53 ~22 ~-32 minecraft:mossy_stone_bricks
fill ~-53 ~22 ~-30 ~-53 ~22 ~-29 minecraft:mossy_stone_bricks
setblock ~-53 ~25 ~-33 minecraft:mossy_stone_bricks
setblock ~-53 ~30 ~-162 minecraft:mossy_stone_bricks
setblock ~-52 ~3 ~-156 minecraft:mossy_stone_bricks
setblock ~-52 ~10 ~-160 minecraft:mossy_stone_bricks
setblock ~-52 ~12 ~-156 minecraft:mossy_stone_bricks
setblock ~-52 ~14 ~-160 minecraft:mossy_stone_bricks
fill ~-52 ~18 ~-31 ~-52 ~19 ~-31 minecraft:mossy_stone_bricks
setblock ~-52 ~30 ~-157 minecraft:mossy_stone_bricks
fill ~-52 ~30 ~-29 ~-52 ~31 ~-29 minecraft:mossy_stone_bricks
setblock ~-52 ~31 ~-158 minecraft:mossy_stone_bricks
setblock ~-51 ~3 ~-36 minecraft:mossy_stone_bricks
setblock ~-51 ~5 ~-156 minecraft:mossy_stone_bricks
setblock ~-51 ~7 ~-160 minecraft:mossy_stone_bricks
setblock ~-51 ~8 ~-36 minecraft:mossy_stone_bricks
setblock ~-51 ~13 ~-156 minecraft:mossy_stone_bricks
setblock ~-51 ~18 ~-158 minecraft:mossy_stone_bricks
setblock ~-50 ~13 ~-160 minecraft:mossy_stone_bricks
setblock ~-50 ~17 ~-36 minecraft:mossy_stone_bricks
fill ~-50 ~18 ~-35 ~-49 ~18 ~-35 minecraft:mossy_stone_bricks
fill ~-49 ~1 ~-120 ~-49 ~3 ~-120 minecraft:mossy_stone_bricks
setblock ~-49 ~2 ~-36 minecraft:mossy_stone_bricks
setblock ~-49 ~4 ~-160 minecraft:mossy_stone_bricks
setblock ~-49 ~6 ~-32 minecraft:mossy_stone_bricks
setblock ~-49 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~-49 ~12 ~-156 minecraft:mossy_stone_bricks
setblock ~-49 ~15 ~-32 minecraft:mossy_stone_bricks
fill ~-49 ~18 ~-158 ~-48 ~18 ~-158 minecraft:mossy_stone_bricks
setblock ~-48 ~3 ~-160 minecraft:mossy_stone_bricks
fill ~-48 ~4 ~-138 ~-48 ~6 ~-138 minecraft:mossy_stone_bricks
setblock ~-48 ~13 ~-156 minecraft:mossy_stone_bricks
setblock ~-48 ~14 ~-32 minecraft:mossy_stone_bricks
setblock ~-48 ~18 ~-34 minecraft:mossy_stone_bricks
fill ~-47 ~3 ~-138 ~-46 ~3 ~-138 minecraft:mossy_stone_bricks
fill ~-47 ~4 ~-156 ~-47 ~5 ~-156 minecraft:mossy_stone_bricks
setblock ~-47 ~5 ~-160 minecraft:mossy_stone_bricks
fill ~-47 ~5 ~-138 ~-46 ~5 ~-138 minecraft:mossy_stone_bricks
setblock ~-47 ~7 ~-120 minecraft:mossy_stone_bricks
fill ~-47 ~8 ~-160 ~-46 ~8 ~-160 minecraft:mossy_stone_bricks
setblock ~-47 ~9 ~-36 minecraft:mossy_stone_bricks
setblock ~-47 ~10 ~-156 minecraft:mossy_stone_bricks
fill ~-47 ~17 ~-31 ~-47 ~18 ~-31 minecraft:mossy_stone_bricks
setblock ~-46 ~9 ~-32 minecraft:mossy_stone_bricks
setblock ~-46 ~12 ~-156 minecraft:mossy_stone_bricks
setblock ~-45 ~3 ~-36 minecraft:mossy_stone_bricks
setblock ~-45 ~7 ~-160 minecraft:mossy_stone_bricks
setblock ~-45 ~18 ~-32 minecraft:mossy_stone_bricks
fill ~-45 ~19 ~-31 ~-45 ~20 ~-31 minecraft:mossy_stone_bricks
fill ~-44 ~3 ~-138 ~-43 ~3 ~-138 minecraft:mossy_stone_bricks
fill ~-44 ~3 ~-120 ~-43 ~3 ~-120 minecraft:mossy_stone_bricks
fill ~-44 ~4 ~-138 ~-44 ~5 ~-138 minecraft:mossy_stone_bricks
fill ~-44 ~6 ~-120 ~-43 ~6 ~-120 minecraft:mossy_stone_bricks
fill ~-44 ~9 ~-156 ~-44 ~11 ~-156 minecraft:mossy_stone_bricks
setblock ~-44 ~14 ~-36 minecraft:mossy_stone_bricks
fill ~-44 ~16 ~-156 ~-44 ~17 ~-156 minecraft:mossy_stone_bricks
setblock ~-43 ~5 ~-156 minecraft:mossy_stone_bricks
setblock ~-43 ~8 ~-32 minecraft:mossy_stone_bricks
fill ~-43 ~17 ~-36 ~-43 ~19 ~-36 minecraft:mossy_stone_bricks
fill ~-43 ~18 ~-156 ~-43 ~19 ~-156 minecraft:mossy_stone_bricks
fill ~-43 ~18 ~-31 ~-42 ~18 ~-31 minecraft:mossy_stone_bricks
setblock ~-42 ~2 ~-156 minecraft:mossy_stone_bricks
setblock ~-42 ~4 ~-156 minecraft:mossy_stone_bricks
setblock ~-42 ~7 ~-32 minecraft:mossy_stone_bricks
setblock ~-42 ~11 ~-32 minecraft:mossy_stone_bricks
fill ~-42 ~13 ~-156 ~-41 ~13 ~-156 minecraft:mossy_stone_bricks
fill ~-42 ~15 ~-156 ~-42 ~16 ~-156 minecraft:mossy_stone_bricks
setblock ~-42 ~16 ~-36 minecraft:mossy_stone_bricks
setblock ~-42 ~18 ~-161 minecraft:mossy_stone_bricks
fill ~-41 ~3 ~-120 ~-40 ~3 ~-120 minecraft:mossy_stone_bricks
fill ~-41 ~5 ~-120 ~-40 ~5 ~-120 minecraft:mossy_stone_bricks
fill ~-41 ~6 ~-138 ~-41 ~7 ~-138 minecraft:mossy_stone_bricks
setblock ~-41 ~12 ~-160 minecraft:mossy_stone_bricks
fill ~-41 ~17 ~-36 ~-41 ~19 ~-36 minecraft:mossy_stone_bricks
setblock ~-41 ~18 ~-159 minecraft:mossy_stone_bricks
setblock ~-41 ~20 ~-161 minecraft:mossy_stone_bricks
setblock ~-40 ~4 ~-160 minecraft:mossy_stone_bricks
setblock ~-40 ~7 ~-138 minecraft:mossy_stone_bricks
setblock ~-40 ~7 ~-120 minecraft:mossy_stone_bricks
setblock ~-40 ~7 ~-32 minecraft:mossy_stone_bricks
setblock ~-40 ~12 ~-36 minecraft:mossy_stone_bricks
setblock ~-40 ~15 ~-160 minecraft:mossy_stone_bricks
fill ~-40 ~18 ~-156 ~-40 ~19 ~-156 minecraft:mossy_stone_bricks
setblock ~-40 ~19 ~-161 minecraft:mossy_stone_bricks
setblock ~-39 ~5 ~-32 minecraft:mossy_stone_bricks
setblock ~-39 ~8 ~-36 minecraft:mossy_stone_bricks
setblock ~-39 ~10 ~-156 minecraft:mossy_stone_bricks
setblock ~-39 ~18 ~-158 minecraft:mossy_stone_bricks
fill ~-38 ~ ~-156 ~-37 ~ ~-156 minecraft:mossy_stone_bricks
setblock ~-38 ~1 ~-138 minecraft:mossy_stone_bricks
setblock ~-38 ~3 ~-160 minecraft:mossy_stone_bricks
setblock ~-38 ~8 ~-160 minecraft:mossy_stone_bricks
setblock ~-38 ~12 ~-32 minecraft:mossy_stone_bricks
setblock ~-38 ~18 ~-159 minecraft:mossy_stone_bricks
setblock ~-37 ~4 ~-32 minecraft:mossy_stone_bricks
setblock ~-37 ~6 ~-156 minecraft:mossy_stone_bricks
fill ~-37 ~13 ~-160 ~-37 ~14 ~-160 minecraft:mossy_stone_bricks
fill ~-37 ~18 ~-161 ~-37 ~19 ~-161 minecraft:mossy_stone_bricks
fill ~-37 ~18 ~-158 ~-37 ~18 ~-157 minecraft:mossy_stone_bricks
setblock ~-37 ~18 ~-35 minecraft:mossy_stone_bricks
setblock ~-36 ~1 ~-137 minecraft:mossy_stone_bricks
setblock ~-36 ~1 ~-131 minecraft:mossy_stone_bricks
setblock ~-36 ~1 ~-122 minecraft:mossy_stone_bricks
fill ~-36 ~3 ~-160 ~-36 ~4 ~-160 minecraft:mossy_stone_bricks
fill ~-36 ~3 ~-129 ~-36 ~4 ~-129 minecraft:mossy_stone_bricks
fill ~-36 ~3 ~-125 ~-36 ~3 ~-124 minecraft:mossy_stone_bricks
setblock ~-36 ~4 ~-36 minecraft:mossy_stone_bricks
setblock ~-36 ~5 ~-126 minecraft:mossy_stone_bricks
setblock ~-36 ~5 ~-32 minecraft:mossy_stone_bricks
setblock ~-36 ~7 ~-122 minecraft:mossy_stone_bricks
fill ~-36 ~7 ~-36 ~-36 ~8 ~-36 minecraft:mossy_stone_bricks
setblock ~-36 ~7 ~-33 minecraft:mossy_stone_bricks
setblock ~-36 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~-36 ~11 ~-160 minecraft:mossy_stone_bricks
setblock ~-36 ~15 ~-32 minecraft:mossy_stone_bricks
setblock ~-35 ~ ~-36 minecraft:mossy_stone_bricks
setblock ~-35 ~6 ~-32 minecraft:mossy_stone_bricks
setblock ~-35 ~10 ~-160 minecraft:mossy_stone_bricks
setblock ~-35 ~10 ~-32 minecraft:mossy_stone_bricks
setblock ~-35 ~11 ~-156 minecraft:mossy_stone_bricks
fill ~-35 ~12 ~-160 ~-35 ~13 ~-160 minecraft:mossy_stone_bricks
setblock ~-35 ~14 ~-36 minecraft:mossy_stone_bricks
fill ~-35 ~18 ~-156 ~-35 ~19 ~-156 minecraft:mossy_stone_bricks
setblock ~-34 ~4 ~-32 minecraft:mossy_stone_bricks
setblock ~-34 ~5 ~-156 minecraft:mossy_stone_bricks
setblock ~-34 ~7 ~-36 minecraft:mossy_stone_bricks
setblock ~-34 ~11 ~-32 minecraft:mossy_stone_bricks
setblock ~-34 ~17 ~-156 minecraft:mossy_stone_bricks
setblock ~-34 ~18 ~-158 minecraft:mossy_stone_bricks
setblock ~-33 ~ ~-36 minecraft:mossy_stone_bricks
setblock ~-33 ~6 ~-160 minecraft:mossy_stone_bricks
fill ~-33 ~10 ~-36 ~-33 ~12 ~-36 minecraft:mossy_stone_bricks
fill ~-33 ~12 ~-160 ~-32 ~12 ~-160 minecraft:mossy_stone_bricks
setblock ~-33 ~13 ~-160 minecraft:mossy_stone_bricks
setblock ~-33 ~15 ~-32 minecraft:mossy_stone_bricks
setblock ~-32 ~4 ~-144 minecraft:mossy_stone_bricks
setblock ~-32 ~6 ~-145 minecraft:mossy_stone_bricks
setblock ~-32 ~6 ~-101 minecraft:mossy_stone_bricks
fill ~-32 ~7 ~-103 ~-32 ~8 ~-103 minecraft:mossy_stone_bricks
setblock ~-32 ~8 ~-147 minecraft:mossy_stone_bricks
setblock ~-32 ~8 ~-101 minecraft:mossy_stone_bricks
fill ~-32 ~10 ~-147 ~-32 ~10 ~-146 minecraft:mossy_stone_bricks
setblock ~-32 ~12 ~-102 minecraft:mossy_stone_bricks
setblock ~-32 ~13 ~-146 minecraft:mossy_stone_bricks
setblock ~-32 ~13 ~-104 minecraft:mossy_stone_bricks
setblock ~-32 ~13 ~-37 minecraft:mossy_stone_bricks
fill ~-32 ~15 ~-160 ~-31 ~15 ~-160 minecraft:mossy_stone_bricks
setblock ~-32 ~15 ~-148 minecraft:mossy_stone_bricks
fill ~-32 ~16 ~-156 ~-32 ~19 ~-156 minecraft:mossy_stone_bricks
setblock ~-32 ~16 ~-145 minecraft:mossy_stone_bricks
setblock ~-32 ~16 ~-37 minecraft:mossy_stone_bricks
setblock ~-32 ~17 ~-103 minecraft:mossy_stone_bricks
setblock ~-32 ~17 ~-100 minecraft:mossy_stone_bricks
setblock ~-32 ~18 ~-102 minecraft:mossy_stone_bricks
setblock ~-32 ~23 ~-148 minecraft:mossy_stone_bricks
setblock ~-32 ~24 ~-104 minecraft:mossy_stone_bricks
setblock ~-32 ~27 ~-148 minecraft:mossy_stone_bricks
setblock ~-32 ~27 ~-104 minecraft:mossy_stone_bricks
setblock ~-32 ~27 ~-102 minecraft:mossy_stone_bricks
fill ~-32 ~32 ~-146 ~-32 ~32 ~-145 minecraft:mossy_stone_bricks
setblock ~-32 ~33 ~-100 minecraft:mossy_stone_bricks
setblock ~-32 ~34 ~-147 minecraft:mossy_stone_bricks
fill ~-32 ~37 ~-104 ~-32 ~38 ~-104 minecraft:mossy_stone_bricks
fill ~-32 ~38 ~-145 ~-32 ~39 ~-145 minecraft:mossy_stone_bricks
setblock ~-32 ~39 ~-148 minecraft:mossy_stone_bricks
setblock ~-32 ~39 ~-100 minecraft:mossy_stone_bricks
setblock ~-32 ~40 ~-144 minecraft:mossy_stone_bricks
setblock ~-32 ~42 ~-145 minecraft:mossy_stone_bricks
fill ~-32 ~44 ~-144 ~-32 ~45 ~-144 minecraft:mossy_stone_bricks
setblock ~-32 ~45 ~-102 minecraft:mossy_stone_bricks
setblock ~-32 ~46 ~-145 minecraft:mossy_stone_bricks
setblock ~-32 ~49 ~-100 minecraft:mossy_stone_bricks
setblock ~-32 ~50 ~-104 minecraft:mossy_stone_bricks
setblock ~-32 ~52 ~-145 minecraft:mossy_stone_bricks
fill ~-32 ~53 ~-99 ~-30 ~53 ~-99 minecraft:mossy_stone_bricks
setblock ~-31 ~3 ~-150 minecraft:mossy_stone_bricks
fill ~-31 ~4 ~-105 ~-31 ~5 ~-105 minecraft:mossy_stone_bricks
setblock ~-31 ~4 ~-32 minecraft:mossy_stone_bricks
setblock ~-31 ~7 ~-149 minecraft:mossy_stone_bricks
setblock ~-31 ~8 ~-160 minecraft:mossy_stone_bricks
setblock ~-31 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~-31 ~10 ~-98 minecraft:mossy_stone_bricks
setblock ~-31 ~10 ~-32 minecraft:mossy_stone_bricks
setblock ~-31 ~11 ~-160 minecraft:mossy_stone_bricks
setblock ~-31 ~11 ~-38 minecraft:mossy_stone_bricks
setblock ~-31 ~12 ~-106 minecraft:mossy_stone_bricks
fill ~-31 ~13 ~-160 ~-30 ~13 ~-160 minecraft:mossy_stone_bricks
setblock ~-31 ~13 ~-143 minecraft:mossy_stone_bricks
setblock ~-31 ~13 ~-32 minecraft:mossy_stone_bricks
setblock ~-31 ~14 ~-150 minecraft:mossy_stone_bricks
setblock ~-31 ~15 ~-156 minecraft:mossy_stone_bricks
setblock ~-31 ~15 ~-149 minecraft:mossy_stone_bricks
setblock ~-31 ~15 ~-38 minecraft:mossy_stone_bricks
setblock ~-31 ~16 ~-106 minecraft:mossy_stone_bricks
setblock ~-31 ~16 ~-99 minecraft:mossy_stone_bricks
fill ~-31 ~17 ~-150 ~-31 ~18 ~-150 minecraft:mossy_stone_bricks
setblock ~-31 ~18 ~-161 minecraft:mossy_stone_bricks
fill ~-31 ~18 ~-99 ~-31 ~18 ~-98 minecraft:mossy_stone_bricks
setblock ~-31 ~20 ~-98 minecraft:mossy_stone_bricks
setblock ~-31 ~31 ~-99 minecraft:mossy_stone_bricks
fill ~-31 ~34 ~-142 ~-31 ~35 ~-142 minecraft:mossy_stone_bricks
fill ~-31 ~34 ~-106 ~-31 ~35 ~-106 minecraft:mossy_stone_bricks
setblock ~-31 ~40 ~-150 minecraft:mossy_stone_bricks
setblock ~-31 ~42 ~-106 minecraft:mossy_stone_bricks
setblock ~-31 ~43 ~-149 minecraft:mossy_stone_bricks
setblock ~-31 ~45 ~-106 minecraft:mossy_stone_bricks
setblock ~-31 ~47 ~-149 minecraft:mossy_stone_bricks
setblock ~-31 ~47 ~-98 minecraft:mossy_stone_bricks
setblock ~-31 ~49 ~-142 minecraft:mossy_stone_bricks
setblock ~-31 ~52 ~-150 minecraft:mossy_stone_bricks
fill ~-31 ~52 ~-107 ~-31 ~53 ~-107 minecraft:mossy_stone_bricks
fill ~-30 ~3 ~-141 ~-29 ~3 ~-141 minecraft:mossy_stone_bricks
setblock ~-30 ~3 ~-32 minecraft:mossy_stone_bricks
setblock ~-30 ~9 ~-160 minecraft:mossy_stone_bricks
fill ~-30 ~12 ~-32 ~-28 ~12 ~-32 minecraft:mossy_stone_bricks
setblock ~-30 ~17 ~-161 minecraft:mossy_stone_bricks
setblock ~-30 ~17 ~-36 minecraft:mossy_stone_bricks
setblock ~-30 ~18 ~-158 minecraft:mossy_stone_bricks
setblock ~-30 ~22 ~-97 minecraft:mossy_stone_bricks
fill ~-30 ~23 ~-141 ~-30 ~24 ~-141 minecraft:mossy_stone_bricks
setblock ~-30 ~25 ~-97 minecraft:mossy_stone_bricks
setblock ~-30 ~28 ~-107 minecraft:mossy_stone_bricks
setblock ~-30 ~32 ~-151 minecraft:mossy_stone_bricks
setblock ~-30 ~37 ~-151 minecraft:mossy_stone_bricks
setblock ~-30 ~38 ~-141 minecraft:mossy_stone_bricks
fill ~-30 ~39 ~-97 ~-30 ~40 ~-97 minecraft:mossy_stone_bricks
setblock ~-30 ~43 ~-107 minecraft:mossy_stone_bricks
setblock ~-30 ~49 ~-151 minecraft:mossy_stone_bricks
setblock ~-30 ~49 ~-141 minecraft:mossy_stone_bricks
setblock ~-30 ~49 ~-107 minecraft:mossy_stone_bricks
setblock ~-30 ~52 ~-141 minecraft:mossy_stone_bricks
setblock ~-30 ~52 ~-103 minecraft:mossy_stone_bricks
setblock ~-29 ~ ~-156 minecraft:mossy_stone_bricks
fill ~-29 ~3 ~-156 ~-28 ~3 ~-156 minecraft:mossy_stone_bricks
fill ~-29 ~3 ~-151 ~-29 ~4 ~-151 minecraft:mossy_stone_bricks
setblock ~-29 ~7 ~-97 minecraft:mossy_stone_bricks
fill ~-29 ~7 ~-38 ~-29 ~8 ~-38 minecraft:mossy_stone_bricks
setblock ~-29 ~10 ~-32 minecraft:mossy_stone_bricks
fill ~-29 ~11 ~-141 ~-29 ~12 ~-141 minecraft:mossy_stone_bricks
setblock ~-29 ~13 ~-32 minecraft:mossy_stone_bricks
setblock ~-29 ~19 ~-31 minecraft:mossy_stone_bricks
setblock ~-29 ~23 ~-151 minecraft:mossy_stone_bricks
setblock ~-29 ~23 ~-107 minecraft:mossy_stone_bricks
setblock ~-29 ~24 ~-97 minecraft:mossy_stone_bricks
setblock ~-29 ~30 ~-141 minecraft:mossy_stone_bricks
setblock ~-29 ~30 ~-107 minecraft:mossy_stone_bricks
setblock ~-29 ~38 ~-107 minecraft:mossy_stone_bricks
setblock ~-29 ~47 ~-97 minecraft:mossy_stone_bricks
setblock ~-29 ~48 ~-107 minecraft:mossy_stone_bricks
setblock ~-29 ~50 ~-97 minecraft:mossy_stone_bricks
setblock ~-29 ~52 ~-140 minecraft:mossy_stone_bricks
fill ~-28 ~6 ~-156 ~-27 ~6 ~-156 minecraft:mossy_stone_bricks
fill ~-28 ~7 ~-156 ~-28 ~8 ~-156 minecraft:mossy_stone_bricks
setblock ~-28 ~8 ~-152 minecraft:mossy_stone_bricks
setblock ~-28 ~10 ~-38 minecraft:mossy_stone_bricks
fill ~-28 ~13 ~-108 ~-28 ~14 ~-108 minecraft:mossy_stone_bricks
setblock ~-28 ~15 ~-160 minecraft:mossy_stone_bricks
fill ~-28 ~16 ~-152 ~-28 ~17 ~-152 minecraft:mossy_stone_bricks
setblock ~-28 ~17 ~-108 minecraft:mossy_stone_bricks
fill ~-28 ~17 ~-31 ~-28 ~18 ~-31 minecraft:mossy_stone_bricks
setblock ~-28 ~21 ~-152 minecraft:mossy_stone_bricks
setblock ~-28 ~27 ~-108 minecraft:mossy_stone_bricks
fill ~-28 ~34 ~-108 ~-27 ~34 ~-108 minecraft:mossy_stone_bricks
setblock ~-28 ~37 ~-152 minecraft:mossy_stone_bricks
setblock ~-28 ~39 ~-96 minecraft:mossy_stone_bricks
setblock ~-28 ~40 ~-108 minecraft:mossy_stone_bricks
setblock ~-28 ~49 ~-108 minecraft:mossy_stone_bricks
setblock ~-27 ~1 ~-38 minecraft:mossy_stone_bricks
setblock ~-27 ~5 ~-160 minecraft:mossy_stone_bricks
fill ~-27 ~5 ~-156 ~-27 ~6 ~-156 minecraft:mossy_stone_bricks
fill ~-27 ~5 ~-96 ~-27 ~6 ~-96 minecraft:mossy_stone_bricks
setblock ~-27 ~6 ~-38 minecraft:mossy_stone_bricks
setblock ~-27 ~7 ~-152 minecraft:mossy_stone_bricks
setblock ~-27 ~7 ~-140 minecraft:mossy_stone_bricks
fill ~-27 ~13 ~-96 ~-27 ~14 ~-96 minecraft:mossy_stone_bricks
setblock ~-27 ~14 ~-140 minecraft:mossy_stone_bricks
setblock ~-27 ~18 ~-161 minecraft:mossy_stone_bricks
fill ~-27 ~18 ~-159 ~-27 ~18 ~-157 minecraft:mossy_stone_bricks
setblock ~-27 ~18 ~-140 minecraft:mossy_stone_bricks
fill ~-27 ~18 ~-36 ~-27 ~19 ~-36 minecraft:mossy_stone_bricks
setblock ~-27 ~18 ~-32 minecraft:mossy_stone_bricks
setblock ~-27 ~27 ~-152 minecraft:mossy_stone_bricks
setblock ~-27 ~28 ~-108 minecraft:mossy_stone_bricks
fill ~-27 ~42 ~-152 ~-27 ~43 ~-152 minecraft:mossy_stone_bricks
setblock ~-27 ~44 ~-133 minecraft:mossy_stone_bricks
setblock ~-27 ~45 ~-123 minecraft:mossy_stone_bricks
setblock ~-27 ~45 ~-120 minecraft:mossy_stone_bricks
setblock ~-27 ~45 ~-109 minecraft:mossy_stone_bricks
setblock ~-27 ~46 ~-152 minecraft:mossy_stone_bricks
setblock ~-27 ~46 ~-127 minecraft:mossy_stone_bricks
setblock ~-27 ~46 ~-121 minecraft:mossy_stone_bricks
setblock ~-27 ~49 ~-152 minecraft:mossy_stone_bricks
setblock ~-27 ~49 ~-96 minecraft:mossy_stone_bricks
setblock ~-27 ~52 ~-99 minecraft:mossy_stone_bricks
setblock ~-27 ~54 ~-139 minecraft:mossy_stone_bricks
fill ~-26 ~3 ~-116 ~-25 ~3 ~-116 minecraft:mossy_stone_bricks
fill ~-26 ~4 ~-127 ~-25 ~4 ~-127 minecraft:mossy_stone_bricks
fill ~-26 ~4 ~-125 ~-25 ~4 ~-125 minecraft:mossy_stone_bricks
setblock ~-26 ~4 ~-117 minecraft:mossy_stone_bricks
setblock ~-26 ~5 ~-132 minecraft:mossy_stone_bricks
fill ~-26 ~5 ~-129 ~-26 ~6 ~-129 minecraft:mossy_stone_bricks
fill ~-26 ~5 ~-123 ~-25 ~5 ~-123 minecraft:mossy_stone_bricks
fill ~-26 ~5 ~-119 ~-26 ~5 ~-118 minecraft:mossy_stone_bricks
setblock ~-26 ~5 ~-116 minecraft:mossy_stone_bricks
setblock ~-26 ~6 ~-96 minecraft:mossy_stone_bricks
fill ~-26 ~7 ~-118 ~-25 ~7 ~-118 minecraft:mossy_stone_bricks
setblock ~-26 ~8 ~-131 minecraft:mossy_stone_bricks
setblock ~-26 ~8 ~-124 minecraft:mossy_stone_bricks
setblock ~-26 ~8 ~-121 minecraft:mossy_stone_bricks
fill ~-26 ~8 ~-38 ~-26 ~9 ~-38 minecraft:mossy_stone_bricks
fill ~-26 ~9 ~-117 ~-25 ~9 ~-117 minecraft:mossy_stone_bricks
setblock ~-26 ~10 ~-136 minecraft:mossy_stone_bricks
setblock ~-26 ~10 ~-133 minecraft:mossy_stone_bricks
fill ~-26 ~10 ~-119 ~-25 ~10 ~-119 minecraft:mossy_stone_bricks
setblock ~-26 ~12 ~-136 minecraft:mossy_stone_bricks
setblock ~-26 ~12 ~-120 minecraft:mossy_stone_bricks
setblock ~-26 ~12 ~-116 minecraft:mossy_stone_bricks
fill ~-26 ~13 ~-156 ~-26 ~14 ~-156 minecraft:mossy_stone_bricks
fill ~-26 ~13 ~-139 ~-25 ~13 ~-139 minecraft:mossy_stone_bricks
setblock ~-26 ~13 ~-126 minecraft:mossy_stone_bricks
fill ~-26 ~13 ~-109 ~-25 ~13 ~-109 minecraft:mossy_stone_bricks
setblock ~-26 ~14 ~-133 minecraft:mossy_stone_bricks
setblock ~-26 ~14 ~-116 minecraft:mossy_stone_bricks
setblock ~-26 ~15 ~-129 minecraft:mossy_stone_bricks
fill ~-26 ~15 ~-121 ~-26 ~15 ~-120 minecraft:mossy_stone_bricks
fill ~-26 ~17 ~-125 ~-26 ~17 ~-124 minecraft:mossy_stone_bricks
setblock ~-26 ~18 ~-160 minecraft:mossy_stone_bricks
fill ~-26 ~18 ~-115 ~-26 ~19 ~-115 minecraft:mossy_stone_bricks
setblock ~-26 ~19 ~-161 minecraft:mossy_stone_bricks
setblock ~-26 ~19 ~-120 minecraft:mossy_stone_bricks
setblock ~-26 ~19 ~-117 minecraft:mossy_stone_bricks
setblock ~-26 ~20 ~-137 minecraft:mossy_stone_bricks
setblock ~-26 ~20 ~-131 minecraft:mossy_stone_bricks
setblock ~-26 ~20 ~-116 minecraft:mossy_stone_bricks
setblock ~-26 ~23 ~-131 minecraft:mossy_stone_bricks
setblock ~-26 ~24 ~-137 minecraft:mossy_stone_bricks
setblock ~-26 ~24 ~-133 minecraft:mossy_stone_bricks
setblock ~-26 ~25 ~-135 minecraft:mossy_stone_bricks
setblock ~-26 ~25 ~-129 minecraft:mossy_stone_bricks
setblock ~-26 ~25 ~-111 minecraft:mossy_stone_bricks
setblock ~-26 ~26 ~-127 minecraft:mossy_stone_bricks
setblock ~-26 ~26 ~-117 minecraft:mossy_stone_bricks
setblock ~-26 ~27 ~-139 minecraft:mossy_stone_bricks
setblock ~-26 ~27 ~-121 minecraft:mossy_stone_bricks
setblock ~-26 ~28 ~-152 minecraft:mossy_stone_bricks
setblock ~-26 ~29 ~-128 minecraft:mossy_stone_bricks
setblock ~-26 ~30 ~-119 minecraft:mossy_stone_bricks
setblock ~-26 ~30 ~-111 minecraft:mossy_stone_bricks
setblock ~-26 ~31 ~-127 minecraft:mossy_stone_bricks
fill ~-26 ~31 ~-113 ~-26 ~32 ~-113 minecraft:mossy_stone_bricks
setblock ~-26 ~32 ~-126 minecraft:mossy_stone_bricks
setblock ~-26 ~34 ~-118 minecraft:mossy_stone_bricks
setblock ~-26 ~34 ~-113 minecraft:mossy_stone_bricks
setblock ~-26 ~35 ~-126 minecraft:mossy_stone_bricks
setblock ~-26 ~35 ~-117 minecraft:mossy_stone_bricks
fill ~-26 ~36 ~-125 ~-26 ~36 ~-123 minecraft:mossy_stone_bricks
fill ~-26 ~37 ~-139 ~-26 ~38 ~-139 minecraft:mossy_stone_bricks
setblock ~-26 ~37 ~-123 minecraft:mossy_stone_bricks
setblock ~-26 ~38 ~-135 minecraft:mossy_stone_bricks
fill ~-26 ~38 ~-109 ~-26 ~39 ~-109 minecraft:mossy_stone_bricks
fill ~-26 ~39 ~-137 ~-26 ~39 ~-136 minecraft:mossy_stone_bricks
fill ~-26 ~39 ~-134 ~-26 ~39 ~-133 minecraft:mossy_stone_bricks
setblock ~-26 ~39 ~-123 minecraft:mossy_stone_bricks
fill ~-26 ~41 ~-126 ~-25 ~41 ~-126 minecraft:mossy_stone_bricks
fill ~-26 ~42 ~-134 ~-25 ~42 ~-134 minecraft:mossy_stone_bricks
setblock ~-26 ~42 ~-127 minecraft:mossy_stone_bricks
setblock ~-26 ~42 ~-125 minecraft:mossy_stone_bricks
setblock ~-26 ~42 ~-111 minecraft:mossy_stone_bricks
setblock ~-26 ~43 ~-152 minecraft:mossy_stone_bricks
fill ~-26 ~44 ~-117 ~-25 ~44 ~-117 minecraft:mossy_stone_bricks
setblock ~-26 ~44 ~-114 minecraft:mossy_stone_bricks
setblock ~-26 ~52 ~-139 minecraft:mossy_stone_bricks
setblock ~-26 ~52 ~-103 minecraft:mossy_stone_bricks
setblock ~-26 ~52 ~-101 minecraft:mossy_stone_bricks
setblock ~-26 ~52 ~-96 minecraft:mossy_stone_bricks
fill ~-25 ~ ~-141 ~-25 ~ ~-138 minecraft:mossy_stone_bricks
setblock ~-25 ~ ~-107 minecraft:mossy_stone_bricks
setblock ~-25 ~1 ~-124 minecraft:mossy_stone_bricks
setblock ~-25 ~1 ~-104 minecraft:mossy_stone_bricks
setblock ~-25 ~2 ~-111 minecraft:mossy_stone_bricks
setblock ~-25 ~3 ~-134 minecraft:mossy_stone_bricks
setblock ~-25 ~3 ~-115 minecraft:mossy_stone_bricks
fill ~-25 ~3 ~-113 ~-25 ~4 ~-113 minecraft:mossy_stone_bricks
setblock ~-25 ~4 ~-111 minecraft:mossy_stone_bricks
setblock ~-25 ~5 ~-108 minecraft:mossy_stone_bricks
setblock ~-25 ~6 ~-137 minecraft:mossy_stone_bricks
setblock ~-25 ~6 ~-126 minecraft:mossy_stone_bricks
setblock ~-25 ~6 ~-122 minecraft:mossy_stone_bricks
setblock ~-25 ~6 ~-105 minecraft:mossy_stone_bricks
fill ~-25 ~7 ~-119 ~-25 ~7 ~-117 minecraft:mossy_stone_bricks
setblock ~-25 ~7 ~-104 minecraft:mossy_stone_bricks
setblock ~-25 ~8 ~-123 minecraft:mossy_stone_bricks
setblock ~-25 ~9 ~-32 minecraft:mossy_stone_bricks
setblock ~-25 ~10 ~-111 minecraft:mossy_stone_bricks
fill ~-25 ~12 ~-143 ~-25 ~12 ~-142 minecraft:mossy_stone_bricks
fill ~-25 ~12 ~-139 ~-25 ~12 ~-138 minecraft:mossy_stone_bricks
setblock ~-25 ~12 ~-121 minecraft:mossy_stone_bricks
fill ~-25 ~12 ~-109 ~-25 ~13 ~-109 minecraft:mossy_stone_bricks
setblock ~-25 ~13 ~-32 minecraft:mossy_stone_bricks
setblock ~-25 ~16 ~-138 minecraft:mossy_stone_bricks
setblock ~-25 ~17 ~-126 minecraft:mossy_stone_bricks
fill ~-25 ~17 ~-115 ~-25 ~17 ~-114 minecraft:mossy_stone_bricks
setblock ~-25 ~17 ~-107 minecraft:mossy_stone_bricks
fill ~-25 ~21 ~-140 ~-25 ~21 ~-139 minecraft:mossy_stone_bricks
fill ~-25 ~21 ~-134 ~-25 ~21 ~-133 minecraft:mossy_stone_bricks
setblock ~-25 ~21 ~-122 minecraft:mossy_stone_bricks
setblock ~-25 ~21 ~-108 minecraft:mossy_stone_bricks
setblock ~-25 ~21 ~-104 minecraft:mossy_stone_bricks
setblock ~-25 ~23 ~-152 minecraft:mossy_stone_bricks
setblock ~-25 ~23 ~-129 minecraft:mossy_stone_bricks
setblock ~-25 ~23 ~-107 minecraft:mossy_stone_bricks
setblock ~-25 ~24 ~-142 minecraft:mossy_stone_bricks
setblock ~-25 ~24 ~-130 minecraft:mossy_stone_bricks
setblock ~-25 ~24 ~-121 minecraft:mossy_stone_bricks
setblock ~-25 ~25 ~-140 minecraft:mossy_stone_bricks
setblock ~-25 ~25 ~-137 minecraft:mossy_stone_bricks
setblock ~-25 ~25 ~-123 minecraft:mossy_stone_bricks
setblock ~-25 ~26 ~-152 minecraft:mossy_stone_bricks
setblock ~-25 ~26 ~-125 minecraft:mossy_stone_bricks
setblock ~-25 ~27 ~-131 minecraft:mossy_stone_bricks
setblock ~-25 ~27 ~-116 minecraft:mossy_stone_bricks
fill ~-25 ~29 ~-144 ~-25 ~31 ~-144 minecraft:mossy_stone_bricks
setblock ~-25 ~30 ~-116 minecraft:mossy_stone_bricks
fill ~-25 ~31 ~-122 ~-25 ~32 ~-122 minecraft:mossy_stone_bricks
setblock ~-25 ~32 ~-120 minecraft:mossy_stone_bricks
setblock ~-25 ~32 ~-115 minecraft:mossy_stone_bricks
setblock ~-25 ~32 ~-111 minecraft:mossy_stone_bricks
setblock ~-25 ~32 ~-106 minecraft:mossy_stone_bricks
setblock ~-25 ~33 ~-96 minecraft:mossy_stone_bricks
setblock ~-25 ~34 ~-130 minecraft:mossy_stone_bricks
fill ~-25 ~34 ~-123 ~-25 ~35 ~-123 minecraft:mossy_stone_bricks
fill ~-25 ~35 ~-142 ~-25 ~35 ~-141 minecraft:mossy_stone_bricks
setblock ~-25 ~35 ~-132 minecraft:mossy_stone_bricks
setblock ~-25 ~35 ~-96 minecraft:mossy_stone_bricks
fill ~-25 ~37 ~-111 ~-25 ~37 ~-110 minecraft:mossy_stone_bricks
setblock ~-25 ~38 ~-138 minecraft:mossy_stone_bricks
setblock ~-25 ~38 ~-134 minecraft:mossy_stone_bricks
setblock ~-25 ~39 ~-121 minecraft:mossy_stone_bricks
setblock ~-25 ~39 ~-111 minecraft:mossy_stone_bricks
setblock ~-25 ~40 ~-132 minecraft:mossy_stone_bricks
setblock ~-25 ~40 ~-122 minecraft:mossy_stone_bricks
setblock ~-25 ~41 ~-135 minecraft:mossy_stone_bricks
setblock ~-25 ~41 ~-129 minecraft:mossy_stone_bricks
setblock ~-25 ~41 ~-112 minecraft:mossy_stone_bricks
fill ~-25 ~41 ~-108 ~-25 ~42 ~-108 minecraft:mossy_stone_bricks
setblock ~-25 ~42 ~-141 minecraft:mossy_stone_bricks
setblock ~-25 ~42 ~-126 minecraft:mossy_stone_bricks
setblock ~-25 ~43 ~-124 minecraft:mossy_stone_bricks
setblock ~-25 ~43 ~-121 minecraft:mossy_stone_bricks
setblock ~-25 ~44 ~-128 minecraft:mossy_stone_bricks
fill ~-25 ~46 ~-140 ~-25 ~47 ~-140 minecraft:mossy_stone_bricks
fill ~-25 ~49 ~-96 ~-25 ~50 ~-96 minecraft:mossy_stone_bricks
setblock ~-25 ~52 ~-152 minecraft:mossy_stone_bricks
setblock ~-25 ~53 ~-95 minecraft:mossy_stone_bricks
setblock ~-24 ~1 ~-145 minecraft:mossy_stone_bricks
setblock ~-24 ~5 ~-38 minecraft:mossy_stone_bricks
setblock ~-24 ~5 ~-32 minecraft:mossy_stone_bricks
setblock ~-24 ~6 ~-152 minecraft:mossy_stone_bricks
fill ~-24 ~8 ~-125 ~-23 ~8 ~-125 minecraft:mossy_stone_bricks
setblock ~-24 ~8 ~-103 minecraft:mossy_stone_bricks
setblock ~-24 ~12 ~-160 minecraft:mossy_stone_bricks
fill ~-24 ~14 ~-160 ~-23 ~14 ~-160 minecraft:mossy_stone_bricks
setblock ~-24 ~14 ~-32 minecraft:mossy_stone_bricks
setblock ~-24 ~15 ~-160 minecraft:mossy_stone_bricks
setblock ~-24 ~15 ~-152 minecraft:mossy_stone_bricks
setblock ~-24 ~18 ~-32 minecraft:mossy_stone_bricks
fill ~-24 ~19 ~-103 ~-23 ~19 ~-103 minecraft:mossy_stone_bricks
setblock ~-24 ~21 ~-96 minecraft:mossy_stone_bricks
setblock ~-24 ~30 ~-96 minecraft:mossy_stone_bricks
fill ~-24 ~30 ~-32 ~-24 ~31 ~-32 minecraft:mossy_stone_bricks
setblock ~-24 ~30 ~-30 minecraft:mossy_stone_bricks
setblock ~-24 ~35 ~-103 minecraft:mossy_stone_bricks
setblock ~-24 ~38 ~-96 minecraft:mossy_stone_bricks
setblock ~-24 ~40 ~-152 minecraft:mossy_stone_bricks
setblock ~-24 ~40 ~-103 minecraft:mossy_stone_bricks
setblock ~-24 ~41 ~-96 minecraft:mossy_stone_bricks
setblock ~-24 ~42 ~-152 minecraft:mossy_stone_bricks
setblock ~-24 ~44 ~-143 minecraft:mossy_stone_bricks
fill ~-24 ~44 ~-131 ~-23 ~44 ~-131 minecraft:mossy_stone_bricks
setblock ~-24 ~44 ~-130 minecraft:mossy_stone_bricks
setblock ~-24 ~44 ~-111 minecraft:mossy_stone_bricks
setblock ~-24 ~45 ~-140 minecraft:mossy_stone_bricks
fill ~-23 ~4 ~-103 ~-23 ~6 ~-103 minecraft:mossy_stone_bricks
setblock ~-23 ~5 ~-29 minecraft:mossy_stone_bricks
setblock ~-23 ~7 ~-151 minecraft:mossy_stone_bricks
fill ~-23 ~7 ~-145 ~-23 ~9 ~-145 minecraft:mossy_stone_bricks
setblock ~-23 ~7 ~-97 minecraft:mossy_stone_bricks
setblock ~-23 ~7 ~-38 minecraft:mossy_stone_bricks
fill ~-23 ~10 ~-156 ~-21 ~10 ~-156 minecraft:mossy_stone_bricks
setblock ~-23 ~12 ~-28 minecraft:mossy_stone_bricks
setblock ~-23 ~13 ~-36 minecraft:mossy_stone_bricks
fill ~-23 ~14 ~-28 ~-22 ~14 ~-28 minecraft:mossy_stone_bricks
setblock ~-23 ~15 ~-151 minecraft:mossy_stone_bricks
setblock ~-23 ~15 ~-36 minecraft:mossy_stone_bricks
setblock ~-23 ~18 ~-30 minecraft:mossy_stone_bricks
setblock ~-23 ~22 ~-32 minecraft:mossy_stone_bricks
setblock ~-23 ~23 ~-151 minecraft:mossy_stone_bricks
fill ~-23 ~25 ~-124 ~-22 ~25 ~-124 minecraft:mossy_stone_bricks
setblock ~-23 ~27 ~-97 minecraft:mossy_stone_bricks
setblock ~-23 ~30 ~-35 minecraft:mossy_stone_bricks
setblock ~-23 ~30 ~-26 minecraft:mossy_stone_bricks
setblock ~-23 ~32 ~-151 minecraft:mossy_stone_bricks
setblock ~-23 ~32 ~-103 minecraft:mossy_stone_bricks
setblock ~-23 ~34 ~-97 minecraft:mossy_stone_bricks
setblock ~-23 ~36 ~-151 minecraft:mossy_stone_bricks
setblock ~-23 ~36 ~-97 minecraft:mossy_stone_bricks
setblock ~-23 ~40 ~-145 minecraft:mossy_stone_bricks
setblock ~-23 ~44 ~-138 minecraft:mossy_stone_bricks
setblock ~-23 ~44 ~-125 minecraft:mossy_stone_bricks
setblock ~-23 ~44 ~-120 minecraft:mossy_stone_bricks
setblock ~-23 ~44 ~-97 minecraft:mossy_stone_bricks
fill ~-23 ~52 ~-145 ~-23 ~52 ~-144 minecraft:mossy_stone_bricks
fill ~-23 ~52 ~-108 ~-22 ~52 ~-108 minecraft:mossy_stone_bricks
setblock ~-23 ~52 ~-99 minecraft:mossy_stone_bricks
setblock ~-22 ~3 ~-26 minecraft:mossy_stone_bricks
setblock ~-22 ~4 ~-28 minecraft:mossy_stone_bricks
setblock ~-22 ~6 ~-26 minecraft:mossy_stone_bricks
fill ~-22 ~8 ~-30 ~-22 ~8 ~-29 minecraft:mossy_stone_bricks
fill ~-22 ~12 ~-156 ~-21 ~12 ~-156 minecraft:mossy_stone_bricks
setblock ~-22 ~15 ~-32 minecraft:mossy_stone_bricks
setblock ~-22 ~17 ~-31 minecraft:mossy_stone_bricks
setblock ~-22 ~18 ~-159 minecraft:mossy_stone_bricks
fill ~-22 ~18 ~-36 ~-22 ~19 ~-36 minecraft:mossy_stone_bricks
setblock ~-22 ~18 ~-34 minecraft:mossy_stone_bricks
setblock ~-22 ~21 ~-27 minecraft:mossy_stone_bricks
setblock ~-22 ~23 ~-28 minecraft:mossy_stone_bricks
fill ~-22 ~25 ~-33 ~-22 ~26 ~-33 minecraft:mossy_stone_bricks
setblock ~-22 ~25 ~-30 minecraft:mossy_stone_bricks
setblock ~-22 ~26 ~-151 minecraft:mossy_stone_bricks
fill ~-22 ~28 ~-32 ~-22 ~28 ~-31 minecraft:mossy_stone_bricks
setblock ~-22 ~29 ~-97 minecraft:mossy_stone_bricks
setblock ~-22 ~30 ~-103 minecraft:mossy_stone_bricks
setblock ~-22 ~31 ~-151 minecraft:mossy_stone_bricks
setblock ~-22 ~31 ~-36 minecraft:mossy_stone_bricks
setblock ~-22 ~33 ~-97 minecraft:mossy_stone_bricks
setblock ~-22 ~42 ~-151 minecraft:mossy_stone_bricks
setblock ~-22 ~44 ~-133 minecraft:mossy_stone_bricks
setblock ~-22 ~44 ~-128 minecraft:mossy_stone_bricks
setblock ~-22 ~44 ~-124 minecraft:mossy_stone_bricks
fill ~-22 ~46 ~-97 ~-22 ~47 ~-97 minecraft:mossy_stone_bricks
setblock ~-22 ~50 ~-141 minecraft:mossy_stone_bricks
setblock ~-22 ~50 ~-97 minecraft:mossy_stone_bricks
setblock ~-22 ~52 ~-107 minecraft:mossy_stone_bricks
setblock ~-22 ~52 ~-100 minecraft:mossy_stone_bricks
setblock ~-22 ~52 ~-96 minecraft:mossy_stone_bricks
setblock ~-22 ~54 ~-152 minecraft:mossy_stone_bricks
setblock ~-22 ~54 ~-140 minecraft:mossy_stone_bricks
setblock ~-21 ~3 ~-150 minecraft:mossy_stone_bricks
fill ~-21 ~3 ~-103 ~-20 ~3 ~-103 minecraft:mossy_stone_bricks
setblock ~-21 ~4 ~-145 minecraft:mossy_stone_bricks
setblock ~-21 ~5 ~-156 minecraft:mossy_stone_bricks
setblock ~-21 ~6 ~-139 minecraft:mossy_stone_bricks
setblock ~-21 ~6 ~-25 minecraft:mossy_stone_bricks
fill ~-21 ~7 ~-99 ~-21 ~8 ~-99 minecraft:mossy_stone_bricks
setblock ~-21 ~8 ~-160 minecraft:mossy_stone_bricks
setblock ~-21 ~11 ~-99 minecraft:mossy_stone_bricks
setblock ~-21 ~12 ~-98 minecraft:mossy_stone_bricks
setblock ~-21 ~12 ~-25 minecraft:mossy_stone_bricks
fill ~-21 ~13 ~-27 ~-21 ~14 ~-27 minecraft:mossy_stone_bricks
setblock ~-21 ~16 ~-99 minecraft:mossy_stone_bricks
setblock ~-21 ~17 ~-98 minecraft:mossy_stone_bricks
setblock ~-21 ~19 ~-103 minecraft:mossy_stone_bricks
setblock ~-21 ~19 ~-98 minecraft:mossy_stone_bricks
setblock ~-21 ~21 ~-25 minecraft:mossy_stone_bricks
setblock ~-21 ~24 ~-124 minecraft:mossy_stone_bricks
setblock ~-21 ~25 ~-99 minecraft:mossy_stone_bricks
setblock ~-21 ~26 ~-35 minecraft:mossy_stone_bricks
setblock ~-21 ~27 ~-98 minecraft:mossy_stone_bricks
setblock ~-21 ~27 ~-34 minecraft:mossy_stone_bricks
fill ~-21 ~28 ~-150 ~-21 ~28 ~-149 minecraft:mossy_stone_bricks
fill ~-21 ~28 ~-33 ~-21 ~29 ~-33 minecraft:mossy_stone_bricks
setblock ~-21 ~28 ~-24 minecraft:mossy_stone_bricks
setblock ~-21 ~36 ~-150 minecraft:mossy_stone_bricks
setblock ~-21 ~37 ~-145 minecraft:mossy_stone_bricks
setblock ~-21 ~42 ~-145 minecraft:mossy_stone_bricks
fill ~-21 ~44 ~-134 ~-20 ~44 ~-134 minecraft:mossy_stone_bricks
setblock ~-21 ~44 ~-122 minecraft:mossy_stone_bricks
setblock ~-21 ~44 ~-109 minecraft:mossy_stone_bricks
setblock ~-21 ~45 ~-143 minecraft:mossy_stone_bricks
fill ~-21 ~45 ~-105 ~-21 ~46 ~-105 minecraft:mossy_stone_bricks
setblock ~-21 ~47 ~-149 minecraft:mossy_stone_bricks
setblock ~-21 ~49 ~-142 minecraft:mossy_stone_bricks
setblock ~-21 ~49 ~-105 minecraft:mossy_stone_bricks
fill ~-21 ~52 ~-141 ~-21 ~53 ~-141 minecraft:mossy_stone_bricks
setblock ~-20 ~1 ~-25 minecraft:mossy_stone_bricks
fill ~-20 ~2 ~-141 ~-20 ~2 ~-140 minecraft:mossy_stone_bricks
setblock ~-20 ~3 ~-125 minecraft:mossy_stone_bricks
setblock ~-20 ~3 ~-38 minecraft:mossy_stone_bricks
setblock ~-20 ~3 ~-35 minecraft:mossy_stone_bricks
setblock ~-20 ~4 ~-156 minecraft:mossy_stone_bricks
setblock ~-20 ~4 ~-139 minecraft:mossy_stone_bricks
fill ~-20 ~7 ~-101 ~-20 ~8 ~-101 minecraft:mossy_stone_bricks
setblock ~-20 ~10 ~-25 minecraft:mossy_stone_bricks
setblock ~-20 ~13 ~-141 minecraft:mossy_stone_bricks
setblock ~-20 ~15 ~-148 minecraft:mossy_stone_bricks
setblock ~-20 ~15 ~-101 minecraft:mossy_stone_bricks
setblock ~-20 ~15 ~-35 minecraft:mossy_stone_bricks
setblock ~-20 ~16 ~-103 minecraft:mossy_stone_bricks
fill ~-20 ~16 ~-24 ~-19 ~16 ~-24 minecraft:mossy_stone_bricks
setblock ~-20 ~17 ~-100 minecraft:mossy_stone_bricks
setblock ~-20 ~19 ~-100 minecraft:mossy_stone_bricks
setblock ~-20 ~19 ~-25 minecraft:mossy_stone_bricks
setblock ~-20 ~20 ~-101 minecraft:mossy_stone_bricks
setblock ~-20 ~23 ~-147 minecraft:mossy_stone_bricks
fill ~-20 ~23 ~-124 ~-19 ~23 ~-124 minecraft:mossy_stone_bricks
fill ~-20 ~28 ~-25 ~-20 ~29 ~-25 minecraft:mossy_stone_bricks
setblock ~-20 ~30 ~-145 minecraft:mossy_stone_bricks
fill ~-20 ~31 ~-38 ~-19 ~31 ~-38 minecraft:mossy_stone_bricks
setblock ~-20 ~32 ~-37 minecraft:mossy_stone_bricks
setblock ~-20 ~34 ~-100 minecraft:mossy_stone_bricks
fill ~-20 ~36 ~-145 ~-19 ~36 ~-145 minecraft:mossy_stone_bricks
fill ~-20 ~38 ~-101 ~-20 ~38 ~-100 minecraft:mossy_stone_bricks
setblock ~-20 ~39 ~-145 minecraft:mossy_stone_bricks
setblock ~-20 ~40 ~-100 minecraft:mossy_stone_bricks
setblock ~-20 ~44 ~-144 minecraft:mossy_stone_bricks
setblock ~-20 ~44 ~-106 minecraft:mossy_stone_bricks
setblock ~-20 ~47 ~-145 minecraft:mossy_stone_bricks
setblock ~-20 ~50 ~-147 minecraft:mossy_stone_bricks
setblock ~-20 ~50 ~-102 minecraft:mossy_stone_bricks
setblock ~-20 ~52 ~-147 minecraft:mossy_stone_bricks
setblock ~-20 ~52 ~-145 minecraft:mossy_stone_bricks
fill ~-19 ~-26 ~-140 ~-18 ~-26 ~-140 minecraft:mossy_stone_bricks
setblock ~-19 ~1 ~-140 minecraft:mossy_stone_bricks
setblock ~-19 ~3 ~-160 minecraft:mossy_stone_bricks
setblock ~-19 ~3 ~-24 minecraft:mossy_stone_bricks
setblock ~-19 ~5 ~-140 minecraft:mossy_stone_bricks
setblock ~-19 ~7 ~-139 minecraft:mossy_stone_bricks
setblock ~-19 ~7 ~-103 minecraft:mossy_stone_bricks
setblock ~-19 ~7 ~-36 minecraft:mossy_stone_bricks
fill ~-19 ~9 ~-103 ~-19 ~9 ~-102 minecraft:mossy_stone_bricks
setblock ~-19 ~12 ~-146 minecraft:mossy_stone_bricks
setblock ~-19 ~14 ~-160 minecraft:mossy_stone_bricks
setblock ~-19 ~14 ~-139 minecraft:mossy_stone_bricks
setblock ~-19 ~16 ~-156 minecraft:mossy_stone_bricks
setblock ~-19 ~18 ~-36 minecraft:mossy_stone_bricks
setblock ~-19 ~19 ~-161 minecraft:mossy_stone_bricks
setblock ~-19 ~19 ~-37 minecraft:mossy_stone_bricks
setblock ~-19 ~23 ~-37 minecraft:mossy_stone_bricks
setblock ~-19 ~24 ~-36 minecraft:mossy_stone_bricks
fill ~-19 ~25 ~-145 ~-19 ~26 ~-145 minecraft:mossy_stone_bricks
setblock ~-19 ~27 ~-146 minecraft:mossy_stone_bricks
setblock ~-19 ~29 ~-24 minecraft:mossy_stone_bricks
setblock ~-19 ~30 ~-146 minecraft:mossy_stone_bricks
fill ~-19 ~32 ~-124 ~-19 ~33 ~-124 minecraft:mossy_stone_bricks
setblock ~-19 ~32 ~-103 minecraft:mossy_stone_bricks
setblock ~-19 ~41 ~-146 minecraft:mossy_stone_bricks
setblock ~-19 ~44 ~-114 minecraft:mossy_stone_bricks
setblock ~-19 ~44 ~-105 minecraft:mossy_stone_bricks
fill ~-19 ~44 ~-101 ~-19 ~45 ~-101 minecraft:mossy_stone_bricks
setblock ~-19 ~52 ~-101 minecraft:mossy_stone_bricks
setblock ~-19 ~53 ~-104 minecraft:mossy_stone_bricks
setblock ~-18 ~2 ~-156 minecraft:mossy_stone_bricks
setblock ~-18 ~4 ~-145 minecraft:mossy_stone_bricks
fill ~-18 ~9 ~-160 ~-17 ~9 ~-160 minecraft:mossy_stone_bricks
setblock ~-18 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~-18 ~10 ~-24 minecraft:mossy_stone_bricks
setblock ~-18 ~12 ~-145 minecraft:mossy_stone_bricks
setblock ~-18 ~12 ~-37 minecraft:mossy_stone_bricks
fill ~-18 ~14 ~-24 ~-18 ~14 ~-23 minecraft:mossy_stone_bricks
setblock ~-18 ~16 ~-37 minecraft:mossy_stone_bricks
setblock ~-18 ~25 ~-37 minecraft:mossy_stone_bricks
fill ~-18 ~26 ~-124 ~-17 ~26 ~-124 minecraft:mossy_stone_bricks
setblock ~-18 ~26 ~-103 minecraft:mossy_stone_bricks
fill ~-18 ~28 ~-124 ~-18 ~29 ~-124 minecraft:mossy_stone_bricks
setblock ~-18 ~29 ~-36 minecraft:mossy_stone_bricks
setblock ~-18 ~30 ~-27 minecraft:mossy_stone_bricks
setblock ~-18 ~44 ~-135 minecraft:mossy_stone_bricks
setblock ~-18 ~44 ~-115 minecraft:mossy_stone_bricks
fill ~-17 ~-25 ~-140 ~-16 ~-25 ~-133 minecraft:mossy_stone_bricks
fill ~-17 ~-23 ~-139 ~-17 ~-23 ~-133 minecraft:mossy_stone_bricks
fill ~-17 ~1 ~-37 ~-16 ~1 ~-37 minecraft:mossy_stone_bricks
setblock ~-17 ~3 ~-156 minecraft:mossy_stone_bricks
setblock ~-17 ~4 ~-103 minecraft:mossy_stone_bricks
setblock ~-17 ~5 ~-160 minecraft:mossy_stone_bricks
setblock ~-17 ~8 ~-37 minecraft:mossy_stone_bricks
fill ~-17 ~9 ~-146 ~-17 ~9 ~-145 minecraft:mossy_stone_bricks
setblock ~-17 ~11 ~-156 minecraft:mossy_stone_bricks
setblock ~-17 ~13 ~-156 minecraft:mossy_stone_bricks
setblock ~-17 ~13 ~-103 minecraft:mossy_stone_bricks
fill ~-17 ~14 ~-23 ~-17 ~14 ~-22 minecraft:mossy_stone_bricks
fill ~-17 ~15 ~-22 ~-17 ~16 ~-22 minecraft:mossy_stone_bricks
setblock ~-17 ~21 ~-37 minecraft:mossy_stone_bricks
fill ~-17 ~23 ~-146 ~-17 ~24 ~-146 minecraft:mossy_stone_bricks
setblock ~-17 ~24 ~-38 minecraft:mossy_stone_bricks
fill ~-17 ~26 ~-38 ~-15 ~26 ~-38 minecraft:mossy_stone_bricks
setblock ~-17 ~27 ~-124 minecraft:mossy_stone_bricks
fill ~-17 ~28 ~-146 ~-16 ~28 ~-146 minecraft:mossy_stone_bricks
setblock ~-17 ~30 ~-124 minecraft:mossy_stone_bricks
fill ~-17 ~30 ~-26 ~-17 ~30 ~-25 minecraft:mossy_stone_bricks
setblock ~-17 ~30 ~-21 minecraft:mossy_stone_bricks
fill ~-17 ~37 ~-146 ~-16 ~37 ~-146 minecraft:mossy_stone_bricks
setblock ~-17 ~38 ~-103 minecraft:mossy_stone_bricks
fill ~-17 ~39 ~-146 ~-16 ~39 ~-146 minecraft:mossy_stone_bricks
setblock ~-17 ~40 ~-145 minecraft:mossy_stone_bricks
setblock ~-17 ~44 ~-134 minecraft:mossy_stone_bricks
fill ~-17 ~44 ~-129 ~-17 ~44 ~-128 minecraft:mossy_stone_bricks
setblock ~-17 ~44 ~-123 minecraft:mossy_stone_bricks
fill ~-17 ~44 ~-121 ~-17 ~44 ~-120 minecraft:mossy_stone_bricks
setblock ~-17 ~44 ~-111 minecraft:mossy_stone_bricks
setblock ~-16 ~1 ~-156 minecraft:mossy_stone_bricks
setblock ~-16 ~1 ~-139 minecraft:mossy_stone_bricks
setblock ~-16 ~2 ~-125 minecraft:mossy_stone_bricks
setblock ~-16 ~4 ~-37 minecraft:mossy_stone_bricks
setblock ~-16 ~6 ~-23 minecraft:mossy_stone_bricks
setblock ~-16 ~7 ~-145 minecraft:mossy_stone_bricks
setblock ~-16 ~7 ~-22 minecraft:mossy_stone_bricks
fill ~-16 ~11 ~-22 ~-15 ~11 ~-22 minecraft:mossy_stone_bricks
setblock ~-16 ~12 ~-160 minecraft:mossy_stone_bricks
fill ~-16 ~19 ~-37 ~-15 ~19 ~-37 minecraft:mossy_stone_bricks
setblock ~-16 ~19 ~-23 minecraft:mossy_stone_bricks
fill ~-16 ~23 ~-37 ~-16 ~24 ~-37 minecraft:mossy_stone_bricks
setblock ~-16 ~30 ~-34 minecraft:mossy_stone_bricks
setblock ~-16 ~30 ~-28 minecraft:mossy_stone_bricks
setblock ~-16 ~35 ~-145 minecraft:mossy_stone_bricks
setblock ~-16 ~42 ~-103 minecraft:mossy_stone_bricks
setblock ~-16 ~43 ~-145 minecraft:mossy_stone_bricks
setblock ~-16 ~44 ~-139 minecraft:mossy_stone_bricks
setblock ~-16 ~44 ~-117 minecraft:mossy_stone_bricks
setblock ~-16 ~44 ~-105 minecraft:mossy_stone_bricks
fill ~-15 ~ ~-125 ~-14 ~ ~-125 minecraft:mossy_stone_bricks
setblock ~-15 ~4 ~-160 minecraft:mossy_stone_bricks
setblock ~-15 ~4 ~-103 minecraft:mossy_stone_bricks
setblock ~-15 ~6 ~-160 minecraft:mossy_stone_bricks
setblock ~-15 ~7 ~-103 minecraft:mossy_stone_bricks
fill ~-15 ~8 ~-146 ~-15 ~9 ~-146 minecraft:mossy_stone_bricks
setblock ~-15 ~8 ~-102 minecraft:mossy_stone_bricks
setblock ~-15 ~10 ~-140 minecraft:mossy_stone_bricks
setblock ~-15 ~10 ~-102 minecraft:mossy_stone_bricks
fill ~-15 ~10 ~-38 ~-15 ~11 ~-38 minecraft:mossy_stone_bricks
setblock ~-15 ~13 ~-160 minecraft:mossy_stone_bricks
setblock ~-15 ~14 ~-139 minecraft:mossy_stone_bricks
setblock ~-15 ~18 ~-159 minecraft:mossy_stone_bricks
fill ~-15 ~18 ~-146 ~-14 ~18 ~-146 minecraft:mossy_stone_bricks
setblock ~-15 ~18 ~-102 minecraft:mossy_stone_bricks
setblock ~-15 ~23 ~-103 minecraft:mossy_stone_bricks
setblock ~-15 ~24 ~-146 minecraft:mossy_stone_bricks
setblock ~-15 ~25 ~-102 minecraft:mossy_stone_bricks
fill ~-15 ~25 ~-38 ~-15 ~26 ~-38 minecraft:mossy_stone_bricks
setblock ~-15 ~28 ~-124 minecraft:mossy_stone_bricks
setblock ~-15 ~29 ~-102 minecraft:mossy_stone_bricks
fill ~-15 ~30 ~-146 ~-14 ~30 ~-146 minecraft:mossy_stone_bricks
setblock ~-15 ~30 ~-22 minecraft:mossy_stone_bricks
setblock ~-15 ~31 ~-21 minecraft:mossy_stone_bricks
setblock ~-15 ~32 ~-146 minecraft:mossy_stone_bricks
fill ~-15 ~36 ~-145 ~-15 ~37 ~-145 minecraft:mossy_stone_bricks
setblock ~-15 ~41 ~-145 minecraft:mossy_stone_bricks
setblock ~-15 ~42 ~-146 minecraft:mossy_stone_bricks
setblock ~-15 ~44 ~-137 minecraft:mossy_stone_bricks
setblock ~-15 ~44 ~-132 minecraft:mossy_stone_bricks
fill ~-15 ~44 ~-126 ~-14 ~44 ~-126 minecraft:mossy_stone_bricks
setblock ~-15 ~44 ~-122 minecraft:mossy_stone_bricks
setblock ~-15 ~44 ~-120 minecraft:mossy_stone_bricks
fill ~-14 ~3 ~-22 ~-14 ~4 ~-22 minecraft:mossy_stone_bricks
fill ~-14 ~6 ~-23 ~-14 ~6 ~-22 minecraft:mossy_stone_bricks
fill ~-14 ~14 ~-22 ~-13 ~14 ~-22 minecraft:mossy_stone_bricks
fill ~-14 ~18 ~-157 ~-13 ~18 ~-157 minecraft:mossy_stone_bricks
setblock ~-14 ~19 ~-102 minecraft:mossy_stone_bricks
setblock ~-14 ~23 ~-145 minecraft:mossy_stone_bricks
setblock ~-14 ~25 ~-37 minecraft:mossy_stone_bricks
fill ~-14 ~27 ~-103 ~-14 ~27 ~-102 minecraft:mossy_stone_bricks
setblock ~-14 ~28 ~-146 minecraft:mossy_stone_bricks
setblock ~-14 ~30 ~-26 minecraft:mossy_stone_bricks
setblock ~-14 ~35 ~-102 minecraft:mossy_stone_bricks
setblock ~-14 ~39 ~-103 minecraft:mossy_stone_bricks
setblock ~-14 ~44 ~-114 minecraft:mossy_stone_bricks
setblock ~-14 ~44 ~-103 minecraft:mossy_stone_bricks
setblock ~-13 ~ ~-37 minecraft:mossy_stone_bricks
fill ~-13 ~3 ~-160 ~-13 ~4 ~-160 minecraft:mossy_stone_bricks
setblock ~-13 ~3 ~-102 minecraft:mossy_stone_bricks
setblock ~-13 ~8 ~-146 minecraft:mossy_stone_bricks
fill ~-13 ~8 ~-103 ~-13 ~9 ~-103 minecraft:mossy_stone_bricks
setblock ~-13 ~10 ~-22 minecraft:mossy_stone_bricks
setblock ~-13 ~11 ~-156 minecraft:mossy_stone_bricks
fill ~-13 ~14 ~-37 ~-13 ~15 ~-37 minecraft:mossy_stone_bricks
setblock ~-13 ~17 ~-156 minecraft:mossy_stone_bricks
setblock ~-13 ~17 ~-146 minecraft:mossy_stone_bricks
setblock ~-13 ~19 ~-146 minecraft:mossy_stone_bricks
setblock ~-13 ~22 ~-22 minecraft:mossy_stone_bricks
setblock ~-13 ~23 ~-103 minecraft:mossy_stone_bricks
setblock ~-13 ~24 ~-145 minecraft:mossy_stone_bricks
setblock ~-13 ~24 ~-38 minecraft:mossy_stone_bricks
fill ~-13 ~25 ~-23 ~-13 ~25 ~-22 minecraft:mossy_stone_bricks
setblock ~-13 ~26 ~-146 minecraft:mossy_stone_bricks
setblock ~-13 ~26 ~-103 minecraft:mossy_stone_bricks
setblock ~-13 ~27 ~-38 minecraft:mossy_stone_bricks
fill ~-13 ~28 ~-37 ~-13 ~29 ~-37 minecraft:mossy_stone_bricks
fill ~-13 ~29 ~-103 ~-12 ~29 ~-103 minecraft:mossy_stone_bricks
setblock ~-13 ~32 ~-103 minecraft:mossy_stone_bricks
setblock ~-13 ~37 ~-146 minecraft:mossy_stone_bricks
setblock ~-13 ~42 ~-146 minecraft:mossy_stone_bricks
setblock ~-13 ~44 ~-139 minecraft:mossy_stone_bricks
setblock ~-13 ~44 ~-130 minecraft:mossy_stone_bricks
setblock ~-13 ~44 ~-125 minecraft:mossy_stone_bricks
setblock ~-13 ~44 ~-107 minecraft:mossy_stone_bricks
setblock ~-12 ~2 ~-156 minecraft:mossy_stone_bricks
setblock ~-12 ~2 ~-36 minecraft:mossy_stone_bricks
setblock ~-12 ~3 ~-24 minecraft:mossy_stone_bricks
setblock ~-12 ~5 ~-160 minecraft:mossy_stone_bricks
fill ~-12 ~5 ~-103 ~-12 ~5 ~-102 minecraft:mossy_stone_bricks
setblock ~-12 ~6 ~-156 minecraft:mossy_stone_bricks
fill ~-12 ~6 ~-103 ~-11 ~6 ~-103 minecraft:mossy_stone_bricks
setblock ~-12 ~7 ~-36 minecraft:mossy_stone_bricks
setblock ~-12 ~11 ~-160 minecraft:mossy_stone_bricks
setblock ~-12 ~12 ~-102 minecraft:mossy_stone_bricks
fill ~-12 ~14 ~-146 ~-12 ~14 ~-145 minecraft:mossy_stone_bricks
setblock ~-12 ~21 ~-102 minecraft:mossy_stone_bricks
setblock ~-12 ~24 ~-102 minecraft:mossy_stone_bricks
fill ~-12 ~24 ~-24 ~-12 ~24 ~-23 minecraft:mossy_stone_bricks
fill ~-12 ~27 ~-103 ~-11 ~27 ~-103 minecraft:mossy_stone_bricks
setblock ~-12 ~27 ~-37 minecraft:mossy_stone_bricks
setblock ~-12 ~38 ~-102 minecraft:mossy_stone_bricks
setblock ~-12 ~41 ~-145 minecraft:mossy_stone_bricks
fill ~-12 ~44 ~-144 ~-12 ~44 ~-143 minecraft:mossy_stone_bricks
setblock ~-12 ~44 ~-105 minecraft:mossy_stone_bricks
setblock ~-12 ~44 ~-101 minecraft:mossy_stone_bricks
setblock ~-11 ~ ~-137 minecraft:mossy_stone_bricks
setblock ~-11 ~ ~-133 minecraft:mossy_stone_bricks
setblock ~-11 ~ ~-129 minecraft:mossy_stone_bricks
setblock ~-11 ~ ~-127 minecraft:mossy_stone_bricks
setblock ~-11 ~ ~-124 minecraft:mossy_stone_bricks
fill ~-11 ~ ~-107 ~-11 ~1 ~-107 minecraft:mossy_stone_bricks
fill ~-11 ~1 ~-139 ~-11 ~1 ~-138 minecraft:mossy_stone_bricks
fill ~-11 ~1 ~-136 ~-11 ~2 ~-136 minecraft:mossy_stone_bricks
setblock ~-11 ~1 ~-122 minecraft:mossy_stone_bricks
setblock ~-11 ~1 ~-105 minecraft:mossy_stone_bricks
setblock ~-11 ~1 ~-24 minecraft:mossy_stone_bricks
fill ~-11 ~2 ~-145 ~-11 ~4 ~-145 minecraft:mossy_stone_bricks
fill ~-11 ~2 ~-141 ~-11 ~4 ~-141 minecraft:mossy_stone_bricks
setblock ~-11 ~4 ~-131 minecraft:mossy_stone_bricks
setblock ~-11 ~4 ~-125 minecraft:mossy_stone_bricks
setblock ~-11 ~4 ~-116 minecraft:mossy_stone_bricks
setblock ~-11 ~4 ~-24 minecraft:mossy_stone_bricks
setblock ~-11 ~5 ~-138 minecraft:mossy_stone_bricks
setblock ~-11 ~5 ~-135 minecraft:mossy_stone_bricks
setblock ~-11 ~5 ~-129 minecraft:mossy_stone_bricks
setblock ~-11 ~5 ~-127 minecraft:mossy_stone_bricks
setblock ~-11 ~5 ~-108 minecraft:mossy_stone_bricks
fill ~-11 ~5 ~-106 ~-11 ~5 ~-105 minecraft:mossy_stone_bricks
setblock ~-11 ~5 ~-23 minecraft:mossy_stone_bricks
setblock ~-11 ~6 ~-160 minecraft:mossy_stone_bricks
fill ~-11 ~6 ~-116 ~-11 ~7 ~-116 minecraft:mossy_stone_bricks
setblock ~-11 ~7 ~-142 minecraft:mossy_stone_bricks
setblock ~-11 ~7 ~-136 minecraft:mossy_stone_bricks
setblock ~-11 ~8 ~-112 minecraft:mossy_stone_bricks
setblock ~-11 ~8 ~-106 minecraft:mossy_stone_bricks
fill ~-11 ~8 ~-37 ~-11 ~8 ~-36 minecraft:mossy_stone_bricks
fill ~-11 ~9 ~-139 ~-10 ~11 ~-139 minecraft:mossy_stone_bricks
fill ~-11 ~10 ~-109 ~-10 ~11 ~-109 minecraft:mossy_stone_bricks
fill ~-11 ~10 ~-107 ~-10 ~11 ~-107 minecraft:mossy_stone_bricks
setblock ~-11 ~10 ~-36 minecraft:mossy_stone_bricks
setblock ~-11 ~14 ~-160 minecraft:mossy_stone_bricks
setblock ~-11 ~16 ~-37 minecraft:mossy_stone_bricks
fill ~-11 ~17 ~-156 ~-10 ~17 ~-156 minecraft:mossy_stone_bricks
fill ~-11 ~17 ~-145 ~-11 ~17 ~-104 minecraft:mossy_stone_bricks
setblock ~-11 ~17 ~-23 minecraft:mossy_stone_bricks
setblock ~-11 ~18 ~-157 minecraft:mossy_stone_bricks
fill ~-11 ~18 ~-146 ~-10 ~18 ~-146 minecraft:mossy_stone_bricks
fill ~-11 ~18 ~-102 ~-10 ~18 ~-102 minecraft:mossy_stone_bricks
setblock ~-11 ~23 ~-135 minecraft:mossy_stone_bricks
fill ~-11 ~23 ~-132 ~-11 ~23 ~-131 minecraft:mossy_stone_bricks
setblock ~-11 ~23 ~-106 minecraft:mossy_stone_bricks
setblock ~-11 ~24 ~-127 minecraft:mossy_stone_bricks
setblock ~-11 ~24 ~-23 minecraft:mossy_stone_bricks
setblock ~-11 ~25 ~-140 minecraft:mossy_stone_bricks
setblock ~-11 ~25 ~-135 minecraft:mossy_stone_bricks
setblock ~-11 ~25 ~-115 minecraft:mossy_stone_bricks
setblock ~-11 ~25 ~-37 minecraft:mossy_stone_bricks
setblock ~-11 ~26 ~-128 minecraft:mossy_stone_bricks
setblock ~-11 ~26 ~-114 minecraft:mossy_stone_bricks
setblock ~-11 ~26 ~-36 minecraft:mossy_stone_bricks
fill ~-11 ~27 ~-142 ~-11 ~27 ~-141 minecraft:mossy_stone_bricks
setblock ~-11 ~27 ~-136 minecraft:mossy_stone_bricks
setblock ~-11 ~27 ~-118 minecraft:mossy_stone_bricks
setblock ~-11 ~27 ~-112 minecraft:mossy_stone_bricks
setblock ~-11 ~28 ~-141 minecraft:mossy_stone_bricks
setblock ~-11 ~28 ~-107 minecraft:mossy_stone_bricks
setblock ~-11 ~30 ~-129 minecraft:mossy_stone_bricks
setblock ~-11 ~30 ~-123 minecraft:mossy_stone_bricks
fill ~-11 ~30 ~-111 ~-11 ~31 ~-111 minecraft:mossy_stone_bricks
setblock ~-11 ~30 ~-34 minecraft:mossy_stone_bricks
setblock ~-11 ~30 ~-25 minecraft:mossy_stone_bricks
fill ~-11 ~30 ~-23 ~-11 ~30 ~-22 minecraft:mossy_stone_bricks
fill ~-11 ~32 ~-141 ~-11 ~33 ~-141 minecraft:mossy_stone_bricks
fill ~-11 ~32 ~-127 ~-11 ~33 ~-127 minecraft:mossy_stone_bricks
fill ~-11 ~32 ~-114 ~-11 ~33 ~-114 minecraft:mossy_stone_bricks
setblock ~-11 ~32 ~-38 minecraft:mossy_stone_bricks
setblock ~-11 ~34 ~-139 minecraft:mossy_stone_bricks
setblock ~-11 ~34 ~-119 minecraft:mossy_stone_bricks
setblock ~-11 ~35 ~-136 minecraft:mossy_stone_bricks
setblock ~-11 ~35 ~-111 minecraft:mossy_stone_bricks
setblock ~-11 ~35 ~-106 minecraft:mossy_stone_bricks
setblock ~-11 ~35 ~-104 minecraft:mossy_stone_bricks
setblock ~-11 ~36 ~-121 minecraft:mossy_stone_bricks
setblock ~-11 ~37 ~-143 minecraft:mossy_stone_bricks
setblock ~-11 ~37 ~-129 minecraft:mossy_stone_bricks
setblock ~-11 ~38 ~-138 minecraft:mossy_stone_bricks
setblock ~-11 ~38 ~-106 minecraft:mossy_stone_bricks
setblock ~-11 ~39 ~-144 minecraft:mossy_stone_bricks
setblock ~-11 ~39 ~-127 minecraft:mossy_stone_bricks
setblock ~-11 ~40 ~-119 minecraft:mossy_stone_bricks
setblock ~-11 ~41 ~-131 minecraft:mossy_stone_bricks
setblock ~-11 ~41 ~-122 minecraft:mossy_stone_bricks
setblock ~-11 ~41 ~-112 minecraft:mossy_stone_bricks
fill ~-11 ~41 ~-108 ~-11 ~42 ~-108 minecraft:mossy_stone_bricks
setblock ~-11 ~42 ~-138 minecraft:mossy_stone_bricks
setblock ~-11 ~42 ~-117 minecraft:mossy_stone_bricks
fill ~-11 ~42 ~-107 ~-11 ~42 ~-105 minecraft:mossy_stone_bricks
setblock ~-11 ~43 ~-137 minecraft:mossy_stone_bricks
setblock ~-11 ~44 ~-145 minecraft:mossy_stone_bricks
setblock ~-11 ~44 ~-130 minecraft:mossy_stone_bricks
setblock ~-11 ~44 ~-124 minecraft:mossy_stone_bricks
setblock ~-11 ~44 ~-111 minecraft:mossy_stone_bricks
fill ~-10 ~5 ~-156 ~-10 ~6 ~-156 minecraft:mossy_stone_bricks
setblock ~-10 ~5 ~-36 minecraft:mossy_stone_bricks
setblock ~-10 ~11 ~-156 minecraft:mossy_stone_bricks
setblock ~-10 ~12 ~-24 minecraft:mossy_stone_bricks
setblock ~-10 ~13 ~-145 minecraft:mossy_stone_bricks
fill ~-10 ~17 ~-25 ~-9 ~17 ~-25 minecraft:mossy_stone_bricks
setblock ~-10 ~20 ~-36 minecraft:mossy_stone_bricks
setblock ~-10 ~23 ~-35 minecraft:mossy_stone_bricks
fill ~-10 ~25 ~-24 ~-9 ~25 ~-24 minecraft:mossy_stone_bricks
fill ~-10 ~26 ~-124 ~-10 ~27 ~-124 minecraft:mossy_stone_bricks
setblock ~-10 ~26 ~-35 minecraft:mossy_stone_bricks
fill ~-10 ~31 ~-103 ~-10 ~32 ~-103 minecraft:mossy_stone_bricks
setblock ~-10 ~44 ~-141 minecraft:mossy_stone_bricks
fill ~-10 ~44 ~-129 ~-10 ~44 ~-128 minecraft:mossy_stone_bricks
setblock ~-10 ~45 ~-147 minecraft:mossy_stone_bricks
setblock ~-10 ~45 ~-125 minecraft:mossy_stone_bricks
setblock ~-10 ~46 ~-123 minecraft:mossy_stone_bricks
setblock ~-10 ~52 ~-122 minecraft:mossy_stone_bricks
setblock ~-10 ~55 ~-121 minecraft:mossy_stone_bricks
fill ~-10 ~59 ~-125 ~-9 ~59 ~-125 minecraft:mossy_stone_bricks
setblock ~-10 ~61 ~-123 minecraft:mossy_stone_bricks
setblock ~-10 ~63 ~-127 minecraft:mossy_stone_bricks
setblock ~-10 ~66 ~-124 minecraft:mossy_stone_bricks
fill ~-10 ~67 ~-120 ~-8 ~67 ~-120 minecraft:mossy_stone_bricks
setblock ~-9 ~1 ~-145 minecraft:mossy_stone_bricks
setblock ~-9 ~1 ~-33 minecraft:mossy_stone_bricks
setblock ~-9 ~2 ~-26 minecraft:mossy_stone_bricks
setblock ~-9 ~4 ~-34 minecraft:mossy_stone_bricks
setblock ~-9 ~5 ~-146 minecraft:mossy_stone_bricks
fill ~-9 ~6 ~-145 ~-9 ~7 ~-145 minecraft:mossy_stone_bricks
setblock ~-9 ~6 ~-33 minecraft:mossy_stone_bricks
fill ~-9 ~12 ~-40 ~-9 ~12 ~-39 minecraft:mossy_stone_bricks
setblock ~-9 ~12 ~-33 minecraft:mossy_stone_bricks
setblock ~-9 ~13 ~-160 minecraft:mossy_stone_bricks
setblock ~-9 ~13 ~-40 minecraft:mossy_stone_bricks
setblock ~-9 ~14 ~-102 minecraft:mossy_stone_bricks
setblock ~-9 ~14 ~-33 minecraft:mossy_stone_bricks
setblock ~-9 ~15 ~-39 minecraft:mossy_stone_bricks
fill ~-9 ~15 ~-27 ~-9 ~16 ~-27 minecraft:mossy_stone_bricks
setblock ~-9 ~16 ~-35 minecraft:mossy_stone_bricks
setblock ~-9 ~17 ~-102 minecraft:mossy_stone_bricks
setblock ~-9 ~17 ~-40 minecraft:mossy_stone_bricks
fill ~-9 ~17 ~-38 ~-9 ~17 ~-36 minecraft:mossy_stone_bricks
setblock ~-9 ~17 ~-24 minecraft:mossy_stone_bricks
setblock ~-9 ~19 ~-145 minecraft:mossy_stone_bricks
setblock ~-9 ~19 ~-36 minecraft:mossy_stone_bricks
fill ~-9 ~20 ~-103 ~-9 ~20 ~-102 minecraft:mossy_stone_bricks
setblock ~-9 ~20 ~-26 minecraft:mossy_stone_bricks
setblock ~-9 ~21 ~-27 minecraft:mossy_stone_bricks
setblock ~-9 ~22 ~-33 minecraft:mossy_stone_bricks
setblock ~-9 ~23 ~-102 minecraft:mossy_stone_bricks
fill ~-9 ~23 ~-26 ~-9 ~24 ~-26 minecraft:mossy_stone_bricks
setblock ~-9 ~25 ~-35 minecraft:mossy_stone_bricks
setblock ~-9 ~26 ~-102 minecraft:mossy_stone_bricks
setblock ~-9 ~29 ~-145 minecraft:mossy_stone_bricks
setblock ~-9 ~30 ~-28 minecraft:mossy_stone_bricks
setblock ~-9 ~31 ~-145 minecraft:mossy_stone_bricks
setblock ~-9 ~44 ~-134 minecraft:mossy_stone_bricks
setblock ~-9 ~45 ~-129 minecraft:mossy_stone_bricks
setblock ~-9 ~45 ~-101 minecraft:mossy_stone_bricks
setblock ~-9 ~47 ~-129 minecraft:mossy_stone_bricks
setblock ~-9 ~52 ~-123 minecraft:mossy_stone_bricks
setblock ~-9 ~53 ~-120 minecraft:mossy_stone_bricks
setblock ~-9 ~55 ~-119 minecraft:mossy_stone_bricks
setblock ~-9 ~56 ~-128 minecraft:mossy_stone_bricks
setblock ~-9 ~59 ~-129 minecraft:mossy_stone_bricks
setblock ~-9 ~60 ~-125 minecraft:mossy_stone_bricks
setblock ~-9 ~60 ~-122 minecraft:mossy_stone_bricks
setblock ~-9 ~62 ~-126 minecraft:mossy_stone_bricks
fill ~-9 ~64 ~-120 ~-9 ~64 ~-119 minecraft:mossy_stone_bricks
setblock ~-9 ~65 ~-126 minecraft:mossy_stone_bricks
fill ~-9 ~66 ~-118 ~-8 ~66 ~-118 minecraft:mossy_stone_bricks
setblock ~-9 ~67 ~-130 minecraft:mossy_stone_bricks
setblock ~-8 ~ ~-28 minecraft:mossy_stone_bricks
setblock ~-8 ~4 ~-160 minecraft:mossy_stone_bricks
setblock ~-8 ~4 ~-146 minecraft:mossy_stone_bricks
setblock ~-8 ~6 ~-160 minecraft:mossy_stone_bricks
fill ~-8 ~7 ~-146 ~-8 ~8 ~-146 minecraft:mossy_stone_bricks
setblock ~-8 ~7 ~-103 minecraft:mossy_stone_bricks
setblock ~-8 ~8 ~-160 minecraft:mossy_stone_bricks
setblock ~-8 ~8 ~-28 minecraft:mossy_stone_bricks
fill ~-8 ~9 ~-103 ~-8 ~9 ~-102 minecraft:mossy_stone_bricks
setblock ~-8 ~10 ~-32 minecraft:mossy_stone_bricks
setblock ~-8 ~12 ~-103 minecraft:mossy_stone_bricks
setblock ~-8 ~14 ~-103 minecraft:mossy_stone_bricks
setblock ~-8 ~22 ~-28 minecraft:mossy_stone_bricks
setblock ~-8 ~25 ~-34 minecraft:mossy_stone_bricks
setblock ~-8 ~26 ~-40 minecraft:mossy_stone_bricks
setblock ~-8 ~26 ~-29 minecraft:mossy_stone_bricks
setblock ~-8 ~31 ~-124 minecraft:mossy_stone_bricks
setblock ~-8 ~32 ~-103 minecraft:mossy_stone_bricks
setblock ~-8 ~39 ~-102 minecraft:mossy_stone_bricks
setblock ~-8 ~44 ~-130 minecraft:mossy_stone_bricks
setblock ~-8 ~44 ~-125 minecraft:mossy_stone_bricks
setblock ~-8 ~44 ~-122 minecraft:mossy_stone_bricks
setblock ~-8 ~44 ~-107 minecraft:mossy_stone_bricks
setblock ~-8 ~47 ~-130 minecraft:mossy_stone_bricks
fill ~-8 ~49 ~-121 ~-8 ~49 ~-120 minecraft:mossy_stone_bricks
setblock ~-8 ~50 ~-127 minecraft:mossy_stone_bricks
setblock ~-8 ~51 ~-130 minecraft:mossy_stone_bricks
setblock ~-8 ~54 ~-127 minecraft:mossy_stone_bricks
setblock ~-8 ~57 ~-120 minecraft:mossy_stone_bricks
setblock ~-8 ~59 ~-130 minecraft:mossy_stone_bricks
setblock ~-8 ~59 ~-128 minecraft:mossy_stone_bricks
setblock ~-8 ~63 ~-128 minecraft:mossy_stone_bricks
fill ~-8 ~67 ~-131 ~-6 ~67 ~-131 minecraft:mossy_stone_bricks
fill ~-8 ~67 ~-117 ~-6 ~67 ~-117 minecraft:mossy_stone_bricks
fill ~-7 ~ ~-74 ~-7 ~ ~-73 minecraft:mossy_stone_bricks
fill ~-7 ~1 ~-145 ~-7 ~2 ~-145 minecraft:mossy_stone_bricks
fill ~-7 ~4 ~-145 ~-6 ~4 ~-145 minecraft:mossy_stone_bricks
setblock ~-7 ~4 ~-26 minecraft:mossy_stone_bricks
setblock ~-7 ~5 ~-146 minecraft:mossy_stone_bricks
fill ~-7 ~10 ~-145 ~-6 ~10 ~-145 minecraft:mossy_stone_bricks
setblock ~-7 ~12 ~-161 minecraft:mossy_stone_bricks
setblock ~-7 ~14 ~-30 minecraft:mossy_stone_bricks
fill ~-7 ~18 ~-159 ~-6 ~18 ~-159 minecraft:mossy_stone_bricks
setblock ~-7 ~18 ~-103 minecraft:mossy_stone_bricks
setblock ~-7 ~18 ~-30 minecraft:mossy_stone_bricks
setblock ~-7 ~18 ~-25 minecraft:mossy_stone_bricks
setblock ~-7 ~19 ~-26 minecraft:mossy_stone_bricks
setblock ~-7 ~21 ~-160 minecraft:mossy_stone_bricks
setblock ~-7 ~27 ~-31 minecraft:mossy_stone_bricks
fill ~-7 ~28 ~-145 ~-6 ~28 ~-145 minecraft:mossy_stone_bricks
setblock ~-7 ~30 ~-31 minecraft:mossy_stone_bricks
setblock ~-7 ~30 ~-28 minecraft:mossy_stone_bricks
setblock ~-7 ~30 ~-26 minecraft:mossy_stone_bricks
setblock ~-7 ~32 ~-145 minecraft:mossy_stone_bricks
setblock ~-7 ~34 ~-146 minecraft:mossy_stone_bricks
setblock ~-7 ~34 ~-103 minecraft:mossy_stone_bricks
setblock ~-7 ~44 ~-138 minecraft:mossy_stone_bricks
setblock ~-7 ~44 ~-136 minecraft:mossy_stone_bricks
setblock ~-7 ~45 ~-131 minecraft:mossy_stone_bricks
fill ~-7 ~46 ~-101 ~-7 ~47 ~-101 minecraft:mossy_stone_bricks
setblock ~-7 ~52 ~-130 minecraft:mossy_stone_bricks
fill ~-7 ~53 ~-129 ~-7 ~54 ~-129 minecraft:mossy_stone_bricks
setblock ~-7 ~54 ~-117 minecraft:mossy_stone_bricks
setblock ~-7 ~56 ~-119 minecraft:mossy_stone_bricks
setblock ~-7 ~60 ~-118 minecraft:mossy_stone_bricks
setblock ~-7 ~63 ~-119 minecraft:mossy_stone_bricks
setblock ~-6 ~1 ~-162 minecraft:mossy_stone_bricks
setblock ~-6 ~1 ~-158 minecraft:mossy_stone_bricks
fill ~-6 ~4 ~-103 ~-6 ~5 ~-103 minecraft:mossy_stone_bricks
fill ~-6 ~5 ~-163 ~-6 ~6 ~-163 minecraft:mossy_stone_bricks
setblock ~-6 ~6 ~-162 minecraft:mossy_stone_bricks
setblock ~-6 ~10 ~-161 minecraft:mossy_stone_bricks
setblock ~-6 ~10 ~-158 minecraft:mossy_stone_bricks
setblock ~-6 ~11 ~-156 minecraft:mossy_stone_bricks
setblock ~-6 ~16 ~-103 minecraft:mossy_stone_bricks
setblock ~-6 ~17 ~-164 minecraft:mossy_stone_bricks
setblock ~-6 ~18 ~-145 minecraft:mossy_stone_bricks
setblock ~-6 ~21 ~-40 minecraft:mossy_stone_bricks
setblock ~-6 ~23 ~-146 minecraft:mossy_stone_bricks
setblock ~-6 ~24 ~-161 minecraft:mossy_stone_bricks
setblock ~-6 ~26 ~-165 minecraft:mossy_stone_bricks
fill ~-6 ~26 ~-155 ~-5 ~26 ~-155 minecraft:mossy_stone_bricks
setblock ~-6 ~26 ~-145 minecraft:mossy_stone_bricks
setblock ~-6 ~26 ~-102 minecraft:mossy_stone_bricks
setblock ~-6 ~27 ~-154 minecraft:mossy_stone_bricks
fill ~-6 ~29 ~-103 ~-5 ~29 ~-103 minecraft:mossy_stone_bricks
setblock ~-6 ~30 ~-33 minecraft:mossy_stone_bricks
setblock ~-6 ~36 ~-145 minecraft:mossy_stone_bricks
fill ~-6 ~36 ~-103 ~-5 ~36 ~-103 minecraft:mossy_stone_bricks
setblock ~-6 ~38 ~-145 minecraft:mossy_stone_bricks
setblock ~-6 ~41 ~-102 minecraft:mossy_stone_bricks
setblock ~-6 ~44 ~-145 minecraft:mossy_stone_bricks
fill ~-6 ~44 ~-131 ~-6 ~44 ~-130 minecraft:mossy_stone_bricks
setblock ~-6 ~44 ~-122 minecraft:mossy_stone_bricks
setblock ~-6 ~45 ~-101 minecraft:mossy_stone_bricks
fill ~-6 ~46 ~-117 ~-5 ~46 ~-117 minecraft:mossy_stone_bricks
setblock ~-6 ~51 ~-131 minecraft:mossy_stone_bricks
setblock ~-6 ~54 ~-116 minecraft:mossy_stone_bricks
setblock ~-6 ~56 ~-117 minecraft:mossy_stone_bricks
fill ~-6 ~66 ~-128 ~-6 ~66 ~-127 minecraft:mossy_stone_bricks
setblock ~-6 ~66 ~-115 minecraft:mossy_stone_bricks
setblock ~-5 ~3 ~-37 minecraft:mossy_stone_bricks
setblock ~-5 ~3 ~-33 minecraft:mossy_stone_bricks
setblock ~-5 ~4 ~-155 minecraft:mossy_stone_bricks
setblock ~-5 ~5 ~-103 minecraft:mossy_stone_bricks
setblock ~-5 ~5 ~-34 minecraft:mossy_stone_bricks
setblock ~-5 ~8 ~-145 minecraft:mossy_stone_bricks
setblock ~-5 ~8 ~-27 minecraft:mossy_stone_bricks
setblock ~-5 ~9 ~-165 minecraft:mossy_stone_bricks
setblock ~-5 ~10 ~-157 minecraft:mossy_stone_bricks
setblock ~-5 ~13 ~-103 minecraft:mossy_stone_bricks
setblock ~-5 ~14 ~-155 minecraft:mossy_stone_bricks
setblock ~-5 ~17 ~-165 minecraft:mossy_stone_bricks
setblock ~-5 ~18 ~-157 minecraft:mossy_stone_bricks
setblock ~-5 ~19 ~-40 minecraft:mossy_stone_bricks
setblock ~-5 ~20 ~-102 minecraft:mossy_stone_bricks
setblock ~-5 ~21 ~-165 minecraft:mossy_stone_bricks
setblock ~-5 ~21 ~-163 minecraft:mossy_stone_bricks
setblock ~-5 ~21 ~-145 minecraft:mossy_stone_bricks
setblock ~-5 ~21 ~-103 minecraft:mossy_stone_bricks
setblock ~-5 ~24 ~-157 minecraft:mossy_stone_bricks
fill ~-5 ~24 ~-31 ~-4 ~24 ~-31 minecraft:mossy_stone_bricks
setblock ~-5 ~26 ~-103 minecraft:mossy_stone_bricks
fill ~-5 ~35 ~-102 ~-5 ~36 ~-102 minecraft:mossy_stone_bricks
setblock ~-5 ~39 ~-102 minecraft:mossy_stone_bricks
setblock ~-5 ~40 ~-103 minecraft:mossy_stone_bricks
setblock ~-5 ~44 ~-123 minecraft:mossy_stone_bricks
setblock ~-5 ~50 ~-117 minecraft:mossy_stone_bricks
setblock ~-5 ~53 ~-133 minecraft:mossy_stone_bricks
setblock ~-5 ~54 ~-115 minecraft:mossy_stone_bricks
setblock ~-5 ~56 ~-133 minecraft:mossy_stone_bricks
setblock ~-5 ~58 ~-117 minecraft:mossy_stone_bricks
setblock ~-5 ~60 ~-131 minecraft:mossy_stone_bricks
setblock ~-5 ~62 ~-117 minecraft:mossy_stone_bricks
fill ~-4 ~-27 ~-121 ~31 ~-27 ~-121 minecraft:mossy_stone_bricks
fill ~-4 ~3 ~-102 ~-4 ~3 ~-101 minecraft:mossy_stone_bricks
fill ~-4 ~4 ~-166 ~-4 ~6 ~-166 minecraft:mossy_stone_bricks
fill ~-4 ~7 ~-154 ~-3 ~7 ~-154 minecraft:mossy_stone_bricks
setblock ~-4 ~8 ~-166 minecraft:mossy_stone_bricks
setblock ~-4 ~9 ~-37 minecraft:mossy_stone_bricks
setblock ~-4 ~10 ~-166 minecraft:mossy_stone_bricks
setblock ~-4 ~10 ~-146 minecraft:mossy_stone_bricks
setblock ~-4 ~12 ~-156 minecraft:mossy_stone_bricks
setblock ~-4 ~12 ~-102 minecraft:mossy_stone_bricks
setblock ~-4 ~17 ~-40 minecraft:mossy_stone_bricks
setblock ~-4 ~20 ~-154 minecraft:mossy_stone_bricks
setblock ~-4 ~20 ~-145 minecraft:mossy_stone_bricks
setblock ~-4 ~21 ~-166 minecraft:mossy_stone_bricks
fill ~-4 ~24 ~-36 ~-4 ~24 ~-35 minecraft:mossy_stone_bricks
setblock ~-4 ~26 ~-160 minecraft:mossy_stone_bricks
fill ~-4 ~29 ~-146 ~-4 ~29 ~-145 minecraft:mossy_stone_bricks
setblock ~-4 ~34 ~-146 minecraft:mossy_stone_bricks
setblock ~-4 ~35 ~-103 minecraft:mossy_stone_bricks
setblock ~-4 ~36 ~-145 minecraft:mossy_stone_bricks
setblock ~-4 ~39 ~-145 minecraft:mossy_stone_bricks
setblock ~-4 ~40 ~-102 minecraft:mossy_stone_bricks
setblock ~-4 ~44 ~-139 minecraft:mossy_stone_bricks
setblock ~-4 ~44 ~-134 minecraft:mossy_stone_bricks
setblock ~-4 ~44 ~-114 minecraft:mossy_stone_bricks
setblock ~-4 ~44 ~-110 minecraft:mossy_stone_bricks
setblock ~-4 ~45 ~-116 minecraft:mossy_stone_bricks
setblock ~-4 ~52 ~-115 minecraft:mossy_stone_bricks
setblock ~-4 ~66 ~-131 minecraft:mossy_stone_bricks
setblock ~-4 ~66 ~-122 minecraft:mossy_stone_bricks
fill ~-4 ~66 ~-120 ~-3 ~66 ~-119 minecraft:mossy_stone_bricks
setblock ~-4 ~68 ~-134 minecraft:mossy_stone_bricks
setblock ~-4 ~68 ~-114 minecraft:mossy_stone_bricks
fill ~-3 ~ ~-165 ~-3 ~1 ~-165 minecraft:mossy_stone_bricks
setblock ~-3 ~4 ~-165 minecraft:mossy_stone_bricks
fill ~-3 ~5 ~-154 ~-3 ~7 ~-154 minecraft:mossy_stone_bricks
fill ~-3 ~7 ~-102 ~-3 ~8 ~-102 minecraft:mossy_stone_bricks
setblock ~-3 ~8 ~-155 minecraft:mossy_stone_bricks
setblock ~-3 ~10 ~-36 minecraft:mossy_stone_bricks
fill ~-3 ~12 ~-154 ~-1 ~12 ~-154 minecraft:mossy_stone_bricks
setblock ~-3 ~16 ~-103 minecraft:mossy_stone_bricks
setblock ~-3 ~19 ~-146 minecraft:mossy_stone_bricks
setblock ~-3 ~20 ~-40 minecraft:mossy_stone_bricks
setblock ~-3 ~22 ~-165 minecraft:mossy_stone_bricks
setblock ~-3 ~23 ~-103 minecraft:mossy_stone_bricks
setblock ~-3 ~25 ~-103 minecraft:mossy_stone_bricks
setblock ~-3 ~31 ~-146 minecraft:mossy_stone_bricks
setblock ~-3 ~37 ~-102 minecraft:mossy_stone_bricks
setblock ~-3 ~39 ~-146 minecraft:mossy_stone_bricks
setblock ~-3 ~39 ~-102 minecraft:mossy_stone_bricks
setblock ~-3 ~40 ~-145 minecraft:mossy_stone_bricks
setblock ~-3 ~40 ~-103 minecraft:mossy_stone_bricks
setblock ~-3 ~41 ~-102 minecraft:mossy_stone_bricks
setblock ~-3 ~46 ~-101 minecraft:mossy_stone_bricks
setblock ~-3 ~58 ~-114 minecraft:mossy_stone_bricks
setblock ~-3 ~59 ~-134 minecraft:mossy_stone_bricks
setblock ~-3 ~62 ~-116 minecraft:mossy_stone_bricks
setblock ~-3 ~62 ~-114 minecraft:mossy_stone_bricks
fill ~-3 ~63 ~-134 ~-2 ~63 ~-134 minecraft:mossy_stone_bricks
setblock ~-3 ~64 ~-132 minecraft:mossy_stone_bricks
setblock ~-3 ~66 ~-125 minecraft:mossy_stone_bricks
setblock ~-3 ~68 ~-135 minecraft:mossy_stone_bricks
setblock ~-3 ~68 ~-113 minecraft:mossy_stone_bricks
setblock ~-2 ~ ~-154 minecraft:mossy_stone_bricks
setblock ~-2 ~3 ~-166 minecraft:mossy_stone_bricks
fill ~-2 ~6 ~-167 ~1 ~6 ~-167 minecraft:mossy_stone_bricks
fill ~-2 ~11 ~-32 ~-1 ~11 ~-32 minecraft:mossy_stone_bricks
setblock ~-2 ~19 ~-167 minecraft:mossy_stone_bricks
fill ~-2 ~19 ~-154 ~-1 ~19 ~-154 minecraft:mossy_stone_bricks
setblock ~-2 ~19 ~-25 minecraft:mossy_stone_bricks
setblock ~-2 ~20 ~-103 minecraft:mossy_stone_bricks
fill ~-2 ~21 ~-25 ~-1 ~21 ~-25 minecraft:mossy_stone_bricks
setblock ~-2 ~22 ~-153 minecraft:mossy_stone_bricks
setblock ~-2 ~23 ~-40 minecraft:mossy_stone_bricks
fill ~-2 ~24 ~-167 ~-1 ~24 ~-167 minecraft:mossy_stone_bricks
setblock ~-2 ~24 ~-103 minecraft:mossy_stone_bricks
setblock ~-2 ~24 ~-36 minecraft:mossy_stone_bricks
fill ~-2 ~25 ~-26 ~-1 ~25 ~-26 minecraft:mossy_stone_bricks
setblock ~-2 ~26 ~-158 minecraft:mossy_stone_bricks
setblock ~-2 ~38 ~-145 minecraft:mossy_stone_bricks
setblock ~-2 ~44 ~-143 minecraft:mossy_stone_bricks
setblock ~-2 ~44 ~-140 minecraft:mossy_stone_bricks
setblock ~-2 ~44 ~-138 minecraft:mossy_stone_bricks
fill ~-2 ~44 ~-135 ~-2 ~44 ~-134 minecraft:mossy_stone_bricks
setblock ~-2 ~44 ~-127 minecraft:mossy_stone_bricks
fill ~-2 ~50 ~-115 ~-2 ~50 ~-114 minecraft:mossy_stone_bricks
fill ~-2 ~51 ~-134 ~-1 ~51 ~-134 minecraft:mossy_stone_bricks
setblock ~-2 ~54 ~-133 minecraft:mossy_stone_bricks
setblock ~-2 ~59 ~-115 minecraft:mossy_stone_bricks
setblock ~-2 ~61 ~-134 minecraft:mossy_stone_bricks
setblock ~-2 ~61 ~-114 minecraft:mossy_stone_bricks
fill ~-2 ~63 ~-115 ~-2 ~64 ~-115 minecraft:mossy_stone_bricks
setblock ~-2 ~66 ~-119 minecraft:mossy_stone_bricks
setblock ~-2 ~67 ~-135 minecraft:mossy_stone_bricks
fill ~-1 ~-10 ~-145 ~24 ~-2 ~-103 minecraft:mossy_stone_bricks
setblock ~-1 ~7 ~-167 minecraft:mossy_stone_bricks
setblock ~-1 ~8 ~-166 minecraft:mossy_stone_bricks
setblock ~-1 ~8 ~-103 minecraft:mossy_stone_bricks
setblock ~-1 ~11 ~-35 minecraft:mossy_stone_bricks
fill ~-1 ~14 ~-26 ~-1 ~14 ~-25 minecraft:mossy_stone_bricks
setblock ~-1 ~16 ~-102 minecraft:mossy_stone_bricks
fill ~-1 ~18 ~-146 ~-1 ~18 ~-145 minecraft:mossy_stone_bricks
setblock ~-1 ~19 ~-145 minecraft:mossy_stone_bricks
fill ~-1 ~21 ~-154 ~-1 ~22 ~-154 minecraft:mossy_stone_bricks
setblock ~-1 ~23 ~-102 minecraft:mossy_stone_bricks
fill ~-1 ~24 ~-124 ~-1 ~25 ~-124 minecraft:mossy_stone_bricks
setblock ~-1 ~24 ~-40 minecraft:mossy_stone_bricks
setblock ~-1 ~24 ~-33 minecraft:mossy_stone_bricks
setblock ~-1 ~25 ~-103 minecraft:mossy_stone_bricks
setblock ~-1 ~26 ~-160 minecraft:mossy_stone_bricks
setblock ~-1 ~26 ~-102 minecraft:mossy_stone_bricks
fill ~-1 ~29 ~-103 ~1 ~29 ~-103 minecraft:mossy_stone_bricks
setblock ~-1 ~41 ~-103 minecraft:mossy_stone_bricks
setblock ~-1 ~42 ~-146 minecraft:mossy_stone_bricks
setblock ~-1 ~44 ~-126 minecraft:mossy_stone_bricks
setblock ~-1 ~44 ~-119 minecraft:mossy_stone_bricks
fill ~-1 ~46 ~-101 ~-1 ~47 ~-101 minecraft:mossy_stone_bricks
fill ~-1 ~51 ~-115 ~ ~51 ~-115 minecraft:mossy_stone_bricks
setblock ~-1 ~54 ~-114 minecraft:mossy_stone_bricks
setblock ~-1 ~57 ~-114 minecraft:mossy_stone_bricks
setblock ~-1 ~63 ~-133 minecraft:mossy_stone_bricks
setblock ~-1 ~66 ~-135 minecraft:mossy_stone_bricks
fill ~ ~3 ~-167 ~ ~6 ~-167 minecraft:mossy_stone_bricks
setblock ~ ~9 ~-102 minecraft:mossy_stone_bricks
setblock ~ ~15 ~-102 minecraft:mossy_stone_bricks
setblock ~ ~16 ~-154 minecraft:mossy_stone_bricks
setblock ~ ~20 ~-145 minecraft:mossy_stone_bricks
setblock ~ ~22 ~-154 minecraft:mossy_stone_bricks
fill ~ ~24 ~-39 ~ ~24 ~-38 minecraft:mossy_stone_bricks
setblock ~ ~29 ~-146 minecraft:mossy_stone_bricks
setblock ~ ~35 ~-102 minecraft:mossy_stone_bricks
fill ~ ~40 ~-102 ~1 ~40 ~-102 minecraft:mossy_stone_bricks
setblock ~ ~41 ~-146 minecraft:mossy_stone_bricks
fill ~ ~44 ~-147 ~2 ~44 ~-147 minecraft:mossy_stone_bricks
setblock ~ ~46 ~-134 minecraft:mossy_stone_bricks
setblock ~ ~58 ~-115 minecraft:mossy_stone_bricks
setblock ~ ~59 ~-114 minecraft:mossy_stone_bricks
fill ~ ~66 ~-132 ~1 ~66 ~-132 minecraft:mossy_stone_bricks
setblock ~ ~66 ~-128 minecraft:mossy_stone_bricks
setblock ~1 ~ ~-166 minecraft:mossy_stone_bricks
setblock ~1 ~3 ~-166 minecraft:mossy_stone_bricks
fill ~1 ~8 ~-154 ~1 ~8 ~-153 minecraft:mossy_stone_bricks
setblock ~1 ~10 ~-146 minecraft:mossy_stone_bricks
setblock ~1 ~10 ~-102 minecraft:mossy_stone_bricks
setblock ~1 ~11 ~-37 minecraft:mossy_stone_bricks
setblock ~1 ~15 ~-154 minecraft:mossy_stone_bricks
fill ~1 ~18 ~-26 ~1 ~18 ~-25 minecraft:mossy_stone_bricks
fill ~1 ~19 ~-146 ~1 ~20 ~-146 minecraft:mossy_stone_bricks
setblock ~1 ~19 ~-102 minecraft:mossy_stone_bricks
setblock ~1 ~20 ~-167 minecraft:mossy_stone_bricks
setblock ~1 ~20 ~-153 minecraft:mossy_stone_bricks
setblock ~1 ~21 ~-102 minecraft:mossy_stone_bricks
setblock ~1 ~23 ~-25 minecraft:mossy_stone_bricks
setblock ~1 ~24 ~-153 minecraft:mossy_stone_bricks
setblock ~1 ~24 ~-40 minecraft:mossy_stone_bricks
fill ~1 ~24 ~-31 ~1 ~24 ~-28 minecraft:mossy_stone_bricks
fill ~1 ~26 ~-157 ~2 ~26 ~-157 minecraft:mossy_stone_bricks
setblock ~1 ~26 ~-156 minecraft:mossy_stone_bricks
setblock ~1 ~27 ~-146 minecraft:mossy_stone_bricks
setblock ~1 ~30 ~-146 minecraft:mossy_stone_bricks
setblock ~1 ~34 ~-102 minecraft:mossy_stone_bricks
setblock ~1 ~40 ~-146 minecraft:mossy_stone_bricks
setblock ~1 ~42 ~-145 minecraft:mossy_stone_bricks
fill ~1 ~44 ~-136 ~3 ~44 ~-136 minecraft:mossy_stone_bricks
fill ~1 ~44 ~-128 ~1 ~44 ~-127 minecraft:mossy_stone_bricks
fill ~1 ~44 ~-116 ~1 ~44 ~-115 minecraft:mossy_stone_bricks
setblock ~1 ~47 ~-133 minecraft:mossy_stone_bricks
setblock ~1 ~48 ~-134 minecraft:mossy_stone_bricks
fill ~1 ~59 ~-134 ~1 ~59 ~-133 minecraft:mossy_stone_bricks
fill ~1 ~60 ~-134 ~2 ~60 ~-134 minecraft:mossy_stone_bricks
setblock ~1 ~61 ~-114 minecraft:mossy_stone_bricks
setblock ~1 ~66 ~-129 minecraft:mossy_stone_bricks
fill ~1 ~66 ~-122 ~3 ~66 ~-122 minecraft:mossy_stone_bricks
fill ~2 ~1 ~-154 ~2 ~2 ~-152 minecraft:mossy_stone_bricks
setblock ~2 ~3 ~-153 minecraft:mossy_stone_bricks
setblock ~2 ~4 ~-154 minecraft:mossy_stone_bricks
setblock ~2 ~9 ~-103 minecraft:mossy_stone_bricks
setblock ~2 ~11 ~-38 minecraft:mossy_stone_bricks
fill ~2 ~12 ~-154 ~2 ~12 ~-153 minecraft:mossy_stone_bricks
setblock ~2 ~14 ~-154 minecraft:mossy_stone_bricks
setblock ~2 ~15 ~-153 minecraft:mossy_stone_bricks
setblock ~2 ~15 ~-102 minecraft:mossy_stone_bricks
setblock ~2 ~18 ~-40 minecraft:mossy_stone_bricks
fill ~2 ~19 ~-166 ~3 ~19 ~-166 minecraft:mossy_stone_bricks
setblock ~2 ~20 ~-26 minecraft:mossy_stone_bricks
setblock ~2 ~22 ~-167 minecraft:mossy_stone_bricks
setblock ~2 ~23 ~-26 minecraft:mossy_stone_bricks
setblock ~2 ~24 ~-38 minecraft:mossy_stone_bricks
setblock ~2 ~26 ~-163 minecraft:mossy_stone_bricks
setblock ~2 ~26 ~-159 minecraft:mossy_stone_bricks
setblock ~2 ~26 ~-124 minecraft:mossy_stone_bricks
setblock ~2 ~26 ~-26 minecraft:mossy_stone_bricks
setblock ~2 ~32 ~-146 minecraft:mossy_stone_bricks
setblock ~2 ~34 ~-146 minecraft:mossy_stone_bricks
fill ~2 ~38 ~-145 ~3 ~38 ~-145 minecraft:mossy_stone_bricks
setblock ~2 ~39 ~-102 minecraft:mossy_stone_bricks
setblock ~2 ~44 ~-141 minecraft:mossy_stone_bricks
setblock ~2 ~44 ~-131 minecraft:mossy_stone_bricks
setblock ~2 ~44 ~-118 minecraft:mossy_stone_bricks
fill ~2 ~44 ~-115 ~2 ~45 ~-115 minecraft:mossy_stone_bricks
setblock ~2 ~51 ~-115 minecraft:mossy_stone_bricks
setblock ~2 ~54 ~-133 minecraft:mossy_stone_bricks
setblock ~2 ~58 ~-133 minecraft:mossy_stone_bricks
setblock ~2 ~63 ~-115 minecraft:mossy_stone_bricks
fill ~2 ~64 ~-133 ~2 ~65 ~-133 minecraft:mossy_stone_bricks
setblock ~2 ~66 ~-134 minecraft:mossy_stone_bricks
setblock ~2 ~66 ~-126 minecraft:mossy_stone_bricks
fill ~2 ~66 ~-123 ~2 ~66 ~-122 minecraft:mossy_stone_bricks
setblock ~3 ~6 ~-154 minecraft:mossy_stone_bricks
setblock ~3 ~7 ~-166 minecraft:mossy_stone_bricks
setblock ~3 ~8 ~-165 minecraft:mossy_stone_bricks
setblock ~3 ~10 ~-146 minecraft:mossy_stone_bricks
setblock ~3 ~10 ~-35 minecraft:mossy_stone_bricks
fill ~3 ~14 ~-166 ~3 ~14 ~-165 minecraft:mossy_stone_bricks
setblock ~3 ~14 ~-26 minecraft:mossy_stone_bricks
fill ~3 ~15 ~-103 ~3 ~16 ~-103 minecraft:mossy_stone_bricks
fill ~3 ~16 ~-146 ~4 ~16 ~-146 minecraft:mossy_stone_bricks
fill ~3 ~18 ~-166 ~4 ~18 ~-166 minecraft:mossy_stone_bricks
setblock ~3 ~18 ~-145 minecraft:mossy_stone_bricks
setblock ~3 ~19 ~-25 minecraft:mossy_stone_bricks
setblock ~3 ~20 ~-155 minecraft:mossy_stone_bricks
setblock ~3 ~23 ~-146 minecraft:mossy_stone_bricks
setblock ~3 ~24 ~-102 minecraft:mossy_stone_bricks
setblock ~3 ~24 ~-34 minecraft:mossy_stone_bricks
fill ~3 ~25 ~-103 ~4 ~25 ~-103 minecraft:mossy_stone_bricks
setblock ~3 ~28 ~-102 minecraft:mossy_stone_bricks
setblock ~3 ~29 ~-124 minecraft:mossy_stone_bricks
fill ~3 ~30 ~-103 ~3 ~31 ~-103 minecraft:mossy_stone_bricks
setblock ~3 ~36 ~-102 minecraft:mossy_stone_bricks
fill ~3 ~39 ~-145 ~4 ~39 ~-145 minecraft:mossy_stone_bricks
setblock ~3 ~44 ~-124 minecraft:mossy_stone_bricks
setblock ~3 ~44 ~-121 minecraft:mossy_stone_bricks
setblock ~3 ~44 ~-117 minecraft:mossy_stone_bricks
setblock ~3 ~44 ~-106 minecraft:mossy_stone_bricks
setblock ~3 ~45 ~-114 minecraft:mossy_stone_bricks
setblock ~3 ~46 ~-101 minecraft:mossy_stone_bricks
setblock ~3 ~47 ~-114 minecraft:mossy_stone_bricks
fill ~3 ~49 ~-132 ~4 ~49 ~-132 minecraft:mossy_stone_bricks
setblock ~3 ~52 ~-114 minecraft:mossy_stone_bricks
fill ~3 ~55 ~-114 ~3 ~56 ~-114 minecraft:mossy_stone_bricks
setblock ~3 ~57 ~-132 minecraft:mossy_stone_bricks
setblock ~3 ~59 ~-132 minecraft:mossy_stone_bricks
setblock ~3 ~61 ~-116 minecraft:mossy_stone_bricks
setblock ~3 ~67 ~-113 minecraft:mossy_stone_bricks
setblock ~4 ~1 ~-156 minecraft:mossy_stone_bricks
fill ~4 ~7 ~-156 ~4 ~8 ~-156 minecraft:mossy_stone_bricks
setblock ~4 ~10 ~-166 minecraft:mossy_stone_bricks
setblock ~4 ~14 ~-164 minecraft:mossy_stone_bricks
fill ~4 ~15 ~-40 ~5 ~15 ~-40 minecraft:mossy_stone_bricks
setblock ~4 ~17 ~-164 minecraft:mossy_stone_bricks
setblock ~4 ~18 ~-102 minecraft:mossy_stone_bricks
setblock ~4 ~20 ~-40 minecraft:mossy_stone_bricks
setblock ~4 ~23 ~-166 minecraft:mossy_stone_bricks
setblock ~4 ~23 ~-124 minecraft:mossy_stone_bricks
fill ~4 ~24 ~-32 ~4 ~24 ~-31 minecraft:mossy_stone_bricks
setblock ~4 ~24 ~-28 minecraft:mossy_stone_bricks
setblock ~4 ~25 ~-164 minecraft:mossy_stone_bricks
setblock ~4 ~26 ~-162 minecraft:mossy_stone_bricks
fill ~4 ~31 ~-145 ~4 ~32 ~-145 minecraft:mossy_stone_bricks
setblock ~4 ~31 ~-103 minecraft:mossy_stone_bricks
setblock ~4 ~37 ~-145 minecraft:mossy_stone_bricks
setblock ~4 ~44 ~-111 minecraft:mossy_stone_bricks
setblock ~4 ~48 ~-133 minecraft:mossy_stone_bricks
fill ~4 ~51 ~-116 ~4 ~51 ~-115 minecraft:mossy_stone_bricks
setblock ~5 ~ ~-70 minecraft:mossy_stone_bricks
fill ~5 ~3 ~-165 ~5 ~4 ~-165 minecraft:mossy_stone_bricks
setblock ~5 ~4 ~-163 minecraft:mossy_stone_bricks
setblock ~5 ~4 ~-157 minecraft:mossy_stone_bricks
fill ~5 ~4 ~-29 ~5 ~4 ~-28 minecraft:mossy_stone_bricks
fill ~5 ~5 ~-38 ~5 ~5 ~-37 minecraft:mossy_stone_bricks
setblock ~5 ~5 ~-29 minecraft:mossy_stone_bricks
setblock ~5 ~5 ~-26 minecraft:mossy_stone_bricks
setblock ~5 ~6 ~-103 minecraft:mossy_stone_bricks
setblock ~5 ~6 ~-27 minecraft:mossy_stone_bricks
fill ~5 ~7 ~-40 ~6 ~7 ~-40 minecraft:mossy_stone_bricks
fill ~5 ~7 ~-32 ~5 ~7 ~-29 minecraft:mossy_stone_bricks
setblock ~5 ~10 ~-155 minecraft:mossy_stone_bricks
setblock ~5 ~10 ~-146 minecraft:mossy_stone_bricks
setblock ~5 ~11 ~-40 minecraft:mossy_stone_bricks
setblock ~5 ~14 ~-26 minecraft:mossy_stone_bricks
setblock ~5 ~15 ~-163 minecraft:mossy_stone_bricks
setblock ~5 ~19 ~-103 minecraft:mossy_stone_bricks
fill ~5 ~22 ~-40 ~5 ~23 ~-40 minecraft:mossy_stone_bricks
setblock ~5 ~23 ~-155 minecraft:mossy_stone_bricks
setblock ~5 ~25 ~-26 minecraft:mossy_stone_bricks
setblock ~5 ~26 ~-158 minecraft:mossy_stone_bricks
fill ~5 ~26 ~-146 ~6 ~26 ~-146 minecraft:mossy_stone_bricks
fill ~5 ~28 ~-146 ~6 ~28 ~-146 minecraft:mossy_stone_bricks
setblock ~5 ~31 ~-124 minecraft:mossy_stone_bricks
setblock ~5 ~34 ~-145 minecraft:mossy_stone_bricks
setblock ~5 ~36 ~-145 minecraft:mossy_stone_bricks
setblock ~5 ~44 ~-141 minecraft:mossy_stone_bricks
fill ~5 ~44 ~-132 ~6 ~44 ~-132 minecraft:mossy_stone_bricks
setblock ~5 ~44 ~-123 minecraft:mossy_stone_bricks
setblock ~5 ~44 ~-114 minecraft:mossy_stone_bricks
setblock ~5 ~45 ~-133 minecraft:mossy_stone_bricks
setblock ~5 ~47 ~-117 minecraft:mossy_stone_bricks
setblock ~5 ~54 ~-115 minecraft:mossy_stone_bricks
setblock ~5 ~57 ~-131 minecraft:mossy_stone_bricks
setblock ~5 ~59 ~-131 minecraft:mossy_stone_bricks
setblock ~5 ~61 ~-133 minecraft:mossy_stone_bricks
setblock ~5 ~66 ~-127 minecraft:mossy_stone_bricks
setblock ~5 ~66 ~-125 minecraft:mossy_stone_bricks
fill ~6 ~ ~-161 ~6 ~ ~-160 minecraft:mossy_stone_bricks
setblock ~6 ~2 ~-160 minecraft:mossy_stone_bricks
setblock ~6 ~5 ~-156 minecraft:mossy_stone_bricks
setblock ~6 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~6 ~12 ~-158 minecraft:mossy_stone_bricks
setblock ~6 ~12 ~-156 minecraft:mossy_stone_bricks
setblock ~6 ~12 ~-40 minecraft:mossy_stone_bricks
setblock ~6 ~13 ~-164 minecraft:mossy_stone_bricks
setblock ~6 ~14 ~-159 minecraft:mossy_stone_bricks
setblock ~6 ~15 ~-164 minecraft:mossy_stone_bricks
fill ~6 ~16 ~-161 ~6 ~17 ~-161 minecraft:mossy_stone_bricks
setblock ~6 ~16 ~-156 minecraft:mossy_stone_bricks
setblock ~6 ~19 ~-164 minecraft:mossy_stone_bricks
fill ~6 ~19 ~-145 ~7 ~19 ~-145 minecraft:mossy_stone_bricks
setblock ~6 ~20 ~-25 minecraft:mossy_stone_bricks
fill ~6 ~22 ~-157 ~6 ~23 ~-157 minecraft:mossy_stone_bricks
fill ~6 ~23 ~-158 ~6 ~23 ~-157 minecraft:mossy_stone_bricks
setblock ~6 ~24 ~-37 minecraft:mossy_stone_bricks
fill ~6 ~24 ~-33 ~6 ~24 ~-32 minecraft:mossy_stone_bricks
setblock ~6 ~28 ~-154 minecraft:mossy_stone_bricks
setblock ~6 ~30 ~-145 minecraft:mossy_stone_bricks
fill ~6 ~42 ~-145 ~7 ~42 ~-145 minecraft:mossy_stone_bricks
setblock ~6 ~44 ~-145 minecraft:mossy_stone_bricks
setblock ~6 ~44 ~-140 minecraft:mossy_stone_bricks
fill ~6 ~45 ~-131 ~7 ~45 ~-131 minecraft:mossy_stone_bricks
setblock ~6 ~49 ~-117 minecraft:mossy_stone_bricks
setblock ~6 ~51 ~-131 minecraft:mossy_stone_bricks
setblock ~6 ~53 ~-117 minecraft:mossy_stone_bricks
setblock ~6 ~61 ~-131 minecraft:mossy_stone_bricks
setblock ~6 ~64 ~-116 minecraft:mossy_stone_bricks
setblock ~6 ~66 ~-124 minecraft:mossy_stone_bricks
setblock ~6 ~67 ~-133 minecraft:mossy_stone_bricks
fill ~7 ~3 ~-162 ~7 ~4 ~-162 minecraft:mossy_stone_bricks
setblock ~7 ~4 ~-26 minecraft:mossy_stone_bricks
setblock ~7 ~5 ~-145 minecraft:mossy_stone_bricks
setblock ~7 ~5 ~-102 minecraft:mossy_stone_bricks
fill ~7 ~6 ~-146 ~8 ~6 ~-146 minecraft:mossy_stone_bricks
setblock ~7 ~7 ~-156 minecraft:mossy_stone_bricks
setblock ~7 ~8 ~-103 minecraft:mossy_stone_bricks
setblock ~7 ~10 ~-102 minecraft:mossy_stone_bricks
fill ~7 ~13 ~-32 ~8 ~13 ~-32 minecraft:mossy_stone_bricks
setblock ~7 ~13 ~-31 minecraft:mossy_stone_bricks
setblock ~7 ~16 ~-145 minecraft:mossy_stone_bricks
setblock ~7 ~16 ~-40 minecraft:mossy_stone_bricks
setblock ~7 ~16 ~-26 minecraft:mossy_stone_bricks
fill ~7 ~17 ~-32 ~8 ~17 ~-32 minecraft:mossy_stone_bricks
setblock ~7 ~18 ~-31 minecraft:mossy_stone_bricks
setblock ~7 ~19 ~-26 minecraft:mossy_stone_bricks
setblock ~7 ~20 ~-145 minecraft:mossy_stone_bricks
setblock ~7 ~21 ~-161 minecraft:mossy_stone_bricks
setblock ~7 ~23 ~-102 minecraft:mossy_stone_bricks
setblock ~7 ~23 ~-25 minecraft:mossy_stone_bricks
fill ~7 ~24 ~-26 ~8 ~24 ~-26 minecraft:mossy_stone_bricks
setblock ~7 ~25 ~-31 minecraft:mossy_stone_bricks
setblock ~7 ~26 ~-158 minecraft:mossy_stone_bricks
setblock ~7 ~26 ~-29 minecraft:mossy_stone_bricks
setblock ~7 ~27 ~-157 minecraft:mossy_stone_bricks
setblock ~7 ~28 ~-163 minecraft:mossy_stone_bricks
setblock ~7 ~28 ~-102 minecraft:mossy_stone_bricks
setblock ~7 ~28 ~-30 minecraft:mossy_stone_bricks
fill ~7 ~31 ~-26 ~7 ~32 ~-26 minecraft:mossy_stone_bricks
fill ~7 ~35 ~-146 ~7 ~35 ~-145 minecraft:mossy_stone_bricks
setblock ~7 ~35 ~-103 minecraft:mossy_stone_bricks
fill ~7 ~36 ~-102 ~7 ~37 ~-102 minecraft:mossy_stone_bricks
setblock ~7 ~39 ~-146 minecraft:mossy_stone_bricks
fill ~7 ~39 ~-103 ~7 ~39 ~-102 minecraft:mossy_stone_bricks
setblock ~7 ~44 ~-147 minecraft:mossy_stone_bricks
fill ~7 ~44 ~-144 ~7 ~44 ~-143 minecraft:mossy_stone_bricks
setblock ~7 ~44 ~-139 minecraft:mossy_stone_bricks
fill ~7 ~44 ~-130 ~7 ~45 ~-130 minecraft:mossy_stone_bricks
fill ~7 ~44 ~-114 ~8 ~44 ~-114 minecraft:mossy_stone_bricks
setblock ~7 ~45 ~-118 minecraft:mossy_stone_bricks
fill ~7 ~47 ~-119 ~7 ~48 ~-119 minecraft:mossy_stone_bricks
setblock ~7 ~49 ~-131 minecraft:mossy_stone_bricks
fill ~7 ~50 ~-130 ~8 ~50 ~-130 minecraft:mossy_stone_bricks
setblock ~7 ~52 ~-129 minecraft:mossy_stone_bricks
setblock ~7 ~59 ~-129 minecraft:mossy_stone_bricks
fill ~7 ~62 ~-131 ~7 ~62 ~-130 minecraft:mossy_stone_bricks
setblock ~8 ~ ~-103 minecraft:mossy_stone_bricks
setblock ~8 ~ ~-70 minecraft:mossy_stone_bricks
setblock ~8 ~1 ~-32 minecraft:mossy_stone_bricks
setblock ~8 ~3 ~-156 minecraft:mossy_stone_bricks
setblock ~8 ~3 ~-102 minecraft:mossy_stone_bricks
setblock ~8 ~3 ~-40 minecraft:mossy_stone_bricks
setblock ~8 ~3 ~-31 minecraft:mossy_stone_bricks
setblock ~8 ~3 ~-26 minecraft:mossy_stone_bricks
setblock ~8 ~4 ~-146 minecraft:mossy_stone_bricks
setblock ~8 ~7 ~-160 minecraft:mossy_stone_bricks
setblock ~8 ~7 ~-26 minecraft:mossy_stone_bricks
fill ~8 ~8 ~-146 ~9 ~8 ~-146 minecraft:mossy_stone_bricks
setblock ~8 ~9 ~-40 minecraft:mossy_stone_bricks
setblock ~8 ~11 ~-26 minecraft:mossy_stone_bricks
setblock ~8 ~12 ~-156 minecraft:mossy_stone_bricks
setblock ~8 ~13 ~-34 minecraft:mossy_stone_bricks
setblock ~8 ~14 ~-33 minecraft:mossy_stone_bricks
fill ~8 ~15 ~-32 ~8 ~17 ~-32 minecraft:mossy_stone_bricks
fill ~8 ~15 ~-27 ~9 ~15 ~-27 minecraft:mossy_stone_bricks
setblock ~8 ~16 ~-156 minecraft:mossy_stone_bricks
setblock ~8 ~17 ~-31 minecraft:mossy_stone_bricks
setblock ~8 ~19 ~-28 minecraft:mossy_stone_bricks
setblock ~8 ~20 ~-31 minecraft:mossy_stone_bricks
setblock ~8 ~24 ~-124 minecraft:mossy_stone_bricks
setblock ~8 ~24 ~-38 minecraft:mossy_stone_bricks
setblock ~8 ~25 ~-26 minecraft:mossy_stone_bricks
setblock ~8 ~27 ~-103 minecraft:mossy_stone_bricks
setblock ~8 ~28 ~-162 minecraft:mossy_stone_bricks
setblock ~8 ~28 ~-33 minecraft:mossy_stone_bricks
setblock ~8 ~28 ~-27 minecraft:mossy_stone_bricks
fill ~8 ~31 ~-102 ~8 ~32 ~-102 minecraft:mossy_stone_bricks
setblock ~8 ~31 ~-24 minecraft:mossy_stone_bricks
setblock ~8 ~32 ~-25 minecraft:mossy_stone_bricks
setblock ~8 ~44 ~-141 minecraft:mossy_stone_bricks
fill ~8 ~44 ~-127 ~9 ~44 ~-127 minecraft:mossy_stone_bricks
setblock ~8 ~46 ~-130 minecraft:mossy_stone_bricks
setblock ~8 ~47 ~-120 minecraft:mossy_stone_bricks
fill ~8 ~54 ~-121 ~8 ~54 ~-120 minecraft:mossy_stone_bricks
setblock ~8 ~63 ~-128 minecraft:mossy_stone_bricks
setblock ~8 ~67 ~-132 minecraft:mossy_stone_bricks
setblock ~9 ~2 ~-156 minecraft:mossy_stone_bricks
setblock ~9 ~3 ~-24 minecraft:mossy_stone_bricks
setblock ~9 ~5 ~-40 minecraft:mossy_stone_bricks
setblock ~9 ~6 ~-156 minecraft:mossy_stone_bricks
setblock ~9 ~6 ~-24 minecraft:mossy_stone_bricks
fill ~9 ~7 ~-145 ~10 ~7 ~-145 minecraft:mossy_stone_bricks
setblock ~9 ~8 ~-103 minecraft:mossy_stone_bricks
fill ~9 ~8 ~-25 ~10 ~8 ~-25 minecraft:mossy_stone_bricks
setblock ~9 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~9 ~9 ~-102 minecraft:mossy_stone_bricks
setblock ~9 ~9 ~-24 minecraft:mossy_stone_bricks
setblock ~9 ~12 ~-160 minecraft:mossy_stone_bricks
setblock ~9 ~12 ~-37 minecraft:mossy_stone_bricks
setblock ~9 ~13 ~-33 minecraft:mossy_stone_bricks
setblock ~9 ~14 ~-40 minecraft:mossy_stone_bricks
fill ~9 ~14 ~-38 ~9 ~14 ~-37 minecraft:mossy_stone_bricks
fill ~9 ~14 ~-27 ~9 ~15 ~-27 minecraft:mossy_stone_bricks
setblock ~9 ~17 ~-146 minecraft:mossy_stone_bricks
setblock ~9 ~18 ~-159 minecraft:mossy_stone_bricks
setblock ~9 ~18 ~-145 minecraft:mossy_stone_bricks
