execute as @e[type=minecraft:marker,tag=castelo_origem,limit=1] at @s run function castelo:_blocos5
tellraw @a [{"text":"[Castelo] ","color":"gold"},{"text":"Construindo... 62%","color":"gray"}]
schedule function castelo:_etapa6 1t
