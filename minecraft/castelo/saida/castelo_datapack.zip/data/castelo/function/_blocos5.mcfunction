setblock ~-43 ~18 ~-160 minecraft:cracked_stone_bricks
setblock ~-42 ~18 ~-31 minecraft:cracked_stone_bricks
setblock ~-41 ~1 ~-120 minecraft:cracked_stone_bricks
setblock ~-41 ~4 ~-120 minecraft:cracked_stone_bricks
setblock ~-41 ~10 ~-32 minecraft:cracked_stone_bricks
setblock ~-41 ~11 ~-156 minecraft:cracked_stone_bricks
setblock ~-41 ~13 ~-156 minecraft:cracked_stone_bricks
setblock ~-41 ~14 ~-32 minecraft:cracked_stone_bricks
setblock ~-41 ~17 ~-156 minecraft:cracked_stone_bricks
setblock ~-41 ~18 ~-160 minecraft:cracked_stone_bricks
setblock ~-40 ~5 ~-120 minecraft:cracked_stone_bricks
setblock ~-40 ~6 ~-156 minecraft:cracked_stone_bricks
setblock ~-40 ~15 ~-156 minecraft:cracked_stone_bricks
setblock ~-39 ~1 ~-138 minecraft:cracked_stone_bricks
setblock ~-39 ~10 ~-32 minecraft:cracked_stone_bricks
setblock ~-39 ~18 ~-34 minecraft:cracked_stone_bricks
setblock ~-39 ~19 ~-31 minecraft:cracked_stone_bricks
setblock ~-38 ~4 ~-120 minecraft:cracked_stone_bricks
setblock ~-38 ~14 ~-160 minecraft:cracked_stone_bricks
setblock ~-38 ~15 ~-36 minecraft:cracked_stone_bricks
setblock ~-38 ~18 ~-33 minecraft:cracked_stone_bricks
fill ~-37 ~1 ~-120 ~-36 ~2 ~-120 minecraft:cracked_stone_bricks
setblock ~-37 ~4 ~-156 minecraft:cracked_stone_bricks
setblock ~-37 ~10 ~-32 minecraft:cracked_stone_bricks
setblock ~-37 ~18 ~-32 minecraft:cracked_stone_bricks
fill ~-36 ~4 ~-137 ~-36 ~5 ~-137 minecraft:cracked_stone_bricks
setblock ~-36 ~4 ~-135 minecraft:cracked_stone_bricks
setblock ~-36 ~4 ~-129 minecraft:cracked_stone_bricks
setblock ~-36 ~4 ~-124 minecraft:cracked_stone_bricks
setblock ~-36 ~6 ~-134 minecraft:cracked_stone_bricks
setblock ~-36 ~8 ~-36 minecraft:cracked_stone_bricks
setblock ~-36 ~14 ~-32 minecraft:cracked_stone_bricks
setblock ~-35 ~13 ~-160 minecraft:cracked_stone_bricks
setblock ~-35 ~13 ~-36 minecraft:cracked_stone_bricks
setblock ~-35 ~15 ~-156 minecraft:cracked_stone_bricks
setblock ~-35 ~18 ~-161 minecraft:cracked_stone_bricks
setblock ~-35 ~18 ~-33 minecraft:cracked_stone_bricks
setblock ~-33 ~2 ~-36 minecraft:cracked_stone_bricks
setblock ~-33 ~14 ~-36 minecraft:cracked_stone_bricks
setblock ~-33 ~52 ~-144 minecraft:cracked_stone_bricks
setblock ~-33 ~54 ~-147 minecraft:cracked_stone_bricks
fill ~-32 ~3 ~-103 ~-32 ~3 ~-102 minecraft:cracked_stone_bricks
setblock ~-32 ~8 ~-103 minecraft:cracked_stone_bricks
setblock ~-32 ~9 ~-160 minecraft:cracked_stone_bricks
setblock ~-32 ~9 ~-32 minecraft:cracked_stone_bricks
fill ~-32 ~17 ~-156 ~-32 ~19 ~-156 minecraft:cracked_stone_bricks
fill ~-32 ~17 ~-38 ~-31 ~17 ~-38 minecraft:cracked_stone_bricks
setblock ~-32 ~26 ~-148 minecraft:cracked_stone_bricks
setblock ~-32 ~30 ~-145 minecraft:cracked_stone_bricks
setblock ~-32 ~32 ~-145 minecraft:cracked_stone_bricks
setblock ~-32 ~35 ~-100 minecraft:cracked_stone_bricks
setblock ~-32 ~38 ~-104 minecraft:cracked_stone_bricks
setblock ~-32 ~39 ~-145 minecraft:cracked_stone_bricks
setblock ~-32 ~39 ~-101 minecraft:cracked_stone_bricks
setblock ~-32 ~44 ~-103 minecraft:cracked_stone_bricks
setblock ~-32 ~45 ~-144 minecraft:cracked_stone_bricks
setblock ~-32 ~48 ~-103 minecraft:cracked_stone_bricks
setblock ~-32 ~49 ~-145 minecraft:cracked_stone_bricks
setblock ~-32 ~52 ~-100 minecraft:cracked_stone_bricks
setblock ~-31 ~3 ~-32 minecraft:cracked_stone_bricks
setblock ~-31 ~5 ~-105 minecraft:cracked_stone_bricks
setblock ~-31 ~9 ~-98 minecraft:cracked_stone_bricks
setblock ~-31 ~10 ~-150 minecraft:cracked_stone_bricks
fill ~-31 ~11 ~-142 ~-31 ~12 ~-142 minecraft:cracked_stone_bricks
fill ~-31 ~12 ~-150 ~-31 ~13 ~-150 minecraft:cracked_stone_bricks
fill ~-31 ~12 ~-143 ~-31 ~12 ~-142 minecraft:cracked_stone_bricks
setblock ~-31 ~14 ~-99 minecraft:cracked_stone_bricks
setblock ~-31 ~16 ~-143 minecraft:cracked_stone_bricks
setblock ~-31 ~18 ~-142 minecraft:cracked_stone_bricks
setblock ~-31 ~18 ~-98 minecraft:cracked_stone_bricks
setblock ~-31 ~18 ~-32 minecraft:cracked_stone_bricks
setblock ~-31 ~29 ~-105 minecraft:cracked_stone_bricks
setblock ~-31 ~33 ~-149 minecraft:cracked_stone_bricks
setblock ~-31 ~33 ~-143 minecraft:cracked_stone_bricks
setblock ~-31 ~33 ~-99 minecraft:cracked_stone_bricks
setblock ~-31 ~35 ~-106 minecraft:cracked_stone_bricks
setblock ~-31 ~36 ~-99 minecraft:cracked_stone_bricks
setblock ~-31 ~39 ~-143 minecraft:cracked_stone_bricks
setblock ~-31 ~40 ~-99 minecraft:cracked_stone_bricks
setblock ~-31 ~42 ~-99 minecraft:cracked_stone_bricks
setblock ~-31 ~44 ~-150 minecraft:cracked_stone_bricks
setblock ~-31 ~45 ~-142 minecraft:cracked_stone_bricks
setblock ~-31 ~46 ~-105 minecraft:cracked_stone_bricks
setblock ~-31 ~47 ~-150 minecraft:cracked_stone_bricks
setblock ~-31 ~52 ~-141 minecraft:cracked_stone_bricks
setblock ~-31 ~52 ~-97 minecraft:cracked_stone_bricks
setblock ~-31 ~53 ~-107 minecraft:cracked_stone_bricks
setblock ~-31 ~54 ~-141 minecraft:cracked_stone_bricks
setblock ~-31 ~54 ~-97 minecraft:cracked_stone_bricks
setblock ~-30 ~ ~-38 minecraft:cracked_stone_bricks
setblock ~-30 ~4 ~-141 minecraft:cracked_stone_bricks
setblock ~-30 ~4 ~-107 minecraft:cracked_stone_bricks
setblock ~-30 ~6 ~-32 minecraft:cracked_stone_bricks
setblock ~-30 ~7 ~-141 minecraft:cracked_stone_bricks
setblock ~-30 ~8 ~-107 minecraft:cracked_stone_bricks
setblock ~-30 ~10 ~-97 minecraft:cracked_stone_bricks
setblock ~-30 ~13 ~-160 minecraft:cracked_stone_bricks
setblock ~-30 ~14 ~-38 minecraft:cracked_stone_bricks
setblock ~-30 ~16 ~-156 minecraft:cracked_stone_bricks
setblock ~-30 ~18 ~-35 minecraft:cracked_stone_bricks
setblock ~-30 ~19 ~-151 minecraft:cracked_stone_bricks
setblock ~-30 ~24 ~-141 minecraft:cracked_stone_bricks
setblock ~-30 ~35 ~-151 minecraft:cracked_stone_bricks
setblock ~-30 ~37 ~-141 minecraft:cracked_stone_bricks
setblock ~-30 ~40 ~-97 minecraft:cracked_stone_bricks
setblock ~-30 ~52 ~-151 minecraft:cracked_stone_bricks
setblock ~-30 ~52 ~-146 minecraft:cracked_stone_bricks
setblock ~-29 ~3 ~-141 minecraft:cracked_stone_bricks
setblock ~-29 ~4 ~-151 minecraft:cracked_stone_bricks
setblock ~-29 ~7 ~-160 minecraft:cracked_stone_bricks
setblock ~-29 ~8 ~-38 minecraft:cracked_stone_bricks
setblock ~-29 ~14 ~-107 minecraft:cracked_stone_bricks
setblock ~-29 ~18 ~-159 minecraft:cracked_stone_bricks
setblock ~-29 ~18 ~-97 minecraft:cracked_stone_bricks
setblock ~-29 ~21 ~-141 minecraft:cracked_stone_bricks
setblock ~-29 ~22 ~-107 minecraft:cracked_stone_bricks
setblock ~-29 ~23 ~-97 minecraft:cracked_stone_bricks
setblock ~-29 ~27 ~-141 minecraft:cracked_stone_bricks
setblock ~-29 ~29 ~-141 minecraft:cracked_stone_bricks
setblock ~-29 ~36 ~-151 minecraft:cracked_stone_bricks
setblock ~-29 ~38 ~-97 minecraft:cracked_stone_bricks
setblock ~-29 ~50 ~-141 minecraft:cracked_stone_bricks
setblock ~-29 ~52 ~-101 minecraft:cracked_stone_bricks
setblock ~-28 ~4 ~-32 minecraft:cracked_stone_bricks
fill ~-28 ~14 ~-156 ~-28 ~15 ~-156 minecraft:cracked_stone_bricks
setblock ~-28 ~18 ~-140 minecraft:cracked_stone_bricks
setblock ~-28 ~19 ~-96 minecraft:cracked_stone_bricks
setblock ~-28 ~20 ~-108 minecraft:cracked_stone_bricks
setblock ~-28 ~23 ~-96 minecraft:cracked_stone_bricks
setblock ~-28 ~25 ~-140 minecraft:cracked_stone_bricks
setblock ~-28 ~33 ~-108 minecraft:cracked_stone_bricks
setblock ~-28 ~41 ~-96 minecraft:cracked_stone_bricks
setblock ~-28 ~47 ~-152 minecraft:cracked_stone_bricks
setblock ~-28 ~50 ~-152 minecraft:cracked_stone_bricks
setblock ~-28 ~50 ~-140 minecraft:cracked_stone_bricks
setblock ~-27 ~5 ~-38 minecraft:cracked_stone_bricks
setblock ~-27 ~6 ~-156 minecraft:cracked_stone_bricks
setblock ~-27 ~6 ~-96 minecraft:cracked_stone_bricks
setblock ~-27 ~9 ~-108 minecraft:cracked_stone_bricks
setblock ~-27 ~9 ~-32 minecraft:cracked_stone_bricks
setblock ~-27 ~11 ~-96 minecraft:cracked_stone_bricks
setblock ~-27 ~18 ~-96 minecraft:cracked_stone_bricks
setblock ~-27 ~21 ~-96 minecraft:cracked_stone_bricks
setblock ~-27 ~27 ~-96 minecraft:cracked_stone_bricks
setblock ~-27 ~39 ~-152 minecraft:cracked_stone_bricks
setblock ~-27 ~43 ~-152 minecraft:cracked_stone_bricks
setblock ~-27 ~44 ~-128 minecraft:cracked_stone_bricks
setblock ~-27 ~44 ~-96 minecraft:cracked_stone_bricks
setblock ~-27 ~45 ~-129 minecraft:cracked_stone_bricks
fill ~-27 ~45 ~-127 ~-27 ~45 ~-126 minecraft:cracked_stone_bricks
setblock ~-27 ~48 ~-152 minecraft:cracked_stone_bricks
fill ~-26 ~5 ~-125 ~-26 ~5 ~-124 minecraft:cracked_stone_bricks
setblock ~-26 ~6 ~-129 minecraft:cracked_stone_bricks
setblock ~-26 ~6 ~-109 minecraft:cracked_stone_bricks
fill ~-26 ~7 ~-127 ~-25 ~7 ~-127 minecraft:cracked_stone_bricks
setblock ~-26 ~7 ~-32 minecraft:cracked_stone_bricks
setblock ~-26 ~8 ~-133 minecraft:cracked_stone_bricks
setblock ~-26 ~8 ~-128 minecraft:cracked_stone_bricks
setblock ~-26 ~8 ~-119 minecraft:cracked_stone_bricks
setblock ~-26 ~8 ~-111 minecraft:cracked_stone_bricks
setblock ~-26 ~9 ~-38 minecraft:cracked_stone_bricks
setblock ~-26 ~10 ~-120 minecraft:cracked_stone_bricks
setblock ~-26 ~10 ~-113 minecraft:cracked_stone_bricks
setblock ~-26 ~10 ~-96 minecraft:cracked_stone_bricks
setblock ~-26 ~12 ~-156 minecraft:cracked_stone_bricks
setblock ~-26 ~12 ~-137 minecraft:cracked_stone_bricks
setblock ~-26 ~12 ~-127 minecraft:cracked_stone_bricks
setblock ~-26 ~12 ~-121 minecraft:cracked_stone_bricks
setblock ~-26 ~14 ~-156 minecraft:cracked_stone_bricks
setblock ~-26 ~14 ~-152 minecraft:cracked_stone_bricks
fill ~-26 ~14 ~-131 ~-26 ~14 ~-130 minecraft:cracked_stone_bricks
setblock ~-26 ~14 ~-127 minecraft:cracked_stone_bricks
setblock ~-26 ~14 ~-123 minecraft:cracked_stone_bricks
setblock ~-26 ~15 ~-135 minecraft:cracked_stone_bricks
fill ~-26 ~16 ~-132 ~-26 ~16 ~-130 minecraft:cracked_stone_bricks
setblock ~-26 ~17 ~-161 minecraft:cracked_stone_bricks
fill ~-26 ~17 ~-120 ~-25 ~17 ~-120 minecraft:cracked_stone_bricks
setblock ~-26 ~18 ~-134 minecraft:cracked_stone_bricks
setblock ~-26 ~19 ~-124 minecraft:cracked_stone_bricks
setblock ~-26 ~19 ~-110 minecraft:cracked_stone_bricks
setblock ~-26 ~20 ~-112 minecraft:cracked_stone_bricks
setblock ~-26 ~21 ~-134 minecraft:cracked_stone_bricks
setblock ~-26 ~21 ~-119 minecraft:cracked_stone_bricks
setblock ~-26 ~21 ~-110 minecraft:cracked_stone_bricks
setblock ~-26 ~23 ~-139 minecraft:cracked_stone_bricks
setblock ~-26 ~23 ~-126 minecraft:cracked_stone_bricks
setblock ~-26 ~23 ~-109 minecraft:cracked_stone_bricks
setblock ~-26 ~25 ~-139 minecraft:cracked_stone_bricks
setblock ~-26 ~26 ~-132 minecraft:cracked_stone_bricks
fill ~-26 ~28 ~-131 ~-26 ~28 ~-130 minecraft:cracked_stone_bricks
setblock ~-26 ~28 ~-115 minecraft:cracked_stone_bricks
fill ~-26 ~29 ~-121 ~-25 ~29 ~-121 minecraft:cracked_stone_bricks
setblock ~-26 ~29 ~-109 minecraft:cracked_stone_bricks
setblock ~-26 ~30 ~-123 minecraft:cracked_stone_bricks
setblock ~-26 ~31 ~-128 minecraft:cracked_stone_bricks
setblock ~-26 ~34 ~-121 minecraft:cracked_stone_bricks
fill ~-26 ~35 ~-112 ~-26 ~40 ~-112 minecraft:cracked_stone_bricks
setblock ~-26 ~36 ~-128 minecraft:cracked_stone_bricks
setblock ~-26 ~36 ~-123 minecraft:cracked_stone_bricks
setblock ~-26 ~37 ~-115 minecraft:cracked_stone_bricks
setblock ~-26 ~39 ~-133 minecraft:cracked_stone_bricks
setblock ~-26 ~39 ~-127 minecraft:cracked_stone_bricks
setblock ~-26 ~42 ~-117 minecraft:cracked_stone_bricks
setblock ~-26 ~44 ~-111 minecraft:cracked_stone_bricks
setblock ~-26 ~45 ~-96 minecraft:cracked_stone_bricks
setblock ~-26 ~47 ~-108 minecraft:cracked_stone_bricks
setblock ~-26 ~47 ~-96 minecraft:cracked_stone_bricks
fill ~-26 ~49 ~-108 ~-26 ~50 ~-108 minecraft:cracked_stone_bricks
setblock ~-25 ~ ~-119 minecraft:cracked_stone_bricks
fill ~-25 ~1 ~-141 ~-25 ~2 ~-141 minecraft:cracked_stone_bricks
setblock ~-25 ~1 ~-127 minecraft:cracked_stone_bricks
setblock ~-25 ~1 ~-110 minecraft:cracked_stone_bricks
setblock ~-25 ~2 ~-131 minecraft:cracked_stone_bricks
setblock ~-25 ~2 ~-123 minecraft:cracked_stone_bricks
setblock ~-25 ~2 ~-119 minecraft:cracked_stone_bricks
setblock ~-25 ~3 ~-156 minecraft:cracked_stone_bricks
setblock ~-25 ~3 ~-135 minecraft:cracked_stone_bricks
fill ~-25 ~3 ~-129 ~-25 ~3 ~-128 minecraft:cracked_stone_bricks
setblock ~-25 ~3 ~-126 minecraft:cracked_stone_bricks
setblock ~-25 ~3 ~-110 minecraft:cracked_stone_bricks
setblock ~-25 ~4 ~-125 minecraft:cracked_stone_bricks
setblock ~-25 ~4 ~-121 minecraft:cracked_stone_bricks
setblock ~-25 ~4 ~-119 minecraft:cracked_stone_bricks
setblock ~-25 ~4 ~-113 minecraft:cracked_stone_bricks
setblock ~-25 ~5 ~-143 minecraft:cracked_stone_bricks
setblock ~-25 ~7 ~-143 minecraft:cracked_stone_bricks
fill ~-25 ~7 ~-118 ~-25 ~7 ~-117 minecraft:cracked_stone_bricks
setblock ~-25 ~9 ~-142 minecraft:cracked_stone_bricks
setblock ~-25 ~9 ~-117 minecraft:cracked_stone_bricks
setblock ~-25 ~10 ~-138 minecraft:cracked_stone_bricks
setblock ~-25 ~12 ~-142 minecraft:cracked_stone_bricks
setblock ~-25 ~12 ~-134 minecraft:cracked_stone_bricks
setblock ~-25 ~12 ~-125 minecraft:cracked_stone_bricks
setblock ~-25 ~12 ~-36 minecraft:cracked_stone_bricks
setblock ~-25 ~13 ~-124 minecraft:cracked_stone_bricks
setblock ~-25 ~13 ~-109 minecraft:cracked_stone_bricks
setblock ~-25 ~13 ~-105 minecraft:cracked_stone_bricks
fill ~-25 ~14 ~-139 ~-25 ~15 ~-139 minecraft:cracked_stone_bricks
setblock ~-25 ~15 ~-132 minecraft:cracked_stone_bricks
setblock ~-25 ~15 ~-110 minecraft:cracked_stone_bricks
setblock ~-25 ~15 ~-104 minecraft:cracked_stone_bricks
setblock ~-25 ~16 ~-117 minecraft:cracked_stone_bricks
fill ~-25 ~17 ~-121 ~-25 ~17 ~-120 minecraft:cracked_stone_bricks
fill ~-25 ~17 ~-114 ~-25 ~18 ~-114 minecraft:cracked_stone_bricks
setblock ~-25 ~18 ~-161 minecraft:cracked_stone_bricks
setblock ~-25 ~18 ~-121 minecraft:cracked_stone_bricks
setblock ~-25 ~19 ~-112 minecraft:cracked_stone_bricks
fill ~-25 ~20 ~-125 ~-25 ~20 ~-124 minecraft:cracked_stone_bricks
setblock ~-25 ~20 ~-109 minecraft:cracked_stone_bricks
setblock ~-25 ~20 ~-96 minecraft:cracked_stone_bricks
setblock ~-25 ~21 ~-143 minecraft:cracked_stone_bricks
setblock ~-25 ~21 ~-139 minecraft:cracked_stone_bricks
setblock ~-25 ~21 ~-133 minecraft:cracked_stone_bricks
setblock ~-25 ~21 ~-117 minecraft:cracked_stone_bricks
setblock ~-25 ~23 ~-130 minecraft:cracked_stone_bricks
setblock ~-25 ~23 ~-104 minecraft:cracked_stone_bricks
setblock ~-25 ~24 ~-140 minecraft:cracked_stone_bricks
setblock ~-25 ~24 ~-110 minecraft:cracked_stone_bricks
setblock ~-25 ~24 ~-105 minecraft:cracked_stone_bricks
setblock ~-25 ~25 ~-138 minecraft:cracked_stone_bricks
setblock ~-25 ~25 ~-134 minecraft:cracked_stone_bricks
setblock ~-25 ~25 ~-131 minecraft:cracked_stone_bricks
setblock ~-25 ~26 ~-144 minecraft:cracked_stone_bricks
fill ~-25 ~27 ~-105 ~-25 ~27 ~-104 minecraft:cracked_stone_bricks
setblock ~-25 ~30 ~-120 minecraft:cracked_stone_bricks
setblock ~-25 ~30 ~-106 minecraft:cracked_stone_bricks
setblock ~-25 ~31 ~-117 minecraft:cracked_stone_bricks
setblock ~-25 ~31 ~-114 minecraft:cracked_stone_bricks
setblock ~-25 ~32 ~-140 minecraft:cracked_stone_bricks
setblock ~-25 ~32 ~-121 minecraft:cracked_stone_bricks
setblock ~-25 ~35 ~-143 minecraft:cracked_stone_bricks
setblock ~-25 ~35 ~-141 minecraft:cracked_stone_bricks
setblock ~-25 ~38 ~-121 minecraft:cracked_stone_bricks
setblock ~-25 ~39 ~-125 minecraft:cracked_stone_bricks
setblock ~-25 ~41 ~-137 minecraft:cracked_stone_bricks
setblock ~-25 ~41 ~-126 minecraft:cracked_stone_bricks
setblock ~-25 ~41 ~-113 minecraft:cracked_stone_bricks
setblock ~-25 ~41 ~-109 minecraft:cracked_stone_bricks
setblock ~-25 ~42 ~-134 minecraft:cracked_stone_bricks
setblock ~-25 ~42 ~-108 minecraft:cracked_stone_bricks
setblock ~-25 ~43 ~-122 minecraft:cracked_stone_bricks
setblock ~-25 ~43 ~-96 minecraft:cracked_stone_bricks
setblock ~-25 ~44 ~-152 minecraft:cracked_stone_bricks
setblock ~-25 ~44 ~-130 minecraft:cracked_stone_bricks
setblock ~-25 ~44 ~-117 minecraft:cracked_stone_bricks
setblock ~-25 ~53 ~-153 minecraft:cracked_stone_bricks
setblock ~-24 ~1 ~-156 minecraft:cracked_stone_bricks
setblock ~-24 ~3 ~-32 minecraft:cracked_stone_bricks
setblock ~-24 ~4 ~-152 minecraft:cracked_stone_bricks
setblock ~-24 ~4 ~-103 minecraft:cracked_stone_bricks
fill ~-24 ~7 ~-96 ~-24 ~8 ~-96 minecraft:cracked_stone_bricks
setblock ~-24 ~10 ~-32 minecraft:cracked_stone_bricks
setblock ~-24 ~13 ~-96 minecraft:cracked_stone_bricks
setblock ~-24 ~15 ~-103 minecraft:cracked_stone_bricks
setblock ~-24 ~17 ~-156 minecraft:cracked_stone_bricks
setblock ~-24 ~22 ~-152 minecraft:cracked_stone_bricks
setblock ~-24 ~27 ~-124 minecraft:cracked_stone_bricks
setblock ~-24 ~27 ~-103 minecraft:cracked_stone_bricks
setblock ~-24 ~28 ~-145 minecraft:cracked_stone_bricks
setblock ~-24 ~29 ~-103 minecraft:cracked_stone_bricks
setblock ~-24 ~31 ~-31 minecraft:cracked_stone_bricks
setblock ~-24 ~36 ~-145 minecraft:cracked_stone_bricks
setblock ~-24 ~38 ~-145 minecraft:cracked_stone_bricks
setblock ~-24 ~43 ~-145 minecraft:cracked_stone_bricks
setblock ~-24 ~44 ~-127 minecraft:cracked_stone_bricks
setblock ~-24 ~44 ~-109 minecraft:cracked_stone_bricks
setblock ~-24 ~52 ~-109 minecraft:cracked_stone_bricks
setblock ~-23 ~2 ~-156 minecraft:cracked_stone_bricks
setblock ~-23 ~3 ~-30 minecraft:cracked_stone_bricks
fill ~-23 ~5 ~-103 ~-23 ~6 ~-103 minecraft:cracked_stone_bricks
setblock ~-23 ~7 ~-31 minecraft:cracked_stone_bricks
fill ~-23 ~8 ~-156 ~-23 ~9 ~-156 minecraft:cracked_stone_bricks
setblock ~-23 ~8 ~-145 minecraft:cracked_stone_bricks
setblock ~-23 ~8 ~-125 minecraft:cracked_stone_bricks
setblock ~-23 ~10 ~-29 minecraft:cracked_stone_bricks
setblock ~-23 ~12 ~-97 minecraft:cracked_stone_bricks
fill ~-23 ~13 ~-156 ~-22 ~13 ~-156 minecraft:cracked_stone_bricks
setblock ~-23 ~14 ~-145 minecraft:cracked_stone_bricks
setblock ~-23 ~16 ~-30 minecraft:cracked_stone_bricks
setblock ~-23 ~18 ~-34 minecraft:cracked_stone_bricks
setblock ~-23 ~19 ~-103 minecraft:cracked_stone_bricks
setblock ~-23 ~21 ~-151 minecraft:cracked_stone_bricks
setblock ~-23 ~25 ~-145 minecraft:cracked_stone_bricks
setblock ~-23 ~26 ~-97 minecraft:cracked_stone_bricks
setblock ~-23 ~28 ~-31 minecraft:cracked_stone_bricks
setblock ~-23 ~32 ~-97 minecraft:cracked_stone_bricks
setblock ~-23 ~44 ~-133 minecraft:cracked_stone_bricks
setblock ~-23 ~44 ~-131 minecraft:cracked_stone_bricks
setblock ~-23 ~44 ~-123 minecraft:cracked_stone_bricks
setblock ~-23 ~49 ~-107 minecraft:cracked_stone_bricks
setblock ~-23 ~52 ~-144 minecraft:cracked_stone_bricks
setblock ~-22 ~1 ~-29 minecraft:cracked_stone_bricks
setblock ~-22 ~3 ~-97 minecraft:cracked_stone_bricks
setblock ~-22 ~6 ~-30 minecraft:cracked_stone_bricks
setblock ~-22 ~8 ~-160 minecraft:cracked_stone_bricks
setblock ~-22 ~10 ~-156 minecraft:cracked_stone_bricks
setblock ~-22 ~11 ~-160 minecraft:cracked_stone_bricks
setblock ~-22 ~13 ~-26 minecraft:cracked_stone_bricks
setblock ~-22 ~14 ~-97 minecraft:cracked_stone_bricks
setblock ~-22 ~17 ~-151 minecraft:cracked_stone_bricks
setblock ~-22 ~18 ~-27 minecraft:cracked_stone_bricks
setblock ~-22 ~19 ~-30 minecraft:cracked_stone_bricks
setblock ~-22 ~20 ~-151 minecraft:cracked_stone_bricks
setblock ~-22 ~25 ~-97 minecraft:cracked_stone_bricks
setblock ~-22 ~26 ~-29 minecraft:cracked_stone_bricks
setblock ~-22 ~26 ~-27 minecraft:cracked_stone_bricks
setblock ~-22 ~27 ~-26 minecraft:cracked_stone_bricks
setblock ~-22 ~31 ~-145 minecraft:cracked_stone_bricks
setblock ~-22 ~45 ~-107 minecraft:cracked_stone_bricks
setblock ~-22 ~47 ~-107 minecraft:cracked_stone_bricks
setblock ~-22 ~49 ~-151 minecraft:cracked_stone_bricks
setblock ~-22 ~52 ~-108 minecraft:cracked_stone_bricks
setblock ~-22 ~52 ~-103 minecraft:cracked_stone_bricks
setblock ~-22 ~53 ~-152 minecraft:cracked_stone_bricks
setblock ~-21 ~-24 ~-141 minecraft:cracked_stone_bricks
setblock ~-21 ~1 ~-145 minecraft:cracked_stone_bricks
setblock ~-21 ~1 ~-34 minecraft:cracked_stone_bricks
setblock ~-21 ~3 ~-33 minecraft:cracked_stone_bricks
fill ~-21 ~4 ~-25 ~-21 ~4 ~-24 minecraft:cracked_stone_bricks
setblock ~-21 ~5 ~-141 minecraft:cracked_stone_bricks
setblock ~-21 ~8 ~-145 minecraft:cracked_stone_bricks
setblock ~-21 ~8 ~-99 minecraft:cracked_stone_bricks
setblock ~-21 ~10 ~-149 minecraft:cracked_stone_bricks
setblock ~-21 ~12 ~-156 minecraft:cracked_stone_bricks
setblock ~-21 ~14 ~-141 minecraft:cracked_stone_bricks
setblock ~-21 ~14 ~-25 minecraft:cracked_stone_bricks
setblock ~-21 ~15 ~-36 minecraft:cracked_stone_bricks
setblock ~-21 ~17 ~-36 minecraft:cracked_stone_bricks
setblock ~-21 ~20 ~-150 minecraft:cracked_stone_bricks
setblock ~-21 ~24 ~-103 minecraft:cracked_stone_bricks
setblock ~-21 ~26 ~-149 minecraft:cracked_stone_bricks
setblock ~-21 ~28 ~-149 minecraft:cracked_stone_bricks
setblock ~-21 ~28 ~-103 minecraft:cracked_stone_bricks
setblock ~-21 ~30 ~-145 minecraft:cracked_stone_bricks
setblock ~-21 ~35 ~-103 minecraft:cracked_stone_bricks
setblock ~-21 ~35 ~-98 minecraft:cracked_stone_bricks
setblock ~-21 ~40 ~-145 minecraft:cracked_stone_bricks
fill ~-21 ~44 ~-111 ~-21 ~44 ~-110 minecraft:cracked_stone_bricks
setblock ~-21 ~44 ~-107 minecraft:cracked_stone_bricks
setblock ~-21 ~44 ~-104 minecraft:cracked_stone_bricks
setblock ~-21 ~44 ~-98 minecraft:cracked_stone_bricks
setblock ~-21 ~46 ~-150 minecraft:cracked_stone_bricks
setblock ~-21 ~46 ~-105 minecraft:cracked_stone_bricks
setblock ~-21 ~50 ~-149 minecraft:cracked_stone_bricks
setblock ~-21 ~50 ~-143 minecraft:cracked_stone_bricks
setblock ~-21 ~52 ~-151 minecraft:cracked_stone_bricks
fill ~-20 ~-19 ~-139 ~-20 ~-19 ~-133 minecraft:cracked_stone_bricks
setblock ~-20 ~3 ~-103 minecraft:cracked_stone_bricks
fill ~-20 ~8 ~-103 ~-20 ~9 ~-103 minecraft:cracked_stone_bricks
fill ~-20 ~9 ~-141 ~-20 ~9 ~-140 minecraft:cracked_stone_bricks
setblock ~-20 ~10 ~-148 minecraft:cracked_stone_bricks
setblock ~-20 ~10 ~-145 minecraft:cracked_stone_bricks
setblock ~-20 ~10 ~-101 minecraft:cracked_stone_bricks
setblock ~-20 ~13 ~-100 minecraft:cracked_stone_bricks
setblock ~-20 ~14 ~-139 minecraft:cracked_stone_bricks
setblock ~-20 ~18 ~-36 minecraft:cracked_stone_bricks
setblock ~-20 ~21 ~-36 minecraft:cracked_stone_bricks
setblock ~-20 ~23 ~-145 minecraft:cracked_stone_bricks
fill ~-20 ~27 ~-101 ~-20 ~27 ~-100 minecraft:cracked_stone_bricks
setblock ~-20 ~28 ~-36 minecraft:cracked_stone_bricks
setblock ~-20 ~29 ~-145 minecraft:cracked_stone_bricks
setblock ~-20 ~29 ~-35 minecraft:cracked_stone_bricks
setblock ~-20 ~29 ~-25 minecraft:cracked_stone_bricks
setblock ~-20 ~37 ~-147 minecraft:cracked_stone_bricks
setblock ~-20 ~44 ~-134 minecraft:cracked_stone_bricks
setblock ~-20 ~44 ~-131 minecraft:cracked_stone_bricks
setblock ~-20 ~45 ~-102 minecraft:cracked_stone_bricks
setblock ~-20 ~52 ~-98 minecraft:cracked_stone_bricks
setblock ~-20 ~53 ~-99 minecraft:cracked_stone_bricks
fill ~-19 ~-27 ~-122 ~-17 ~-27 ~-122 minecraft:cracked_stone_bricks
setblock ~-19 ~5 ~-24 minecraft:cracked_stone_bricks
setblock ~-19 ~7 ~-140 minecraft:cracked_stone_bricks
setblock ~-19 ~11 ~-36 minecraft:cracked_stone_bricks
setblock ~-19 ~12 ~-141 minecraft:cracked_stone_bricks
setblock ~-19 ~12 ~-24 minecraft:cracked_stone_bricks
setblock ~-19 ~14 ~-36 minecraft:cracked_stone_bricks
fill ~-19 ~18 ~-156 ~-18 ~19 ~-156 minecraft:cracked_stone_bricks
setblock ~-19 ~21 ~-103 minecraft:cracked_stone_bricks
setblock ~-19 ~23 ~-124 minecraft:cracked_stone_bricks
setblock ~-19 ~25 ~-23 minecraft:cracked_stone_bricks
setblock ~-19 ~26 ~-24 minecraft:cracked_stone_bricks
setblock ~-19 ~27 ~-103 minecraft:cracked_stone_bricks
fill ~-19 ~29 ~-124 ~-18 ~29 ~-124 minecraft:cracked_stone_bricks
setblock ~-19 ~29 ~-36 minecraft:cracked_stone_bricks
setblock ~-19 ~30 ~-27 minecraft:cracked_stone_bricks
setblock ~-19 ~34 ~-146 minecraft:cracked_stone_bricks
setblock ~-19 ~36 ~-145 minecraft:cracked_stone_bricks
setblock ~-19 ~40 ~-145 minecraft:cracked_stone_bricks
setblock ~-19 ~40 ~-103 minecraft:cracked_stone_bricks
setblock ~-19 ~44 ~-135 minecraft:cracked_stone_bricks
setblock ~-19 ~44 ~-116 minecraft:cracked_stone_bricks
setblock ~-19 ~44 ~-108 minecraft:cracked_stone_bricks
setblock ~-19 ~45 ~-101 minecraft:cracked_stone_bricks
setblock ~-18 ~1 ~-103 minecraft:cracked_stone_bricks
setblock ~-18 ~3 ~-23 minecraft:cracked_stone_bricks
setblock ~-18 ~6 ~-103 minecraft:cracked_stone_bricks
fill ~-18 ~12 ~-160 ~-17 ~12 ~-160 minecraft:cracked_stone_bricks
setblock ~-18 ~13 ~-156 minecraft:cracked_stone_bricks
setblock ~-18 ~14 ~-23 minecraft:cracked_stone_bricks
fill ~-18 ~18 ~-157 ~-18 ~18 ~-156 minecraft:cracked_stone_bricks
setblock ~-18 ~18 ~-37 minecraft:cracked_stone_bricks
setblock ~-18 ~31 ~-21 minecraft:cracked_stone_bricks
fill ~-18 ~43 ~-103 ~-17 ~43 ~-103 minecraft:cracked_stone_bricks
setblock ~-18 ~44 ~-103 minecraft:cracked_stone_bricks
setblock ~-17 ~4 ~-160 minecraft:cracked_stone_bricks
fill ~-17 ~4 ~-140 ~-16 ~4 ~-140 minecraft:cracked_stone_bricks
setblock ~-17 ~4 ~-23 minecraft:cracked_stone_bricks
setblock ~-17 ~5 ~-125 minecraft:cracked_stone_bricks
setblock ~-17 ~7 ~-38 minecraft:cracked_stone_bricks
setblock ~-17 ~9 ~-160 minecraft:cracked_stone_bricks
setblock ~-17 ~9 ~-145 minecraft:cracked_stone_bricks
fill ~-17 ~9 ~-140 ~-16 ~10 ~-140 minecraft:cracked_stone_bricks
setblock ~-17 ~10 ~-146 minecraft:cracked_stone_bricks
setblock ~-17 ~14 ~-22 minecraft:cracked_stone_bricks
fill ~-17 ~15 ~-146 ~-16 ~15 ~-146 minecraft:cracked_stone_bricks
setblock ~-17 ~20 ~-37 minecraft:cracked_stone_bricks
setblock ~-17 ~27 ~-145 minecraft:cracked_stone_bricks
setblock ~-17 ~30 ~-33 minecraft:cracked_stone_bricks
setblock ~-17 ~30 ~-25 minecraft:cracked_stone_bricks
setblock ~-17 ~31 ~-145 minecraft:cracked_stone_bricks
fill ~-17 ~40 ~-103 ~-17 ~41 ~-103 minecraft:cracked_stone_bricks
setblock ~-17 ~42 ~-102 minecraft:cracked_stone_bricks
setblock ~-17 ~44 ~-124 minecraft:cracked_stone_bricks
setblock ~-16 ~5 ~-156 minecraft:cracked_stone_bricks
fill ~-16 ~6 ~-160 ~-16 ~7 ~-160 minecraft:cracked_stone_bricks
setblock ~-16 ~6 ~-125 minecraft:cracked_stone_bricks
setblock ~-16 ~9 ~-103 minecraft:cracked_stone_bricks
setblock ~-16 ~10 ~-102 minecraft:cracked_stone_bricks
fill ~-16 ~18 ~-156 ~-16 ~19 ~-156 minecraft:cracked_stone_bricks
setblock ~-16 ~21 ~-103 minecraft:cracked_stone_bricks
setblock ~-16 ~25 ~-124 minecraft:cracked_stone_bricks
setblock ~-16 ~30 ~-31 minecraft:cracked_stone_bricks
setblock ~-16 ~35 ~-103 minecraft:cracked_stone_bricks
setblock ~-16 ~41 ~-102 minecraft:cracked_stone_bricks
setblock ~-16 ~44 ~-114 minecraft:cracked_stone_bricks
setblock ~-15 ~7 ~-146 minecraft:cracked_stone_bricks
setblock ~-15 ~8 ~-160 minecraft:cracked_stone_bricks
setblock ~-15 ~8 ~-140 minecraft:cracked_stone_bricks
setblock ~-15 ~8 ~-23 minecraft:cracked_stone_bricks
setblock ~-15 ~9 ~-145 minecraft:cracked_stone_bricks
setblock ~-15 ~11 ~-160 minecraft:cracked_stone_bricks
fill ~-15 ~11 ~-22 ~-15 ~13 ~-22 minecraft:cracked_stone_bricks
setblock ~-15 ~14 ~-103 minecraft:cracked_stone_bricks
fill ~-15 ~16 ~-156 ~-15 ~17 ~-156 minecraft:cracked_stone_bricks
setblock ~-15 ~19 ~-22 minecraft:cracked_stone_bricks
fill ~-15 ~20 ~-161 ~-15 ~21 ~-161 minecraft:cracked_stone_bricks
setblock ~-15 ~20 ~-103 minecraft:cracked_stone_bricks
fill ~-15 ~23 ~-23 ~-15 ~25 ~-23 minecraft:cracked_stone_bricks
setblock ~-15 ~26 ~-38 minecraft:cracked_stone_bricks
setblock ~-15 ~28 ~-38 minecraft:cracked_stone_bricks
setblock ~-15 ~30 ~-26 minecraft:cracked_stone_bricks
setblock ~-15 ~32 ~-102 minecraft:cracked_stone_bricks
setblock ~-15 ~35 ~-146 minecraft:cracked_stone_bricks
fill ~-15 ~44 ~-106 ~-14 ~44 ~-106 minecraft:cracked_stone_bricks
setblock ~-15 ~45 ~-147 minecraft:cracked_stone_bricks
setblock ~-14 ~4 ~-22 minecraft:cracked_stone_bricks
setblock ~-14 ~6 ~-22 minecraft:cracked_stone_bricks
fill ~-14 ~7 ~-38 ~-14 ~7 ~-37 minecraft:cracked_stone_bricks
setblock ~-14 ~8 ~-125 minecraft:cracked_stone_bricks
setblock ~-14 ~10 ~-103 minecraft:cracked_stone_bricks
setblock ~-14 ~12 ~-160 minecraft:cracked_stone_bricks
setblock ~-14 ~13 ~-22 minecraft:cracked_stone_bricks
setblock ~-14 ~14 ~-156 minecraft:cracked_stone_bricks
setblock ~-14 ~16 ~-22 minecraft:cracked_stone_bricks
setblock ~-14 ~21 ~-22 minecraft:cracked_stone_bricks
setblock ~-14 ~23 ~-124 minecraft:cracked_stone_bricks
fill ~-14 ~25 ~-22 ~-13 ~25 ~-22 minecraft:cracked_stone_bricks
setblock ~-14 ~28 ~-103 minecraft:cracked_stone_bricks
setblock ~-14 ~28 ~-22 minecraft:cracked_stone_bricks
setblock ~-14 ~30 ~-102 minecraft:cracked_stone_bricks
setblock ~-14 ~34 ~-146 minecraft:cracked_stone_bricks
setblock ~-14 ~35 ~-145 minecraft:cracked_stone_bricks
setblock ~-14 ~35 ~-103 minecraft:cracked_stone_bricks
setblock ~-14 ~36 ~-146 minecraft:cracked_stone_bricks
setblock ~-14 ~43 ~-145 minecraft:cracked_stone_bricks
setblock ~-14 ~44 ~-139 minecraft:cracked_stone_bricks
setblock ~-14 ~44 ~-130 minecraft:cracked_stone_bricks
setblock ~-14 ~44 ~-127 minecraft:cracked_stone_bricks
setblock ~-14 ~44 ~-123 minecraft:cracked_stone_bricks
setblock ~-13 ~4 ~-103 minecraft:cracked_stone_bricks
setblock ~-13 ~7 ~-156 minecraft:cracked_stone_bricks
fill ~-13 ~9 ~-125 ~-13 ~15 ~-125 minecraft:cracked_stone_bricks
fill ~-13 ~9 ~-103 ~-12 ~9 ~-103 minecraft:cracked_stone_bricks
setblock ~-13 ~10 ~-160 minecraft:cracked_stone_bricks
setblock ~-13 ~15 ~-103 minecraft:cracked_stone_bricks
setblock ~-13 ~15 ~-37 minecraft:cracked_stone_bricks
setblock ~-13 ~19 ~-161 minecraft:cracked_stone_bricks
fill ~-13 ~20 ~-37 ~-13 ~21 ~-37 minecraft:cracked_stone_bricks
setblock ~-13 ~22 ~-23 minecraft:cracked_stone_bricks
setblock ~-13 ~29 ~-37 minecraft:cracked_stone_bricks
setblock ~-13 ~30 ~-27 minecraft:cracked_stone_bricks
setblock ~-13 ~34 ~-145 minecraft:cracked_stone_bricks
setblock ~-13 ~35 ~-146 minecraft:cracked_stone_bricks
setblock ~-13 ~40 ~-146 minecraft:cracked_stone_bricks
setblock ~-13 ~44 ~-121 minecraft:cracked_stone_bricks
setblock ~-12 ~ ~-24 minecraft:cracked_stone_bricks
setblock ~-12 ~5 ~-125 minecraft:cracked_stone_bricks
fill ~-12 ~5 ~-102 ~-10 ~5 ~-102 minecraft:cracked_stone_bricks
setblock ~-12 ~9 ~-146 minecraft:cracked_stone_bricks
setblock ~-12 ~10 ~-103 minecraft:cracked_stone_bricks
setblock ~-12 ~10 ~-24 minecraft:cracked_stone_bricks
setblock ~-12 ~13 ~-156 minecraft:cracked_stone_bricks
setblock ~-12 ~13 ~-24 minecraft:cracked_stone_bricks
setblock ~-12 ~14 ~-103 minecraft:cracked_stone_bricks
setblock ~-12 ~15 ~-156 minecraft:cracked_stone_bricks
setblock ~-12 ~16 ~-37 minecraft:cracked_stone_bricks
setblock ~-12 ~16 ~-24 minecraft:cracked_stone_bricks
setblock ~-12 ~21 ~-24 minecraft:cracked_stone_bricks
setblock ~-12 ~28 ~-103 minecraft:cracked_stone_bricks
setblock ~-12 ~30 ~-124 minecraft:cracked_stone_bricks
setblock ~-12 ~37 ~-103 minecraft:cracked_stone_bricks
setblock ~-12 ~43 ~-145 minecraft:cracked_stone_bricks
fill ~-12 ~44 ~-146 ~-11 ~44 ~-146 minecraft:cracked_stone_bricks
setblock ~-12 ~44 ~-108 minecraft:cracked_stone_bricks
setblock ~-12 ~44 ~-106 minecraft:cracked_stone_bricks
setblock ~-11 ~ ~-134 minecraft:cracked_stone_bricks
setblock ~-11 ~ ~-118 minecraft:cracked_stone_bricks
setblock ~-11 ~1 ~-120 minecraft:cracked_stone_bricks
setblock ~-11 ~1 ~-110 minecraft:cracked_stone_bricks
setblock ~-11 ~2 ~-123 minecraft:cracked_stone_bricks
fill ~-11 ~3 ~-141 ~-11 ~4 ~-141 minecraft:cracked_stone_bricks
setblock ~-11 ~3 ~-133 minecraft:cracked_stone_bricks
setblock ~-11 ~3 ~-109 minecraft:cracked_stone_bricks
fill ~-11 ~3 ~-102 ~-9 ~3 ~-102 minecraft:cracked_stone_bricks
setblock ~-11 ~4 ~-145 minecraft:cracked_stone_bricks
setblock ~-11 ~4 ~-106 minecraft:cracked_stone_bricks
setblock ~-11 ~5 ~-144 minecraft:cracked_stone_bricks
setblock ~-11 ~6 ~-103 minecraft:cracked_stone_bricks
fill ~-11 ~7 ~-117 ~-11 ~7 ~-116 minecraft:cracked_stone_bricks
setblock ~-11 ~8 ~-138 minecraft:cracked_stone_bricks
setblock ~-11 ~8 ~-36 minecraft:cracked_stone_bricks
fill ~-11 ~9 ~-143 ~-10 ~9 ~-142 minecraft:cracked_stone_bricks
fill ~-11 ~9 ~-120 ~-10 ~9 ~-120 minecraft:cracked_stone_bricks
fill ~-11 ~10 ~-135 ~-10 ~10 ~-135 minecraft:cracked_stone_bricks
fill ~-11 ~10 ~-116 ~-10 ~10 ~-116 minecraft:cracked_stone_bricks
setblock ~-11 ~12 ~-156 minecraft:cracked_stone_bricks
setblock ~-11 ~15 ~-103 minecraft:cracked_stone_bricks
setblock ~-11 ~19 ~-161 minecraft:cracked_stone_bricks
setblock ~-11 ~22 ~-37 minecraft:cracked_stone_bricks
setblock ~-11 ~22 ~-24 minecraft:cracked_stone_bricks
setblock ~-11 ~23 ~-144 minecraft:cracked_stone_bricks
setblock ~-11 ~23 ~-104 minecraft:cracked_stone_bricks
setblock ~-11 ~24 ~-142 minecraft:cracked_stone_bricks
setblock ~-11 ~24 ~-138 minecraft:cracked_stone_bricks
setblock ~-11 ~24 ~-128 minecraft:cracked_stone_bricks
setblock ~-11 ~24 ~-113 minecraft:cracked_stone_bricks
setblock ~-11 ~26 ~-139 minecraft:cracked_stone_bricks
setblock ~-11 ~26 ~-110 minecraft:cracked_stone_bricks
setblock ~-11 ~26 ~-24 minecraft:cracked_stone_bricks
setblock ~-11 ~27 ~-141 minecraft:cracked_stone_bricks
setblock ~-11 ~27 ~-126 minecraft:cracked_stone_bricks
fill ~-11 ~29 ~-146 ~-10 ~29 ~-146 minecraft:cracked_stone_bricks
setblock ~-11 ~29 ~-112 minecraft:cracked_stone_bricks
setblock ~-11 ~30 ~-133 minecraft:cracked_stone_bricks
fill ~-11 ~30 ~-127 ~-11 ~31 ~-127 minecraft:cracked_stone_bricks
setblock ~-11 ~30 ~-109 minecraft:cracked_stone_bricks
setblock ~-11 ~30 ~-22 minecraft:cracked_stone_bricks
setblock ~-11 ~31 ~-122 minecraft:cracked_stone_bricks
setblock ~-11 ~32 ~-143 minecraft:cracked_stone_bricks
setblock ~-11 ~32 ~-123 minecraft:cracked_stone_bricks
setblock ~-11 ~32 ~-112 minecraft:cracked_stone_bricks
setblock ~-11 ~32 ~-110 minecraft:cracked_stone_bricks
setblock ~-11 ~34 ~-121 minecraft:cracked_stone_bricks
setblock ~-11 ~35 ~-126 minecraft:cracked_stone_bricks
fill ~-11 ~35 ~-118 ~-11 ~36 ~-118 minecraft:cracked_stone_bricks
setblock ~-11 ~36 ~-112 minecraft:cracked_stone_bricks
setblock ~-11 ~37 ~-137 minecraft:cracked_stone_bricks
setblock ~-11 ~38 ~-118 minecraft:cracked_stone_bricks
setblock ~-11 ~39 ~-141 minecraft:cracked_stone_bricks
setblock ~-11 ~39 ~-123 minecraft:cracked_stone_bricks
setblock ~-11 ~39 ~-116 minecraft:cracked_stone_bricks
setblock ~-11 ~39 ~-107 minecraft:cracked_stone_bricks
setblock ~-11 ~40 ~-145 minecraft:cracked_stone_bricks
fill ~-11 ~40 ~-142 ~-11 ~41 ~-142 minecraft:cracked_stone_bricks
setblock ~-11 ~40 ~-121 minecraft:cracked_stone_bricks
fill ~-11 ~41 ~-144 ~-11 ~42 ~-144 minecraft:cracked_stone_bricks
setblock ~-11 ~41 ~-129 minecraft:cracked_stone_bricks
setblock ~-11 ~41 ~-123 minecraft:cracked_stone_bricks
setblock ~-11 ~41 ~-102 minecraft:cracked_stone_bricks
setblock ~-11 ~42 ~-139 minecraft:cracked_stone_bricks
setblock ~-11 ~42 ~-125 minecraft:cracked_stone_bricks
setblock ~-11 ~42 ~-105 minecraft:cracked_stone_bricks
setblock ~-11 ~43 ~-107 minecraft:cracked_stone_bricks
fill ~-11 ~44 ~-120 ~-11 ~44 ~-119 minecraft:cracked_stone_bricks
setblock ~-11 ~44 ~-112 minecraft:cracked_stone_bricks
fill ~-10 ~-27 ~-122 ~-8 ~-27 ~-122 minecraft:cracked_stone_bricks
setblock ~-10 ~1 ~-145 minecraft:cracked_stone_bricks
setblock ~-10 ~6 ~-35 minecraft:cracked_stone_bricks
setblock ~-10 ~6 ~-24 minecraft:cracked_stone_bricks
setblock ~-10 ~9 ~-160 minecraft:cracked_stone_bricks
setblock ~-10 ~13 ~-160 minecraft:cracked_stone_bricks
setblock ~-10 ~13 ~-103 minecraft:cracked_stone_bricks
setblock ~-10 ~16 ~-25 minecraft:cracked_stone_bricks
setblock ~-10 ~20 ~-24 minecraft:cracked_stone_bricks
setblock ~-10 ~22 ~-35 minecraft:cracked_stone_bricks
setblock ~-10 ~32 ~-103 minecraft:cracked_stone_bricks
setblock ~-10 ~44 ~-128 minecraft:cracked_stone_bricks
setblock ~-10 ~45 ~-122 minecraft:cracked_stone_bricks
setblock ~-10 ~47 ~-121 minecraft:cracked_stone_bricks
setblock ~-10 ~51 ~-124 minecraft:cracked_stone_bricks
setblock ~-10 ~52 ~-127 minecraft:cracked_stone_bricks
setblock ~-10 ~54 ~-126 minecraft:cracked_stone_bricks
setblock ~-10 ~58 ~-123 minecraft:cracked_stone_bricks
setblock ~-10 ~60 ~-124 minecraft:cracked_stone_bricks
setblock ~-10 ~62 ~-127 minecraft:cracked_stone_bricks
setblock ~-9 ~ ~-27 minecraft:cracked_stone_bricks
setblock ~-9 ~3 ~-38 minecraft:cracked_stone_bricks
setblock ~-9 ~4 ~-103 minecraft:cracked_stone_bricks
setblock ~-9 ~5 ~-38 minecraft:cracked_stone_bricks
setblock ~-9 ~6 ~-156 minecraft:cracked_stone_bricks
setblock ~-9 ~7 ~-145 minecraft:cracked_stone_bricks
setblock ~-9 ~7 ~-27 minecraft:cracked_stone_bricks
setblock ~-9 ~11 ~-40 minecraft:cracked_stone_bricks
setblock ~-9 ~12 ~-39 minecraft:cracked_stone_bricks
setblock ~-9 ~12 ~-37 minecraft:cracked_stone_bricks
setblock ~-9 ~16 ~-27 minecraft:cracked_stone_bricks
setblock ~-9 ~17 ~-36 minecraft:cracked_stone_bricks
fill ~-9 ~19 ~-102 ~-9 ~20 ~-102 minecraft:cracked_stone_bricks
fill ~-9 ~19 ~-40 ~-8 ~19 ~-40 minecraft:cracked_stone_bricks
setblock ~-9 ~19 ~-34 minecraft:cracked_stone_bricks
fill ~-9 ~23 ~-40 ~-8 ~23 ~-40 minecraft:cracked_stone_bricks
setblock ~-9 ~24 ~-40 minecraft:cracked_stone_bricks
setblock ~-9 ~24 ~-34 minecraft:cracked_stone_bricks
setblock ~-9 ~27 ~-27 minecraft:cracked_stone_bricks
setblock ~-9 ~29 ~-124 minecraft:cracked_stone_bricks
setblock ~-9 ~29 ~-33 minecraft:cracked_stone_bricks
setblock ~-9 ~29 ~-27 minecraft:cracked_stone_bricks
setblock ~-9 ~30 ~-102 minecraft:cracked_stone_bricks
fill ~-9 ~42 ~-103 ~-9 ~42 ~-102 minecraft:cracked_stone_bricks
setblock ~-9 ~44 ~-125 minecraft:cracked_stone_bricks
setblock ~-9 ~44 ~-103 minecraft:cracked_stone_bricks
setblock ~-9 ~47 ~-120 minecraft:cracked_stone_bricks
setblock ~-9 ~48 ~-125 minecraft:cracked_stone_bricks
setblock ~-9 ~56 ~-125 minecraft:cracked_stone_bricks
setblock ~-9 ~57 ~-123 minecraft:cracked_stone_bricks
setblock ~-9 ~58 ~-119 minecraft:cracked_stone_bricks
fill ~-9 ~60 ~-120 ~-8 ~60 ~-120 minecraft:cracked_stone_bricks
setblock ~-9 ~62 ~-128 minecraft:cracked_stone_bricks
setblock ~-9 ~63 ~-125 minecraft:cracked_stone_bricks
setblock ~-9 ~64 ~-119 minecraft:cracked_stone_bricks
fill ~-8 ~ ~-74 ~-8 ~ ~-71 minecraft:cracked_stone_bricks
setblock ~-8 ~2 ~-31 minecraft:cracked_stone_bricks
setblock ~-8 ~7 ~-32 minecraft:cracked_stone_bricks
fill ~-8 ~10 ~-146 ~-7 ~10 ~-146 minecraft:cracked_stone_bricks
setblock ~-8 ~10 ~-145 minecraft:cracked_stone_bricks
setblock ~-8 ~14 ~-146 minecraft:cracked_stone_bricks
setblock ~-8 ~17 ~-34 minecraft:cracked_stone_bricks
setblock ~-8 ~20 ~-33 minecraft:cracked_stone_bricks
setblock ~-8 ~21 ~-102 minecraft:cracked_stone_bricks
setblock ~-8 ~22 ~-29 minecraft:cracked_stone_bricks
setblock ~-8 ~28 ~-124 minecraft:cracked_stone_bricks
setblock ~-8 ~37 ~-146 minecraft:cracked_stone_bricks
setblock ~-8 ~43 ~-103 minecraft:cracked_stone_bricks
setblock ~-8 ~44 ~-128 minecraft:cracked_stone_bricks
setblock ~-8 ~44 ~-117 minecraft:cracked_stone_bricks
setblock ~-8 ~47 ~-121 minecraft:cracked_stone_bricks
setblock ~-8 ~64 ~-130 minecraft:cracked_stone_bricks
setblock ~-8 ~66 ~-123 minecraft:cracked_stone_bricks
setblock ~-8 ~66 ~-118 minecraft:cracked_stone_bricks
setblock ~-7 ~4 ~-102 minecraft:cracked_stone_bricks
fill ~-7 ~8 ~-26 ~-6 ~8 ~-26 minecraft:cracked_stone_bricks
setblock ~-7 ~11 ~-26 minecraft:cracked_stone_bricks
setblock ~-7 ~13 ~-29 minecraft:cracked_stone_bricks
setblock ~-7 ~13 ~-26 minecraft:cracked_stone_bricks
setblock ~-7 ~19 ~-32 minecraft:cracked_stone_bricks
setblock ~-7 ~21 ~-158 minecraft:cracked_stone_bricks
setblock ~-7 ~23 ~-103 minecraft:cracked_stone_bricks
setblock ~-7 ~23 ~-31 minecraft:cracked_stone_bricks
setblock ~-7 ~27 ~-163 minecraft:cracked_stone_bricks
setblock ~-7 ~50 ~-118 minecraft:cracked_stone_bricks
setblock ~-7 ~57 ~-131 minecraft:cracked_stone_bricks
setblock ~-7 ~67 ~-116 minecraft:cracked_stone_bricks
setblock ~-6 ~4 ~-145 minecraft:cracked_stone_bricks
setblock ~-6 ~6 ~-40 minecraft:cracked_stone_bricks
setblock ~-6 ~11 ~-164 minecraft:cracked_stone_bricks
setblock ~-6 ~12 ~-163 minecraft:cracked_stone_bricks
setblock ~-6 ~13 ~-146 minecraft:cracked_stone_bricks
setblock ~-6 ~13 ~-103 minecraft:cracked_stone_bricks
setblock ~-6 ~15 ~-163 minecraft:cracked_stone_bricks
setblock ~-6 ~15 ~-146 minecraft:cracked_stone_bricks
setblock ~-6 ~18 ~-159 minecraft:cracked_stone_bricks
setblock ~-6 ~26 ~-154 minecraft:cracked_stone_bricks
setblock ~-6 ~26 ~-26 minecraft:cracked_stone_bricks
setblock ~-6 ~28 ~-145 minecraft:cracked_stone_bricks
setblock ~-6 ~29 ~-146 minecraft:cracked_stone_bricks
setblock ~-6 ~44 ~-141 minecraft:cracked_stone_bricks
setblock ~-6 ~45 ~-116 minecraft:cracked_stone_bricks
setblock ~-6 ~58 ~-131 minecraft:cracked_stone_bricks
setblock ~-6 ~60 ~-117 minecraft:cracked_stone_bricks
setblock ~-6 ~66 ~-123 minecraft:cracked_stone_bricks
setblock ~-6 ~66 ~-120 minecraft:cracked_stone_bricks
fill ~-5 ~-26 ~-121 ~-1 ~-19 ~-101 minecraft:cracked_stone_bricks
setblock ~-5 ~ ~-70 minecraft:cracked_stone_bricks
setblock ~-5 ~3 ~-102 minecraft:cracked_stone_bricks
setblock ~-5 ~4 ~-30 minecraft:cracked_stone_bricks
setblock ~-5 ~5 ~-165 minecraft:cracked_stone_bricks
setblock ~-5 ~5 ~-145 minecraft:cracked_stone_bricks
setblock ~-5 ~7 ~-33 minecraft:cracked_stone_bricks
setblock ~-5 ~8 ~-30 minecraft:cracked_stone_bricks
setblock ~-5 ~10 ~-163 minecraft:cracked_stone_bricks
fill ~-5 ~12 ~-157 ~-5 ~13 ~-157 minecraft:cracked_stone_bricks
setblock ~-5 ~12 ~-26 minecraft:cracked_stone_bricks
setblock ~-5 ~15 ~-40 minecraft:cracked_stone_bricks
setblock ~-5 ~17 ~-157 minecraft:cracked_stone_bricks
setblock ~-5 ~19 ~-102 minecraft:cracked_stone_bricks
setblock ~-5 ~20 ~-146 minecraft:cracked_stone_bricks
setblock ~-5 ~27 ~-145 minecraft:cracked_stone_bricks
fill ~-5 ~28 ~-103 ~-5 ~29 ~-103 minecraft:cracked_stone_bricks
setblock ~-5 ~29 ~-102 minecraft:cracked_stone_bricks
setblock ~-5 ~30 ~-145 minecraft:cracked_stone_bricks
setblock ~-5 ~35 ~-145 minecraft:cracked_stone_bricks
fill ~-5 ~35 ~-103 ~-5 ~36 ~-103 minecraft:cracked_stone_bricks
setblock ~-5 ~37 ~-146 minecraft:cracked_stone_bricks
fill ~-5 ~39 ~-146 ~-5 ~40 ~-146 minecraft:cracked_stone_bricks
setblock ~-5 ~44 ~-135 minecraft:cracked_stone_bricks
setblock ~-5 ~44 ~-125 minecraft:cracked_stone_bricks
setblock ~-5 ~45 ~-131 minecraft:cracked_stone_bricks
setblock ~-5 ~46 ~-147 minecraft:cracked_stone_bricks
setblock ~-5 ~46 ~-117 minecraft:cracked_stone_bricks
setblock ~-5 ~50 ~-133 minecraft:cracked_stone_bricks
setblock ~-5 ~53 ~-115 minecraft:cracked_stone_bricks
setblock ~-5 ~54 ~-117 minecraft:cracked_stone_bricks
setblock ~-5 ~55 ~-133 minecraft:cracked_stone_bricks
fill ~-5 ~56 ~-131 ~-5 ~57 ~-131 minecraft:cracked_stone_bricks
setblock ~-5 ~66 ~-114 minecraft:cracked_stone_bricks
setblock ~-5 ~67 ~-134 minecraft:cracked_stone_bricks
setblock ~-4 ~4 ~-154 minecraft:cracked_stone_bricks
setblock ~-4 ~5 ~-166 minecraft:cracked_stone_bricks
setblock ~-4 ~8 ~-164 minecraft:cracked_stone_bricks
setblock ~-4 ~10 ~-103 minecraft:cracked_stone_bricks
setblock ~-4 ~14 ~-164 minecraft:cracked_stone_bricks
setblock ~-4 ~16 ~-156 minecraft:cracked_stone_bricks
setblock ~-4 ~17 ~-146 minecraft:cracked_stone_bricks
setblock ~-4 ~20 ~-166 minecraft:cracked_stone_bricks
setblock ~-4 ~24 ~-156 minecraft:cracked_stone_bricks
setblock ~-4 ~24 ~-145 minecraft:cracked_stone_bricks
setblock ~-4 ~24 ~-103 minecraft:cracked_stone_bricks
setblock ~-4 ~24 ~-40 minecraft:cracked_stone_bricks
setblock ~-4 ~24 ~-38 minecraft:cracked_stone_bricks
setblock ~-4 ~26 ~-153 minecraft:cracked_stone_bricks
setblock ~-4 ~29 ~-145 minecraft:cracked_stone_bricks
setblock ~-4 ~44 ~-129 minecraft:cracked_stone_bricks
setblock ~-4 ~45 ~-101 minecraft:cracked_stone_bricks
setblock ~-4 ~64 ~-132 minecraft:cracked_stone_bricks
fill ~-4 ~66 ~-129 ~-3 ~66 ~-129 minecraft:cracked_stone_bricks
setblock ~-4 ~66 ~-126 minecraft:cracked_stone_bricks
fill ~-4 ~66 ~-119 ~-3 ~66 ~-119 minecraft:cracked_stone_bricks
setblock ~-3 ~6 ~-154 minecraft:cracked_stone_bricks
setblock ~-3 ~8 ~-145 minecraft:cracked_stone_bricks
setblock ~-3 ~8 ~-102 minecraft:cracked_stone_bricks
setblock ~-3 ~10 ~-33 minecraft:cracked_stone_bricks
setblock ~-3 ~12 ~-146 minecraft:cracked_stone_bricks
setblock ~-3 ~18 ~-154 minecraft:cracked_stone_bricks
setblock ~-3 ~18 ~-146 minecraft:cracked_stone_bricks
setblock ~-3 ~21 ~-155 minecraft:cracked_stone_bricks
setblock ~-3 ~31 ~-102 minecraft:cracked_stone_bricks
setblock ~-3 ~38 ~-145 minecraft:cracked_stone_bricks
setblock ~-3 ~44 ~-142 minecraft:cracked_stone_bricks
setblock ~-3 ~44 ~-137 minecraft:cracked_stone_bricks
fill ~-3 ~44 ~-122 ~-3 ~44 ~-121 minecraft:cracked_stone_bricks
setblock ~-3 ~56 ~-132 minecraft:cracked_stone_bricks
setblock ~-3 ~61 ~-116 minecraft:cracked_stone_bricks
setblock ~-3 ~63 ~-132 minecraft:cracked_stone_bricks
setblock ~-3 ~64 ~-134 minecraft:cracked_stone_bricks
setblock ~-3 ~67 ~-135 minecraft:cracked_stone_bricks
setblock ~-2 ~1 ~-153 minecraft:cracked_stone_bricks
fill ~-2 ~6 ~-153 ~-1 ~6 ~-153 minecraft:cracked_stone_bricks
setblock ~-2 ~11 ~-35 minecraft:cracked_stone_bricks
setblock ~-2 ~11 ~-27 minecraft:cracked_stone_bricks
setblock ~-2 ~12 ~-166 minecraft:cracked_stone_bricks
fill ~-2 ~12 ~-154 ~-1 ~12 ~-154 minecraft:cracked_stone_bricks
setblock ~-2 ~17 ~-154 minecraft:cracked_stone_bricks
setblock ~-2 ~18 ~-145 minecraft:cracked_stone_bricks
setblock ~-2 ~18 ~-103 minecraft:cracked_stone_bricks
setblock ~-2 ~18 ~-25 minecraft:cracked_stone_bricks
setblock ~-2 ~19 ~-153 minecraft:cracked_stone_bricks
setblock ~-2 ~24 ~-153 minecraft:cracked_stone_bricks
setblock ~-2 ~24 ~-38 minecraft:cracked_stone_bricks
setblock ~-2 ~25 ~-40 minecraft:cracked_stone_bricks
setblock ~-2 ~26 ~-165 minecraft:cracked_stone_bricks
setblock ~-2 ~26 ~-161 minecraft:cracked_stone_bricks
setblock ~-2 ~29 ~-145 minecraft:cracked_stone_bricks
setblock ~-2 ~37 ~-145 minecraft:cracked_stone_bricks
setblock ~-2 ~43 ~-103 minecraft:cracked_stone_bricks
setblock ~-2 ~44 ~-141 minecraft:cracked_stone_bricks
setblock ~-2 ~49 ~-134 minecraft:cracked_stone_bricks
setblock ~-2 ~50 ~-133 minecraft:cracked_stone_bricks
setblock ~-2 ~64 ~-115 minecraft:cracked_stone_bricks
setblock ~-1 ~2 ~-166 minecraft:cracked_stone_bricks
fill ~-1 ~5 ~-153 ~-1 ~6 ~-153 minecraft:cracked_stone_bricks
setblock ~-1 ~11 ~-31 minecraft:cracked_stone_bricks
fill ~-1 ~13 ~-40 ~-1 ~15 ~-40 minecraft:cracked_stone_bricks
setblock ~-1 ~15 ~-154 minecraft:cracked_stone_bricks
setblock ~-1 ~21 ~-25 minecraft:cracked_stone_bricks
setblock ~-1 ~22 ~-154 minecraft:cracked_stone_bricks
setblock ~-1 ~24 ~-31 minecraft:cracked_stone_bricks
fill ~-1 ~24 ~-27 ~ ~24 ~-27 minecraft:cracked_stone_bricks
setblock ~-1 ~27 ~-168 minecraft:cracked_stone_bricks
setblock ~-1 ~27 ~-146 minecraft:cracked_stone_bricks
setblock ~-1 ~31 ~-102 minecraft:cracked_stone_bricks
setblock ~-1 ~35 ~-145 minecraft:cracked_stone_bricks
setblock ~-1 ~39 ~-145 minecraft:cracked_stone_bricks
setblock ~-1 ~44 ~-142 minecraft:cracked_stone_bricks
setblock ~-1 ~44 ~-116 minecraft:cracked_stone_bricks
setblock ~-1 ~51 ~-114 minecraft:cracked_stone_bricks
setblock ~-1 ~64 ~-134 minecraft:cracked_stone_bricks
setblock ~-1 ~66 ~-126 minecraft:cracked_stone_bricks
setblock ~ ~5 ~-154 minecraft:cracked_stone_bricks
fill ~ ~11 ~-166 ~ ~13 ~-166 minecraft:cracked_stone_bricks
setblock ~ ~16 ~-166 minecraft:cracked_stone_bricks
fill ~ ~18 ~-145 ~2 ~18 ~-145 minecraft:cracked_stone_bricks
setblock ~ ~19 ~-102 minecraft:cracked_stone_bricks
fill ~ ~20 ~-25 ~1 ~20 ~-25 minecraft:cracked_stone_bricks
fill ~ ~23 ~-146 ~1 ~23 ~-146 minecraft:cracked_stone_bricks
setblock ~ ~23 ~-145 minecraft:cracked_stone_bricks
setblock ~ ~23 ~-103 minecraft:cracked_stone_bricks
setblock ~ ~23 ~-26 minecraft:cracked_stone_bricks
setblock ~ ~24 ~-166 minecraft:cracked_stone_bricks
setblock ~ ~26 ~-103 minecraft:cracked_stone_bricks
fill ~ ~29 ~-103 ~1 ~29 ~-103 minecraft:cracked_stone_bricks
fill ~ ~32 ~-124 ~ ~33 ~-124 minecraft:cracked_stone_bricks
setblock ~ ~34 ~-145 minecraft:cracked_stone_bricks
setblock ~ ~44 ~-125 minecraft:cracked_stone_bricks
setblock ~ ~44 ~-114 minecraft:cracked_stone_bricks
setblock ~ ~44 ~-108 minecraft:cracked_stone_bricks
fill ~ ~52 ~-115 ~ ~53 ~-115 minecraft:cracked_stone_bricks
setblock ~ ~60 ~-115 minecraft:cracked_stone_bricks
setblock ~ ~66 ~-123 minecraft:cracked_stone_bricks
setblock ~1 ~6 ~-166 minecraft:cracked_stone_bricks
setblock ~1 ~8 ~-153 minecraft:cracked_stone_bricks
setblock ~1 ~14 ~-153 minecraft:cracked_stone_bricks
setblock ~1 ~17 ~-40 minecraft:cracked_stone_bricks
setblock ~1 ~18 ~-25 minecraft:cracked_stone_bricks
fill ~1 ~20 ~-146 ~2 ~20 ~-146 minecraft:cracked_stone_bricks
fill ~1 ~21 ~-154 ~2 ~21 ~-154 minecraft:cracked_stone_bricks
setblock ~1 ~23 ~-167 minecraft:cracked_stone_bricks
setblock ~1 ~24 ~-29 minecraft:cracked_stone_bricks
setblock ~1 ~25 ~-166 minecraft:cracked_stone_bricks
setblock ~1 ~31 ~-145 minecraft:cracked_stone_bricks
setblock ~1 ~31 ~-102 minecraft:cracked_stone_bricks
setblock ~1 ~44 ~-115 minecraft:cracked_stone_bricks
setblock ~1 ~44 ~-107 minecraft:cracked_stone_bricks
setblock ~1 ~50 ~-134 minecraft:cracked_stone_bricks
setblock ~1 ~59 ~-133 minecraft:cracked_stone_bricks
setblock ~1 ~63 ~-133 minecraft:cracked_stone_bricks
setblock ~1 ~66 ~-134 minecraft:cracked_stone_bricks
setblock ~1 ~66 ~-119 minecraft:cracked_stone_bricks
setblock ~2 ~2 ~-153 minecraft:cracked_stone_bricks
setblock ~2 ~9 ~-167 minecraft:cracked_stone_bricks
setblock ~2 ~11 ~-153 minecraft:cracked_stone_bricks
fill ~2 ~12 ~-103 ~2 ~12 ~-102 minecraft:cracked_stone_bricks
setblock ~2 ~13 ~-40 minecraft:cracked_stone_bricks
setblock ~2 ~13 ~-26 minecraft:cracked_stone_bricks
fill ~2 ~14 ~-103 ~2 ~15 ~-103 minecraft:cracked_stone_bricks
fill ~2 ~16 ~-26 ~2 ~17 ~-26 minecraft:cracked_stone_bricks
setblock ~2 ~21 ~-103 minecraft:cracked_stone_bricks
setblock ~2 ~23 ~-153 minecraft:cracked_stone_bricks
setblock ~2 ~24 ~-103 minecraft:cracked_stone_bricks
fill ~2 ~24 ~-36 ~3 ~24 ~-36 minecraft:cracked_stone_bricks
setblock ~2 ~24 ~-32 minecraft:cracked_stone_bricks
setblock ~2 ~27 ~-152 minecraft:cracked_stone_bricks
setblock ~2 ~28 ~-145 minecraft:cracked_stone_bricks
setblock ~2 ~32 ~-102 minecraft:cracked_stone_bricks
setblock ~2 ~37 ~-146 minecraft:cracked_stone_bricks
setblock ~2 ~44 ~-147 minecraft:cracked_stone_bricks
setblock ~2 ~44 ~-132 minecraft:cracked_stone_bricks
setblock ~2 ~44 ~-112 minecraft:cracked_stone_bricks
setblock ~2 ~47 ~-115 minecraft:cracked_stone_bricks
setblock ~2 ~55 ~-114 minecraft:cracked_stone_bricks
setblock ~2 ~60 ~-134 minecraft:cracked_stone_bricks
setblock ~2 ~66 ~-120 minecraft:cracked_stone_bricks
setblock ~3 ~1 ~-155 minecraft:cracked_stone_bricks
setblock ~3 ~3 ~-154 minecraft:cracked_stone_bricks
setblock ~3 ~6 ~-103 minecraft:cracked_stone_bricks
setblock ~3 ~9 ~-146 minecraft:cracked_stone_bricks
setblock ~3 ~10 ~-33 minecraft:cracked_stone_bricks
setblock ~3 ~10 ~-30 minecraft:cracked_stone_bricks
setblock ~3 ~11 ~-40 minecraft:cracked_stone_bricks
setblock ~3 ~14 ~-165 minecraft:cracked_stone_bricks
setblock ~3 ~19 ~-166 minecraft:cracked_stone_bricks
setblock ~3 ~20 ~-102 minecraft:cracked_stone_bricks
setblock ~3 ~20 ~-40 minecraft:cracked_stone_bricks
setblock ~3 ~26 ~-162 minecraft:cracked_stone_bricks
setblock ~3 ~27 ~-145 minecraft:cracked_stone_bricks
fill ~3 ~29 ~-103 ~4 ~29 ~-103 minecraft:cracked_stone_bricks
fill ~3 ~30 ~-146 ~3 ~31 ~-146 minecraft:cracked_stone_bricks
setblock ~3 ~35 ~-145 minecraft:cracked_stone_bricks
setblock ~3 ~40 ~-146 minecraft:cracked_stone_bricks
setblock ~3 ~43 ~-145 minecraft:cracked_stone_bricks
setblock ~3 ~44 ~-136 minecraft:cracked_stone_bricks
setblock ~3 ~44 ~-109 minecraft:cracked_stone_bricks
fill ~3 ~44 ~-107 ~4 ~44 ~-107 minecraft:cracked_stone_bricks
setblock ~3 ~50 ~-114 minecraft:cracked_stone_bricks
setblock ~3 ~55 ~-134 minecraft:cracked_stone_bricks
setblock ~3 ~64 ~-132 minecraft:cracked_stone_bricks
setblock ~3 ~64 ~-116 minecraft:cracked_stone_bricks
setblock ~4 ~1 ~-103 minecraft:cracked_stone_bricks
setblock ~4 ~3 ~-166 minecraft:cracked_stone_bricks
setblock ~4 ~5 ~-166 minecraft:cracked_stone_bricks
setblock ~4 ~8 ~-156 minecraft:cracked_stone_bricks
setblock ~4 ~8 ~-146 minecraft:cracked_stone_bricks
setblock ~4 ~13 ~-103 minecraft:cracked_stone_bricks
setblock ~4 ~16 ~-103 minecraft:cracked_stone_bricks
setblock ~4 ~18 ~-166 minecraft:cracked_stone_bricks
setblock ~4 ~18 ~-25 minecraft:cracked_stone_bricks
setblock ~4 ~20 ~-145 minecraft:cracked_stone_bricks
fill ~4 ~24 ~-146 ~4 ~24 ~-145 minecraft:cracked_stone_bricks
fill ~4 ~28 ~-103 ~4 ~29 ~-103 minecraft:cracked_stone_bricks
setblock ~4 ~44 ~-138 minecraft:cracked_stone_bricks
setblock ~4 ~44 ~-125 minecraft:cracked_stone_bricks
setblock ~4 ~44 ~-112 minecraft:cracked_stone_bricks
setblock ~4 ~49 ~-132 minecraft:cracked_stone_bricks
setblock ~4 ~59 ~-115 minecraft:cracked_stone_bricks
setblock ~4 ~65 ~-132 minecraft:cracked_stone_bricks
setblock ~5 ~3 ~-30 minecraft:cracked_stone_bricks
setblock ~5 ~4 ~-40 minecraft:cracked_stone_bricks
setblock ~5 ~5 ~-103 minecraft:cracked_stone_bricks
setblock ~5 ~5 ~-35 minecraft:cracked_stone_bricks
setblock ~5 ~5 ~-32 minecraft:cracked_stone_bricks
setblock ~5 ~6 ~-38 minecraft:cracked_stone_bricks
fill ~5 ~6 ~-30 ~5 ~7 ~-30 minecraft:cracked_stone_bricks
setblock ~5 ~7 ~-145 minecraft:cracked_stone_bricks
setblock ~5 ~7 ~-102 minecraft:cracked_stone_bricks
fill ~5 ~7 ~-31 ~5 ~7 ~-30 minecraft:cracked_stone_bricks
setblock ~5 ~8 ~-29 minecraft:cracked_stone_bricks
setblock ~5 ~13 ~-165 minecraft:cracked_stone_bricks
setblock ~5 ~13 ~-146 minecraft:cracked_stone_bricks
setblock ~5 ~14 ~-155 minecraft:cracked_stone_bricks
setblock ~5 ~16 ~-155 minecraft:cracked_stone_bricks
fill ~5 ~17 ~-146 ~6 ~17 ~-146 minecraft:cracked_stone_bricks
setblock ~5 ~17 ~-103 minecraft:cracked_stone_bricks
setblock ~5 ~17 ~-40 minecraft:cracked_stone_bricks
setblock ~5 ~19 ~-146 minecraft:cracked_stone_bricks
setblock ~5 ~20 ~-155 minecraft:cracked_stone_bricks
setblock ~5 ~24 ~-165 minecraft:cracked_stone_bricks
fill ~5 ~24 ~-35 ~5 ~24 ~-34 minecraft:cracked_stone_bricks
setblock ~5 ~25 ~-157 minecraft:cracked_stone_bricks
fill ~5 ~26 ~-102 ~6 ~26 ~-102 minecraft:cracked_stone_bricks
setblock ~5 ~41 ~-146 minecraft:cracked_stone_bricks
setblock ~5 ~44 ~-143 minecraft:cracked_stone_bricks
setblock ~5 ~44 ~-116 minecraft:cracked_stone_bricks
fill ~5 ~45 ~-101 ~5 ~47 ~-101 minecraft:cracked_stone_bricks
setblock ~5 ~46 ~-117 minecraft:cracked_stone_bricks
setblock ~5 ~47 ~-115 minecraft:cracked_stone_bricks
setblock ~5 ~49 ~-131 minecraft:cracked_stone_bricks
setblock ~5 ~53 ~-131 minecraft:cracked_stone_bricks
setblock ~6 ~ ~-160 minecraft:cracked_stone_bricks
setblock ~6 ~1 ~-145 minecraft:cracked_stone_bricks
setblock ~6 ~7 ~-160 minecraft:cracked_stone_bricks
setblock ~6 ~8 ~-163 minecraft:cracked_stone_bricks
fill ~6 ~10 ~-160 ~6 ~10 ~-159 minecraft:cracked_stone_bricks
setblock ~6 ~15 ~-161 minecraft:cracked_stone_bricks
setblock ~6 ~23 ~-159 minecraft:cracked_stone_bricks
setblock ~6 ~24 ~-156 minecraft:cracked_stone_bricks
setblock ~6 ~24 ~-34 minecraft:cracked_stone_bricks
setblock ~6 ~24 ~-32 minecraft:cracked_stone_bricks
setblock ~6 ~26 ~-165 minecraft:cracked_stone_bricks
setblock ~6 ~26 ~-124 minecraft:cracked_stone_bricks
setblock ~6 ~30 ~-32 minecraft:cracked_stone_bricks
setblock ~6 ~43 ~-145 minecraft:cracked_stone_bricks
setblock ~6 ~44 ~-119 minecraft:cracked_stone_bricks
setblock ~6 ~44 ~-112 minecraft:cracked_stone_bricks
setblock ~6 ~44 ~-107 minecraft:cracked_stone_bricks
setblock ~6 ~56 ~-132 minecraft:cracked_stone_bricks
setblock ~6 ~58 ~-132 minecraft:cracked_stone_bricks
setblock ~6 ~60 ~-132 minecraft:cracked_stone_bricks
setblock ~7 ~6 ~-161 minecraft:cracked_stone_bricks
fill ~7 ~10 ~-162 ~7 ~11 ~-162 minecraft:cracked_stone_bricks
setblock ~7 ~19 ~-145 minecraft:cracked_stone_bricks
setblock ~7 ~20 ~-102 minecraft:cracked_stone_bricks
fill ~7 ~20 ~-32 ~8 ~20 ~-32 minecraft:cracked_stone_bricks
setblock ~7 ~21 ~-25 minecraft:cracked_stone_bricks
setblock ~7 ~24 ~-159 minecraft:cracked_stone_bricks
setblock ~7 ~26 ~-103 minecraft:cracked_stone_bricks
setblock ~7 ~30 ~-124 minecraft:cracked_stone_bricks
setblock ~7 ~34 ~-102 minecraft:cracked_stone_bricks
setblock ~7 ~37 ~-102 minecraft:cracked_stone_bricks
fill ~7 ~44 ~-126 ~7 ~44 ~-125 minecraft:cracked_stone_bricks
setblock ~7 ~44 ~-122 minecraft:cracked_stone_bricks
setblock ~7 ~44 ~-111 minecraft:cracked_stone_bricks
setblock ~7 ~44 ~-108 minecraft:cracked_stone_bricks
setblock ~7 ~45 ~-130 minecraft:cracked_stone_bricks
setblock ~7 ~46 ~-101 minecraft:cracked_stone_bricks
setblock ~7 ~51 ~-118 minecraft:cracked_stone_bricks
setblock ~7 ~52 ~-117 minecraft:cracked_stone_bricks
setblock ~7 ~59 ~-119 minecraft:cracked_stone_bricks
setblock ~7 ~63 ~-129 minecraft:cracked_stone_bricks
setblock ~7 ~66 ~-129 minecraft:cracked_stone_bricks
setblock ~7 ~67 ~-115 minecraft:cracked_stone_bricks
setblock ~7 ~68 ~-133 minecraft:cracked_stone_bricks
fill ~8 ~6 ~-146 ~8 ~6 ~-145 minecraft:cracked_stone_bricks
setblock ~8 ~6 ~-102 minecraft:cracked_stone_bricks
setblock ~8 ~10 ~-26 minecraft:cracked_stone_bricks
setblock ~8 ~12 ~-160 minecraft:cracked_stone_bricks
setblock ~8 ~12 ~-29 minecraft:cracked_stone_bricks
setblock ~8 ~13 ~-102 minecraft:cracked_stone_bricks
setblock ~8 ~16 ~-32 minecraft:cracked_stone_bricks
setblock ~8 ~17 ~-26 minecraft:cracked_stone_bricks
setblock ~8 ~19 ~-34 minecraft:cracked_stone_bricks
fill ~8 ~20 ~-27 ~9 ~20 ~-27 minecraft:cracked_stone_bricks
setblock ~8 ~21 ~-34 minecraft:cracked_stone_bricks
setblock ~8 ~24 ~-103 minecraft:cracked_stone_bricks
setblock ~8 ~24 ~-26 minecraft:cracked_stone_bricks
fill ~8 ~25 ~-27 ~8 ~26 ~-27 minecraft:cracked_stone_bricks
setblock ~8 ~26 ~-32 minecraft:cracked_stone_bricks
setblock ~8 ~29 ~-102 minecraft:cracked_stone_bricks
setblock ~8 ~30 ~-26 minecraft:cracked_stone_bricks
fill ~8 ~32 ~-124 ~8 ~33 ~-124 minecraft:cracked_stone_bricks
fill ~8 ~39 ~-102 ~9 ~39 ~-102 minecraft:cracked_stone_bricks
setblock ~8 ~51 ~-120 minecraft:cracked_stone_bricks
setblock ~8 ~52 ~-121 minecraft:cracked_stone_bricks
setblock ~8 ~55 ~-118 minecraft:cracked_stone_bricks
setblock ~8 ~56 ~-128 minecraft:cracked_stone_bricks
setblock ~9 ~ ~-156 minecraft:cracked_stone_bricks
setblock ~9 ~ ~-145 minecraft:cracked_stone_bricks
fill ~9 ~6 ~-38 ~9 ~7 ~-38 minecraft:cracked_stone_bricks
setblock ~9 ~10 ~-146 minecraft:cracked_stone_bricks
setblock ~9 ~10 ~-34 minecraft:cracked_stone_bricks
setblock ~9 ~10 ~-27 minecraft:cracked_stone_bricks
setblock ~9 ~11 ~-33 minecraft:cracked_stone_bricks
fill ~9 ~13 ~-39 ~9 ~13 ~-38 minecraft:cracked_stone_bricks
setblock ~9 ~14 ~-37 minecraft:cracked_stone_bricks
setblock ~9 ~16 ~-145 minecraft:cracked_stone_bricks
setblock ~9 ~16 ~-26 minecraft:cracked_stone_bricks
setblock ~9 ~17 ~-156 minecraft:cracked_stone_bricks
setblock ~9 ~17 ~-102 minecraft:cracked_stone_bricks
setblock ~9 ~17 ~-33 minecraft:cracked_stone_bricks
setblock ~9 ~19 ~-36 minecraft:cracked_stone_bricks
setblock ~9 ~20 ~-102 minecraft:cracked_stone_bricks
setblock ~9 ~20 ~-26 minecraft:cracked_stone_bricks
fill ~9 ~21 ~-146 ~10 ~21 ~-146 minecraft:cracked_stone_bricks
setblock ~9 ~21 ~-37 minecraft:cracked_stone_bricks
setblock ~9 ~22 ~-27 minecraft:cracked_stone_bricks
setblock ~9 ~23 ~-26 minecraft:cracked_stone_bricks
setblock ~9 ~24 ~-34 minecraft:cracked_stone_bricks
setblock ~9 ~25 ~-146 minecraft:cracked_stone_bricks
setblock ~9 ~26 ~-39 minecraft:cracked_stone_bricks
setblock ~9 ~29 ~-145 minecraft:cracked_stone_bricks
setblock ~9 ~34 ~-103 minecraft:cracked_stone_bricks
setblock ~9 ~44 ~-129 minecraft:cracked_stone_bricks
fill ~9 ~44 ~-106 ~10 ~44 ~-106 minecraft:cracked_stone_bricks
setblock ~9 ~46 ~-129 minecraft:cracked_stone_bricks
setblock ~9 ~47 ~-125 minecraft:cracked_stone_bricks
setblock ~9 ~48 ~-129 minecraft:cracked_stone_bricks
setblock ~9 ~54 ~-124 minecraft:cracked_stone_bricks
setblock ~9 ~57 ~-128 minecraft:cracked_stone_bricks
setblock ~9 ~60 ~-123 minecraft:cracked_stone_bricks
setblock ~9 ~60 ~-120 minecraft:cracked_stone_bricks
setblock ~9 ~61 ~-126 minecraft:cracked_stone_bricks
setblock ~9 ~62 ~-123 minecraft:cracked_stone_bricks
setblock ~9 ~64 ~-124 minecraft:cracked_stone_bricks
setblock ~10 ~3 ~-35 minecraft:cracked_stone_bricks
setblock ~10 ~5 ~-146 minecraft:cracked_stone_bricks
setblock ~10 ~6 ~-145 minecraft:cracked_stone_bricks
setblock ~10 ~8 ~-25 minecraft:cracked_stone_bricks
setblock ~10 ~10 ~-102 minecraft:cracked_stone_bricks
setblock ~10 ~15 ~-146 minecraft:cracked_stone_bricks
setblock ~10 ~15 ~-24 minecraft:cracked_stone_bricks
setblock ~10 ~19 ~-102 minecraft:cracked_stone_bricks
fill ~10 ~20 ~-36 ~10 ~20 ~-35 minecraft:cracked_stone_bricks
setblock ~10 ~21 ~-25 minecraft:cracked_stone_bricks
setblock ~10 ~23 ~-103 minecraft:cracked_stone_bricks
fill ~10 ~23 ~-24 ~11 ~23 ~-24 minecraft:cracked_stone_bricks
setblock ~10 ~32 ~-102 minecraft:cracked_stone_bricks
setblock ~10 ~34 ~-102 minecraft:cracked_stone_bricks
setblock ~10 ~35 ~-103 minecraft:cracked_stone_bricks
setblock ~10 ~42 ~-146 minecraft:cracked_stone_bricks
setblock ~10 ~43 ~-103 minecraft:cracked_stone_bricks
setblock ~10 ~44 ~-140 minecraft:cracked_stone_bricks
setblock ~10 ~44 ~-128 minecraft:cracked_stone_bricks
fill ~10 ~44 ~-113 ~10 ~44 ~-112 minecraft:cracked_stone_bricks
setblock ~10 ~47 ~-127 minecraft:cracked_stone_bricks
fill ~10 ~50 ~-125 ~10 ~50 ~-124 minecraft:cracked_stone_bricks
setblock ~10 ~50 ~-121 minecraft:cracked_stone_bricks
setblock ~10 ~51 ~-122 minecraft:cracked_stone_bricks
setblock ~10 ~52 ~-125 minecraft:cracked_stone_bricks
setblock ~10 ~53 ~-127 minecraft:cracked_stone_bricks
setblock ~10 ~54 ~-126 minecraft:cracked_stone_bricks
setblock ~10 ~58 ~-122 minecraft:cracked_stone_bricks
setblock ~10 ~60 ~-126 minecraft:cracked_stone_bricks
setblock ~10 ~63 ~-121 minecraft:cracked_stone_bricks
setblock ~10 ~64 ~-123 minecraft:cracked_stone_bricks
setblock ~10 ~66 ~-128 minecraft:cracked_stone_bricks
fill ~10 ~66 ~-120 ~10 ~66 ~-119 minecraft:cracked_stone_bricks
setblock ~11 ~ ~-142 minecraft:cracked_stone_bricks
fill ~11 ~ ~-131 ~11 ~ ~-130 minecraft:cracked_stone_bricks
setblock ~11 ~ ~-114 minecraft:cracked_stone_bricks
fill ~11 ~ ~-109 ~11 ~1 ~-109 minecraft:cracked_stone_bricks
fill ~11 ~1 ~-128 ~11 ~1 ~-127 minecraft:cracked_stone_bricks
setblock ~11 ~2 ~-125 minecraft:cracked_stone_bricks
setblock ~11 ~2 ~-104 minecraft:cracked_stone_bricks
setblock ~11 ~2 ~-36 minecraft:cracked_stone_bricks
setblock ~11 ~3 ~-110 minecraft:cracked_stone_bricks
setblock ~11 ~3 ~-108 minecraft:cracked_stone_bricks
setblock ~11 ~4 ~-111 minecraft:cracked_stone_bricks
setblock ~11 ~5 ~-144 minecraft:cracked_stone_bricks
setblock ~11 ~5 ~-105 minecraft:cracked_stone_bricks
setblock ~11 ~6 ~-141 minecraft:cracked_stone_bricks
setblock ~11 ~6 ~-127 minecraft:cracked_stone_bricks
setblock ~11 ~6 ~-121 minecraft:cracked_stone_bricks
fill ~11 ~6 ~-110 ~11 ~6 ~-109 minecraft:cracked_stone_bricks
setblock ~11 ~7 ~-118 minecraft:cracked_stone_bricks
setblock ~11 ~8 ~-109 minecraft:cracked_stone_bricks
setblock ~11 ~9 ~-135 minecraft:cracked_stone_bricks
setblock ~11 ~9 ~-107 minecraft:cracked_stone_bricks
setblock ~11 ~9 ~-37 minecraft:cracked_stone_bricks
setblock ~11 ~12 ~-107 minecraft:cracked_stone_bricks
setblock ~11 ~13 ~-141 minecraft:cracked_stone_bricks
setblock ~11 ~13 ~-133 minecraft:cracked_stone_bricks
setblock ~11 ~13 ~-23 minecraft:cracked_stone_bricks
setblock ~11 ~14 ~-128 minecraft:cracked_stone_bricks
setblock ~11 ~14 ~-108 minecraft:cracked_stone_bricks
setblock ~11 ~15 ~-156 minecraft:cracked_stone_bricks
setblock ~11 ~15 ~-125 minecraft:cracked_stone_bricks
setblock ~11 ~16 ~-111 minecraft:cracked_stone_bricks
setblock ~11 ~16 ~-107 minecraft:cracked_stone_bricks
fill ~11 ~17 ~-161 ~12 ~17 ~-161 minecraft:cracked_stone_bricks
setblock ~11 ~17 ~-143 minecraft:cracked_stone_bricks
setblock ~11 ~17 ~-120 minecraft:cracked_stone_bricks
fill ~11 ~17 ~-116 ~11 ~18 ~-116 minecraft:cracked_stone_bricks
setblock ~11 ~17 ~-24 minecraft:cracked_stone_bricks
fill ~11 ~18 ~-146 ~12 ~18 ~-146 minecraft:cracked_stone_bricks
setblock ~11 ~18 ~-109 minecraft:cracked_stone_bricks
setblock ~11 ~19 ~-144 minecraft:cracked_stone_bricks
setblock ~11 ~19 ~-139 minecraft:cracked_stone_bricks
setblock ~11 ~19 ~-128 minecraft:cracked_stone_bricks
setblock ~11 ~19 ~-108 minecraft:cracked_stone_bricks
setblock ~11 ~21 ~-143 minecraft:cracked_stone_bricks
setblock ~11 ~21 ~-118 minecraft:cracked_stone_bricks
setblock ~11 ~21 ~-105 minecraft:cracked_stone_bricks
setblock ~11 ~21 ~-24 minecraft:cracked_stone_bricks
setblock ~11 ~23 ~-143 minecraft:cracked_stone_bricks
setblock ~11 ~23 ~-141 minecraft:cracked_stone_bricks
setblock ~11 ~24 ~-128 minecraft:cracked_stone_bricks
setblock ~11 ~24 ~-118 minecraft:cracked_stone_bricks
fill ~11 ~25 ~-146 ~12 ~26 ~-146 minecraft:cracked_stone_bricks
setblock ~11 ~25 ~-141 minecraft:cracked_stone_bricks
fill ~11 ~25 ~-137 ~11 ~26 ~-137 minecraft:cracked_stone_bricks
setblock ~11 ~25 ~-129 minecraft:cracked_stone_bricks
setblock ~11 ~25 ~-122 minecraft:cracked_stone_bricks
setblock ~11 ~25 ~-37 minecraft:cracked_stone_bricks
setblock ~11 ~26 ~-144 minecraft:cracked_stone_bricks
setblock ~11 ~26 ~-106 minecraft:cracked_stone_bricks
setblock ~11 ~27 ~-112 minecraft:cracked_stone_bricks
setblock ~11 ~28 ~-141 minecraft:cracked_stone_bricks
setblock ~11 ~29 ~-128 minecraft:cracked_stone_bricks
setblock ~11 ~29 ~-118 minecraft:cracked_stone_bricks
setblock ~11 ~30 ~-125 minecraft:cracked_stone_bricks
setblock ~11 ~30 ~-32 minecraft:cracked_stone_bricks
fill ~11 ~30 ~-22 ~11 ~31 ~-22 minecraft:cracked_stone_bricks
setblock ~11 ~31 ~-138 minecraft:cracked_stone_bricks
setblock ~11 ~31 ~-121 minecraft:cracked_stone_bricks
setblock ~11 ~31 ~-119 minecraft:cracked_stone_bricks
setblock ~11 ~32 ~-142 minecraft:cracked_stone_bricks
setblock ~11 ~32 ~-123 minecraft:cracked_stone_bricks
setblock ~11 ~32 ~-106 minecraft:cracked_stone_bricks
setblock ~11 ~34 ~-136 minecraft:cracked_stone_bricks
setblock ~11 ~34 ~-112 minecraft:cracked_stone_bricks
setblock ~11 ~35 ~-146 minecraft:cracked_stone_bricks
setblock ~11 ~35 ~-105 minecraft:cracked_stone_bricks
setblock ~11 ~36 ~-131 minecraft:cracked_stone_bricks
setblock ~11 ~37 ~-138 minecraft:cracked_stone_bricks
setblock ~11 ~38 ~-144 minecraft:cracked_stone_bricks
setblock ~11 ~38 ~-140 minecraft:cracked_stone_bricks
fill ~11 ~38 ~-132 ~11 ~38 ~-131 minecraft:cracked_stone_bricks
setblock ~11 ~38 ~-122 minecraft:cracked_stone_bricks
setblock ~11 ~39 ~-145 minecraft:cracked_stone_bricks
setblock ~11 ~39 ~-120 minecraft:cracked_stone_bricks
setblock ~11 ~39 ~-118 minecraft:cracked_stone_bricks
setblock ~11 ~40 ~-143 minecraft:cracked_stone_bricks
setblock ~11 ~41 ~-142 minecraft:cracked_stone_bricks
fill ~11 ~42 ~-138 ~11 ~43 ~-138 minecraft:cracked_stone_bricks
setblock ~11 ~42 ~-127 minecraft:cracked_stone_bricks
setblock ~11 ~42 ~-112 minecraft:cracked_stone_bricks
setblock ~11 ~43 ~-114 minecraft:cracked_stone_bricks
setblock ~11 ~44 ~-145 minecraft:cracked_stone_bricks
setblock ~11 ~44 ~-143 minecraft:cracked_stone_bricks
setblock ~11 ~44 ~-135 minecraft:cracked_stone_bricks
setblock ~11 ~44 ~-121 minecraft:cracked_stone_bricks
setblock ~11 ~44 ~-111 minecraft:cracked_stone_bricks
setblock ~11 ~67 ~-125 minecraft:cracked_stone_bricks
setblock ~12 ~5 ~-156 minecraft:cracked_stone_bricks
setblock ~12 ~8 ~-125 minecraft:cracked_stone_bricks
setblock ~12 ~8 ~-103 minecraft:cracked_stone_bricks
fill ~12 ~11 ~-160 ~13 ~11 ~-160 minecraft:cracked_stone_bricks
setblock ~12 ~12 ~-102 minecraft:cracked_stone_bricks
setblock ~12 ~16 ~-37 minecraft:cracked_stone_bricks
setblock ~12 ~16 ~-24 minecraft:cracked_stone_bricks
setblock ~12 ~17 ~-23 minecraft:cracked_stone_bricks
setblock ~12 ~20 ~-102 minecraft:cracked_stone_bricks
setblock ~12 ~25 ~-124 minecraft:cracked_stone_bricks
setblock ~12 ~26 ~-23 minecraft:cracked_stone_bricks
setblock ~12 ~30 ~-30 minecraft:cracked_stone_bricks
setblock ~12 ~32 ~-39 minecraft:cracked_stone_bricks
fill ~12 ~35 ~-145 ~13 ~35 ~-145 minecraft:cracked_stone_bricks
setblock ~12 ~44 ~-136 minecraft:cracked_stone_bricks
setblock ~12 ~44 ~-134 minecraft:cracked_stone_bricks
setblock ~13 ~ ~-37 minecraft:cracked_stone_bricks
setblock ~13 ~5 ~-160 minecraft:cracked_stone_bricks
setblock ~13 ~8 ~-160 minecraft:cracked_stone_bricks
fill ~13 ~10 ~-160 ~13 ~12 ~-160 minecraft:cracked_stone_bricks
setblock ~13 ~12 ~-146 minecraft:cracked_stone_bricks
setblock ~13 ~12 ~-22 minecraft:cracked_stone_bricks
setblock ~13 ~13 ~-38 minecraft:cracked_stone_bricks
setblock ~13 ~16 ~-22 minecraft:cracked_stone_bricks
setblock ~13 ~19 ~-22 minecraft:cracked_stone_bricks
setblock ~13 ~24 ~-37 minecraft:cracked_stone_bricks
setblock ~13 ~28 ~-103 minecraft:cracked_stone_bricks
setblock ~13 ~31 ~-124 minecraft:cracked_stone_bricks
setblock ~13 ~40 ~-103 minecraft:cracked_stone_bricks
setblock ~13 ~44 ~-122 minecraft:cracked_stone_bricks
setblock ~13 ~44 ~-119 minecraft:cracked_stone_bricks
setblock ~14 ~8 ~-37 minecraft:cracked_stone_bricks
setblock ~14 ~10 ~-22 minecraft:cracked_stone_bricks
setblock ~14 ~13 ~-160 minecraft:cracked_stone_bricks
setblock ~14 ~13 ~-37 minecraft:cracked_stone_bricks
setblock ~14 ~17 ~-23 minecraft:cracked_stone_bricks
fill ~14 ~20 ~-22 ~14 ~21 ~-22 minecraft:cracked_stone_bricks
setblock ~14 ~22 ~-38 minecraft:cracked_stone_bricks
setblock ~14 ~32 ~-21 minecraft:cracked_stone_bricks
setblock ~14 ~42 ~-103 minecraft:cracked_stone_bricks
setblock ~14 ~44 ~-133 minecraft:cracked_stone_bricks
setblock ~15 ~ ~-145 minecraft:cracked_stone_bricks
setblock ~15 ~2 ~-23 minecraft:cracked_stone_bricks
setblock ~15 ~3 ~-37 minecraft:cracked_stone_bricks
setblock ~15 ~4 ~-160 minecraft:cracked_stone_bricks
setblock ~15 ~9 ~-145 minecraft:cracked_stone_bricks
setblock ~15 ~11 ~-37 minecraft:cracked_stone_bricks
fill ~15 ~11 ~-22 ~15 ~13 ~-22 minecraft:cracked_stone_bricks
setblock ~15 ~16 ~-22 minecraft:cracked_stone_bricks
setblock ~15 ~19 ~-146 minecraft:cracked_stone_bricks
fill ~15 ~20 ~-38 ~16 ~20 ~-38 minecraft:cracked_stone_bricks
setblock ~15 ~21 ~-103 minecraft:cracked_stone_bricks
setblock ~15 ~28 ~-146 minecraft:cracked_stone_bricks
setblock ~15 ~31 ~-124 minecraft:cracked_stone_bricks
setblock ~15 ~36 ~-146 minecraft:cracked_stone_bricks
setblock ~15 ~44 ~-119 minecraft:cracked_stone_bricks
setblock ~15 ~44 ~-117 minecraft:cracked_stone_bricks
setblock ~16 ~5 ~-125 minecraft:cracked_stone_bricks
setblock ~16 ~5 ~-37 minecraft:cracked_stone_bricks
setblock ~16 ~5 ~-23 minecraft:cracked_stone_bricks
setblock ~16 ~6 ~-103 minecraft:cracked_stone_bricks
setblock ~16 ~7 ~-146 minecraft:cracked_stone_bricks
setblock ~16 ~8 ~-23 minecraft:cracked_stone_bricks
setblock ~16 ~10 ~-37 minecraft:cracked_stone_bricks
setblock ~16 ~11 ~-156 minecraft:cracked_stone_bricks
setblock ~16 ~13 ~-38 minecraft:cracked_stone_bricks
setblock ~16 ~14 ~-37 minecraft:cracked_stone_bricks
setblock ~16 ~15 ~-22 minecraft:cracked_stone_bricks
setblock ~16 ~16 ~-103 minecraft:cracked_stone_bricks
setblock ~16 ~23 ~-23 minecraft:cracked_stone_bricks
setblock ~16 ~24 ~-124 minecraft:cracked_stone_bricks
setblock ~16 ~25 ~-103 minecraft:cracked_stone_bricks
setblock ~16 ~26 ~-124 minecraft:cracked_stone_bricks
setblock ~16 ~28 ~-124 minecraft:cracked_stone_bricks
setblock ~16 ~30 ~-103 minecraft:cracked_stone_bricks
setblock ~16 ~30 ~-21 minecraft:cracked_stone_bricks
setblock ~16 ~31 ~-145 minecraft:cracked_stone_bricks
setblock ~16 ~35 ~-103 minecraft:cracked_stone_bricks
setblock ~16 ~36 ~-145 minecraft:cracked_stone_bricks
setblock ~16 ~41 ~-145 minecraft:cracked_stone_bricks
fill ~16 ~44 ~-138 ~16 ~44 ~-137 minecraft:cracked_stone_bricks
setblock ~16 ~44 ~-110 minecraft:cracked_stone_bricks
setblock ~16 ~44 ~-105 minecraft:cracked_stone_bricks
fill ~17 ~3 ~-102 ~18 ~3 ~-102 minecraft:cracked_stone_bricks
setblock ~17 ~10 ~-160 minecraft:cracked_stone_bricks
setblock ~17 ~10 ~-145 minecraft:cracked_stone_bricks
setblock ~17 ~10 ~-103 minecraft:cracked_stone_bricks
setblock ~17 ~12 ~-37 minecraft:cracked_stone_bricks
setblock ~17 ~15 ~-38 minecraft:cracked_stone_bricks
setblock ~17 ~17 ~-161 minecraft:cracked_stone_bricks
fill ~17 ~18 ~-156 ~17 ~19 ~-156 minecraft:cracked_stone_bricks
fill ~17 ~18 ~-146 ~18 ~18 ~-146 minecraft:cracked_stone_bricks
fill ~17 ~25 ~-146 ~18 ~25 ~-146 minecraft:cracked_stone_bricks
setblock ~17 ~25 ~-124 minecraft:cracked_stone_bricks
fill ~17 ~25 ~-102 ~18 ~25 ~-102 minecraft:cracked_stone_bricks
setblock ~17 ~28 ~-38 minecraft:cracked_stone_bricks
setblock ~17 ~28 ~-23 minecraft:cracked_stone_bricks
setblock ~17 ~32 ~-146 minecraft:cracked_stone_bricks
setblock ~17 ~44 ~-142 minecraft:cracked_stone_bricks
setblock ~17 ~44 ~-118 minecraft:cracked_stone_bricks
setblock ~18 ~2 ~-125 minecraft:cracked_stone_bricks
setblock ~18 ~3 ~-23 minecraft:cracked_stone_bricks
setblock ~18 ~4 ~-160 minecraft:cracked_stone_bricks
fill ~18 ~7 ~-103 ~18 ~7 ~-102 minecraft:cracked_stone_bricks
setblock ~18 ~11 ~-24 minecraft:cracked_stone_bricks
setblock ~18 ~30 ~-124 minecraft:cracked_stone_bricks
setblock ~18 ~30 ~-29 minecraft:cracked_stone_bricks
setblock ~18 ~34 ~-145 minecraft:cracked_stone_bricks
setblock ~18 ~34 ~-102 minecraft:cracked_stone_bricks
setblock ~18 ~44 ~-146 minecraft:cracked_stone_bricks
setblock ~18 ~44 ~-134 minecraft:cracked_stone_bricks
setblock ~18 ~44 ~-132 minecraft:cracked_stone_bricks
fill ~18 ~44 ~-126 ~20 ~44 ~-126 minecraft:cracked_stone_bricks
setblock ~18 ~44 ~-113 minecraft:cracked_stone_bricks
setblock ~19 ~3 ~-38 minecraft:cracked_stone_bricks
setblock ~19 ~4 ~-125 minecraft:cracked_stone_bricks
setblock ~19 ~5 ~-24 minecraft:cracked_stone_bricks
setblock ~19 ~7 ~-23 minecraft:cracked_stone_bricks
setblock ~19 ~10 ~-146 minecraft:cracked_stone_bricks
setblock ~19 ~13 ~-146 minecraft:cracked_stone_bricks
setblock ~19 ~15 ~-146 minecraft:cracked_stone_bricks
setblock ~19 ~16 ~-103 minecraft:cracked_stone_bricks
setblock ~19 ~17 ~-161 minecraft:cracked_stone_bricks
fill ~19 ~18 ~-156 ~19 ~19 ~-156 minecraft:cracked_stone_bricks
setblock ~19 ~23 ~-145 minecraft:cracked_stone_bricks
setblock ~19 ~23 ~-37 minecraft:cracked_stone_bricks
setblock ~19 ~25 ~-37 minecraft:cracked_stone_bricks
setblock ~19 ~27 ~-146 minecraft:cracked_stone_bricks
setblock ~19 ~28 ~-37 minecraft:cracked_stone_bricks
setblock ~19 ~29 ~-36 minecraft:cracked_stone_bricks
setblock ~19 ~36 ~-145 minecraft:cracked_stone_bricks
setblock ~19 ~44 ~-121 minecraft:cracked_stone_bricks
setblock ~19 ~44 ~-107 minecraft:cracked_stone_bricks
setblock ~19 ~54 ~-101 minecraft:cracked_stone_bricks
setblock ~20 ~5 ~-156 minecraft:cracked_stone_bricks
setblock ~20 ~6 ~-35 minecraft:cracked_stone_bricks
setblock ~20 ~10 ~-24 minecraft:cracked_stone_bricks
setblock ~20 ~11 ~-160 minecraft:cracked_stone_bricks
setblock ~20 ~13 ~-148 minecraft:cracked_stone_bricks
setblock ~20 ~13 ~-101 minecraft:cracked_stone_bricks
setblock ~20 ~19 ~-103 minecraft:cracked_stone_bricks
fill ~20 ~21 ~-25 ~20 ~22 ~-25 minecraft:cracked_stone_bricks
setblock ~20 ~23 ~-124 minecraft:cracked_stone_bricks
setblock ~20 ~26 ~-148 minecraft:cracked_stone_bricks
setblock ~20 ~26 ~-145 minecraft:cracked_stone_bricks
setblock ~20 ~27 ~-100 minecraft:cracked_stone_bricks
setblock ~20 ~28 ~-148 minecraft:cracked_stone_bricks
setblock ~20 ~30 ~-101 minecraft:cracked_stone_bricks
setblock ~20 ~31 ~-147 minecraft:cracked_stone_bricks
setblock ~20 ~31 ~-37 minecraft:cracked_stone_bricks
setblock ~20 ~41 ~-103 minecraft:cracked_stone_bricks
setblock ~20 ~44 ~-131 minecraft:cracked_stone_bricks
setblock ~20 ~44 ~-129 minecraft:cracked_stone_bricks
fill ~20 ~44 ~-115 ~21 ~44 ~-115 minecraft:cracked_stone_bricks
setblock ~20 ~44 ~-106 minecraft:cracked_stone_bricks
setblock ~20 ~45 ~-146 minecraft:cracked_stone_bricks
setblock ~20 ~45 ~-102 minecraft:cracked_stone_bricks
setblock ~20 ~47 ~-100 minecraft:cracked_stone_bricks
setblock ~20 ~48 ~-104 minecraft:cracked_stone_bricks
setblock ~20 ~49 ~-101 minecraft:cracked_stone_bricks
fill ~20 ~52 ~-142 ~21 ~52 ~-142 minecraft:cracked_stone_bricks
setblock ~20 ~52 ~-103 minecraft:cracked_stone_bricks
setblock ~21 ~2 ~-27 minecraft:cracked_stone_bricks
setblock ~21 ~6 ~-145 minecraft:cracked_stone_bricks
setblock ~21 ~7 ~-150 minecraft:cracked_stone_bricks
fill ~21 ~8 ~-156 ~22 ~8 ~-156 minecraft:cracked_stone_bricks
fill ~21 ~9 ~-99 ~21 ~9 ~-98 minecraft:cracked_stone_bricks
setblock ~21 ~10 ~-145 minecraft:cracked_stone_bricks
fill ~21 ~10 ~-34 ~21 ~10 ~-33 minecraft:cracked_stone_bricks
setblock ~21 ~12 ~-156 minecraft:cracked_stone_bricks
setblock ~21 ~14 ~-160 minecraft:cracked_stone_bricks
setblock ~21 ~16 ~-156 minecraft:cracked_stone_bricks
fill ~21 ~16 ~-24 ~21 ~17 ~-24 minecraft:cracked_stone_bricks
setblock ~21 ~18 ~-157 minecraft:cracked_stone_bricks
setblock ~21 ~19 ~-150 minecraft:cracked_stone_bricks
setblock ~21 ~20 ~-99 minecraft:cracked_stone_bricks
setblock ~21 ~21 ~-34 minecraft:cracked_stone_bricks
setblock ~21 ~22 ~-35 minecraft:cracked_stone_bricks
fill ~21 ~23 ~-34 ~22 ~23 ~-34 minecraft:cracked_stone_bricks
setblock ~21 ~23 ~-26 minecraft:cracked_stone_bricks
setblock ~21 ~24 ~-35 minecraft:cracked_stone_bricks
setblock ~21 ~27 ~-103 minecraft:cracked_stone_bricks
setblock ~21 ~28 ~-99 minecraft:cracked_stone_bricks
setblock ~21 ~29 ~-27 minecraft:cracked_stone_bricks
setblock ~21 ~30 ~-28 minecraft:cracked_stone_bricks
setblock ~21 ~36 ~-98 minecraft:cracked_stone_bricks
setblock ~21 ~41 ~-98 minecraft:cracked_stone_bricks
setblock ~21 ~42 ~-150 minecraft:cracked_stone_bricks
setblock ~21 ~44 ~-144 minecraft:cracked_stone_bricks
setblock ~21 ~44 ~-130 minecraft:cracked_stone_bricks
setblock ~21 ~44 ~-128 minecraft:cracked_stone_bricks
setblock ~21 ~45 ~-150 minecraft:cracked_stone_bricks
fill ~21 ~46 ~-99 ~21 ~47 ~-99 minecraft:cracked_stone_bricks
setblock ~21 ~48 ~-98 minecraft:cracked_stone_bricks
setblock ~21 ~49 ~-105 minecraft:cracked_stone_bricks
setblock ~21 ~52 ~-98 minecraft:cracked_stone_bricks
setblock ~21 ~54 ~-107 minecraft:cracked_stone_bricks
setblock ~22 ~ ~-103 minecraft:cracked_stone_bricks
fill ~22 ~ ~-29 ~22 ~1 ~-29 minecraft:cracked_stone_bricks
setblock ~22 ~1 ~-28 minecraft:cracked_stone_bricks
setblock ~22 ~3 ~-29 minecraft:cracked_stone_bricks
setblock ~22 ~5 ~-31 minecraft:cracked_stone_bricks
setblock ~22 ~6 ~-29 minecraft:cracked_stone_bricks
setblock ~22 ~6 ~-27 minecraft:cracked_stone_bricks
setblock ~22 ~7 ~-151 minecraft:cracked_stone_bricks
setblock ~22 ~10 ~-151 minecraft:cracked_stone_bricks
setblock ~22 ~11 ~-160 minecraft:cracked_stone_bricks
setblock ~22 ~11 ~-36 minecraft:cracked_stone_bricks
fill ~22 ~11 ~-30 ~22 ~13 ~-30 minecraft:cracked_stone_bricks
setblock ~22 ~11 ~-28 minecraft:cracked_stone_bricks
setblock ~22 ~13 ~-156 minecraft:cracked_stone_bricks
setblock ~22 ~17 ~-97 minecraft:cracked_stone_bricks
setblock ~22 ~18 ~-158 minecraft:cracked_stone_bricks
setblock ~22 ~18 ~-151 minecraft:cracked_stone_bricks
fill ~22 ~23 ~-27 ~22 ~24 ~-27 minecraft:cracked_stone_bricks
setblock ~22 ~25 ~-33 minecraft:cracked_stone_bricks
setblock ~22 ~26 ~-103 minecraft:cracked_stone_bricks
setblock ~22 ~26 ~-97 minecraft:cracked_stone_bricks
setblock ~22 ~26 ~-29 minecraft:cracked_stone_bricks
fill ~22 ~26 ~-27 ~22 ~27 ~-27 minecraft:cracked_stone_bricks
setblock ~22 ~29 ~-30 minecraft:cracked_stone_bricks
setblock ~22 ~30 ~-34 minecraft:cracked_stone_bricks
setblock ~22 ~34 ~-103 minecraft:cracked_stone_bricks
setblock ~22 ~36 ~-151 minecraft:cracked_stone_bricks
fill ~22 ~36 ~-145 ~23 ~36 ~-145 minecraft:cracked_stone_bricks
setblock ~22 ~36 ~-97 minecraft:cracked_stone_bricks
setblock ~22 ~44 ~-126 minecraft:cracked_stone_bricks
setblock ~22 ~44 ~-116 minecraft:cracked_stone_bricks
setblock ~22 ~47 ~-97 minecraft:cracked_stone_bricks
fill ~22 ~48 ~-141 ~22 ~49 ~-141 minecraft:cracked_stone_bricks
setblock ~22 ~50 ~-97 minecraft:cracked_stone_bricks
setblock ~22 ~52 ~-145 minecraft:cracked_stone_bricks
setblock ~22 ~52 ~-97 minecraft:cracked_stone_bricks
fill ~23 ~2 ~-38 ~23 ~3 ~-38 minecraft:cracked_stone_bricks
setblock ~23 ~6 ~-31 minecraft:cracked_stone_bricks
setblock ~23 ~8 ~-160 minecraft:cracked_stone_bricks
setblock ~23 ~8 ~-97 minecraft:cracked_stone_bricks
fill ~23 ~8 ~-38 ~23 ~9 ~-38 minecraft:cracked_stone_bricks
setblock ~23 ~13 ~-145 minecraft:cracked_stone_bricks
setblock ~23 ~14 ~-31 minecraft:cracked_stone_bricks
fill ~23 ~14 ~-28 ~23 ~15 ~-28 minecraft:cracked_stone_bricks
setblock ~23 ~20 ~-151 minecraft:cracked_stone_bricks
setblock ~23 ~20 ~-97 minecraft:cracked_stone_bricks
setblock ~23 ~23 ~-32 minecraft:cracked_stone_bricks
fill ~23 ~25 ~-124 ~24 ~25 ~-124 minecraft:cracked_stone_bricks
setblock ~23 ~26 ~-145 minecraft:cracked_stone_bricks
fill ~23 ~28 ~-32 ~23 ~28 ~-31 minecraft:cracked_stone_bricks
setblock ~23 ~30 ~-103 minecraft:cracked_stone_bricks
setblock ~23 ~31 ~-97 minecraft:cracked_stone_bricks
setblock ~23 ~32 ~-151 minecraft:cracked_stone_bricks
fill ~23 ~37 ~-145 ~23 ~38 ~-145 minecraft:cracked_stone_bricks
setblock ~23 ~37 ~-103 minecraft:cracked_stone_bricks
setblock ~23 ~40 ~-145 minecraft:cracked_stone_bricks
setblock ~23 ~44 ~-129 minecraft:cracked_stone_bricks
setblock ~23 ~52 ~-149 minecraft:cracked_stone_bricks
setblock ~24 ~3 ~-103 minecraft:cracked_stone_bricks
setblock ~24 ~5 ~-156 minecraft:cracked_stone_bricks
setblock ~24 ~5 ~-32 minecraft:cracked_stone_bricks
fill ~24 ~7 ~-103 ~24 ~8 ~-103 minecraft:cracked_stone_bricks
setblock ~24 ~9 ~-145 minecraft:cracked_stone_bricks
setblock ~24 ~18 ~-33 minecraft:cracked_stone_bricks
setblock ~24 ~21 ~-145 minecraft:cracked_stone_bricks
setblock ~24 ~23 ~-152 minecraft:cracked_stone_bricks
setblock ~24 ~32 ~-103 minecraft:cracked_stone_bricks
setblock ~24 ~39 ~-96 minecraft:cracked_stone_bricks
fill ~24 ~44 ~-134 ~24 ~44 ~-133 minecraft:cracked_stone_bricks
setblock ~24 ~44 ~-125 minecraft:cracked_stone_bricks
setblock ~24 ~53 ~-109 minecraft:cracked_stone_bricks
fill ~25 ~-23 ~-57 ~25 ~-23 ~-43 minecraft:cracked_stone_bricks
setblock ~25 ~1 ~-143 minecraft:cracked_stone_bricks
setblock ~25 ~1 ~-128 minecraft:cracked_stone_bricks
setblock ~25 ~1 ~-119 minecraft:cracked_stone_bricks
setblock ~25 ~1 ~-117 minecraft:cracked_stone_bricks
setblock ~25 ~2 ~-123 minecraft:cracked_stone_bricks
setblock ~25 ~3 ~-132 minecraft:cracked_stone_bricks
setblock ~25 ~3 ~-119 minecraft:cracked_stone_bricks
setblock ~25 ~3 ~-104 minecraft:cracked_stone_bricks
setblock ~25 ~5 ~-128 minecraft:cracked_stone_bricks
setblock ~25 ~6 ~-139 minecraft:cracked_stone_bricks
setblock ~25 ~6 ~-117 minecraft:cracked_stone_bricks
setblock ~25 ~6 ~-96 minecraft:cracked_stone_bricks
setblock ~25 ~7 ~-124 minecraft:cracked_stone_bricks
setblock ~25 ~8 ~-135 minecraft:cracked_stone_bricks
setblock ~25 ~8 ~-111 minecraft:cracked_stone_bricks
setblock ~25 ~9 ~-138 minecraft:cracked_stone_bricks
setblock ~25 ~9 ~-118 minecraft:cracked_stone_bricks
setblock ~25 ~10 ~-132 minecraft:cracked_stone_bricks
setblock ~25 ~10 ~-129 minecraft:cracked_stone_bricks
setblock ~25 ~10 ~-116 minecraft:cracked_stone_bricks
setblock ~25 ~10 ~-110 minecraft:cracked_stone_bricks
setblock ~25 ~10 ~-105 minecraft:cracked_stone_bricks
fill ~25 ~12 ~-141 ~25 ~13 ~-141 minecraft:cracked_stone_bricks
setblock ~25 ~12 ~-138 minecraft:cracked_stone_bricks
setblock ~25 ~13 ~-120 minecraft:cracked_stone_bricks
setblock ~25 ~13 ~-117 minecraft:cracked_stone_bricks
setblock ~25 ~13 ~-110 minecraft:cracked_stone_bricks
setblock ~25 ~14 ~-143 minecraft:cracked_stone_bricks
setblock ~25 ~15 ~-135 minecraft:cracked_stone_bricks
fill ~25 ~16 ~-121 ~26 ~16 ~-121 minecraft:cracked_stone_bricks
fill ~25 ~17 ~-119 ~26 ~17 ~-119 minecraft:cracked_stone_bricks
setblock ~25 ~17 ~-107 minecraft:cracked_stone_bricks
setblock ~25 ~18 ~-161 minecraft:cracked_stone_bricks
setblock ~25 ~18 ~-158 minecraft:cracked_stone_bricks
fill ~25 ~19 ~-126 ~26 ~19 ~-126 minecraft:cracked_stone_bricks
setblock ~25 ~19 ~-122 minecraft:cracked_stone_bricks
setblock ~25 ~19 ~-117 minecraft:cracked_stone_bricks
setblock ~25 ~19 ~-107 minecraft:cracked_stone_bricks
setblock ~25 ~19 ~-96 minecraft:cracked_stone_bricks
setblock ~25 ~20 ~-113 minecraft:cracked_stone_bricks
setblock ~25 ~21 ~-126 minecraft:cracked_stone_bricks
setblock ~25 ~21 ~-119 minecraft:cracked_stone_bricks
setblock ~25 ~22 ~-152 minecraft:cracked_stone_bricks
fill ~25 ~23 ~-120 ~25 ~23 ~-119 minecraft:cracked_stone_bricks
fill ~25 ~26 ~-111 ~26 ~26 ~-111 minecraft:cracked_stone_bricks
setblock ~25 ~27 ~-139 minecraft:cracked_stone_bricks
setblock ~25 ~27 ~-133 minecraft:cracked_stone_bricks
setblock ~25 ~27 ~-115 minecraft:cracked_stone_bricks
setblock ~25 ~28 ~-152 minecraft:cracked_stone_bricks
setblock ~25 ~28 ~-132 minecraft:cracked_stone_bricks
setblock ~25 ~29 ~-120 minecraft:cracked_stone_bricks
setblock ~25 ~30 ~-143 minecraft:cracked_stone_bricks
setblock ~25 ~30 ~-131 minecraft:cracked_stone_bricks
setblock ~25 ~31 ~-137 minecraft:cracked_stone_bricks
setblock ~25 ~32 ~-119 minecraft:cracked_stone_bricks
fill ~25 ~34 ~-137 ~25 ~35 ~-137 minecraft:cracked_stone_bricks
setblock ~25 ~34 ~-129 minecraft:cracked_stone_bricks
setblock ~25 ~34 ~-114 minecraft:cracked_stone_bricks
setblock ~25 ~36 ~-144 minecraft:cracked_stone_bricks
setblock ~25 ~36 ~-117 minecraft:cracked_stone_bricks
setblock ~25 ~37 ~-133 minecraft:cracked_stone_bricks
setblock ~25 ~37 ~-116 minecraft:cracked_stone_bricks
setblock ~25 ~38 ~-120 minecraft:cracked_stone_bricks
setblock ~25 ~38 ~-105 minecraft:cracked_stone_bricks
setblock ~25 ~39 ~-127 minecraft:cracked_stone_bricks
setblock ~25 ~39 ~-122 minecraft:cracked_stone_bricks
setblock ~25 ~39 ~-119 minecraft:cracked_stone_bricks
fill ~25 ~39 ~-117 ~25 ~39 ~-116 minecraft:cracked_stone_bricks
setblock ~25 ~40 ~-128 minecraft:cracked_stone_bricks
setblock ~25 ~40 ~-113 minecraft:cracked_stone_bricks
setblock ~25 ~41 ~-131 minecraft:cracked_stone_bricks
setblock ~25 ~41 ~-126 minecraft:cracked_stone_bricks
setblock ~25 ~41 ~-108 minecraft:cracked_stone_bricks
setblock ~25 ~42 ~-123 minecraft:cracked_stone_bricks
setblock ~25 ~42 ~-110 minecraft:cracked_stone_bricks
setblock ~25 ~43 ~-111 minecraft:cracked_stone_bricks
fill ~26 ~-20 ~-57 ~26 ~-20 ~-43 minecraft:cracked_stone_bricks
setblock ~26 ~ ~-38 minecraft:cracked_stone_bricks
setblock ~26 ~3 ~-128 minecraft:cracked_stone_bricks
setblock ~26 ~4 ~-156 minecraft:cracked_stone_bricks
setblock ~26 ~4 ~-117 minecraft:cracked_stone_bricks
setblock ~26 ~5 ~-133 minecraft:cracked_stone_bricks
fill ~26 ~7 ~-127 ~26 ~7 ~-126 minecraft:cracked_stone_bricks
setblock ~26 ~7 ~-118 minecraft:cracked_stone_bricks
setblock ~26 ~8 ~-131 minecraft:cracked_stone_bricks
fill ~26 ~9 ~-113 ~26 ~10 ~-113 minecraft:cracked_stone_bricks
setblock ~26 ~9 ~-32 minecraft:cracked_stone_bricks
setblock ~26 ~12 ~-156 minecraft:cracked_stone_bricks
setblock ~26 ~12 ~-118 minecraft:cracked_stone_bricks
fill ~26 ~13 ~-126 ~26 ~13 ~-125 minecraft:cracked_stone_bricks
setblock ~26 ~15 ~-128 minecraft:cracked_stone_bricks
fill ~26 ~15 ~-119 ~26 ~15 ~-118 minecraft:cracked_stone_bricks
setblock ~26 ~17 ~-133 minecraft:cracked_stone_bricks
fill ~26 ~17 ~-125 ~26 ~17 ~-124 minecraft:cracked_stone_bricks
setblock ~26 ~17 ~-96 minecraft:cracked_stone_bricks
setblock ~26 ~18 ~-121 minecraft:cracked_stone_bricks
setblock ~26 ~19 ~-120 minecraft:cracked_stone_bricks
setblock ~26 ~20 ~-115 minecraft:cracked_stone_bricks
setblock ~26 ~21 ~-125 minecraft:cracked_stone_bricks
setblock ~26 ~21 ~-121 minecraft:cracked_stone_bricks
setblock ~26 ~23 ~-119 minecraft:cracked_stone_bricks
setblock ~26 ~23 ~-113 minecraft:cracked_stone_bricks
setblock ~26 ~23 ~-110 minecraft:cracked_stone_bricks
setblock ~26 ~25 ~-139 minecraft:cracked_stone_bricks
fill ~26 ~26 ~-131 ~26 ~26 ~-130 minecraft:cracked_stone_bricks
setblock ~26 ~27 ~-152 minecraft:cracked_stone_bricks
setblock ~26 ~27 ~-117 minecraft:cracked_stone_bricks
setblock ~26 ~28 ~-111 minecraft:cracked_stone_bricks
setblock ~26 ~30 ~-126 minecraft:cracked_stone_bricks
setblock ~26 ~30 ~-124 minecraft:cracked_stone_bricks
setblock ~26 ~30 ~-116 minecraft:cracked_stone_bricks
setblock ~26 ~31 ~-120 minecraft:cracked_stone_bricks
setblock ~26 ~32 ~-132 minecraft:cracked_stone_bricks
setblock ~26 ~34 ~-135 minecraft:cracked_stone_bricks
setblock ~26 ~35 ~-134 minecraft:cracked_stone_bricks
setblock ~26 ~35 ~-125 minecraft:cracked_stone_bricks
setblock ~26 ~38 ~-126 minecraft:cracked_stone_bricks
fill ~26 ~38 ~-119 ~26 ~38 ~-118 minecraft:cracked_stone_bricks
fill ~26 ~39 ~-131 ~26 ~39 ~-130 minecraft:cracked_stone_bricks
setblock ~26 ~39 ~-128 minecraft:cracked_stone_bricks
setblock ~26 ~39 ~-111 minecraft:cracked_stone_bricks
setblock ~26 ~39 ~-109 minecraft:cracked_stone_bricks
fill ~26 ~40 ~-152 ~26 ~41 ~-152 minecraft:cracked_stone_bricks
fill ~26 ~40 ~-137 ~26 ~40 ~-136 minecraft:cracked_stone_bricks
setblock ~26 ~40 ~-126 minecraft:cracked_stone_bricks
setblock ~26 ~41 ~-139 minecraft:cracked_stone_bricks
setblock ~26 ~42 ~-119 minecraft:cracked_stone_bricks
setblock ~26 ~44 ~-109 minecraft:cracked_stone_bricks
setblock ~26 ~48 ~-108 minecraft:cracked_stone_bricks
fill ~27 ~-26 ~-57 ~43 ~-26 ~-43 minecraft:cracked_stone_bricks
setblock ~27 ~2 ~-156 minecraft:cracked_stone_bricks
setblock ~27 ~3 ~-108 minecraft:cracked_stone_bricks
setblock ~27 ~4 ~-160 minecraft:cracked_stone_bricks
fill ~27 ~5 ~-140 ~27 ~6 ~-140 minecraft:cracked_stone_bricks
setblock ~27 ~7 ~-38 minecraft:cracked_stone_bricks
setblock ~27 ~10 ~-32 minecraft:cracked_stone_bricks
fill ~27 ~12 ~-38 ~27 ~13 ~-38 minecraft:cracked_stone_bricks
fill ~27 ~18 ~-96 ~27 ~19 ~-96 minecraft:cracked_stone_bricks
setblock ~27 ~21 ~-108 minecraft:cracked_stone_bricks
fill ~27 ~30 ~-152 ~27 ~31 ~-152 minecraft:cracked_stone_bricks
setblock ~27 ~39 ~-140 minecraft:cracked_stone_bricks
setblock ~27 ~41 ~-108 minecraft:cracked_stone_bricks
setblock ~27 ~44 ~-114 minecraft:cracked_stone_bricks
setblock ~27 ~44 ~-112 minecraft:cracked_stone_bricks
setblock ~27 ~45 ~-113 minecraft:cracked_stone_bricks
setblock ~27 ~46 ~-152 minecraft:cracked_stone_bricks
setblock ~27 ~46 ~-121 minecraft:cracked_stone_bricks
setblock ~27 ~52 ~-152 minecraft:cracked_stone_bricks
setblock ~27 ~52 ~-105 minecraft:cracked_stone_bricks
setblock ~27 ~53 ~-95 minecraft:cracked_stone_bricks
setblock ~28 ~3 ~-152 minecraft:cracked_stone_bricks
setblock ~28 ~3 ~-96 minecraft:cracked_stone_bricks
setblock ~28 ~6 ~-38 minecraft:cracked_stone_bricks
setblock ~28 ~7 ~-159 minecraft:cracked_stone_bricks
setblock ~28 ~8 ~-108 minecraft:cracked_stone_bricks
setblock ~28 ~9 ~-159 minecraft:cracked_stone_bricks
setblock ~28 ~10 ~-108 minecraft:cracked_stone_bricks
setblock ~28 ~12 ~-160 minecraft:cracked_stone_bricks
setblock ~28 ~16 ~-140 minecraft:cracked_stone_bricks
setblock ~28 ~16 ~-36 minecraft:cracked_stone_bricks
setblock ~28 ~18 ~-31 minecraft:cracked_stone_bricks
setblock ~28 ~19 ~-96 minecraft:cracked_stone_bricks
setblock ~28 ~21 ~-152 minecraft:cracked_stone_bricks
setblock ~28 ~22 ~-96 minecraft:cracked_stone_bricks
setblock ~28 ~24 ~-96 minecraft:cracked_stone_bricks
setblock ~28 ~33 ~-96 minecraft:cracked_stone_bricks
setblock ~28 ~34 ~-152 minecraft:cracked_stone_bricks
setblock ~28 ~36 ~-108 minecraft:cracked_stone_bricks
setblock ~28 ~37 ~-96 minecraft:cracked_stone_bricks
setblock ~28 ~48 ~-108 minecraft:cracked_stone_bricks
fill ~28 ~52 ~-145 ~29 ~52 ~-145 minecraft:cracked_stone_bricks
setblock ~28 ~52 ~-103 minecraft:cracked_stone_bricks
setblock ~29 ~7 ~-151 minecraft:cracked_stone_bricks
setblock ~29 ~9 ~-97 minecraft:cracked_stone_bricks
setblock ~29 ~12 ~-141 minecraft:cracked_stone_bricks
setblock ~29 ~12 ~-97 minecraft:cracked_stone_bricks
fill ~29 ~13 ~-151 ~30 ~13 ~-151 minecraft:cracked_stone_bricks
fill ~29 ~13 ~-107 ~30 ~13 ~-107 minecraft:cracked_stone_bricks
setblock ~29 ~26 ~-151 minecraft:cracked_stone_bricks
setblock ~29 ~34 ~-151 minecraft:cracked_stone_bricks
setblock ~29 ~43 ~-97 minecraft:cracked_stone_bricks
setblock ~29 ~52 ~-96 minecraft:cracked_stone_bricks
setblock ~30 ~5 ~-32 minecraft:cracked_stone_bricks
fill ~30 ~8 ~-160 ~30 ~9 ~-160 minecraft:cracked_stone_bricks
setblock ~30 ~8 ~-97 minecraft:cracked_stone_bricks
setblock ~30 ~17 ~-31 minecraft:cracked_stone_bricks
fill ~30 ~18 ~-156 ~30 ~19 ~-156 minecraft:cracked_stone_bricks
setblock ~30 ~18 ~-35 minecraft:cracked_stone_bricks
setblock ~30 ~21 ~-97 minecraft:cracked_stone_bricks
setblock ~30 ~28 ~-107 minecraft:cracked_stone_bricks
setblock ~30 ~32 ~-107 minecraft:cracked_stone_bricks
setblock ~30 ~36 ~-151 minecraft:cracked_stone_bricks
setblock ~30 ~48 ~-151 minecraft:cracked_stone_bricks
setblock ~30 ~53 ~-96 minecraft:cracked_stone_bricks
setblock ~31 ~1 ~-38 minecraft:cracked_stone_bricks
setblock ~31 ~4 ~-160 minecraft:cracked_stone_bricks
setblock ~31 ~9 ~-98 minecraft:cracked_stone_bricks
setblock ~31 ~10 ~-149 minecraft:cracked_stone_bricks
setblock ~31 ~11 ~-150 minecraft:cracked_stone_bricks
fill ~31 ~11 ~-98 ~31 ~12 ~-98 minecraft:cracked_stone_bricks
setblock ~31 ~13 ~-160 minecraft:cracked_stone_bricks
setblock ~31 ~14 ~-98 minecraft:cracked_stone_bricks
fill ~31 ~15 ~-38 ~31 ~17 ~-38 minecraft:cracked_stone_bricks
setblock ~31 ~16 ~-149 minecraft:cracked_stone_bricks
setblock ~31 ~18 ~-142 minecraft:cracked_stone_bricks
setblock ~31 ~22 ~-142 minecraft:cracked_stone_bricks
setblock ~31 ~22 ~-106 minecraft:cracked_stone_bricks
setblock ~31 ~23 ~-150 minecraft:cracked_stone_bricks
setblock ~31 ~23 ~-98 minecraft:cracked_stone_bricks
setblock ~31 ~25 ~-143 minecraft:cracked_stone_bricks
setblock ~31 ~26 ~-106 minecraft:cracked_stone_bricks
setblock ~31 ~27 ~-149 minecraft:cracked_stone_bricks
setblock ~31 ~32 ~-149 minecraft:cracked_stone_bricks
setblock ~31 ~33 ~-143 minecraft:cracked_stone_bricks
setblock ~31 ~35 ~-106 minecraft:cracked_stone_bricks
setblock ~31 ~37 ~-105 minecraft:cracked_stone_bricks
fill ~31 ~38 ~-99 ~31 ~38 ~-98 minecraft:cracked_stone_bricks
setblock ~31 ~39 ~-99 minecraft:cracked_stone_bricks
setblock ~31 ~41 ~-99 minecraft:cracked_stone_bricks
setblock ~31 ~44 ~-142 minecraft:cracked_stone_bricks
setblock ~31 ~44 ~-99 minecraft:cracked_stone_bricks
setblock ~31 ~48 ~-99 minecraft:cracked_stone_bricks
setblock ~31 ~52 ~-107 minecraft:cracked_stone_bricks
setblock ~32 ~2 ~-37 minecraft:cracked_stone_bricks
setblock ~32 ~5 ~-38 minecraft:cracked_stone_bricks
setblock ~32 ~5 ~-32 minecraft:cracked_stone_bricks
fill ~32 ~11 ~-156 ~33 ~11 ~-156 minecraft:cracked_stone_bricks
setblock ~32 ~12 ~-146 minecraft:cracked_stone_bricks
setblock ~32 ~13 ~-144 minecraft:cracked_stone_bricks
fill ~32 ~13 ~-32 ~33 ~13 ~-32 minecraft:cracked_stone_bricks
fill ~32 ~17 ~-37 ~32 ~18 ~-37 minecraft:cracked_stone_bricks
fill ~32 ~18 ~-148 ~32 ~19 ~-148 minecraft:cracked_stone_bricks
fill ~32 ~21 ~-146 ~32 ~22 ~-146 minecraft:cracked_stone_bricks
setblock ~32 ~24 ~-101 minecraft:cracked_stone_bricks
setblock ~32 ~25 ~-102 minecraft:cracked_stone_bricks
setblock ~32 ~26 ~-101 minecraft:cracked_stone_bricks
setblock ~32 ~27 ~-103 minecraft:cracked_stone_bricks
setblock ~32 ~28 ~-148 minecraft:cracked_stone_bricks
setblock ~32 ~29 ~-104 minecraft:cracked_stone_bricks
setblock ~32 ~30 ~-103 minecraft:cracked_stone_bricks
setblock ~32 ~33 ~-145 minecraft:cracked_stone_bricks
setblock ~32 ~33 ~-104 minecraft:cracked_stone_bricks
setblock ~32 ~34 ~-146 minecraft:cracked_stone_bricks
setblock ~32 ~35 ~-147 minecraft:cracked_stone_bricks
setblock ~32 ~35 ~-101 minecraft:cracked_stone_bricks
setblock ~32 ~36 ~-148 minecraft:cracked_stone_bricks
setblock ~32 ~37 ~-147 minecraft:cracked_stone_bricks
setblock ~32 ~38 ~-104 minecraft:cracked_stone_bricks
setblock ~32 ~40 ~-144 minecraft:cracked_stone_bricks
setblock ~32 ~41 ~-148 minecraft:cracked_stone_bricks
setblock ~32 ~41 ~-145 minecraft:cracked_stone_bricks
setblock ~32 ~42 ~-103 minecraft:cracked_stone_bricks
setblock ~32 ~45 ~-147 minecraft:cracked_stone_bricks
setblock ~32 ~47 ~-146 minecraft:cracked_stone_bricks
fill ~32 ~48 ~-145 ~32 ~48 ~-144 minecraft:cracked_stone_bricks
setblock ~32 ~48 ~-104 minecraft:cracked_stone_bricks
setblock ~32 ~52 ~-146 minecraft:cracked_stone_bricks
setblock ~33 ~12 ~-156 minecraft:cracked_stone_bricks
setblock ~33 ~17 ~-161 minecraft:cracked_stone_bricks
setblock ~33 ~18 ~-33 minecraft:cracked_stone_bricks
fill ~34 ~4 ~-32 ~35 ~4 ~-32 minecraft:cracked_stone_bricks
setblock ~34 ~18 ~-161 minecraft:cracked_stone_bricks
fill ~35 ~18 ~-160 ~35 ~18 ~-159 minecraft:cracked_stone_bricks
setblock ~36 ~1 ~-156 minecraft:cracked_stone_bricks
setblock ~36 ~3 ~-156 minecraft:cracked_stone_bricks
setblock ~36 ~6 ~-156 minecraft:cracked_stone_bricks
setblock ~36 ~6 ~-33 minecraft:cracked_stone_bricks
setblock ~36 ~8 ~-36 minecraft:cracked_stone_bricks
setblock ~36 ~13 ~-156 minecraft:cracked_stone_bricks
setblock ~36 ~18 ~-161 minecraft:cracked_stone_bricks
fill ~36 ~18 ~-36 ~36 ~19 ~-36 minecraft:cracked_stone_bricks
setblock ~37 ~5 ~-160 minecraft:cracked_stone_bricks
setblock ~37 ~5 ~-32 minecraft:cracked_stone_bricks
setblock ~38 ~2 ~-36 minecraft:cracked_stone_bricks
setblock ~38 ~3 ~-160 minecraft:cracked_stone_bricks
setblock ~38 ~6 ~-36 minecraft:cracked_stone_bricks
setblock ~38 ~11 ~-36 minecraft:cracked_stone_bricks
setblock ~38 ~13 ~-32 minecraft:cracked_stone_bricks
setblock ~38 ~14 ~-156 minecraft:cracked_stone_bricks
setblock ~38 ~18 ~-31 minecraft:cracked_stone_bricks
setblock ~39 ~1 ~-156 minecraft:cracked_stone_bricks
setblock ~39 ~5 ~-36 minecraft:cracked_stone_bricks
setblock ~39 ~13 ~-160 minecraft:cracked_stone_bricks
setblock ~40 ~4 ~-160 minecraft:cracked_stone_bricks
setblock ~40 ~14 ~-160 minecraft:cracked_stone_bricks
fill ~41 ~13 ~-32 ~42 ~13 ~-32 minecraft:cracked_stone_bricks
fill ~41 ~18 ~-156 ~41 ~19 ~-156 minecraft:cracked_stone_bricks
setblock ~42 ~3 ~-32 minecraft:cracked_stone_bricks
setblock ~42 ~9 ~-36 minecraft:cracked_stone_bricks
setblock ~42 ~11 ~-156 minecraft:cracked_stone_bricks
setblock ~42 ~17 ~-161 minecraft:cracked_stone_bricks
setblock ~42 ~17 ~-156 minecraft:cracked_stone_bricks
setblock ~42 ~19 ~-161 minecraft:cracked_stone_bricks
setblock ~43 ~1 ~-156 minecraft:cracked_stone_bricks
setblock ~43 ~3 ~-156 minecraft:cracked_stone_bricks
fill ~43 ~18 ~-161 ~43 ~18 ~-160 minecraft:cracked_stone_bricks
setblock ~43 ~20 ~-161 minecraft:cracked_stone_bricks
setblock ~44 ~ ~-36 minecraft:cracked_stone_bricks
setblock ~44 ~6 ~-33 minecraft:cracked_stone_bricks
setblock ~44 ~10 ~-36 minecraft:cracked_stone_bricks
setblock ~45 ~16 ~-36 minecraft:cracked_stone_bricks
setblock ~45 ~18 ~-160 minecraft:cracked_stone_bricks
setblock ~45 ~20 ~-31 minecraft:cracked_stone_bricks
setblock ~46 ~17 ~-31 minecraft:cracked_stone_bricks
setblock ~46 ~18 ~-34 minecraft:cracked_stone_bricks
setblock ~47 ~1 ~-156 minecraft:cracked_stone_bricks
fill ~47 ~6 ~-160 ~48 ~6 ~-160 minecraft:cracked_stone_bricks
setblock ~47 ~9 ~-32 minecraft:cracked_stone_bricks
setblock ~47 ~11 ~-36 minecraft:cracked_stone_bricks
setblock ~47 ~12 ~-160 minecraft:cracked_stone_bricks
setblock ~47 ~13 ~-36 minecraft:cracked_stone_bricks
fill ~48 ~6 ~-36 ~49 ~6 ~-36 minecraft:cracked_stone_bricks
setblock ~48 ~10 ~-32 minecraft:cracked_stone_bricks
setblock ~50 ~6 ~-160 minecraft:cracked_stone_bricks
setblock ~50 ~9 ~-36 minecraft:cracked_stone_bricks
setblock ~50 ~18 ~-160 minecraft:cracked_stone_bricks
setblock ~50 ~19 ~-161 minecraft:cracked_stone_bricks
setblock ~51 ~2 ~-156 minecraft:cracked_stone_bricks
setblock ~51 ~8 ~-32 minecraft:cracked_stone_bricks
setblock ~51 ~10 ~-160 minecraft:cracked_stone_bricks
setblock ~51 ~10 ~-36 minecraft:cracked_stone_bricks
setblock ~51 ~11 ~-32 minecraft:cracked_stone_bricks
setblock ~51 ~14 ~-160 minecraft:cracked_stone_bricks
setblock ~51 ~18 ~-161 minecraft:cracked_stone_bricks
setblock ~51 ~18 ~-158 minecraft:cracked_stone_bricks
setblock ~51 ~18 ~-35 minecraft:cracked_stone_bricks
setblock ~51 ~18 ~-31 minecraft:cracked_stone_bricks
setblock ~52 ~ ~-156 minecraft:cracked_stone_bricks
setblock ~52 ~11 ~-160 minecraft:cracked_stone_bricks
setblock ~52 ~19 ~-31 minecraft:cracked_stone_bricks
setblock ~52 ~30 ~-158 minecraft:cracked_stone_bricks
setblock ~53 ~4 ~-36 minecraft:cracked_stone_bricks
fill ~53 ~10 ~-163 ~53 ~10 ~-162 minecraft:cracked_stone_bricks
fill ~53 ~17 ~-163 ~53 ~17 ~-162 minecraft:cracked_stone_bricks
setblock ~53 ~18 ~-32 minecraft:cracked_stone_bricks
setblock ~53 ~20 ~-162 minecraft:cracked_stone_bricks
setblock ~53 ~21 ~-31 minecraft:cracked_stone_bricks
setblock ~53 ~22 ~-29 minecraft:cracked_stone_bricks
fill ~53 ~25 ~-162 ~53 ~26 ~-162 minecraft:cracked_stone_bricks
setblock ~53 ~31 ~-165 minecraft:cracked_stone_bricks
setblock ~53 ~31 ~-37 minecraft:cracked_stone_bricks
setblock ~54 ~ ~-158 minecraft:cracked_stone_bricks
fill ~54 ~ ~-30 ~54 ~1 ~-30 minecraft:cracked_stone_bricks
setblock ~54 ~1 ~-159 minecraft:cracked_stone_bricks
setblock ~54 ~2 ~-34 minecraft:cracked_stone_bricks
setblock ~54 ~4 ~-165 minecraft:cracked_stone_bricks
setblock ~54 ~4 ~-160 minecraft:cracked_stone_bricks
setblock ~54 ~4 ~-34 minecraft:cracked_stone_bricks
setblock ~54 ~8 ~-160 minecraft:cracked_stone_bricks
fill ~54 ~8 ~-158 ~54 ~9 ~-158 minecraft:cracked_stone_bricks
setblock ~54 ~8 ~-34 minecraft:cracked_stone_bricks
setblock ~54 ~13 ~-165 minecraft:cracked_stone_bricks
setblock ~54 ~13 ~-163 minecraft:cracked_stone_bricks
setblock ~54 ~13 ~-37 minecraft:cracked_stone_bricks
fill ~54 ~15 ~-163 ~54 ~15 ~-162 minecraft:cracked_stone_bricks
setblock ~54 ~15 ~-157 minecraft:cracked_stone_bricks
setblock ~54 ~18 ~-155 minecraft:cracked_stone_bricks
setblock ~54 ~21 ~-36 minecraft:cracked_stone_bricks
fill ~54 ~22 ~-31 ~54 ~23 ~-31 minecraft:cracked_stone_bricks
setblock ~54 ~23 ~-155 minecraft:cracked_stone_bricks
setblock ~54 ~25 ~-35 minecraft:cracked_stone_bricks
setblock ~54 ~25 ~-30 minecraft:cracked_stone_bricks
setblock ~54 ~26 ~-161 minecraft:cracked_stone_bricks
setblock ~54 ~27 ~-31 minecraft:cracked_stone_bricks
setblock ~54 ~28 ~-160 minecraft:cracked_stone_bricks
setblock ~54 ~28 ~-37 minecraft:cracked_stone_bricks
setblock ~54 ~29 ~-163 minecraft:cracked_stone_bricks
setblock ~55 ~ ~-37 minecraft:cracked_stone_bricks
setblock ~55 ~1 ~-155 minecraft:cracked_stone_bricks
setblock ~55 ~3 ~-155 minecraft:cracked_stone_bricks
setblock ~55 ~3 ~-153 minecraft:cracked_stone_bricks
setblock ~55 ~4 ~-166 minecraft:cracked_stone_bricks
fill ~55 ~8 ~-166 ~55 ~8 ~-165 minecraft:cracked_stone_bricks
setblock ~55 ~8 ~-156 minecraft:cracked_stone_bricks
setblock ~55 ~8 ~-36 minecraft:cracked_stone_bricks
setblock ~55 ~9 ~-153 minecraft:cracked_stone_bricks
setblock ~55 ~10 ~-166 minecraft:cracked_stone_bricks
setblock ~55 ~11 ~-26 minecraft:cracked_stone_bricks
setblock ~55 ~13 ~-166 minecraft:cracked_stone_bricks
setblock ~55 ~13 ~-155 minecraft:cracked_stone_bricks
setblock ~55 ~14 ~-153 minecraft:cracked_stone_bricks
setblock ~55 ~15 ~-167 minecraft:cracked_stone_bricks
setblock ~55 ~19 ~-155 minecraft:cracked_stone_bricks
setblock ~55 ~22 ~-156 minecraft:cracked_stone_bricks
setblock ~55 ~25 ~-37 minecraft:cracked_stone_bricks
setblock ~55 ~26 ~-155 minecraft:cracked_stone_bricks
setblock ~55 ~26 ~-36 minecraft:cracked_stone_bricks
setblock ~55 ~28 ~-27 minecraft:cracked_stone_bricks
setblock ~55 ~30 ~-35 minecraft:cracked_stone_bricks
setblock ~55 ~30 ~-32 minecraft:cracked_stone_bricks
setblock ~56 ~2 ~-38 minecraft:cracked_stone_bricks
setblock ~56 ~5 ~-40 minecraft:cracked_stone_bricks
fill ~56 ~7 ~-154 ~56 ~8 ~-154 minecraft:cracked_stone_bricks
setblock ~56 ~11 ~-168 minecraft:cracked_stone_bricks
setblock ~56 ~11 ~-166 minecraft:cracked_stone_bricks
setblock ~56 ~13 ~-26 minecraft:cracked_stone_bricks
setblock ~56 ~14 ~-38 minecraft:cracked_stone_bricks
setblock ~56 ~15 ~-154 minecraft:cracked_stone_bricks
setblock ~56 ~17 ~-38 minecraft:cracked_stone_bricks
setblock ~56 ~17 ~-26 minecraft:cracked_stone_bricks
setblock ~56 ~18 ~-168 minecraft:cracked_stone_bricks
setblock ~56 ~25 ~-154 minecraft:cracked_stone_bricks
setblock ~56 ~25 ~-38 minecraft:cracked_stone_bricks
setblock ~56 ~26 ~-96 minecraft:cracked_stone_bricks
setblock ~56 ~26 ~-40 minecraft:cracked_stone_bricks
fill ~56 ~30 ~-151 ~57 ~30 ~-151 minecraft:cracked_stone_bricks
setblock ~56 ~30 ~-30 minecraft:cracked_stone_bricks
setblock ~57 ~ ~-151 minecraft:cracked_stone_bricks
setblock ~57 ~1 ~-167 minecraft:cracked_stone_bricks
setblock ~57 ~1 ~-94 minecraft:cracked_stone_bricks
setblock ~57 ~1 ~-41 minecraft:cracked_stone_bricks
setblock ~57 ~6 ~-96 minecraft:cracked_stone_bricks
setblock ~57 ~8 ~-167 minecraft:cracked_stone_bricks
setblock ~57 ~10 ~-41 minecraft:cracked_stone_bricks
fill ~57 ~11 ~-169 ~57 ~12 ~-169 minecraft:cracked_stone_bricks
setblock ~57 ~13 ~-23 minecraft:cracked_stone_bricks
setblock ~57 ~14 ~-151 minecraft:cracked_stone_bricks
setblock ~57 ~16 ~-153 minecraft:cracked_stone_bricks
setblock ~57 ~18 ~-95 minecraft:cracked_stone_bricks
setblock ~57 ~21 ~-94 minecraft:cracked_stone_bricks
setblock ~57 ~21 ~-41 minecraft:cracked_stone_bricks
setblock ~57 ~22 ~-97 minecraft:cracked_stone_bricks
setblock ~57 ~24 ~-94 minecraft:cracked_stone_bricks
setblock ~57 ~25 ~-39 minecraft:cracked_stone_bricks
setblock ~57 ~27 ~-93 minecraft:cracked_stone_bricks
setblock ~57 ~27 ~-41 minecraft:cracked_stone_bricks
setblock ~57 ~30 ~-150 minecraft:cracked_stone_bricks
setblock ~58 ~3 ~-168 minecraft:cracked_stone_bricks
setblock ~58 ~3 ~-96 minecraft:cracked_stone_bricks
setblock ~58 ~4 ~-41 minecraft:cracked_stone_bricks
setblock ~58 ~6 ~-98 minecraft:cracked_stone_bricks
setblock ~58 ~6 ~-92 minecraft:cracked_stone_bricks
setblock ~58 ~6 ~-41 minecraft:cracked_stone_bricks
setblock ~58 ~8 ~-169 minecraft:cracked_stone_bricks
setblock ~58 ~10 ~-40 minecraft:cracked_stone_bricks
setblock ~58 ~11 ~-41 minecraft:cracked_stone_bricks
setblock ~58 ~13 ~-40 minecraft:cracked_stone_bricks
setblock ~58 ~15 ~-97 minecraft:cracked_stone_bricks
setblock ~58 ~15 ~-93 minecraft:cracked_stone_bricks
fill ~58 ~16 ~-96 ~58 ~17 ~-96 minecraft:cracked_stone_bricks
setblock ~58 ~16 ~-94 minecraft:cracked_stone_bricks
setblock ~58 ~16 ~-92 minecraft:cracked_stone_bricks
setblock ~58 ~17 ~-41 minecraft:cracked_stone_bricks
setblock ~58 ~18 ~-93 minecraft:cracked_stone_bricks
setblock ~58 ~20 ~-24 minecraft:cracked_stone_bricks
setblock ~58 ~22 ~-152 minecraft:cracked_stone_bricks
setblock ~58 ~22 ~-40 minecraft:cracked_stone_bricks
setblock ~58 ~22 ~-24 minecraft:cracked_stone_bricks
setblock ~58 ~25 ~-98 minecraft:cracked_stone_bricks
setblock ~58 ~25 ~-94 minecraft:cracked_stone_bricks
fill ~58 ~27 ~-24 ~58 ~27 ~-23 minecraft:cracked_stone_bricks
setblock ~58 ~28 ~-168 minecraft:cracked_stone_bricks
setblock ~58 ~30 ~-157 minecraft:cracked_stone_bricks
fill ~58 ~30 ~-36 ~59 ~30 ~-36 minecraft:cracked_stone_bricks
setblock ~59 ~3 ~-42 minecraft:cracked_stone_bricks
setblock ~59 ~3 ~-23 minecraft:cracked_stone_bricks
fill ~59 ~4 ~-151 ~60 ~4 ~-151 minecraft:cracked_stone_bricks
setblock ~59 ~6 ~-170 minecraft:cracked_stone_bricks
setblock ~59 ~7 ~-99 minecraft:cracked_stone_bricks
fill ~59 ~8 ~-41 ~60 ~8 ~-41 minecraft:cracked_stone_bricks
setblock ~59 ~10 ~-169 minecraft:cracked_stone_bricks
setblock ~59 ~13 ~-23 minecraft:cracked_stone_bricks
setblock ~59 ~17 ~-101 minecraft:cracked_stone_bricks
setblock ~59 ~19 ~-169 minecraft:cracked_stone_bricks
setblock ~59 ~20 ~-100 minecraft:cracked_stone_bricks
setblock ~59 ~22 ~-41 minecraft:cracked_stone_bricks
setblock ~59 ~24 ~-22 minecraft:cracked_stone_bricks
fill ~59 ~26 ~-94 ~60 ~26 ~-94 minecraft:cracked_stone_bricks
setblock ~59 ~30 ~-26 minecraft:cracked_stone_bricks
fill ~60 ~ ~-58 ~60 ~ ~-57 minecraft:cracked_stone_bricks
setblock ~60 ~1 ~-128 minecraft:cracked_stone_bricks
setblock ~60 ~1 ~-77 minecraft:cracked_stone_bricks
setblock ~60 ~1 ~-74 minecraft:cracked_stone_bricks
setblock ~60 ~1 ~-64 minecraft:cracked_stone_bricks
setblock ~60 ~1 ~-52 minecraft:cracked_stone_bricks
setblock ~60 ~2 ~-110 minecraft:cracked_stone_bricks
setblock ~60 ~2 ~-71 minecraft:cracked_stone_bricks
setblock ~60 ~2 ~-49 minecraft:cracked_stone_bricks
setblock ~60 ~3 ~-139 minecraft:cracked_stone_bricks
setblock ~60 ~3 ~-127 minecraft:cracked_stone_bricks
setblock ~60 ~3 ~-125 minecraft:cracked_stone_bricks
setblock ~60 ~3 ~-119 minecraft:cracked_stone_bricks
setblock ~60 ~3 ~-117 minecraft:cracked_stone_bricks
setblock ~60 ~3 ~-43 minecraft:cracked_stone_bricks
setblock ~60 ~4 ~-111 minecraft:cracked_stone_bricks
setblock ~60 ~4 ~-103 minecraft:cracked_stone_bricks
setblock ~60 ~4 ~-77 minecraft:cracked_stone_bricks
setblock ~60 ~4 ~-46 minecraft:cracked_stone_bricks
setblock ~60 ~5 ~-137 minecraft:cracked_stone_bricks
setblock ~60 ~5 ~-123 minecraft:cracked_stone_bricks
setblock ~60 ~5 ~-120 minecraft:cracked_stone_bricks
setblock ~60 ~5 ~-89 minecraft:cracked_stone_bricks
setblock ~60 ~5 ~-75 minecraft:cracked_stone_bricks
setblock ~60 ~5 ~-66 minecraft:cracked_stone_bricks
setblock ~60 ~6 ~-147 minecraft:cracked_stone_bricks
setblock ~60 ~6 ~-138 minecraft:cracked_stone_bricks
setblock ~60 ~6 ~-124 minecraft:cracked_stone_bricks
setblock ~60 ~6 ~-112 minecraft:cracked_stone_bricks
setblock ~60 ~6 ~-102 minecraft:cracked_stone_bricks
setblock ~60 ~6 ~-86 minecraft:cracked_stone_bricks
fill ~60 ~6 ~-84 ~60 ~7 ~-84 minecraft:cracked_stone_bricks
setblock ~60 ~6 ~-73 minecraft:cracked_stone_bricks
setblock ~60 ~6 ~-55 minecraft:cracked_stone_bricks
setblock ~60 ~6 ~-46 minecraft:cracked_stone_bricks
fill ~60 ~8 ~-139 ~60 ~9 ~-139 minecraft:cracked_stone_bricks
setblock ~60 ~8 ~-130 minecraft:cracked_stone_bricks
setblock ~60 ~8 ~-105 minecraft:cracked_stone_bricks
fill ~60 ~9 ~-135 ~60 ~9 ~-134 minecraft:cracked_stone_bricks
setblock ~60 ~9 ~-123 minecraft:cracked_stone_bricks
setblock ~60 ~9 ~-87 minecraft:cracked_stone_bricks
setblock ~60 ~9 ~-47 minecraft:cracked_stone_bricks
setblock ~60 ~9 ~-45 minecraft:cracked_stone_bricks
setblock ~60 ~10 ~-112 minecraft:cracked_stone_bricks
setblock ~60 ~10 ~-109 minecraft:cracked_stone_bricks
setblock ~60 ~10 ~-81 minecraft:cracked_stone_bricks
setblock ~60 ~10 ~-41 minecraft:cracked_stone_bricks
fill ~60 ~11 ~-137 ~60 ~12 ~-137 minecraft:cracked_stone_bricks
setblock ~60 ~11 ~-123 minecraft:cracked_stone_bricks
setblock ~60 ~11 ~-116 minecraft:cracked_stone_bricks
setblock ~60 ~11 ~-114 minecraft:cracked_stone_bricks
setblock ~60 ~11 ~-72 minecraft:cracked_stone_bricks
setblock ~60 ~11 ~-67 minecraft:cracked_stone_bricks
setblock ~60 ~12 ~-149 minecraft:cracked_stone_bricks
setblock ~60 ~12 ~-147 minecraft:cracked_stone_bricks
setblock ~60 ~12 ~-109 minecraft:cracked_stone_bricks
setblock ~60 ~12 ~-66 minecraft:cracked_stone_bricks
setblock ~60 ~12 ~-58 minecraft:cracked_stone_bricks
fill ~60 ~12 ~-53 ~60 ~12 ~-52 minecraft:cracked_stone_bricks
fill ~60 ~13 ~-131 ~60 ~14 ~-131 minecraft:cracked_stone_bricks
setblock ~60 ~13 ~-129 minecraft:cracked_stone_bricks
setblock ~60 ~13 ~-117 minecraft:cracked_stone_bricks
setblock ~60 ~13 ~-59 minecraft:cracked_stone_bricks
setblock ~60 ~13 ~-41 minecraft:cracked_stone_bricks
setblock ~60 ~14 ~-170 minecraft:cracked_stone_bricks
setblock ~60 ~14 ~-146 minecraft:cracked_stone_bricks
setblock ~60 ~14 ~-142 minecraft:cracked_stone_bricks
setblock ~60 ~14 ~-135 minecraft:cracked_stone_bricks
setblock ~60 ~14 ~-124 minecraft:cracked_stone_bricks
setblock ~60 ~14 ~-88 minecraft:cracked_stone_bricks
setblock ~60 ~15 ~-80 minecraft:cracked_stone_bricks
fill ~60 ~16 ~-137 ~60 ~17 ~-137 minecraft:cracked_stone_bricks
setblock ~60 ~16 ~-66 minecraft:cracked_stone_bricks
setblock ~60 ~17 ~-140 minecraft:cracked_stone_bricks
setblock ~60 ~17 ~-104 minecraft:cracked_stone_bricks
fill ~60 ~17 ~-74 ~60 ~17 ~-73 minecraft:cracked_stone_bricks
setblock ~60 ~17 ~-47 minecraft:cracked_stone_bricks
setblock ~60 ~17 ~-44 minecraft:cracked_stone_bricks
fill ~60 ~18 ~-67 ~60 ~19 ~-66 minecraft:cracked_stone_bricks
fill ~60 ~18 ~-60 ~60 ~19 ~-60 minecraft:cracked_stone_bricks
setblock ~60 ~21 ~-91 minecraft:cracked_stone_bricks
setblock ~60 ~22 ~-102 minecraft:cracked_stone_bricks
setblock ~60 ~24 ~-150 minecraft:cracked_stone_bricks
setblock ~60 ~27 ~-170 minecraft:cracked_stone_bricks
setblock ~60 ~28 ~-22 minecraft:cracked_stone_bricks
setblock ~60 ~30 ~-33 minecraft:cracked_stone_bricks
setblock ~60 ~30 ~-24 minecraft:cracked_stone_bricks
setblock ~61 ~14 ~-21 minecraft:cracked_stone_bricks
setblock ~61 ~15 ~-170 minecraft:cracked_stone_bricks
setblock ~61 ~15 ~-22 minecraft:cracked_stone_bricks
setblock ~61 ~18 ~-108 minecraft:cracked_stone_bricks
setblock ~61 ~18 ~-78 minecraft:cracked_stone_bricks
setblock ~61 ~18 ~-57 minecraft:cracked_stone_bricks
setblock ~61 ~18 ~-53 minecraft:cracked_stone_bricks
setblock ~61 ~18 ~-21 minecraft:cracked_stone_bricks
setblock ~61 ~25 ~-170 minecraft:cracked_stone_bricks
setblock ~61 ~26 ~-97 minecraft:cracked_stone_bricks
setblock ~61 ~26 ~-95 minecraft:cracked_stone_bricks
setblock ~61 ~26 ~-42 minecraft:cracked_stone_bricks
fill ~61 ~26 ~-21 ~61 ~27 ~-21 minecraft:cracked_stone_bricks
setblock ~61 ~28 ~-171 minecraft:cracked_stone_bricks
setblock ~61 ~30 ~-165 minecraft:cracked_stone_bricks
setblock ~61 ~30 ~-30 minecraft:cracked_stone_bricks
setblock ~62 ~2 ~-22 minecraft:cracked_stone_bricks
setblock ~62 ~5 ~-150 minecraft:cracked_stone_bricks
setblock ~62 ~5 ~-90 minecraft:cracked_stone_bricks
setblock ~62 ~11 ~-22 minecraft:cracked_stone_bricks
setblock ~62 ~14 ~-170 minecraft:cracked_stone_bricks
setblock ~62 ~18 ~-61 minecraft:cracked_stone_bricks
setblock ~62 ~18 ~-58 minecraft:cracked_stone_bricks
setblock ~62 ~19 ~-171 minecraft:cracked_stone_bricks
setblock ~62 ~21 ~-22 minecraft:cracked_stone_bricks
fill ~62 ~22 ~-149 ~63 ~22 ~-149 minecraft:cracked_stone_bricks
setblock ~62 ~22 ~-90 minecraft:cracked_stone_bricks
setblock ~62 ~30 ~-148 minecraft:cracked_stone_bricks
setblock ~63 ~6 ~-84 minecraft:cracked_stone_bricks
fill ~63 ~7 ~-140 ~63 ~8 ~-140 minecraft:cracked_stone_bricks
setblock ~63 ~8 ~-60 minecraft:cracked_stone_bricks
setblock ~63 ~8 ~-22 minecraft:cracked_stone_bricks
setblock ~63 ~10 ~-90 minecraft:cracked_stone_bricks
setblock ~63 ~13 ~-22 minecraft:cracked_stone_bricks
fill ~63 ~16 ~-102 ~63 ~17 ~-102 minecraft:cracked_stone_bricks
setblock ~63 ~18 ~-140 minecraft:cracked_stone_bricks
setblock ~63 ~18 ~-113 minecraft:cracked_stone_bricks
setblock ~63 ~18 ~-73 minecraft:cracked_stone_bricks
setblock ~63 ~21 ~-42 minecraft:cracked_stone_bricks
setblock ~63 ~24 ~-102 minecraft:cracked_stone_bricks
setblock ~63 ~24 ~-90 minecraft:cracked_stone_bricks
setblock ~63 ~27 ~-22 minecraft:cracked_stone_bricks
setblock ~63 ~30 ~-161 minecraft:cracked_stone_bricks
setblock ~63 ~30 ~-153 minecraft:cracked_stone_bricks
setblock ~63 ~30 ~-26 minecraft:cracked_stone_bricks
setblock ~63 ~31 ~-172 minecraft:cracked_stone_bricks
fill ~64 ~3 ~-84 ~64 ~4 ~-84 minecraft:cracked_stone_bricks
setblock ~64 ~3 ~-78 minecraft:cracked_stone_bricks
setblock ~64 ~4 ~-145 minecraft:cracked_stone_bricks
setblock ~64 ~4 ~-143 minecraft:cracked_stone_bricks
setblock ~64 ~4 ~-122 minecraft:cracked_stone_bricks
setblock ~64 ~4 ~-104 minecraft:cracked_stone_bricks
setblock ~64 ~5 ~-138 minecraft:cracked_stone_bricks
setblock ~64 ~5 ~-136 minecraft:cracked_stone_bricks
setblock ~64 ~5 ~-127 minecraft:cracked_stone_bricks
setblock ~64 ~5 ~-110 minecraft:cracked_stone_bricks
setblock ~64 ~5 ~-80 minecraft:cracked_stone_bricks
setblock ~64 ~5 ~-75 minecraft:cracked_stone_bricks
setblock ~64 ~5 ~-67 minecraft:cracked_stone_bricks
setblock ~64 ~5 ~-65 minecraft:cracked_stone_bricks
setblock ~64 ~5 ~-60 minecraft:cracked_stone_bricks
setblock ~64 ~6 ~-143 minecraft:cracked_stone_bricks
setblock ~64 ~6 ~-131 minecraft:cracked_stone_bricks
setblock ~64 ~6 ~-113 minecraft:cracked_stone_bricks
setblock ~64 ~6 ~-86 minecraft:cracked_stone_bricks
fill ~64 ~6 ~-62 ~64 ~6 ~-61 minecraft:cracked_stone_bricks
setblock ~64 ~6 ~-54 minecraft:cracked_stone_bricks
setblock ~64 ~7 ~-142 minecraft:cracked_stone_bricks
setblock ~64 ~7 ~-111 minecraft:cracked_stone_bricks
setblock ~64 ~7 ~-61 minecraft:cracked_stone_bricks
setblock ~64 ~7 ~-58 minecraft:cracked_stone_bricks
setblock ~64 ~8 ~-125 minecraft:cracked_stone_bricks
setblock ~64 ~8 ~-55 minecraft:cracked_stone_bricks
fill ~64 ~9 ~-127 ~64 ~10 ~-127 minecraft:cracked_stone_bricks
setblock ~64 ~9 ~-120 minecraft:cracked_stone_bricks
setblock ~64 ~9 ~-75 minecraft:cracked_stone_bricks
setblock ~64 ~9 ~-73 minecraft:cracked_stone_bricks
setblock ~64 ~10 ~-143 minecraft:cracked_stone_bricks
setblock ~64 ~10 ~-135 minecraft:cracked_stone_bricks
setblock ~64 ~10 ~-109 minecraft:cracked_stone_bricks
setblock ~64 ~10 ~-61 minecraft:cracked_stone_bricks
setblock ~64 ~11 ~-136 minecraft:cracked_stone_bricks
setblock ~64 ~11 ~-123 minecraft:cracked_stone_bricks
setblock ~64 ~11 ~-71 minecraft:cracked_stone_bricks
setblock ~64 ~12 ~-104 minecraft:cracked_stone_bricks
setblock ~64 ~12 ~-70 minecraft:cracked_stone_bricks
setblock ~64 ~12 ~-47 minecraft:cracked_stone_bricks
setblock ~64 ~13 ~-140 minecraft:cracked_stone_bricks
fill ~64 ~13 ~-136 ~64 ~13 ~-135 minecraft:cracked_stone_bricks
setblock ~64 ~13 ~-71 minecraft:cracked_stone_bricks
setblock ~64 ~13 ~-59 minecraft:cracked_stone_bricks
fill ~64 ~14 ~-114 ~64 ~15 ~-114 minecraft:cracked_stone_bricks
setblock ~64 ~14 ~-48 minecraft:cracked_stone_bricks
setblock ~64 ~14 ~-21 minecraft:cracked_stone_bricks
setblock ~64 ~15 ~-134 minecraft:cracked_stone_bricks
setblock ~64 ~17 ~-150 minecraft:cracked_stone_bricks
setblock ~64 ~18 ~-116 minecraft:cracked_stone_bricks
setblock ~64 ~18 ~-84 minecraft:cracked_stone_bricks
setblock ~64 ~27 ~-21 minecraft:cracked_stone_bricks
setblock ~64 ~28 ~-88 minecraft:cracked_stone_bricks
setblock ~65 ~ ~-42 minecraft:cracked_stone_bricks
setblock ~65 ~3 ~-43 minecraft:cracked_stone_bricks
setblock ~65 ~5 ~-170 minecraft:cracked_stone_bricks
setblock ~65 ~5 ~-43 minecraft:cracked_stone_bricks
setblock ~65 ~6 ~-89 minecraft:cracked_stone_bricks
setblock ~65 ~7 ~-90 minecraft:cracked_stone_bricks
setblock ~65 ~9 ~-149 minecraft:cracked_stone_bricks
setblock ~65 ~9 ~-89 minecraft:cracked_stone_bricks
setblock ~65 ~10 ~-170 minecraft:cracked_stone_bricks
setblock ~65 ~11 ~-103 minecraft:cracked_stone_bricks
fill ~65 ~13 ~-89 ~65 ~14 ~-89 minecraft:cracked_stone_bricks
setblock ~65 ~15 ~-149 minecraft:cracked_stone_bricks
setblock ~65 ~17 ~-111 minecraft:cracked_stone_bricks
setblock ~65 ~17 ~-104 minecraft:cracked_stone_bricks
setblock ~65 ~17 ~-78 minecraft:cracked_stone_bricks
setblock ~65 ~17 ~-76 minecraft:cracked_stone_bricks
setblock ~65 ~17 ~-64 minecraft:cracked_stone_bricks
setblock ~65 ~18 ~-145 minecraft:cracked_stone_bricks
setblock ~65 ~18 ~-137 minecraft:cracked_stone_bricks
fill ~65 ~18 ~-135 ~65 ~19 ~-135 minecraft:cracked_stone_bricks
setblock ~65 ~18 ~-117 minecraft:cracked_stone_bricks
setblock ~65 ~18 ~-80 minecraft:cracked_stone_bricks
setblock ~65 ~18 ~-66 minecraft:cracked_stone_bricks
setblock ~65 ~19 ~-127 minecraft:cracked_stone_bricks
setblock ~65 ~19 ~-123 minecraft:cracked_stone_bricks
setblock ~65 ~19 ~-90 minecraft:cracked_stone_bricks
setblock ~65 ~20 ~-119 minecraft:cracked_stone_bricks
setblock ~65 ~20 ~-47 minecraft:cracked_stone_bricks
setblock ~65 ~21 ~-170 minecraft:cracked_stone_bricks
setblock ~65 ~26 ~-103 minecraft:cracked_stone_bricks
setblock ~65 ~26 ~-97 minecraft:cracked_stone_bricks
fill ~65 ~30 ~-171 ~66 ~30 ~-171 minecraft:cracked_stone_bricks
setblock ~65 ~30 ~-40 minecraft:cracked_stone_bricks
setblock ~65 ~30 ~-32 minecraft:cracked_stone_bricks
setblock ~65 ~30 ~-25 minecraft:cracked_stone_bricks
setblock ~66 ~4 ~-89 minecraft:cracked_stone_bricks
setblock ~66 ~5 ~-103 minecraft:cracked_stone_bricks
setblock ~66 ~6 ~-43 minecraft:cracked_stone_bricks
setblock ~66 ~8 ~-103 minecraft:cracked_stone_bricks
fill ~66 ~10 ~-22 ~66 ~10 ~-21 minecraft:cracked_stone_bricks
setblock ~66 ~11 ~-102 minecraft:cracked_stone_bricks
setblock ~66 ~11 ~-42 minecraft:cracked_stone_bricks
setblock ~66 ~12 ~-103 minecraft:cracked_stone_bricks
setblock ~66 ~14 ~-103 minecraft:cracked_stone_bricks
setblock ~66 ~17 ~-149 minecraft:cracked_stone_bricks
setblock ~66 ~18 ~-21 minecraft:cracked_stone_bricks
setblock ~66 ~21 ~-171 minecraft:cracked_stone_bricks
setblock ~66 ~23 ~-90 minecraft:cracked_stone_bricks
setblock ~66 ~23 ~-43 minecraft:cracked_stone_bricks
fill ~66 ~25 ~-22 ~67 ~25 ~-22 minecraft:cracked_stone_bricks
setblock ~66 ~26 ~-93 minecraft:cracked_stone_bricks
setblock ~66 ~28 ~-88 minecraft:cracked_stone_bricks
setblock ~66 ~30 ~-163 minecraft:cracked_stone_bricks
setblock ~66 ~30 ~-157 minecraft:cracked_stone_bricks
setblock ~66 ~30 ~-36 minecraft:cracked_stone_bricks
setblock ~66 ~30 ~-23 minecraft:cracked_stone_bricks
setblock ~66 ~30 ~-20 minecraft:cracked_stone_bricks
setblock ~67 ~1 ~-170 minecraft:cracked_stone_bricks
fill ~67 ~2 ~-101 ~67 ~3 ~-101 minecraft:cracked_stone_bricks
setblock ~67 ~4 ~-22 minecraft:cracked_stone_bricks
setblock ~67 ~5 ~-102 minecraft:cracked_stone_bricks
setblock ~67 ~6 ~-90 minecraft:cracked_stone_bricks
setblock ~67 ~7 ~-149 minecraft:cracked_stone_bricks
setblock ~67 ~8 ~-150 minecraft:cracked_stone_bricks
fill ~67 ~11 ~-91 ~67 ~15 ~-91 minecraft:cracked_stone_bricks
setblock ~67 ~12 ~-171 minecraft:cracked_stone_bricks
setblock ~67 ~15 ~-102 minecraft:cracked_stone_bricks
setblock ~67 ~17 ~-22 minecraft:cracked_stone_bricks
setblock ~67 ~18 ~-149 minecraft:cracked_stone_bricks
setblock ~67 ~21 ~-149 minecraft:cracked_stone_bricks
setblock ~67 ~23 ~-21 minecraft:cracked_stone_bricks
setblock ~67 ~25 ~-149 minecraft:cracked_stone_bricks
fill ~67 ~26 ~-170 ~68 ~26 ~-170 minecraft:cracked_stone_bricks
setblock ~67 ~28 ~-149 minecraft:cracked_stone_bricks
setblock ~67 ~29 ~-42 minecraft:cracked_stone_bricks
setblock ~67 ~30 ~-165 minecraft:cracked_stone_bricks
setblock ~67 ~30 ~-162 minecraft:cracked_stone_bricks
setblock ~67 ~30 ~-151 minecraft:cracked_stone_bricks
fill ~68 ~ ~-169 ~68 ~1 ~-169 minecraft:cracked_stone_bricks
setblock ~68 ~2 ~-100 minecraft:cracked_stone_bricks
setblock ~68 ~3 ~-41 minecraft:cracked_stone_bricks
setblock ~68 ~6 ~-42 minecraft:cracked_stone_bricks
setblock ~68 ~7 ~-22 minecraft:cracked_stone_bricks
setblock ~68 ~9 ~-170 minecraft:cracked_stone_bricks
setblock ~68 ~9 ~-41 minecraft:cracked_stone_bricks
setblock ~68 ~10 ~-92 minecraft:cracked_stone_bricks
setblock ~68 ~13 ~-102 minecraft:cracked_stone_bricks
fill ~68 ~20 ~-102 ~68 ~21 ~-102 minecraft:cracked_stone_bricks
fill ~68 ~21 ~-170 ~68 ~22 ~-170 minecraft:cracked_stone_bricks
setblock ~68 ~22 ~-42 minecraft:cracked_stone_bricks
setblock ~68 ~24 ~-92 minecraft:cracked_stone_bricks
setblock ~68 ~25 ~-150 minecraft:cracked_stone_bricks
setblock ~68 ~27 ~-103 minecraft:cracked_stone_bricks
setblock ~68 ~30 ~-161 minecraft:cracked_stone_bricks
setblock ~68 ~30 ~-43 minecraft:cracked_stone_bricks
setblock ~69 ~ ~-151 minecraft:cracked_stone_bricks
setblock ~69 ~3 ~-170 minecraft:cracked_stone_bricks
fill ~69 ~4 ~-23 ~70 ~4 ~-23 minecraft:cracked_stone_bricks
setblock ~69 ~5 ~-41 minecraft:cracked_stone_bricks
setblock ~69 ~9 ~-151 minecraft:cracked_stone_bricks
setblock ~69 ~9 ~-22 minecraft:cracked_stone_bricks
setblock ~69 ~11 ~-99 minecraft:cracked_stone_bricks
setblock ~69 ~12 ~-101 minecraft:cracked_stone_bricks
setblock ~69 ~14 ~-93 minecraft:cracked_stone_bricks
setblock ~69 ~21 ~-22 minecraft:cracked_stone_bricks
setblock ~69 ~30 ~-21 minecraft:cracked_stone_bricks
setblock ~70 ~ ~-97 minecraft:cracked_stone_bricks
setblock ~70 ~1 ~-98 minecraft:cracked_stone_bricks
setblock ~70 ~3 ~-169 minecraft:cracked_stone_bricks
setblock ~70 ~3 ~-95 minecraft:cracked_stone_bricks
setblock ~70 ~4 ~-98 minecraft:cracked_stone_bricks
fill ~70 ~5 ~-95 ~70 ~5 ~-94 minecraft:cracked_stone_bricks
setblock ~70 ~5 ~-40 minecraft:cracked_stone_bricks
setblock ~70 ~8 ~-97 minecraft:cracked_stone_bricks
setblock ~70 ~10 ~-168 minecraft:cracked_stone_bricks
setblock ~70 ~15 ~-96 minecraft:cracked_stone_bricks
fill ~70 ~16 ~-97 ~71 ~16 ~-97 minecraft:cracked_stone_bricks
setblock ~70 ~16 ~-93 minecraft:cracked_stone_bricks
setblock ~70 ~17 ~-99 minecraft:cracked_stone_bricks
setblock ~70 ~17 ~-41 minecraft:cracked_stone_bricks
setblock ~70 ~19 ~-151 minecraft:cracked_stone_bricks
setblock ~70 ~20 ~-92 minecraft:cracked_stone_bricks
setblock ~70 ~23 ~-100 minecraft:cracked_stone_bricks
setblock ~70 ~23 ~-40 minecraft:cracked_stone_bricks
setblock ~70 ~30 ~-37 minecraft:cracked_stone_bricks
setblock ~71 ~3 ~-41 minecraft:cracked_stone_bricks
setblock ~71 ~8 ~-94 minecraft:cracked_stone_bricks
fill ~71 ~10 ~-96 ~71 ~10 ~-95 minecraft:cracked_stone_bricks
setblock ~71 ~11 ~-169 minecraft:cracked_stone_bricks
setblock ~71 ~12 ~-151 minecraft:cracked_stone_bricks
setblock ~71 ~16 ~-41 minecraft:cracked_stone_bricks
setblock ~71 ~17 ~-153 minecraft:cracked_stone_bricks
setblock ~71 ~17 ~-97 minecraft:cracked_stone_bricks
fill ~71 ~19 ~-39 ~71 ~20 ~-39 minecraft:cracked_stone_bricks
setblock ~71 ~21 ~-97 minecraft:cracked_stone_bricks
setblock ~71 ~24 ~-41 minecraft:cracked_stone_bricks
setblock ~71 ~25 ~-169 minecraft:cracked_stone_bricks
setblock ~71 ~26 ~-151 minecraft:cracked_stone_bricks
setblock ~71 ~26 ~-98 minecraft:cracked_stone_bricks
setblock ~71 ~28 ~-25 minecraft:cracked_stone_bricks
setblock ~71 ~30 ~-42 minecraft:cracked_stone_bricks
setblock ~71 ~30 ~-33 minecraft:cracked_stone_bricks
setblock ~72 ~5 ~-40 minecraft:cracked_stone_bricks
setblock ~72 ~8 ~-26 minecraft:cracked_stone_bricks
setblock ~72 ~11 ~-38 minecraft:cracked_stone_bricks
setblock ~72 ~12 ~-152 minecraft:cracked_stone_bricks
setblock ~72 ~15 ~-166 minecraft:cracked_stone_bricks
setblock ~72 ~16 ~-168 minecraft:cracked_stone_bricks
setblock ~72 ~17 ~-166 minecraft:cracked_stone_bricks
setblock ~72 ~19 ~-166 minecraft:cracked_stone_bricks
setblock ~72 ~21 ~-38 minecraft:cracked_stone_bricks
setblock ~72 ~23 ~-26 minecraft:cracked_stone_bricks
setblock ~72 ~27 ~-24 minecraft:cracked_stone_bricks
setblock ~72 ~28 ~-168 minecraft:cracked_stone_bricks
setblock ~72 ~30 ~-164 minecraft:cracked_stone_bricks
setblock ~72 ~30 ~-28 minecraft:cracked_stone_bricks
setblock ~72 ~30 ~-23 minecraft:cracked_stone_bricks
setblock ~73 ~ ~-164 minecraft:cracked_stone_bricks
setblock ~73 ~2 ~-156 minecraft:cracked_stone_bricks
setblock ~73 ~2 ~-27 minecraft:cracked_stone_bricks
setblock ~73 ~3 ~-37 minecraft:cracked_stone_bricks
fill ~73 ~4 ~-165 ~74 ~4 ~-165 minecraft:cracked_stone_bricks
setblock ~73 ~4 ~-36 minecraft:cracked_stone_bricks
setblock ~73 ~6 ~-38 minecraft:cracked_stone_bricks
setblock ~73 ~8 ~-167 minecraft:cracked_stone_bricks
setblock ~73 ~8 ~-155 minecraft:cracked_stone_bricks
setblock ~73 ~8 ~-27 minecraft:cracked_stone_bricks
setblock ~73 ~9 ~-25 minecraft:cracked_stone_bricks
setblock ~73 ~11 ~-153 minecraft:cracked_stone_bricks
setblock ~73 ~12 ~-26 minecraft:cracked_stone_bricks
setblock ~73 ~13 ~-167 minecraft:cracked_stone_bricks
setblock ~73 ~13 ~-165 minecraft:cracked_stone_bricks
setblock ~73 ~16 ~-27 minecraft:cracked_stone_bricks
fill ~73 ~19 ~-165 ~73 ~19 ~-164 minecraft:cracked_stone_bricks
setblock ~73 ~19 ~-39 minecraft:cracked_stone_bricks
setblock ~73 ~21 ~-164 minecraft:cracked_stone_bricks
setblock ~73 ~21 ~-39 minecraft:cracked_stone_bricks
setblock ~73 ~21 ~-28 minecraft:cracked_stone_bricks
setblock ~73 ~24 ~-166 minecraft:cracked_stone_bricks
fill ~73 ~25 ~-25 ~73 ~26 ~-25 minecraft:cracked_stone_bricks
setblock ~73 ~31 ~-152 minecraft:cracked_stone_bricks
setblock ~73 ~31 ~-40 minecraft:cracked_stone_bricks
setblock ~74 ~ ~-162 minecraft:cracked_stone_bricks
setblock ~74 ~ ~-33 minecraft:cracked_stone_bricks
setblock ~74 ~3 ~-158 minecraft:cracked_stone_bricks
setblock ~74 ~4 ~-155 minecraft:cracked_stone_bricks
setblock ~74 ~4 ~-27 minecraft:cracked_stone_bricks
setblock ~74 ~9 ~-165 minecraft:cracked_stone_bricks
setblock ~74 ~9 ~-34 minecraft:cracked_stone_bricks
setblock ~74 ~10 ~-35 minecraft:cracked_stone_bricks
setblock ~74 ~10 ~-28 minecraft:cracked_stone_bricks
fill ~74 ~11 ~-162 ~75 ~11 ~-162 minecraft:cracked_stone_bricks
fill ~74 ~11 ~-158 ~74 ~11 ~-157 minecraft:cracked_stone_bricks
fill ~74 ~11 ~-33 ~74 ~11 ~-32 minecraft:cracked_stone_bricks
setblock ~74 ~14 ~-157 minecraft:cracked_stone_bricks
setblock ~74 ~17 ~-29 minecraft:cracked_stone_bricks
setblock ~74 ~19 ~-159 minecraft:cracked_stone_bricks
setblock ~74 ~19 ~-156 minecraft:cracked_stone_bricks
setblock ~74 ~20 ~-27 minecraft:cracked_stone_bricks
setblock ~74 ~21 ~-156 minecraft:cracked_stone_bricks
setblock ~74 ~21 ~-35 minecraft:cracked_stone_bricks
setblock ~74 ~22 ~-158 minecraft:cracked_stone_bricks
setblock ~74 ~25 ~-156 minecraft:cracked_stone_bricks
setblock ~74 ~25 ~-37 minecraft:cracked_stone_bricks
setblock ~74 ~26 ~-165 minecraft:cracked_stone_bricks
setblock ~74 ~27 ~-30 minecraft:cracked_stone_bricks
setblock ~74 ~28 ~-165 minecraft:cracked_stone_bricks
fill ~74 ~28 ~-157 ~74 ~28 ~-156 minecraft:cracked_stone_bricks
setblock ~74 ~30 ~-167 minecraft:cracked_stone_bricks
fill ~75 ~4 ~-161 ~75 ~4 ~-160 minecraft:cracked_stone_bricks
setblock ~75 ~4 ~-35 minecraft:cracked_stone_bricks
setblock ~75 ~5 ~-31 minecraft:cracked_stone_bricks
setblock ~75 ~6 ~-159 minecraft:cracked_stone_bricks
setblock ~75 ~6 ~-157 minecraft:cracked_stone_bricks
setblock ~75 ~8 ~-35 minecraft:cracked_stone_bricks
fill ~75 ~10 ~-162 ~75 ~11 ~-162 minecraft:cracked_stone_bricks
setblock ~75 ~10 ~-30 minecraft:cracked_stone_bricks
fill ~75 ~11 ~-163 ~75 ~11 ~-162 minecraft:cracked_stone_bricks
setblock ~75 ~11 ~-157 minecraft:cracked_stone_bricks
setblock ~75 ~11 ~-31 minecraft:cracked_stone_bricks
setblock ~75 ~13 ~-159 minecraft:cracked_stone_bricks
setblock ~75 ~13 ~-34 minecraft:cracked_stone_bricks
fill ~75 ~17 ~-33 ~75 ~18 ~-33 minecraft:cracked_stone_bricks
setblock ~75 ~19 ~-162 minecraft:cracked_stone_bricks
setblock ~75 ~20 ~-158 minecraft:cracked_stone_bricks
setblock ~75 ~21 ~-34 minecraft:cracked_stone_bricks
setblock ~75 ~24 ~-158 minecraft:cracked_stone_bricks
setblock ~75 ~28 ~-34 minecraft:cracked_stone_bricks
setblock ~75 ~30 ~-161 minecraft:cracked_stone_bricks
setblock ~75 ~30 ~-37 minecraft:cracked_stone_bricks
fill ~75 ~30 ~-30 ~75 ~30 ~-29 minecraft:cracked_stone_bricks
setblock ~75 ~31 ~-28 minecraft:cracked_stone_bricks
setblock ~75 ~32 ~-27 minecraft:cracked_stone_bricks
setblock ~76 ~32 ~-160 minecraft:cracked_stone_bricks
fill ~-31 ~-27 ~-149 ~31 ~-27 ~-142 minecraft:polished_deepslate
fill ~-31 ~-27 ~-141 ~-22 ~-27 ~-131 minecraft:polished_deepslate
fill ~-31 ~-27 ~-125 ~31 ~-27 ~-123 minecraft:polished_deepslate
fill ~-31 ~-27 ~-122 ~-26 ~-27 ~-101 minecraft:polished_deepslate
fill ~-29 ~-27 ~-130 ~29 ~-27 ~-123 minecraft:polished_deepslate
fill ~-25 ~-27 ~-118 ~31 ~-27 ~-101 minecraft:polished_deepslate
fill ~-21 ~-27 ~-138 ~31 ~-27 ~-131 minecraft:polished_deepslate
fill ~-18 ~-27 ~-141 ~-18 ~-27 ~-101 minecraft:polished_deepslate
fill ~-14 ~-27 ~-141 ~31 ~-27 ~-131 minecraft:polished_deepslate
fill ~-7 ~ ~-143 ~-7 ~9 ~-143 minecraft:polished_deepslate
fill ~-7 ~ ~-136 ~-7 ~9 ~-136 minecraft:polished_deepslate
fill ~-7 ~ ~-129 ~-7 ~9 ~-129 minecraft:polished_deepslate
fill ~-7 ~ ~-122 ~-7 ~9 ~-122 minecraft:polished_deepslate
fill ~-7 ~ ~-115 ~-7 ~9 ~-115 minecraft:polished_deepslate
fill ~-7 ~ ~-108 ~-7 ~9 ~-108 minecraft:polished_deepslate
fill ~-5 ~ ~-144 ~5 ~ ~-139 minecraft:polished_deepslate
fill ~-4 ~1 ~-144 ~4 ~1 ~-141 minecraft:polished_deepslate
fill ~-2 ~-27 ~-122 ~31 ~-27 ~-101 minecraft:polished_deepslate
fill ~7 ~ ~-143 ~7 ~9 ~-143 minecraft:polished_deepslate
fill ~7 ~ ~-136 ~7 ~9 ~-136 minecraft:polished_deepslate
fill ~7 ~ ~-129 ~7 ~9 ~-129 minecraft:polished_deepslate
fill ~7 ~ ~-122 ~7 ~9 ~-122 minecraft:polished_deepslate
fill ~7 ~ ~-115 ~7 ~9 ~-115 minecraft:polished_deepslate
fill ~7 ~ ~-108 ~7 ~9 ~-108 minecraft:polished_deepslate
fill ~11 ~-26 ~-136 ~26 ~-24 ~-133 minecraft:polished_deepslate
fill ~-89 ~-6 ~-183 ~-88 ~-1 ~-183 minecraft:gravel
fill ~-89 ~-6 ~-180 ~-89 ~-1 ~-180 minecraft:gravel
fill ~-89 ~-6 ~-178 ~-89 ~-1 ~-178 minecraft:gravel
fill ~-89 ~-6 ~-174 ~-89 ~-1 ~-174 minecraft:gravel
fill ~-89 ~-6 ~-170 ~-89 ~-1 ~-169 minecraft:gravel
fill ~-89 ~-6 ~-165 ~-89 ~-1 ~-161 minecraft:gravel
fill ~-89 ~-6 ~-159 ~-89 ~-1 ~-159 minecraft:gravel
fill ~-89 ~-6 ~-156 ~-89 ~-1 ~-154 minecraft:gravel
fill ~-89 ~-6 ~-152 ~-88 ~-1 ~-152 minecraft:gravel
fill ~-89 ~-6 ~-150 ~-89 ~-1 ~-149 minecraft:gravel
fill ~-89 ~-6 ~-147 ~-89 ~-1 ~-147 minecraft:gravel
fill ~-89 ~-6 ~-145 ~-89 ~-1 ~-145 minecraft:gravel
fill ~-89 ~-6 ~-140 ~-89 ~-1 ~-140 minecraft:gravel
fill ~-89 ~-6 ~-137 ~-89 ~-1 ~-136 minecraft:gravel
fill ~-89 ~-6 ~-132 ~-79 ~-1 ~-132 minecraft:gravel
fill ~-89 ~-6 ~-130 ~-79 ~-1 ~-128 minecraft:gravel
fill ~-89 ~-6 ~-114 ~-80 ~-1 ~-111 minecraft:gravel
fill ~-89 ~-6 ~-108 ~-79 ~-1 ~-108 minecraft:gravel
fill ~-89 ~-6 ~-102 ~-80 ~-1 ~-102 minecraft:gravel
fill ~-89 ~-6 ~-98 ~-89 ~-1 ~-96 minecraft:gravel
fill ~-89 ~-6 ~-90 ~-88 ~-1 ~-90 minecraft:gravel
fill ~-89 ~-6 ~-87 ~-88 ~-1 ~-87 minecraft:gravel
fill ~-89 ~-6 ~-86 ~-89 ~-1 ~-86 minecraft:gravel
fill ~-89 ~-6 ~-78 ~-88 ~-1 ~-78 minecraft:gravel
fill ~-89 ~-6 ~-66 ~-88 ~-1 ~-66 minecraft:gravel
fill ~-89 ~-6 ~-58 ~-88 ~-1 ~-58 minecraft:gravel
fill ~-89 ~-6 ~-57 ~-89 ~-1 ~-56 minecraft:gravel
fill ~-89 ~-6 ~-54 ~-89 ~-1 ~-53 minecraft:gravel
fill ~-89 ~-6 ~-47 ~-88 ~-1 ~-46 minecraft:gravel
fill ~-89 ~-6 ~-36 ~-88 ~-1 ~-36 minecraft:gravel
fill ~-89 ~-6 ~-33 ~-89 ~-1 ~-32 minecraft:gravel
fill ~-89 ~-6 ~-30 ~-89 ~-1 ~-30 minecraft:gravel
fill ~-89 ~-6 ~-26 ~-88 ~-1 ~-26 minecraft:gravel
fill ~-89 ~-6 ~-25 ~-89 ~-1 ~-24 minecraft:gravel
fill ~-89 ~-6 ~-21 ~-89 ~-1 ~-21 minecraft:gravel
fill ~-89 ~-6 ~-18 ~-89 ~-1 ~-17 minecraft:gravel
fill ~-89 ~-6 ~-14 ~-89 ~-1 ~-12 minecraft:gravel
fill ~-89 ~-6 ~-9 ~-88 ~-1 ~-9 minecraft:gravel
fill ~-89 ~-6 ~-7 ~-89 ~-1 ~-7 minecraft:gravel
fill ~-88 ~-6 ~-185 ~-88 ~-1 ~-185 minecraft:gravel
fill ~-88 ~-6 ~-182 ~-87 ~-1 ~-182 minecraft:gravel
fill ~-88 ~-6 ~-181 ~-88 ~-1 ~-181 minecraft:gravel
fill ~-88 ~-6 ~-179 ~-88 ~-1 ~-179 minecraft:gravel
fill ~-88 ~-6 ~-171 ~-88 ~-1 ~-171 minecraft:gravel
fill ~-88 ~-6 ~-167 ~-88 ~-1 ~-166 minecraft:gravel
fill ~-88 ~-6 ~-163 ~-88 ~-1 ~-161 minecraft:gravel
fill ~-88 ~-6 ~-157 ~-88 ~-1 ~-157 minecraft:gravel
fill ~-88 ~-6 ~-151 ~-88 ~-1 ~-151 minecraft:gravel
fill ~-88 ~-6 ~-142 ~-88 ~-1 ~-142 minecraft:gravel
fill ~-88 ~-6 ~-139 ~-87 ~-1 ~-139 minecraft:gravel
fill ~-88 ~-6 ~-133 ~-88 ~-1 ~-100 minecraft:gravel
fill ~-88 ~-6 ~-97 ~-88 ~-1 ~-97 minecraft:gravel
fill ~-88 ~-6 ~-94 ~-87 ~-1 ~-94 minecraft:gravel
fill ~-88 ~-6 ~-93 ~-88 ~-1 ~-93 minecraft:gravel
fill ~-88 ~-6 ~-89 ~-88 ~-1 ~-87 minecraft:gravel
fill ~-88 ~-6 ~-82 ~-88 ~-1 ~-82 minecraft:gravel
fill ~-88 ~-6 ~-80 ~-86 ~-1 ~-80 minecraft:gravel
fill ~-88 ~-6 ~-73 ~-88 ~-1 ~-73 minecraft:gravel
fill ~-88 ~-6 ~-70 ~-87 ~-1 ~-70 minecraft:gravel
fill ~-88 ~-6 ~-68 ~-85 ~-1 ~-68 minecraft:gravel
fill ~-88 ~-6 ~-65 ~-88 ~-1 ~-63 minecraft:gravel
fill ~-88 ~-6 ~-59 ~-88 ~-1 ~-58 minecraft:gravel
fill ~-88 ~-6 ~-51 ~-88 ~-1 ~-51 minecraft:gravel
fill ~-88 ~-6 ~-48 ~-88 ~-1 ~-46 minecraft:gravel
fill ~-88 ~-6 ~-44 ~-88 ~-1 ~-42 minecraft:gravel
fill ~-88 ~-6 ~-38 ~-86 ~-1 ~-38 minecraft:gravel
fill ~-88 ~-6 ~-35 ~-86 ~-1 ~-35 minecraft:gravel
fill ~-88 ~-6 ~-29 ~-88 ~-1 ~-29 minecraft:gravel
fill ~-88 ~-6 ~-27 ~-88 ~-1 ~-26 minecraft:gravel
fill ~-88 ~-6 ~-22 ~-87 ~-1 ~-22 minecraft:gravel
fill ~-88 ~-6 ~-19 ~-88 ~-1 ~-19 minecraft:gravel
fill ~-88 ~-6 ~-16 ~-88 ~-1 ~-15 minecraft:gravel
fill ~-88 ~-6 ~-12 ~-88 ~-1 ~-12 minecraft:gravel
fill ~-87 ~-6 ~-175 ~-86 ~-1 ~-175 minecraft:gravel
fill ~-87 ~-6 ~-170 ~-86 ~-1 ~-170 minecraft:gravel
fill ~-87 ~-6 ~-166 ~-86 ~-1 ~-166 minecraft:gravel
fill ~-87 ~-6 ~-158 ~-86 ~-1 ~-158 minecraft:gravel
fill ~-87 ~-6 ~-155 ~-87 ~-1 ~-155 minecraft:gravel
fill ~-87 ~-6 ~-149 ~-87 ~-1 ~-149 minecraft:gravel
fill ~-87 ~-6 ~-147 ~-87 ~-1 ~-147 minecraft:gravel
fill ~-87 ~-6 ~-143 ~-85 ~-1 ~-143 minecraft:gravel
fill ~-87 ~-6 ~-95 ~-87 ~-1 ~-94 minecraft:gravel
fill ~-87 ~-6 ~-92 ~-87 ~-1 ~-92 minecraft:gravel
fill ~-87 ~-6 ~-88 ~-87 ~-1 ~-88 minecraft:gravel
fill ~-87 ~-6 ~-85 ~-87 ~-1 ~-85 minecraft:gravel
fill ~-87 ~-6 ~-79 ~-87 ~-1 ~-79 minecraft:gravel
fill ~-87 ~-6 ~-62 ~-87 ~-1 ~-62 minecraft:gravel
fill ~-87 ~-6 ~-54 ~-86 ~-1 ~-54 minecraft:gravel
fill ~-87 ~-6 ~-53 ~-87 ~-1 ~-53 minecraft:gravel
fill ~-87 ~-6 ~-46 ~-86 ~-1 ~-46 minecraft:gravel
fill ~-87 ~-6 ~-43 ~-87 ~-1 ~-43 minecraft:gravel
fill ~-87 ~-6 ~-39 ~-87 ~-1 ~-37 minecraft:gravel
fill ~-87 ~-6 ~-34 ~-87 ~-1 ~-31 minecraft:gravel
fill ~-87 ~-6 ~-24 ~-83 ~-1 ~-24 minecraft:gravel
fill ~-87 ~-6 ~-15 ~-85 ~-1 ~-15 minecraft:gravel
