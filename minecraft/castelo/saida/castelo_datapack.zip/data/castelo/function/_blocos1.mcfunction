fill ~-100 ~ ~-196 ~-69 ~31 ~-165 minecraft:air
fill ~-100 ~32 ~-196 ~-69 ~63 ~-165 minecraft:air
fill ~-100 ~64 ~-196 ~-69 ~92 ~-165 minecraft:air
fill ~-100 ~ ~-164 ~-69 ~31 ~-133 minecraft:air
fill ~-100 ~32 ~-164 ~-69 ~63 ~-133 minecraft:air
fill ~-100 ~64 ~-164 ~-69 ~92 ~-133 minecraft:air
fill ~-100 ~ ~-132 ~-69 ~31 ~-101 minecraft:air
fill ~-100 ~32 ~-132 ~-69 ~63 ~-101 minecraft:air
fill ~-100 ~64 ~-132 ~-69 ~92 ~-101 minecraft:air
fill ~-100 ~ ~-100 ~-69 ~31 ~-69 minecraft:air
fill ~-100 ~32 ~-100 ~-69 ~63 ~-69 minecraft:air
fill ~-100 ~64 ~-100 ~-69 ~92 ~-69 minecraft:air
fill ~-100 ~ ~-68 ~-69 ~31 ~-37 minecraft:air
fill ~-100 ~32 ~-68 ~-69 ~63 ~-37 minecraft:air
fill ~-100 ~64 ~-68 ~-69 ~92 ~-37 minecraft:air
fill ~-100 ~ ~-36 ~-69 ~31 ~-5 minecraft:air
fill ~-100 ~32 ~-36 ~-69 ~63 ~-5 minecraft:air
fill ~-100 ~64 ~-36 ~-69 ~92 ~-5 minecraft:air
fill ~-100 ~ ~-4 ~-69 ~31 ~4 minecraft:air
fill ~-100 ~32 ~-4 ~-69 ~63 ~4 minecraft:air
fill ~-100 ~64 ~-4 ~-69 ~92 ~4 minecraft:air
fill ~-68 ~ ~-196 ~-37 ~31 ~-165 minecraft:air
fill ~-68 ~32 ~-196 ~-37 ~63 ~-165 minecraft:air
fill ~-68 ~64 ~-196 ~-37 ~92 ~-165 minecraft:air
fill ~-68 ~ ~-164 ~-37 ~31 ~-133 minecraft:air
fill ~-68 ~32 ~-164 ~-37 ~63 ~-133 minecraft:air
fill ~-68 ~64 ~-164 ~-37 ~92 ~-133 minecraft:air
fill ~-68 ~ ~-132 ~-37 ~31 ~-101 minecraft:air
fill ~-68 ~32 ~-132 ~-37 ~63 ~-101 minecraft:air
fill ~-68 ~64 ~-132 ~-37 ~92 ~-101 minecraft:air
fill ~-68 ~ ~-100 ~-37 ~31 ~-69 minecraft:air
fill ~-68 ~32 ~-100 ~-37 ~63 ~-69 minecraft:air
fill ~-68 ~64 ~-100 ~-37 ~92 ~-69 minecraft:air
fill ~-68 ~ ~-68 ~-37 ~31 ~-37 minecraft:air
fill ~-68 ~32 ~-68 ~-37 ~63 ~-37 minecraft:air
fill ~-68 ~64 ~-68 ~-37 ~92 ~-37 minecraft:air
fill ~-68 ~ ~-36 ~-37 ~31 ~-5 minecraft:air
fill ~-68 ~32 ~-36 ~-37 ~63 ~-5 minecraft:air
fill ~-68 ~64 ~-36 ~-37 ~92 ~-5 minecraft:air
fill ~-68 ~ ~-4 ~-37 ~31 ~4 minecraft:air
fill ~-68 ~32 ~-4 ~-37 ~63 ~4 minecraft:air
fill ~-68 ~64 ~-4 ~-37 ~92 ~4 minecraft:air
fill ~-36 ~ ~-196 ~-5 ~31 ~-165 minecraft:air
fill ~-36 ~32 ~-196 ~-5 ~63 ~-165 minecraft:air
fill ~-36 ~64 ~-196 ~-5 ~92 ~-165 minecraft:air
fill ~-36 ~ ~-164 ~-5 ~31 ~-133 minecraft:air
fill ~-36 ~32 ~-164 ~-5 ~63 ~-133 minecraft:air
fill ~-36 ~64 ~-164 ~-5 ~92 ~-133 minecraft:air
fill ~-36 ~ ~-132 ~-5 ~31 ~-101 minecraft:air
fill ~-36 ~32 ~-132 ~-5 ~63 ~-101 minecraft:air
fill ~-36 ~64 ~-132 ~-5 ~92 ~-101 minecraft:air
fill ~-36 ~ ~-100 ~-5 ~31 ~-69 minecraft:air
fill ~-36 ~32 ~-100 ~-5 ~63 ~-69 minecraft:air
fill ~-36 ~64 ~-100 ~-5 ~92 ~-69 minecraft:air
fill ~-36 ~ ~-68 ~-5 ~31 ~-37 minecraft:air
fill ~-36 ~32 ~-68 ~-5 ~63 ~-37 minecraft:air
fill ~-36 ~64 ~-68 ~-5 ~92 ~-37 minecraft:air
fill ~-36 ~ ~-36 ~-5 ~31 ~-5 minecraft:air
fill ~-36 ~32 ~-36 ~-5 ~63 ~-5 minecraft:air
fill ~-36 ~64 ~-36 ~-5 ~92 ~-5 minecraft:air
fill ~-36 ~ ~-4 ~-5 ~31 ~4 minecraft:air
fill ~-36 ~32 ~-4 ~-5 ~63 ~4 minecraft:air
fill ~-36 ~64 ~-4 ~-5 ~92 ~4 minecraft:air
fill ~-4 ~ ~-196 ~27 ~31 ~-165 minecraft:air
fill ~-4 ~32 ~-196 ~27 ~63 ~-165 minecraft:air
fill ~-4 ~64 ~-196 ~27 ~92 ~-165 minecraft:air
fill ~-4 ~ ~-164 ~27 ~31 ~-133 minecraft:air
fill ~-4 ~32 ~-164 ~27 ~63 ~-133 minecraft:air
fill ~-4 ~64 ~-164 ~27 ~92 ~-133 minecraft:air
fill ~-4 ~ ~-132 ~27 ~31 ~-101 minecraft:air
fill ~-4 ~32 ~-132 ~27 ~63 ~-101 minecraft:air
fill ~-4 ~64 ~-132 ~27 ~92 ~-101 minecraft:air
fill ~-4 ~ ~-100 ~27 ~31 ~-69 minecraft:air
fill ~-4 ~32 ~-100 ~27 ~63 ~-69 minecraft:air
fill ~-4 ~64 ~-100 ~27 ~92 ~-69 minecraft:air
fill ~-4 ~ ~-68 ~27 ~31 ~-37 minecraft:air
fill ~-4 ~32 ~-68 ~27 ~63 ~-37 minecraft:air
fill ~-4 ~64 ~-68 ~27 ~92 ~-37 minecraft:air
fill ~-4 ~ ~-36 ~27 ~31 ~-5 minecraft:air
fill ~-4 ~32 ~-36 ~27 ~63 ~-5 minecraft:air
fill ~-4 ~64 ~-36 ~27 ~92 ~-5 minecraft:air
fill ~-4 ~ ~-4 ~27 ~31 ~4 minecraft:air
fill ~-4 ~32 ~-4 ~27 ~63 ~4 minecraft:air
fill ~-4 ~64 ~-4 ~27 ~92 ~4 minecraft:air
fill ~28 ~ ~-196 ~59 ~31 ~-165 minecraft:air
fill ~28 ~32 ~-196 ~59 ~63 ~-165 minecraft:air
fill ~28 ~64 ~-196 ~59 ~92 ~-165 minecraft:air
fill ~28 ~ ~-164 ~59 ~31 ~-133 minecraft:air
fill ~28 ~32 ~-164 ~59 ~63 ~-133 minecraft:air
fill ~28 ~64 ~-164 ~59 ~92 ~-133 minecraft:air
fill ~28 ~ ~-132 ~59 ~31 ~-101 minecraft:air
fill ~28 ~32 ~-132 ~59 ~63 ~-101 minecraft:air
fill ~28 ~64 ~-132 ~59 ~92 ~-101 minecraft:air
fill ~28 ~ ~-100 ~59 ~31 ~-69 minecraft:air
fill ~28 ~32 ~-100 ~59 ~63 ~-69 minecraft:air
fill ~28 ~64 ~-100 ~59 ~92 ~-69 minecraft:air
fill ~28 ~ ~-68 ~59 ~31 ~-37 minecraft:air
fill ~28 ~32 ~-68 ~59 ~63 ~-37 minecraft:air
fill ~28 ~64 ~-68 ~59 ~92 ~-37 minecraft:air
fill ~28 ~ ~-36 ~59 ~31 ~-5 minecraft:air
fill ~28 ~32 ~-36 ~59 ~63 ~-5 minecraft:air
fill ~28 ~64 ~-36 ~59 ~92 ~-5 minecraft:air
fill ~28 ~ ~-4 ~59 ~31 ~4 minecraft:air
fill ~28 ~32 ~-4 ~59 ~63 ~4 minecraft:air
fill ~28 ~64 ~-4 ~59 ~92 ~4 minecraft:air
fill ~60 ~ ~-196 ~91 ~31 ~-165 minecraft:air
fill ~60 ~32 ~-196 ~91 ~63 ~-165 minecraft:air
fill ~60 ~64 ~-196 ~91 ~92 ~-165 minecraft:air
fill ~60 ~ ~-164 ~91 ~31 ~-133 minecraft:air
fill ~60 ~32 ~-164 ~91 ~63 ~-133 minecraft:air
fill ~60 ~64 ~-164 ~91 ~92 ~-133 minecraft:air
fill ~60 ~ ~-132 ~91 ~31 ~-101 minecraft:air
fill ~60 ~32 ~-132 ~91 ~63 ~-101 minecraft:air
fill ~60 ~64 ~-132 ~91 ~92 ~-101 minecraft:air
fill ~60 ~ ~-100 ~91 ~31 ~-69 minecraft:air
fill ~60 ~32 ~-100 ~91 ~63 ~-69 minecraft:air
fill ~60 ~64 ~-100 ~91 ~92 ~-69 minecraft:air
fill ~60 ~ ~-68 ~91 ~31 ~-37 minecraft:air
fill ~60 ~32 ~-68 ~91 ~63 ~-37 minecraft:air
fill ~60 ~64 ~-68 ~91 ~92 ~-37 minecraft:air
fill ~60 ~ ~-36 ~91 ~31 ~-5 minecraft:air
fill ~60 ~32 ~-36 ~91 ~63 ~-5 minecraft:air
fill ~60 ~64 ~-36 ~91 ~92 ~-5 minecraft:air
fill ~60 ~ ~-4 ~91 ~31 ~4 minecraft:air
fill ~60 ~32 ~-4 ~91 ~63 ~4 minecraft:air
fill ~60 ~64 ~-4 ~91 ~92 ~4 minecraft:air
fill ~92 ~ ~-196 ~100 ~31 ~-165 minecraft:air
fill ~92 ~32 ~-196 ~100 ~63 ~-165 minecraft:air
fill ~92 ~64 ~-196 ~100 ~92 ~-165 minecraft:air
fill ~92 ~ ~-164 ~100 ~31 ~-133 minecraft:air
fill ~92 ~32 ~-164 ~100 ~63 ~-133 minecraft:air
fill ~92 ~64 ~-164 ~100 ~92 ~-133 minecraft:air
fill ~92 ~ ~-132 ~100 ~31 ~-101 minecraft:air
fill ~92 ~32 ~-132 ~100 ~63 ~-101 minecraft:air
fill ~92 ~64 ~-132 ~100 ~92 ~-101 minecraft:air
fill ~92 ~ ~-100 ~100 ~31 ~-69 minecraft:air
fill ~92 ~32 ~-100 ~100 ~63 ~-69 minecraft:air
fill ~92 ~64 ~-100 ~100 ~92 ~-69 minecraft:air
fill ~92 ~ ~-68 ~100 ~31 ~-37 minecraft:air
fill ~92 ~32 ~-68 ~100 ~63 ~-37 minecraft:air
fill ~92 ~64 ~-68 ~100 ~92 ~-37 minecraft:air
fill ~92 ~ ~-36 ~100 ~31 ~-5 minecraft:air
fill ~92 ~32 ~-36 ~100 ~63 ~-5 minecraft:air
fill ~92 ~64 ~-36 ~100 ~92 ~-5 minecraft:air
fill ~92 ~ ~-4 ~100 ~31 ~4 minecraft:air
fill ~92 ~32 ~-4 ~100 ~63 ~4 minecraft:air
fill ~92 ~64 ~-4 ~100 ~92 ~4 minecraft:air
fill ~-90 ~-7 ~-186 ~90 ~-1 ~-174 minecraft:stone_bricks
fill ~-90 ~-7 ~-173 ~-78 ~-1 ~-6 minecraft:stone_bricks
fill ~-77 ~-7 ~-18 ~90 ~-1 ~-6 minecraft:stone_bricks
fill ~-76 ~30 ~-163 ~-52 ~30 ~-157 minecraft:stone_bricks
fill ~-76 ~30 ~-35 ~-52 ~30 ~-29 minecraft:stone_bricks
fill ~-76 ~31 ~-163 ~-76 ~31 ~-157 minecraft:stone_bricks
fill ~-76 ~31 ~-35 ~-76 ~31 ~-29 minecraft:stone_bricks
setblock ~-76 ~32 ~-162 minecraft:stone_bricks
setblock ~-76 ~32 ~-160 minecraft:stone_bricks
setblock ~-76 ~32 ~-158 minecraft:stone_bricks
setblock ~-76 ~32 ~-34 minecraft:stone_bricks
setblock ~-76 ~32 ~-32 minecraft:stone_bricks
setblock ~-76 ~32 ~-30 minecraft:stone_bricks
fill ~-75 ~ ~-163 ~-74 ~2 ~-155 minecraft:stone_bricks
fill ~-75 ~ ~-35 ~-74 ~2 ~-27 minecraft:stone_bricks
fill ~-75 ~3 ~-163 ~-74 ~30 ~-157 minecraft:stone_bricks
fill ~-75 ~3 ~-33 ~-74 ~30 ~-29 minecraft:stone_bricks
fill ~-75 ~4 ~-35 ~-74 ~30 ~-29 minecraft:stone_bricks
fill ~-75 ~30 ~-165 ~-53 ~30 ~-155 minecraft:stone_bricks
fill ~-75 ~30 ~-37 ~-53 ~30 ~-27 minecraft:stone_bricks
fill ~-75 ~31 ~-164 ~-73 ~31 ~-164 minecraft:stone_bricks
fill ~-75 ~31 ~-156 ~-73 ~31 ~-156 minecraft:stone_bricks
fill ~-75 ~31 ~-155 ~-75 ~32 ~-155 minecraft:stone_bricks
fill ~-75 ~31 ~-37 ~-75 ~31 ~-36 minecraft:stone_bricks
fill ~-75 ~31 ~-28 ~-73 ~31 ~-28 minecraft:stone_bricks
fill ~-75 ~31 ~-27 ~-75 ~32 ~-27 minecraft:stone_bricks
setblock ~-75 ~32 ~-165 minecraft:stone_bricks
setblock ~-75 ~32 ~-37 minecraft:stone_bricks
fill ~-74 ~ ~-165 ~-73 ~30 ~-164 minecraft:stone_bricks
fill ~-74 ~ ~-37 ~-73 ~30 ~-36 minecraft:stone_bricks
fill ~-74 ~3 ~-156 ~-73 ~30 ~-155 minecraft:stone_bricks
fill ~-74 ~3 ~-35 ~-74 ~30 ~-27 minecraft:stone_bricks
fill ~-74 ~30 ~-167 ~-54 ~30 ~-153 minecraft:stone_bricks
fill ~-74 ~30 ~-39 ~-54 ~30 ~-25 minecraft:stone_bricks
fill ~-74 ~31 ~-167 ~-74 ~31 ~-166 minecraft:stone_bricks
setblock ~-74 ~31 ~-153 minecraft:stone_bricks
fill ~-74 ~31 ~-39 ~-74 ~31 ~-38 minecraft:stone_bricks
setblock ~-74 ~31 ~-25 minecraft:stone_bricks
setblock ~-74 ~32 ~-166 minecraft:stone_bricks
setblock ~-74 ~32 ~-154 minecraft:stone_bricks
setblock ~-74 ~32 ~-38 minecraft:stone_bricks
setblock ~-74 ~32 ~-26 minecraft:stone_bricks
fill ~-73 ~ ~-167 ~-71 ~30 ~-167 minecraft:stone_bricks
fill ~-73 ~ ~-166 ~-72 ~31 ~-166 minecraft:stone_bricks
fill ~-73 ~ ~-156 ~-73 ~2 ~-152 minecraft:stone_bricks
fill ~-73 ~ ~-39 ~-71 ~30 ~-39 minecraft:stone_bricks
fill ~-73 ~ ~-38 ~-72 ~31 ~-38 minecraft:stone_bricks
fill ~-73 ~ ~-28 ~-73 ~2 ~-24 minecraft:stone_bricks
fill ~-73 ~3 ~-154 ~-72 ~30 ~-153 minecraft:stone_bricks
fill ~-73 ~3 ~-28 ~-73 ~30 ~-25 minecraft:stone_bricks
fill ~-73 ~30 ~-168 ~-55 ~30 ~-152 minecraft:stone_bricks
fill ~-73 ~30 ~-40 ~-55 ~30 ~-24 minecraft:stone_bricks
setblock ~-73 ~31 ~-168 minecraft:stone_bricks
setblock ~-73 ~31 ~-152 minecraft:stone_bricks
setblock ~-73 ~31 ~-40 minecraft:stone_bricks
setblock ~-73 ~31 ~-24 minecraft:stone_bricks
fill ~-72 ~ ~-168 ~-70 ~30 ~-168 minecraft:stone_bricks
fill ~-72 ~ ~-154 ~-72 ~2 ~-151 minecraft:stone_bricks
fill ~-72 ~ ~-40 ~-70 ~30 ~-40 minecraft:stone_bricks
fill ~-72 ~ ~-26 ~-72 ~2 ~-23 minecraft:stone_bricks
fill ~-72 ~3 ~-26 ~-72 ~30 ~-24 minecraft:stone_bricks
fill ~-72 ~4 ~-152 ~-70 ~30 ~-152 minecraft:stone_bricks
fill ~-72 ~26 ~-97 ~-56 ~26 ~-94 minecraft:stone_bricks
fill ~-72 ~27 ~-98 ~-72 ~27 ~-94 minecraft:stone_bricks
setblock ~-72 ~28 ~-98 minecraft:stone_bricks
setblock ~-72 ~28 ~-96 minecraft:stone_bricks
setblock ~-72 ~28 ~-94 minecraft:stone_bricks
fill ~-72 ~30 ~-169 ~-56 ~30 ~-151 minecraft:stone_bricks
fill ~-72 ~30 ~-41 ~-56 ~30 ~-23 minecraft:stone_bricks
setblock ~-72 ~31 ~-169 minecraft:stone_bricks
setblock ~-72 ~31 ~-151 minecraft:stone_bricks
setblock ~-72 ~31 ~-41 minecraft:stone_bricks
setblock ~-72 ~31 ~-23 minecraft:stone_bricks
fill ~-71 ~ ~-169 ~-68 ~30 ~-169 minecraft:stone_bricks
fill ~-71 ~ ~-153 ~-71 ~2 ~-150 minecraft:stone_bricks
fill ~-71 ~ ~-98 ~-70 ~2 ~-92 minecraft:stone_bricks
fill ~-71 ~ ~-41 ~-68 ~30 ~-41 minecraft:stone_bricks
fill ~-71 ~ ~-25 ~-71 ~2 ~-22 minecraft:stone_bricks
fill ~-71 ~3 ~-153 ~-71 ~30 ~-151 minecraft:stone_bricks
fill ~-71 ~3 ~-98 ~-70 ~26 ~-94 minecraft:stone_bricks
fill ~-71 ~3 ~-25 ~-71 ~30 ~-23 minecraft:stone_bricks
fill ~-71 ~26 ~-100 ~-57 ~26 ~-92 minecraft:stone_bricks
fill ~-71 ~27 ~-100 ~-71 ~27 ~-99 minecraft:stone_bricks
fill ~-71 ~27 ~-93 ~-69 ~27 ~-93 minecraft:stone_bricks
setblock ~-71 ~27 ~-92 minecraft:stone_bricks
setblock ~-71 ~28 ~-99 minecraft:stone_bricks
setblock ~-71 ~28 ~-93 minecraft:stone_bricks
fill ~-71 ~30 ~-170 ~-57 ~30 ~-150 minecraft:stone_bricks
fill ~-71 ~30 ~-42 ~-57 ~30 ~-22 minecraft:stone_bricks
fill ~-71 ~31 ~-170 ~-70 ~31 ~-170 minecraft:stone_bricks
fill ~-71 ~31 ~-150 ~-70 ~31 ~-150 minecraft:stone_bricks
fill ~-71 ~31 ~-42 ~-70 ~31 ~-42 minecraft:stone_bricks
fill ~-71 ~31 ~-22 ~-70 ~31 ~-22 minecraft:stone_bricks
fill ~-70 ~ ~-152 ~-70 ~2 ~-150 minecraft:stone_bricks
fill ~-70 ~ ~-100 ~-68 ~26 ~-100 minecraft:stone_bricks
fill ~-70 ~ ~-99 ~-69 ~27 ~-99 minecraft:stone_bricks
fill ~-70 ~ ~-24 ~-70 ~2 ~-22 minecraft:stone_bricks
fill ~-70 ~3 ~-93 ~-69 ~26 ~-92 minecraft:stone_bricks
fill ~-70 ~3 ~-24 ~-70 ~31 ~-23 minecraft:stone_bricks
fill ~-70 ~4 ~-151 ~-68 ~31 ~-151 minecraft:stone_bricks
fill ~-70 ~26 ~-102 ~-58 ~26 ~-90 minecraft:stone_bricks
fill ~-70 ~27 ~-102 ~-69 ~27 ~-102 minecraft:stone_bricks
setblock ~-70 ~27 ~-101 minecraft:stone_bricks
fill ~-70 ~27 ~-90 ~-69 ~27 ~-90 minecraft:stone_bricks
setblock ~-70 ~28 ~-102 minecraft:stone_bricks
setblock ~-70 ~32 ~-170 minecraft:stone_bricks
setblock ~-70 ~32 ~-150 minecraft:stone_bricks
setblock ~-70 ~32 ~-42 minecraft:stone_bricks
setblock ~-70 ~32 ~-22 minecraft:stone_bricks
fill ~-69 ~ ~-170 ~-57 ~2 ~-170 minecraft:stone_bricks
fill ~-69 ~ ~-151 ~-68 ~2 ~-149 minecraft:stone_bricks
fill ~-69 ~ ~-101 ~-67 ~26 ~-101 minecraft:stone_bricks
fill ~-69 ~ ~-93 ~-69 ~2 ~-90 minecraft:stone_bricks
fill ~-69 ~ ~-42 ~-57 ~2 ~-42 minecraft:stone_bricks
fill ~-69 ~ ~-22 ~-57 ~2 ~-22 minecraft:stone_bricks
fill ~-69 ~1 ~-23 ~-68 ~2 ~-21 minecraft:stone_bricks
fill ~-69 ~3 ~-170 ~-59 ~30 ~-170 minecraft:stone_bricks
fill ~-69 ~3 ~-151 ~-68 ~30 ~-150 minecraft:stone_bricks
fill ~-69 ~3 ~-91 ~-67 ~26 ~-91 minecraft:stone_bricks
fill ~-69 ~3 ~-42 ~-59 ~18 ~-42 minecraft:stone_bricks
fill ~-69 ~3 ~-23 ~-68 ~30 ~-22 minecraft:stone_bricks
fill ~-69 ~19 ~-42 ~-65 ~30 ~-42 minecraft:stone_bricks
fill ~-69 ~30 ~-171 ~-59 ~30 ~-149 minecraft:stone_bricks
fill ~-69 ~30 ~-43 ~-59 ~30 ~-21 minecraft:stone_bricks
fill ~-69 ~31 ~-171 ~-68 ~31 ~-171 minecraft:stone_bricks
fill ~-69 ~31 ~-149 ~-68 ~31 ~-149 minecraft:stone_bricks
fill ~-69 ~31 ~-43 ~-68 ~31 ~-43 minecraft:stone_bricks
fill ~-69 ~31 ~-21 ~-68 ~31 ~-21 minecraft:stone_bricks
setblock ~-69 ~32 ~-171 minecraft:stone_bricks
setblock ~-69 ~32 ~-149 minecraft:stone_bricks
setblock ~-69 ~32 ~-43 minecraft:stone_bricks
setblock ~-69 ~32 ~-21 minecraft:stone_bricks
fill ~-68 ~ ~-102 ~-58 ~2 ~-102 minecraft:stone_bricks
fill ~-68 ~ ~-92 ~-68 ~2 ~-89 minecraft:stone_bricks
fill ~-68 ~ ~-23 ~-68 ~2 ~-21 minecraft:stone_bricks
fill ~-68 ~3 ~-102 ~-60 ~18 ~-102 minecraft:stone_bricks
fill ~-68 ~3 ~-92 ~-68 ~26 ~-90 minecraft:stone_bricks
fill ~-68 ~19 ~-102 ~-65 ~26 ~-102 minecraft:stone_bricks
fill ~-68 ~26 ~-103 ~-60 ~26 ~-89 minecraft:stone_bricks
fill ~-68 ~27 ~-103 ~-67 ~27 ~-103 minecraft:stone_bricks
fill ~-68 ~27 ~-89 ~-67 ~27 ~-89 minecraft:stone_bricks
fill ~-67 ~ ~-171 ~-59 ~2 ~-170 minecraft:stone_bricks
fill ~-67 ~ ~-150 ~-57 ~2 ~-150 minecraft:stone_bricks
fill ~-67 ~ ~-149 ~-59 ~2 ~-149 minecraft:stone_bricks
fill ~-67 ~ ~-91 ~-67 ~2 ~-89 minecraft:stone_bricks
fill ~-67 ~ ~-43 ~-59 ~2 ~-42 minecraft:stone_bricks
fill ~-67 ~ ~-21 ~-59 ~2 ~-21 minecraft:stone_bricks
fill ~-67 ~3 ~-171 ~-61 ~30 ~-170 minecraft:stone_bricks
fill ~-67 ~3 ~-150 ~-59 ~18 ~-150 minecraft:stone_bricks
fill ~-67 ~3 ~-149 ~-60 ~18 ~-149 minecraft:stone_bricks
fill ~-67 ~3 ~-90 ~-60 ~18 ~-90 minecraft:stone_bricks
fill ~-67 ~3 ~-43 ~-60 ~18 ~-42 minecraft:stone_bricks
fill ~-67 ~3 ~-22 ~-59 ~30 ~-22 minecraft:stone_bricks
fill ~-67 ~3 ~-21 ~-61 ~30 ~-21 minecraft:stone_bricks
fill ~-67 ~19 ~-150 ~-65 ~30 ~-149 minecraft:stone_bricks
fill ~-67 ~19 ~-43 ~-65 ~30 ~-42 minecraft:stone_bricks
fill ~-67 ~21 ~-90 ~-60 ~26 ~-90 minecraft:stone_bricks
setblock ~-67 ~28 ~-103 minecraft:stone_bricks
setblock ~-67 ~28 ~-89 minecraft:stone_bricks
fill ~-67 ~30 ~-172 ~-61 ~30 ~-148 minecraft:stone_bricks
fill ~-67 ~31 ~-172 ~-61 ~31 ~-172 minecraft:stone_bricks
fill ~-67 ~31 ~-148 ~-61 ~31 ~-148 minecraft:stone_bricks
fill ~-67 ~31 ~-44 ~-61 ~31 ~-44 minecraft:stone_bricks
fill ~-67 ~31 ~-20 ~-61 ~31 ~-20 minecraft:stone_bricks
fill ~-66 ~ ~-103 ~-60 ~18 ~-102 minecraft:stone_bricks
fill ~-66 ~ ~-90 ~-58 ~2 ~-90 minecraft:stone_bricks
fill ~-66 ~ ~-89 ~-60 ~2 ~-88 minecraft:stone_bricks
fill ~-66 ~3 ~-89 ~-60 ~18 ~-89 minecraft:stone_bricks
fill ~-66 ~19 ~-103 ~-65 ~26 ~-102 minecraft:stone_bricks
fill ~-66 ~19 ~-90 ~-65 ~26 ~-89 minecraft:stone_bricks
fill ~-66 ~26 ~-104 ~-62 ~26 ~-88 minecraft:stone_bricks
fill ~-66 ~27 ~-104 ~-62 ~27 ~-104 minecraft:stone_bricks
fill ~-66 ~27 ~-88 ~-62 ~27 ~-88 minecraft:stone_bricks
setblock ~-66 ~28 ~-104 minecraft:stone_bricks
setblock ~-66 ~28 ~-88 minecraft:stone_bricks
fill ~-66 ~30 ~-44 ~-61 ~30 ~-20 minecraft:stone_bricks
setblock ~-66 ~32 ~-172 minecraft:stone_bricks
setblock ~-66 ~32 ~-148 minecraft:stone_bricks
setblock ~-66 ~32 ~-44 minecraft:stone_bricks
setblock ~-66 ~32 ~-20 minecraft:stone_bricks
fill ~-65 ~17 ~-147 ~-60 ~18 ~-102 minecraft:stone_bricks
fill ~-65 ~17 ~-88 ~-60 ~18 ~-42 minecraft:stone_bricks
fill ~-65 ~19 ~-148 ~-65 ~19 ~-102 minecraft:stone_bricks
fill ~-65 ~19 ~-88 ~-65 ~19 ~-42 minecraft:stone_bricks
setblock ~-65 ~20 ~-147 minecraft:stone_bricks
setblock ~-65 ~20 ~-145 minecraft:stone_bricks
fill ~-65 ~20 ~-143 ~-65 ~21 ~-143 minecraft:stone_bricks
setblock ~-65 ~20 ~-141 minecraft:stone_bricks
setblock ~-65 ~20 ~-139 minecraft:stone_bricks
setblock ~-65 ~20 ~-137 minecraft:stone_bricks
fill ~-65 ~20 ~-135 ~-65 ~21 ~-135 minecraft:stone_bricks
setblock ~-65 ~20 ~-133 minecraft:stone_bricks
setblock ~-65 ~20 ~-131 minecraft:stone_bricks
setblock ~-65 ~20 ~-129 minecraft:stone_bricks
fill ~-65 ~20 ~-127 ~-65 ~21 ~-127 minecraft:stone_bricks
setblock ~-65 ~20 ~-123 minecraft:stone_bricks
setblock ~-65 ~20 ~-121 minecraft:stone_bricks
fill ~-65 ~20 ~-119 ~-65 ~21 ~-119 minecraft:stone_bricks
setblock ~-65 ~20 ~-117 minecraft:stone_bricks
setblock ~-65 ~20 ~-115 minecraft:stone_bricks
setblock ~-65 ~20 ~-113 minecraft:stone_bricks
setblock ~-65 ~20 ~-109 minecraft:stone_bricks
setblock ~-65 ~20 ~-107 minecraft:stone_bricks
setblock ~-65 ~20 ~-105 minecraft:stone_bricks
fill ~-65 ~20 ~-87 ~-65 ~21 ~-87 minecraft:stone_bricks
setblock ~-65 ~20 ~-85 minecraft:stone_bricks
setblock ~-65 ~20 ~-83 minecraft:stone_bricks
setblock ~-65 ~20 ~-81 minecraft:stone_bricks
fill ~-65 ~20 ~-79 ~-65 ~21 ~-79 minecraft:stone_bricks
setblock ~-65 ~20 ~-77 minecraft:stone_bricks
setblock ~-65 ~20 ~-75 minecraft:stone_bricks
setblock ~-65 ~20 ~-73 minecraft:stone_bricks
setblock ~-65 ~20 ~-69 minecraft:stone_bricks
setblock ~-65 ~20 ~-67 minecraft:stone_bricks
setblock ~-65 ~20 ~-65 minecraft:stone_bricks
fill ~-65 ~20 ~-63 ~-65 ~21 ~-63 minecraft:stone_bricks
setblock ~-65 ~20 ~-61 minecraft:stone_bricks
setblock ~-65 ~20 ~-59 minecraft:stone_bricks
setblock ~-65 ~20 ~-57 minecraft:stone_bricks
fill ~-65 ~20 ~-55 ~-65 ~21 ~-55 minecraft:stone_bricks
setblock ~-65 ~20 ~-53 minecraft:stone_bricks
setblock ~-65 ~20 ~-51 minecraft:stone_bricks
setblock ~-65 ~20 ~-49 minecraft:stone_bricks
fill ~-65 ~20 ~-47 ~-65 ~21 ~-47 minecraft:stone_bricks
fill ~-64 ~-1 ~-150 ~100 ~-1 ~4 minecraft:stone_bricks
fill ~-64 ~ ~-147 ~-60 ~5 ~-102 minecraft:stone_bricks
fill ~-64 ~ ~-87 ~-60 ~5 ~-42 minecraft:stone_bricks
fill ~-64 ~3 ~-148 ~-60 ~5 ~-102 minecraft:stone_bricks
fill ~-64 ~3 ~-88 ~-60 ~5 ~-42 minecraft:stone_bricks
fill ~-64 ~6 ~-148 ~-60 ~18 ~-141 minecraft:stone_bricks
fill ~-64 ~6 ~-139 ~-60 ~18 ~-133 minecraft:stone_bricks
fill ~-64 ~6 ~-131 ~-60 ~18 ~-125 minecraft:stone_bricks
fill ~-64 ~6 ~-123 ~-60 ~18 ~-117 minecraft:stone_bricks
fill ~-64 ~6 ~-115 ~-60 ~18 ~-109 minecraft:stone_bricks
fill ~-64 ~6 ~-107 ~-60 ~18 ~-102 minecraft:stone_bricks
fill ~-64 ~6 ~-88 ~-60 ~18 ~-85 minecraft:stone_bricks
fill ~-64 ~6 ~-83 ~-60 ~18 ~-77 minecraft:stone_bricks
fill ~-64 ~6 ~-75 ~-60 ~18 ~-69 minecraft:stone_bricks
fill ~-64 ~6 ~-67 ~-60 ~18 ~-61 minecraft:stone_bricks
fill ~-64 ~6 ~-59 ~-60 ~18 ~-53 minecraft:stone_bricks
fill ~-64 ~6 ~-51 ~-60 ~6 ~-22 minecraft:stone_bricks
fill ~-64 ~7 ~-51 ~-60 ~18 ~-42 minecraft:stone_bricks
fill ~-64 ~10 ~-140 ~-60 ~18 ~-102 minecraft:stone_bricks
fill ~-64 ~10 ~-84 ~-60 ~18 ~-42 minecraft:stone_bricks
fill ~-64 ~21 ~-150 ~-59 ~30 ~-150 minecraft:stone_bricks
fill ~-64 ~21 ~-149 ~-61 ~30 ~-149 minecraft:stone_bricks
fill ~-64 ~21 ~-103 ~-62 ~26 ~-102 minecraft:stone_bricks
fill ~-64 ~21 ~-89 ~-62 ~26 ~-89 minecraft:stone_bricks
fill ~-64 ~21 ~-43 ~-61 ~30 ~-42 minecraft:stone_bricks
setblock ~-64 ~28 ~-104 minecraft:stone_bricks
setblock ~-64 ~28 ~-88 minecraft:stone_bricks
setblock ~-64 ~32 ~-172 minecraft:stone_bricks
setblock ~-64 ~32 ~-148 minecraft:stone_bricks
setblock ~-64 ~32 ~-44 minecraft:stone_bricks
setblock ~-64 ~32 ~-20 minecraft:stone_bricks
fill ~-63 ~6 ~-132 ~-60 ~18 ~-102 minecraft:stone_bricks
fill ~-63 ~6 ~-84 ~-60 ~6 ~-22 minecraft:stone_bricks
fill ~-63 ~7 ~-140 ~-60 ~18 ~-102 minecraft:stone_bricks
fill ~-63 ~7 ~-84 ~-60 ~18 ~-42 minecraft:stone_bricks
fill ~-62 ~6 ~-140 ~-60 ~18 ~-102 minecraft:stone_bricks
setblock ~-62 ~28 ~-104 minecraft:stone_bricks
setblock ~-62 ~28 ~-88 minecraft:stone_bricks
setblock ~-62 ~32 ~-172 minecraft:stone_bricks
setblock ~-62 ~32 ~-148 minecraft:stone_bricks
setblock ~-62 ~32 ~-44 minecraft:stone_bricks
setblock ~-62 ~32 ~-20 minecraft:stone_bricks
fill ~-61 ~ ~-101 ~-58 ~2 ~-101 minecraft:stone_bricks
fill ~-61 ~ ~-91 ~-58 ~2 ~-90 minecraft:stone_bricks
fill ~-61 ~3 ~-101 ~-59 ~18 ~-101 minecraft:stone_bricks
fill ~-61 ~3 ~-91 ~-59 ~18 ~-91 minecraft:stone_bricks
fill ~-61 ~21 ~-102 ~-60 ~26 ~-101 minecraft:stone_bricks
fill ~-61 ~21 ~-91 ~-59 ~26 ~-91 minecraft:stone_bricks
fill ~-61 ~27 ~-103 ~-60 ~27 ~-103 minecraft:stone_bricks
fill ~-61 ~27 ~-89 ~-60 ~27 ~-89 minecraft:stone_bricks
setblock ~-61 ~28 ~-103 minecraft:stone_bricks
setblock ~-61 ~28 ~-89 minecraft:stone_bricks
fill ~-60 ~-1 ~-151 ~100 ~-1 ~4 minecraft:stone_bricks
fill ~-60 ~ ~-169 ~-56 ~2 ~-169 minecraft:stone_bricks
fill ~-60 ~ ~-151 ~-57 ~2 ~-150 minecraft:stone_bricks
fill ~-60 ~ ~-148 ~-60 ~18 ~-100 minecraft:stone_bricks
fill ~-60 ~ ~-92 ~-57 ~2 ~-92 minecraft:stone_bricks
fill ~-60 ~ ~-41 ~-57 ~18 ~-41 minecraft:stone_bricks
fill ~-60 ~ ~-23 ~-56 ~2 ~-23 minecraft:stone_bricks
fill ~-60 ~3 ~-169 ~-57 ~30 ~-169 minecraft:stone_bricks
fill ~-60 ~3 ~-151 ~-57 ~18 ~-151 minecraft:stone_bricks
fill ~-60 ~3 ~-92 ~-58 ~18 ~-92 minecraft:stone_bricks
fill ~-60 ~3 ~-23 ~-57 ~30 ~-23 minecraft:stone_bricks
fill ~-60 ~21 ~-151 ~-57 ~30 ~-151 minecraft:stone_bricks
fill ~-60 ~21 ~-100 ~-58 ~26 ~-100 minecraft:stone_bricks
fill ~-60 ~21 ~-92 ~-58 ~26 ~-92 minecraft:stone_bricks
fill ~-60 ~21 ~-41 ~-57 ~30 ~-41 minecraft:stone_bricks
fill ~-60 ~22 ~-42 ~-59 ~30 ~-41 minecraft:stone_bricks
fill ~-60 ~31 ~-171 ~-59 ~31 ~-171 minecraft:stone_bricks
fill ~-60 ~31 ~-149 ~-59 ~31 ~-149 minecraft:stone_bricks
fill ~-60 ~31 ~-43 ~-59 ~31 ~-43 minecraft:stone_bricks
fill ~-60 ~31 ~-21 ~-59 ~31 ~-21 minecraft:stone_bricks
fill ~-59 ~ ~-100 ~-57 ~2 ~-99 minecraft:stone_bricks
fill ~-59 ~ ~-93 ~-57 ~2 ~-92 minecraft:stone_bricks
fill ~-59 ~3 ~-100 ~-58 ~26 ~-99 minecraft:stone_bricks
fill ~-59 ~4 ~-93 ~-58 ~26 ~-92 minecraft:stone_bricks
fill ~-59 ~19 ~-151 ~-57 ~30 ~-151 minecraft:stone_bricks
fill ~-59 ~19 ~-101 ~-59 ~26 ~-99 minecraft:stone_bricks
fill ~-59 ~19 ~-91 ~-59 ~26 ~-91 minecraft:stone_bricks
fill ~-59 ~19 ~-42 ~-59 ~30 ~-41 minecraft:stone_bricks
fill ~-59 ~20 ~-150 ~-59 ~30 ~-150 minecraft:stone_bricks
fill ~-59 ~27 ~-102 ~-58 ~27 ~-102 minecraft:stone_bricks
fill ~-59 ~27 ~-90 ~-58 ~27 ~-90 minecraft:stone_bricks
setblock ~-59 ~32 ~-149 minecraft:stone_bricks
setblock ~-59 ~32 ~-43 minecraft:stone_bricks
setblock ~-59 ~32 ~-21 minecraft:stone_bricks
fill ~-58 ~ ~-168 ~-55 ~2 ~-168 minecraft:stone_bricks
fill ~-58 ~ ~-152 ~-58 ~2 ~-150 minecraft:stone_bricks
fill ~-58 ~ ~-98 ~-56 ~2 ~-98 minecraft:stone_bricks
fill ~-58 ~ ~-94 ~-56 ~2 ~-94 minecraft:stone_bricks
fill ~-58 ~ ~-40 ~-58 ~32 ~-40 minecraft:stone_bricks
fill ~-58 ~ ~-24 ~-55 ~2 ~-24 minecraft:stone_bricks
fill ~-58 ~3 ~-168 ~-56 ~30 ~-168 minecraft:stone_bricks
fill ~-58 ~3 ~-152 ~-56 ~30 ~-152 minecraft:stone_bricks
fill ~-58 ~3 ~-98 ~-57 ~26 ~-94 minecraft:stone_bricks
fill ~-58 ~3 ~-93 ~-58 ~26 ~-92 minecraft:stone_bricks
fill ~-58 ~4 ~-24 ~-56 ~30 ~-24 minecraft:stone_bricks
fill ~-58 ~19 ~-41 ~-57 ~30 ~-40 minecraft:stone_bricks
setblock ~-58 ~27 ~-101 minecraft:stone_bricks
fill ~-58 ~27 ~-91 ~-58 ~27 ~-90 minecraft:stone_bricks
setblock ~-58 ~28 ~-102 minecraft:stone_bricks
setblock ~-58 ~28 ~-90 minecraft:stone_bricks
fill ~-58 ~31 ~-170 ~-57 ~31 ~-170 minecraft:stone_bricks
fill ~-58 ~31 ~-150 ~-57 ~31 ~-150 minecraft:stone_bricks
fill ~-58 ~31 ~-42 ~-57 ~31 ~-42 minecraft:stone_bricks
fill ~-58 ~31 ~-22 ~-57 ~31 ~-22 minecraft:stone_bricks
setblock ~-58 ~32 ~-170 minecraft:stone_bricks
setblock ~-58 ~32 ~-150 minecraft:stone_bricks
setblock ~-58 ~32 ~-42 minecraft:stone_bricks
setblock ~-58 ~32 ~-22 minecraft:stone_bricks
fill ~-57 ~ ~-167 ~-54 ~2 ~-167 minecraft:stone_bricks
fill ~-57 ~ ~-25 ~-54 ~2 ~-25 minecraft:stone_bricks
fill ~-57 ~3 ~-167 ~-55 ~30 ~-167 minecraft:stone_bricks
fill ~-57 ~3 ~-40 ~-56 ~30 ~-39 minecraft:stone_bricks
fill ~-57 ~3 ~-25 ~-55 ~30 ~-25 minecraft:stone_bricks
fill ~-57 ~3 ~-24 ~-56 ~30 ~-24 minecraft:stone_bricks
fill ~-57 ~5 ~-153 ~-55 ~30 ~-153 minecraft:stone_bricks
fill ~-57 ~27 ~-100 ~-57 ~27 ~-99 minecraft:stone_bricks
fill ~-57 ~27 ~-93 ~-57 ~27 ~-92 minecraft:stone_bricks
setblock ~-57 ~28 ~-99 minecraft:stone_bricks
setblock ~-57 ~28 ~-93 minecraft:stone_bricks
fill ~-56 ~ ~-166 ~-54 ~2 ~-166 minecraft:stone_bricks
fill ~-56 ~ ~-154 ~-54 ~2 ~-154 minecraft:stone_bricks
fill ~-56 ~ ~-38 ~-54 ~2 ~-38 minecraft:stone_bricks
fill ~-56 ~ ~-26 ~-54 ~2 ~-25 minecraft:stone_bricks
fill ~-56 ~3 ~-166 ~-55 ~31 ~-166 minecraft:stone_bricks
fill ~-56 ~3 ~-153 ~-55 ~30 ~-153 minecraft:stone_bricks
fill ~-56 ~3 ~-38 ~-55 ~31 ~-38 minecraft:stone_bricks
fill ~-56 ~3 ~-26 ~-55 ~30 ~-25 minecraft:stone_bricks
fill ~-56 ~5 ~-154 ~-55 ~30 ~-153 minecraft:stone_bricks
fill ~-56 ~26 ~-98 ~-56 ~26 ~-94 minecraft:stone_bricks
fill ~-56 ~27 ~-98 ~-56 ~28 ~-98 minecraft:stone_bricks
fill ~-56 ~27 ~-94 ~-56 ~28 ~-94 minecraft:stone_bricks
setblock ~-56 ~31 ~-169 minecraft:stone_bricks
setblock ~-56 ~31 ~-23 minecraft:stone_bricks
fill ~-55 ~-1 ~-156 ~100 ~-1 ~4 minecraft:stone_bricks
fill ~-55 ~ ~-165 ~-53 ~2 ~-164 minecraft:stone_bricks
fill ~-55 ~ ~-156 ~-4 ~18 ~-156 minecraft:stone_bricks
fill ~-55 ~ ~-155 ~-53 ~2 ~-155 minecraft:stone_bricks
fill ~-55 ~ ~-153 ~-54 ~2 ~-153 minecraft:stone_bricks
fill ~-55 ~ ~-39 ~-54 ~2 ~-36 minecraft:stone_bricks
fill ~-55 ~ ~-28 ~-53 ~2 ~-27 minecraft:stone_bricks
fill ~-55 ~3 ~-165 ~-54 ~30 ~-164 minecraft:stone_bricks
fill ~-55 ~3 ~-155 ~-54 ~30 ~-155 minecraft:stone_bricks
fill ~-55 ~3 ~-154 ~-55 ~30 ~-153 minecraft:stone_bricks
fill ~-55 ~3 ~-37 ~-54 ~18 ~-36 minecraft:stone_bricks
fill ~-55 ~3 ~-28 ~-54 ~30 ~-27 minecraft:stone_bricks
fill ~-55 ~4 ~-39 ~-55 ~18 ~-36 minecraft:stone_bricks
fill ~-55 ~19 ~-39 ~-55 ~30 ~-37 minecraft:stone_bricks
fill ~-55 ~21 ~-156 ~-54 ~30 ~-155 minecraft:stone_bricks
fill ~-55 ~21 ~-36 ~-54 ~31 ~-36 minecraft:stone_bricks
setblock ~-55 ~31 ~-168 minecraft:stone_bricks
setblock ~-55 ~31 ~-24 minecraft:stone_bricks
fill ~-54 ~-1 ~-160 ~100 ~-1 ~4 minecraft:stone_bricks
fill ~-54 ~ ~-163 ~-52 ~2 ~-156 minecraft:stone_bricks
fill ~-54 ~ ~-35 ~-20 ~18 ~-35 minecraft:stone_bricks
fill ~-54 ~ ~-34 ~-21 ~18 ~-33 minecraft:stone_bricks
fill ~-54 ~ ~-32 ~-22 ~2 ~-31 minecraft:stone_bricks
fill ~-54 ~ ~-30 ~-52 ~2 ~-29 minecraft:stone_bricks
fill ~-54 ~1 ~-136 ~-54 ~9 ~-120 minecraft:stone_bricks
fill ~-54 ~2 ~-137 ~-54 ~9 ~-120 minecraft:stone_bricks
fill ~-54 ~3 ~-163 ~-53 ~18 ~-156 minecraft:stone_bricks
fill ~-54 ~3 ~-31 ~-53 ~30 ~-29 minecraft:stone_bricks
fill ~-54 ~4 ~-32 ~-22 ~5 ~-32 minecraft:stone_bricks
fill ~-54 ~6 ~-32 ~-45 ~18 ~-32 minecraft:stone_bricks
fill ~-54 ~7 ~-138 ~-36 ~9 ~-138 minecraft:stone_bricks
fill ~-54 ~19 ~-163 ~-53 ~30 ~-161 minecraft:stone_bricks
fill ~-54 ~19 ~-37 ~-54 ~30 ~-37 minecraft:stone_bricks
fill ~-54 ~21 ~-160 ~-53 ~30 ~-157 minecraft:stone_bricks
fill ~-54 ~21 ~-35 ~-53 ~30 ~-29 minecraft:stone_bricks
fill ~-54 ~31 ~-167 ~-54 ~31 ~-166 minecraft:stone_bricks
fill ~-54 ~31 ~-154 ~-54 ~31 ~-153 minecraft:stone_bricks
fill ~-54 ~31 ~-39 ~-54 ~31 ~-38 minecraft:stone_bricks
setblock ~-54 ~31 ~-25 minecraft:stone_bricks
setblock ~-54 ~32 ~-166 minecraft:stone_bricks
setblock ~-54 ~32 ~-154 minecraft:stone_bricks
setblock ~-54 ~32 ~-38 minecraft:stone_bricks
fill ~-53 ~1 ~-138 ~-36 ~9 ~-138 minecraft:stone_bricks
fill ~-53 ~1 ~-120 ~-36 ~9 ~-120 minecraft:stone_bricks
fill ~-53 ~3 ~-36 ~-18 ~18 ~-36 minecraft:stone_bricks
fill ~-53 ~3 ~-32 ~-22 ~5 ~-32 minecraft:stone_bricks
fill ~-53 ~31 ~-165 ~-53 ~31 ~-164 minecraft:stone_bricks
fill ~-53 ~31 ~-156 ~-53 ~31 ~-155 minecraft:stone_bricks
fill ~-53 ~31 ~-37 ~-53 ~31 ~-36 minecraft:stone_bricks
fill ~-53 ~31 ~-28 ~-53 ~31 ~-27 minecraft:stone_bricks
setblock ~-53 ~32 ~-165 minecraft:stone_bricks
setblock ~-53 ~32 ~-155 minecraft:stone_bricks
setblock ~-53 ~32 ~-37 minecraft:stone_bricks
setblock ~-53 ~32 ~-27 minecraft:stone_bricks
fill ~-52 ~ ~-36 ~-18 ~18 ~-36 minecraft:stone_bricks
fill ~-52 ~3 ~-160 ~-5 ~5 ~-160 minecraft:stone_bricks
fill ~-52 ~3 ~-159 ~-6 ~18 ~-156 minecraft:stone_bricks
fill ~-52 ~6 ~-160 ~-45 ~18 ~-156 minecraft:stone_bricks
fill ~-52 ~17 ~-161 ~-6 ~18 ~-156 minecraft:stone_bricks
fill ~-52 ~17 ~-31 ~-22 ~19 ~-31 minecraft:stone_bricks
fill ~-52 ~19 ~-161 ~-6 ~19 ~-161 minecraft:stone_bricks
fill ~-52 ~31 ~-163 ~-52 ~31 ~-157 minecraft:stone_bricks
fill ~-52 ~31 ~-35 ~-52 ~31 ~-29 minecraft:stone_bricks
setblock ~-52 ~32 ~-162 minecraft:stone_bricks
setblock ~-52 ~32 ~-158 minecraft:stone_bricks
setblock ~-52 ~32 ~-34 minecraft:stone_bricks
setblock ~-52 ~32 ~-32 minecraft:stone_bricks
setblock ~-52 ~32 ~-30 minecraft:stone_bricks
fill ~-51 ~ ~-160 ~-5 ~5 ~-160 minecraft:stone_bricks
fill ~-51 ~ ~-159 ~-6 ~18 ~-156 minecraft:stone_bricks
setblock ~-51 ~20 ~-161 minecraft:stone_bricks
setblock ~-51 ~20 ~-31 minecraft:stone_bricks
setblock ~-49 ~20 ~-161 minecraft:stone_bricks
fill ~-47 ~20 ~-161 ~-47 ~21 ~-161 minecraft:stone_bricks
setblock ~-47 ~20 ~-31 minecraft:stone_bricks
setblock ~-45 ~20 ~-161 minecraft:stone_bricks
fill ~-44 ~10 ~-160 ~-5 ~18 ~-160 minecraft:stone_bricks
fill ~-44 ~10 ~-32 ~-22 ~18 ~-32 minecraft:stone_bricks
fill ~-43 ~6 ~-160 ~-37 ~18 ~-156 minecraft:stone_bricks
fill ~-43 ~6 ~-32 ~-37 ~18 ~-32 minecraft:stone_bricks
setblock ~-43 ~20 ~-161 minecraft:stone_bricks
setblock ~-43 ~20 ~-31 minecraft:stone_bricks
fill ~-41 ~20 ~-31 ~-41 ~21 ~-31 minecraft:stone_bricks
fill ~-39 ~20 ~-161 ~-39 ~21 ~-161 minecraft:stone_bricks
setblock ~-39 ~20 ~-31 minecraft:stone_bricks
setblock ~-37 ~20 ~-161 minecraft:stone_bricks
setblock ~-37 ~20 ~-31 minecraft:stone_bricks
fill ~-36 ~1 ~-136 ~-36 ~9 ~-120 minecraft:stone_bricks
fill ~-36 ~2 ~-137 ~-36 ~9 ~-120 minecraft:stone_bricks
fill ~-35 ~6 ~-160 ~-29 ~18 ~-156 minecraft:stone_bricks
fill ~-35 ~7 ~-32 ~-29 ~18 ~-32 minecraft:stone_bricks
setblock ~-35 ~20 ~-161 minecraft:stone_bricks
setblock ~-35 ~20 ~-31 minecraft:stone_bricks
fill ~-34 ~6 ~-32 ~-29 ~18 ~-32 minecraft:stone_bricks
setblock ~-33 ~20 ~-161 minecraft:stone_bricks
fill ~-33 ~20 ~-31 ~-33 ~21 ~-31 minecraft:stone_bricks
fill ~-33 ~52 ~-148 ~-19 ~52 ~-144 minecraft:stone_bricks
fill ~-33 ~52 ~-104 ~-19 ~52 ~-100 minecraft:stone_bricks
fill ~-33 ~53 ~-148 ~-33 ~53 ~-144 minecraft:stone_bricks
fill ~-33 ~53 ~-104 ~-33 ~53 ~-100 minecraft:stone_bricks
setblock ~-33 ~54 ~-145 minecraft:stone_bricks
setblock ~-33 ~54 ~-103 minecraft:stone_bricks
setblock ~-33 ~54 ~-101 minecraft:stone_bricks
fill ~-32 ~ ~-148 ~-19 ~ ~-144 minecraft:stone_bricks
fill ~-32 ~ ~-104 ~-25 ~2 ~-98 minecraft:stone_bricks
fill ~-32 ~ ~-38 ~-5 ~2 ~-37 minecraft:stone_bricks
fill ~-32 ~1 ~-148 ~-19 ~1 ~-145 minecraft:stone_bricks
fill ~-32 ~1 ~-144 ~-25 ~1 ~-142 minecraft:stone_bricks
fill ~-32 ~2 ~-148 ~-19 ~2 ~-146 minecraft:stone_bricks
fill ~-32 ~2 ~-145 ~-23 ~52 ~-145 minecraft:stone_bricks
fill ~-32 ~2 ~-144 ~-25 ~2 ~-143 minecraft:stone_bricks
fill ~-32 ~3 ~-148 ~-20 ~52 ~-146 minecraft:stone_bricks
fill ~-32 ~3 ~-144 ~-25 ~52 ~-144 minecraft:stone_bricks
fill ~-32 ~3 ~-104 ~-25 ~52 ~-100 minecraft:stone_bricks
fill ~-32 ~3 ~-38 ~-13 ~4 ~-37 minecraft:stone_bricks
fill ~-32 ~5 ~-38 ~-19 ~5 ~-36 minecraft:stone_bricks
fill ~-32 ~6 ~-38 ~-20 ~6 ~-35 minecraft:stone_bricks
fill ~-32 ~7 ~-38 ~-21 ~7 ~-33 minecraft:stone_bricks
fill ~-32 ~8 ~-38 ~-22 ~8 ~-33 minecraft:stone_bricks
fill ~-32 ~9 ~-38 ~-23 ~9 ~-33 minecraft:stone_bricks
fill ~-32 ~10 ~-38 ~-24 ~10 ~-32 minecraft:stone_bricks
fill ~-32 ~11 ~-38 ~-25 ~11 ~-32 minecraft:stone_bricks
fill ~-32 ~12 ~-38 ~-26 ~12 ~-32 minecraft:stone_bricks
fill ~-32 ~13 ~-38 ~-27 ~13 ~-32 minecraft:stone_bricks
fill ~-32 ~14 ~-38 ~-28 ~14 ~-32 minecraft:stone_bricks
fill ~-32 ~15 ~-38 ~-29 ~15 ~-32 minecraft:stone_bricks
fill ~-32 ~16 ~-38 ~-30 ~16 ~-31 minecraft:stone_bricks
fill ~-32 ~17 ~-37 ~-31 ~17 ~-31 minecraft:stone_bricks
fill ~-32 ~52 ~-150 ~-20 ~52 ~-142 minecraft:stone_bricks
fill ~-32 ~52 ~-106 ~-20 ~52 ~-98 minecraft:stone_bricks
fill ~-32 ~53 ~-150 ~-32 ~53 ~-149 minecraft:stone_bricks
fill ~-32 ~53 ~-143 ~-30 ~53 ~-143 minecraft:stone_bricks
fill ~-32 ~53 ~-142 ~-32 ~54 ~-142 minecraft:stone_bricks
fill ~-32 ~53 ~-106 ~-32 ~53 ~-105 minecraft:stone_bricks
fill ~-32 ~53 ~-98 ~-32 ~54 ~-98 minecraft:stone_bricks
setblock ~-32 ~54 ~-150 minecraft:stone_bricks
setblock ~-32 ~54 ~-106 minecraft:stone_bricks
fill ~-31 ~ ~-150 ~-20 ~ ~-144 minecraft:stone_bricks
fill ~-31 ~ ~-143 ~-25 ~1 ~-141 minecraft:stone_bricks
fill ~-31 ~ ~-106 ~-25 ~1 ~-97 minecraft:stone_bricks
fill ~-31 ~1 ~-150 ~-20 ~1 ~-145 minecraft:stone_bricks
fill ~-31 ~2 ~-150 ~-20 ~2 ~-146 minecraft:stone_bricks
fill ~-31 ~2 ~-142 ~-26 ~2 ~-141 minecraft:stone_bricks
fill ~-31 ~2 ~-106 ~-26 ~2 ~-97 minecraft:stone_bricks
fill ~-31 ~3 ~-149 ~-21 ~52 ~-146 minecraft:stone_bricks
fill ~-31 ~3 ~-143 ~-25 ~52 ~-143 minecraft:stone_bricks
fill ~-31 ~3 ~-142 ~-26 ~52 ~-142 minecraft:stone_bricks
fill ~-31 ~3 ~-106 ~-26 ~52 ~-98 minecraft:stone_bricks
fill ~-31 ~4 ~-150 ~-21 ~52 ~-146 minecraft:stone_bricks
fill ~-31 ~20 ~-161 ~-31 ~21 ~-161 minecraft:stone_bricks
setblock ~-31 ~20 ~-31 minecraft:stone_bricks
fill ~-31 ~52 ~-151 ~-21 ~52 ~-141 minecraft:stone_bricks
fill ~-31 ~53 ~-151 ~-31 ~54 ~-151 minecraft:stone_bricks
fill ~-31 ~53 ~-141 ~-31 ~54 ~-141 minecraft:stone_bricks
fill ~-31 ~53 ~-97 ~-31 ~54 ~-97 minecraft:stone_bricks
setblock ~-31 ~54 ~-107 minecraft:stone_bricks
fill ~-30 ~ ~-151 ~-21 ~ ~-144 minecraft:stone_bricks
fill ~-30 ~ ~-107 ~-25 ~1 ~-96 minecraft:stone_bricks
fill ~-30 ~1 ~-151 ~-21 ~1 ~-145 minecraft:stone_bricks
fill ~-30 ~2 ~-151 ~-21 ~2 ~-146 minecraft:stone_bricks
fill ~-30 ~2 ~-107 ~-25 ~52 ~-107 minecraft:stone_bricks
fill ~-30 ~3 ~-151 ~-22 ~52 ~-146 minecraft:stone_bricks
fill ~-30 ~3 ~-97 ~-22 ~52 ~-97 minecraft:stone_bricks
fill ~-30 ~5 ~-141 ~-25 ~52 ~-141 minecraft:stone_bricks
fill ~-30 ~52 ~-152 ~-22 ~52 ~-140 minecraft:stone_bricks
fill ~-30 ~52 ~-108 ~-22 ~52 ~-96 minecraft:stone_bricks
fill ~-30 ~53 ~-152 ~-29 ~53 ~-152 minecraft:stone_bricks
fill ~-30 ~53 ~-140 ~-29 ~53 ~-140 minecraft:stone_bricks
fill ~-30 ~53 ~-108 ~-29 ~53 ~-108 minecraft:stone_bricks
fill ~-30 ~53 ~-96 ~-29 ~53 ~-96 minecraft:stone_bricks
setblock ~-30 ~54 ~-152 minecraft:stone_bricks
setblock ~-30 ~54 ~-140 minecraft:stone_bricks
setblock ~-30 ~54 ~-108 minecraft:stone_bricks
setblock ~-30 ~54 ~-96 minecraft:stone_bricks
fill ~-29 ~4 ~-141 ~-25 ~53 ~-141 minecraft:stone_bricks
setblock ~-29 ~20 ~-161 minecraft:stone_bricks
setblock ~-29 ~20 ~-31 minecraft:stone_bricks
fill ~-28 ~ ~-152 ~-22 ~ ~-144 minecraft:stone_bricks
fill ~-28 ~ ~-140 ~-25 ~2 ~-139 minecraft:stone_bricks
fill ~-28 ~ ~-108 ~-25 ~1 ~-95 minecraft:stone_bricks
fill ~-28 ~1 ~-152 ~-22 ~1 ~-145 minecraft:stone_bricks
fill ~-28 ~2 ~-152 ~-22 ~2 ~-146 minecraft:stone_bricks
fill ~-28 ~2 ~-108 ~-25 ~52 ~-107 minecraft:stone_bricks
fill ~-28 ~2 ~-96 ~-22 ~2 ~-96 minecraft:stone_bricks
fill ~-28 ~3 ~-152 ~-24 ~52 ~-145 minecraft:stone_bricks
fill ~-28 ~3 ~-141 ~-25 ~52 ~-140 minecraft:stone_bricks
fill ~-28 ~3 ~-96 ~-24 ~52 ~-96 minecraft:stone_bricks
fill ~-28 ~52 ~-153 ~-24 ~52 ~-139 minecraft:stone_bricks
fill ~-28 ~52 ~-109 ~-24 ~52 ~-95 minecraft:stone_bricks
fill ~-28 ~53 ~-153 ~-24 ~53 ~-153 minecraft:stone_bricks
fill ~-28 ~53 ~-139 ~-24 ~53 ~-139 minecraft:stone_bricks
fill ~-28 ~53 ~-109 ~-24 ~53 ~-109 minecraft:stone_bricks
fill ~-28 ~53 ~-95 ~-24 ~53 ~-95 minecraft:stone_bricks
fill ~-27 ~6 ~-160 ~-21 ~18 ~-156 minecraft:stone_bricks
fill ~-27 ~6 ~-32 ~-22 ~18 ~-32 minecraft:stone_bricks
setblock ~-27 ~20 ~-161 minecraft:stone_bricks
setblock ~-27 ~20 ~-31 minecraft:stone_bricks
fill ~-27 ~44 ~-139 ~27 ~44 ~-101 minecraft:stone_bricks
fill ~-27 ~45 ~-139 ~-27 ~45 ~-96 minecraft:stone_bricks
setblock ~-27 ~46 ~-139 minecraft:stone_bricks
setblock ~-27 ~46 ~-137 minecraft:stone_bricks
fill ~-27 ~46 ~-135 ~-27 ~47 ~-135 minecraft:stone_bricks
setblock ~-27 ~46 ~-133 minecraft:stone_bricks
setblock ~-27 ~46 ~-131 minecraft:stone_bricks
fill ~-27 ~46 ~-129 ~-27 ~47 ~-129 minecraft:stone_bricks
setblock ~-27 ~46 ~-125 minecraft:stone_bricks
fill ~-27 ~46 ~-123 ~-27 ~47 ~-123 minecraft:stone_bricks
setblock ~-27 ~46 ~-119 minecraft:stone_bricks
fill ~-27 ~46 ~-117 ~-27 ~47 ~-117 minecraft:stone_bricks
setblock ~-27 ~46 ~-115 minecraft:stone_bricks
setblock ~-27 ~46 ~-113 minecraft:stone_bricks
fill ~-27 ~46 ~-111 ~-27 ~47 ~-111 minecraft:stone_bricks
fill ~-27 ~46 ~-109 ~-27 ~46 ~-96 minecraft:stone_bricks
setblock ~-27 ~54 ~-153 minecraft:stone_bricks
setblock ~-27 ~54 ~-109 minecraft:stone_bricks
setblock ~-27 ~54 ~-95 minecraft:stone_bricks
fill ~-26 ~-26 ~-122 ~36 ~-22 ~-98 minecraft:stone_bricks
fill ~-26 ~ ~-138 ~-25 ~1 ~-95 minecraft:stone_bricks
fill ~-26 ~2 ~-138 ~-25 ~44 ~-137 minecraft:stone_bricks
fill ~-26 ~2 ~-135 ~-25 ~44 ~-131 minecraft:stone_bricks
fill ~-26 ~2 ~-129 ~-25 ~44 ~-125 minecraft:stone_bricks
fill ~-26 ~2 ~-123 ~-25 ~44 ~-119 minecraft:stone_bricks
fill ~-26 ~2 ~-117 ~-25 ~44 ~-113 minecraft:stone_bricks
fill ~-26 ~2 ~-111 ~-25 ~44 ~-107 minecraft:stone_bricks
fill ~-26 ~3 ~-139 ~-25 ~44 ~-137 minecraft:stone_bricks
fill ~-26 ~7 ~-136 ~-25 ~13 ~-96 minecraft:stone_bricks
fill ~-26 ~19 ~-136 ~-25 ~24 ~-96 minecraft:stone_bricks
fill ~-26 ~30 ~-136 ~-25 ~35 ~-96 minecraft:stone_bricks
fill ~-26 ~41 ~-136 ~-25 ~44 ~-96 minecraft:stone_bricks
fill ~-25 ~-27 ~-122 ~36 ~-22 ~-98 minecraft:stone_bricks
fill ~-25 ~2 ~-105 ~-25 ~2 ~-95 minecraft:stone_bricks
fill ~-25 ~3 ~-105 ~-25 ~52 ~-96 minecraft:stone_bricks
fill ~-25 ~7 ~-142 ~-25 ~13 ~-96 minecraft:stone_bricks
fill ~-25 ~19 ~-142 ~-25 ~24 ~-96 minecraft:stone_bricks
setblock ~-25 ~20 ~-161 minecraft:stone_bricks
fill ~-25 ~20 ~-31 ~-25 ~21 ~-31 minecraft:stone_bricks
fill ~-25 ~30 ~-142 ~-25 ~35 ~-96 minecraft:stone_bricks
fill ~-25 ~41 ~-142 ~-25 ~44 ~-96 minecraft:stone_bricks
fill ~-25 ~45 ~-142 ~-21 ~52 ~-142 minecraft:stone_bricks
fill ~-25 ~45 ~-106 ~-21 ~52 ~-98 minecraft:stone_bricks
setblock ~-25 ~54 ~-153 minecraft:stone_bricks
setblock ~-25 ~54 ~-139 minecraft:stone_bricks
setblock ~-25 ~54 ~-109 minecraft:stone_bricks
setblock ~-25 ~54 ~-95 minecraft:stone_bricks
fill ~-24 ~ ~-125 ~-20 ~11 ~-125 minecraft:stone_bricks
fill ~-24 ~ ~-103 ~-4 ~1 ~-101 minecraft:stone_bricks
fill ~-24 ~ ~-100 ~-19 ~2 ~-100 minecraft:stone_bricks
fill ~-24 ~ ~-99 ~-20 ~2 ~-98 minecraft:stone_bricks
fill ~-24 ~ ~-97 ~-21 ~2 ~-97 minecraft:stone_bricks
fill ~-24 ~ ~-96 ~-22 ~2 ~-96 minecraft:stone_bricks
fill ~-24 ~2 ~-103 ~-23 ~2 ~-96 minecraft:stone_bricks
fill ~-24 ~3 ~-103 ~-23 ~52 ~-97 minecraft:stone_bricks
fill ~-24 ~23 ~-124 ~-1 ~33 ~-124 minecraft:stone_bricks
fill ~-24 ~30 ~-33 ~-6 ~30 ~-27 minecraft:stone_bricks
fill ~-24 ~31 ~-33 ~-21 ~31 ~-33 minecraft:stone_bricks
fill ~-24 ~31 ~-30 ~-24 ~31 ~-27 minecraft:stone_bricks
setblock ~-24 ~32 ~-33 minecraft:stone_bricks
setblock ~-24 ~32 ~-31 minecraft:stone_bricks
setblock ~-24 ~32 ~-29 minecraft:stone_bricks
setblock ~-24 ~32 ~-27 minecraft:stone_bricks
fill ~-24 ~44 ~-144 ~32 ~44 ~-144 minecraft:stone_bricks
fill ~-24 ~44 ~-142 ~31 ~44 ~-142 minecraft:stone_bricks
fill ~-24 ~44 ~-141 ~30 ~44 ~-141 minecraft:stone_bricks
fill ~-24 ~44 ~-140 ~28 ~44 ~-140 minecraft:stone_bricks
fill ~-24 ~45 ~-144 ~-20 ~52 ~-144 minecraft:stone_bricks
fill ~-24 ~45 ~-143 ~-21 ~52 ~-142 minecraft:stone_bricks
fill ~-24 ~45 ~-141 ~-22 ~52 ~-141 minecraft:stone_bricks
fill ~-24 ~45 ~-108 ~-24 ~52 ~-96 minecraft:stone_bricks
fill ~-24 ~46 ~-140 ~-24 ~52 ~-140 minecraft:stone_bricks
fill ~-23 ~ ~-30 ~-22 ~2 ~-25 minecraft:stone_bricks
fill ~-23 ~3 ~-31 ~-22 ~30 ~-28 minecraft:stone_bricks
fill ~-23 ~20 ~-161 ~-23 ~21 ~-161 minecraft:stone_bricks
fill ~-23 ~21 ~-32 ~-22 ~30 ~-28 minecraft:stone_bricks
fill ~-23 ~30 ~-34 ~-7 ~30 ~-25 minecraft:stone_bricks
fill ~-23 ~31 ~-35 ~-20 ~31 ~-35 minecraft:stone_bricks
fill ~-23 ~31 ~-34 ~-23 ~31 ~-33 minecraft:stone_bricks
fill ~-23 ~31 ~-27 ~-21 ~31 ~-27 minecraft:stone_bricks
fill ~-23 ~31 ~-26 ~-23 ~31 ~-25 minecraft:stone_bricks
setblock ~-23 ~32 ~-34 minecraft:stone_bricks
setblock ~-23 ~32 ~-26 minecraft:stone_bricks
fill ~-23 ~44 ~-143 ~31 ~44 ~-142 minecraft:stone_bricks
fill ~-23 ~45 ~-107 ~-22 ~52 ~-97 minecraft:stone_bricks
fill ~-23 ~53 ~-152 ~-22 ~53 ~-152 minecraft:stone_bricks
fill ~-23 ~53 ~-140 ~-22 ~53 ~-140 minecraft:stone_bricks
fill ~-23 ~53 ~-108 ~-22 ~53 ~-108 minecraft:stone_bricks
fill ~-23 ~53 ~-96 ~-22 ~53 ~-96 minecraft:stone_bricks
fill ~-22 ~2 ~-101 ~-4 ~2 ~-101 minecraft:stone_bricks
fill ~-22 ~3 ~-101 ~-20 ~52 ~-100 minecraft:stone_bricks
fill ~-22 ~3 ~-99 ~-21 ~52 ~-98 minecraft:stone_bricks
fill ~-22 ~3 ~-27 ~-21 ~30 ~-26 minecraft:stone_bricks
fill ~-22 ~7 ~-145 ~-3 ~13 ~-145 minecraft:stone_bricks
fill ~-22 ~7 ~-103 ~-2 ~13 ~-102 minecraft:stone_bricks
fill ~-22 ~19 ~-145 ~32 ~24 ~-145 minecraft:stone_bricks
fill ~-22 ~19 ~-103 ~32 ~24 ~-102 minecraft:stone_bricks
fill ~-22 ~21 ~-34 ~-21 ~30 ~-33 minecraft:stone_bricks
fill ~-22 ~30 ~-145 ~32 ~35 ~-145 minecraft:stone_bricks
fill ~-22 ~30 ~-102 ~32 ~44 ~-102 minecraft:stone_bricks
fill ~-22 ~30 ~-36 ~-8 ~30 ~-24 minecraft:stone_bricks
fill ~-22 ~31 ~-103 ~32 ~35 ~-102 minecraft:stone_bricks
fill ~-22 ~31 ~-25 ~-20 ~31 ~-25 minecraft:stone_bricks
setblock ~-22 ~31 ~-24 minecraft:stone_bricks
setblock ~-22 ~32 ~-35 minecraft:stone_bricks
setblock ~-22 ~32 ~-25 minecraft:stone_bricks
fill ~-22 ~41 ~-145 ~32 ~44 ~-145 minecraft:stone_bricks
fill ~-22 ~41 ~-103 ~32 ~44 ~-102 minecraft:stone_bricks
fill ~-22 ~45 ~-145 ~-20 ~52 ~-144 minecraft:stone_bricks
setblock ~-22 ~54 ~-108 minecraft:stone_bricks
setblock ~-22 ~54 ~-96 minecraft:stone_bricks
fill ~-21 ~-27 ~-141 ~34 ~-16 ~-98 minecraft:stone_bricks
fill ~-21 ~-15 ~-141 ~-19 ~11 ~-139 minecraft:stone_bricks
fill ~-21 ~ ~-27 ~-21 ~2 ~-23 minecraft:stone_bricks
fill ~-21 ~2 ~-145 ~-17 ~44 ~-145 minecraft:stone_bricks
fill ~-21 ~2 ~-103 ~-17 ~2 ~-101 minecraft:stone_bricks
fill ~-21 ~3 ~-102 ~-4 ~44 ~-102 minecraft:stone_bricks
fill ~-21 ~3 ~-25 ~-20 ~30 ~-24 minecraft:stone_bricks
fill ~-21 ~4 ~-103 ~-17 ~44 ~-102 minecraft:stone_bricks
fill ~-21 ~12 ~-141 ~-19 ~14 ~-141 minecraft:stone_bricks
fill ~-21 ~12 ~-140 ~-21 ~14 ~-139 minecraft:stone_bricks
setblock ~-21 ~20 ~-161 minecraft:stone_bricks
fill ~-21 ~21 ~-36 ~-18 ~30 ~-36 minecraft:stone_bricks
fill ~-21 ~21 ~-35 ~-20 ~31 ~-35 minecraft:stone_bricks
fill ~-21 ~30 ~-37 ~-9 ~30 ~-23 minecraft:stone_bricks
fill ~-21 ~31 ~-37 ~-20 ~31 ~-37 minecraft:stone_bricks
fill ~-21 ~31 ~-23 ~-20 ~31 ~-23 minecraft:stone_bricks
fill ~-21 ~52 ~-107 ~-21 ~52 ~-97 minecraft:stone_bricks
fill ~-21 ~53 ~-151 ~-21 ~54 ~-151 minecraft:stone_bricks
fill ~-21 ~53 ~-107 ~-21 ~54 ~-107 minecraft:stone_bricks
fill ~-21 ~53 ~-97 ~-21 ~54 ~-97 minecraft:stone_bricks
setblock ~-21 ~54 ~-141 minecraft:stone_bricks
fill ~-20 ~ ~-25 ~-20 ~2 ~-22 minecraft:stone_bricks
fill ~-20 ~14 ~-140 ~-19 ~14 ~-139 minecraft:stone_bricks
fill ~-20 ~30 ~-38 ~-10 ~30 ~-22 minecraft:stone_bricks
fill ~-20 ~31 ~-22 ~-18 ~31 ~-22 minecraft:stone_bricks
setblock ~-20 ~32 ~-23 minecraft:stone_bricks
fill ~-20 ~45 ~-104 ~-20 ~52 ~-100 minecraft:stone_bricks
fill ~-20 ~53 ~-150 ~-20 ~53 ~-149 minecraft:stone_bricks
fill ~-20 ~53 ~-143 ~-20 ~53 ~-142 minecraft:stone_bricks
fill ~-20 ~53 ~-106 ~-20 ~53 ~-105 minecraft:stone_bricks
fill ~-20 ~53 ~-98 ~-20 ~54 ~-98 minecraft:stone_bricks
setblock ~-20 ~54 ~-150 minecraft:stone_bricks
setblock ~-20 ~54 ~-142 minecraft:stone_bricks
setblock ~-20 ~54 ~-106 minecraft:stone_bricks
fill ~-19 ~ ~-24 ~-18 ~2 ~-22 minecraft:stone_bricks
fill ~-19 ~3 ~-146 ~32 ~44 ~-146 minecraft:stone_bricks
fill ~-19 ~3 ~-125 ~-11 ~11 ~-125 minecraft:stone_bricks
fill ~-19 ~3 ~-103 ~-17 ~44 ~-102 minecraft:stone_bricks
fill ~-19 ~3 ~-23 ~-11 ~30 ~-23 minecraft:stone_bricks
fill ~-19 ~4 ~-24 ~-18 ~30 ~-23 minecraft:stone_bricks
fill ~-19 ~6 ~-160 ~-13 ~18 ~-156 minecraft:stone_bricks
fill ~-19 ~6 ~-37 ~-11 ~30 ~-37 minecraft:stone_bricks
fill ~-19 ~12 ~-140 ~-19 ~14 ~-139 minecraft:stone_bricks
setblock ~-19 ~20 ~-161 minecraft:stone_bricks
setblock ~-19 ~32 ~-38 minecraft:stone_bricks
setblock ~-19 ~32 ~-22 minecraft:stone_bricks
fill ~-19 ~44 ~-147 ~32 ~44 ~-144 minecraft:stone_bricks
fill ~-19 ~45 ~-147 ~32 ~45 ~-147 minecraft:stone_bricks
setblock ~-19 ~46 ~-147 minecraft:stone_bricks
fill ~-19 ~46 ~-101 ~-19 ~47 ~-101 minecraft:stone_bricks
fill ~-19 ~53 ~-148 ~-19 ~53 ~-144 minecraft:stone_bricks
fill ~-19 ~53 ~-103 ~-19 ~53 ~-100 minecraft:stone_bricks
setblock ~-19 ~54 ~-147 minecraft:stone_bricks
setblock ~-19 ~54 ~-145 minecraft:stone_bricks
setblock ~-19 ~54 ~-103 minecraft:stone_bricks
setblock ~-19 ~54 ~-101 minecraft:stone_bricks
fill ~-18 ~ ~-146 ~33 ~1 ~-145 minecraft:stone_bricks
fill ~-18 ~2 ~-146 ~33 ~2 ~-146 minecraft:stone_bricks
fill ~-18 ~3 ~-24 ~-18 ~31 ~-23 minecraft:stone_bricks
fill ~-18 ~5 ~-37 ~-11 ~30 ~-37 minecraft:stone_bricks
fill ~-18 ~30 ~-39 ~-12 ~30 ~-21 minecraft:stone_bricks
fill ~-18 ~31 ~-39 ~-12 ~31 ~-39 minecraft:stone_bricks
fill ~-18 ~31 ~-38 ~-18 ~31 ~-36 minecraft:stone_bricks
setblock ~-18 ~32 ~-39 minecraft:stone_bricks
setblock ~-18 ~32 ~-21 minecraft:stone_bricks
fill ~-18 ~45 ~-101 ~32 ~45 ~-101 minecraft:stone_bricks
fill ~-17 ~-15 ~-141 ~-15 ~11 ~-139 minecraft:stone_bricks
fill ~-17 ~ ~-23 ~-9 ~2 ~-23 minecraft:stone_bricks
fill ~-17 ~ ~-22 ~-10 ~2 ~-22 minecraft:stone_bricks
fill ~-17 ~3 ~-22 ~-13 ~30 ~-22 minecraft:stone_bricks
fill ~-17 ~5 ~-38 ~-13 ~30 ~-37 minecraft:stone_bricks
fill ~-17 ~12 ~-141 ~-15 ~14 ~-141 minecraft:stone_bricks
fill ~-17 ~12 ~-140 ~-17 ~14 ~-139 minecraft:stone_bricks
setblock ~-17 ~20 ~-161 minecraft:stone_bricks
fill ~-17 ~31 ~-21 ~-12 ~31 ~-21 minecraft:stone_bricks
setblock ~-17 ~46 ~-147 minecraft:stone_bricks
setblock ~-17 ~46 ~-101 minecraft:stone_bricks
fill ~-16 ~ ~-125 ~-11 ~11 ~-125 minecraft:stone_bricks
fill ~-16 ~14 ~-140 ~-15 ~14 ~-139 minecraft:stone_bricks
fill ~-16 ~30 ~-103 ~32 ~35 ~-102 minecraft:stone_bricks
setblock ~-16 ~32 ~-39 minecraft:stone_bricks
setblock ~-16 ~32 ~-21 minecraft:stone_bricks
fill ~-15 ~2 ~-145 ~-11 ~44 ~-145 minecraft:stone_bricks
fill ~-15 ~2 ~-103 ~-11 ~2 ~-101 minecraft:stone_bricks
fill ~-15 ~3 ~-103 ~-11 ~44 ~-102 minecraft:stone_bricks
fill ~-15 ~12 ~-140 ~-15 ~14 ~-139 minecraft:stone_bricks
fill ~-15 ~46 ~-147 ~-15 ~47 ~-147 minecraft:stone_bricks
setblock ~-15 ~46 ~-101 minecraft:stone_bricks
setblock ~-14 ~32 ~-39 minecraft:stone_bricks
setblock ~-14 ~32 ~-21 minecraft:stone_bricks
setblock ~-13 ~20 ~-161 minecraft:stone_bricks
setblock ~-13 ~46 ~-147 minecraft:stone_bricks
fill ~-13 ~46 ~-101 ~-13 ~47 ~-101 minecraft:stone_bricks
fill ~-12 ~ ~-36 ~-5 ~12 ~-36 minecraft:stone_bricks
fill ~-12 ~1 ~-24 ~-8 ~2 ~-24 minecraft:stone_bricks
fill ~-12 ~3 ~-37 ~-11 ~30 ~-36 minecraft:stone_bricks
fill ~-12 ~4 ~-24 ~-9 ~30 ~-24 minecraft:stone_bricks
fill ~-12 ~31 ~-38 ~-10 ~31 ~-38 minecraft:stone_bricks
fill ~-12 ~31 ~-22 ~-10 ~31 ~-22 minecraft:stone_bricks
setblock ~-12 ~32 ~-39 minecraft:stone_bricks
setblock ~-12 ~32 ~-21 minecraft:stone_bricks
fill ~-11 ~ ~-144 ~-11 ~22 ~-118 minecraft:stone_bricks
fill ~-11 ~ ~-114 ~-11 ~2 ~-101 minecraft:stone_bricks
fill ~-11 ~ ~-24 ~-8 ~2 ~-24 minecraft:stone_bricks
fill ~-11 ~3 ~-114 ~-11 ~22 ~-102 minecraft:stone_bricks
fill ~-11 ~3 ~-24 ~-9 ~30 ~-24 minecraft:stone_bricks
fill ~-11 ~4 ~-117 ~-11 ~22 ~-102 minecraft:stone_bricks
fill ~-11 ~7 ~-160 ~-5 ~18 ~-160 minecraft:stone_bricks
setblock ~-11 ~20 ~-161 minecraft:stone_bricks
fill ~-11 ~23 ~-143 ~-11 ~44 ~-135 minecraft:stone_bricks
fill ~-11 ~23 ~-133 ~-11 ~33 ~-115 minecraft:stone_bricks
fill ~-11 ~23 ~-113 ~-11 ~44 ~-102 minecraft:stone_bricks
fill ~-11 ~24 ~-144 ~-11 ~44 ~-135 minecraft:stone_bricks
fill ~-11 ~25 ~-134 ~-11 ~33 ~-102 minecraft:stone_bricks
setblock ~-11 ~32 ~-22 minecraft:stone_bricks
fill ~-11 ~34 ~-134 ~-11 ~44 ~-126 minecraft:stone_bricks
fill ~-11 ~34 ~-122 ~-11 ~44 ~-102 minecraft:stone_bricks
fill ~-11 ~38 ~-125 ~-11 ~44 ~-102 minecraft:stone_bricks
setblock ~-11 ~46 ~-147 minecraft:stone_bricks
setblock ~-11 ~46 ~-101 minecraft:stone_bricks
fill ~-11 ~66 ~-127 ~11 ~66 ~-121 minecraft:stone_bricks
fill ~-11 ~67 ~-127 ~-11 ~67 ~-121 minecraft:stone_bricks
setblock ~-11 ~68 ~-127 minecraft:stone_bricks
setblock ~-11 ~68 ~-125 minecraft:stone_bricks
setblock ~-11 ~68 ~-123 minecraft:stone_bricks
setblock ~-11 ~68 ~-121 minecraft:stone_bricks
fill ~-10 ~ ~-35 ~-5 ~12 ~-35 minecraft:stone_bricks
fill ~-10 ~ ~-25 ~-5 ~2 ~-25 minecraft:stone_bricks
fill ~-10 ~3 ~-25 ~-9 ~30 ~-24 minecraft:stone_bricks
fill ~-10 ~6 ~-160 ~-5 ~18 ~-160 minecraft:stone_bricks
fill ~-10 ~13 ~-36 ~-9 ~30 ~-35 minecraft:stone_bricks
fill ~-10 ~31 ~-37 ~-9 ~31 ~-37 minecraft:stone_bricks
fill ~-10 ~31 ~-23 ~-9 ~31 ~-23 minecraft:stone_bricks
setblock ~-10 ~32 ~-37 minecraft:stone_bricks
setblock ~-10 ~32 ~-23 minecraft:stone_bricks
fill ~-10 ~45 ~-127 ~-8 ~66 ~-127 minecraft:stone_bricks
fill ~-10 ~45 ~-126 ~-9 ~66 ~-121 minecraft:stone_bricks
fill ~-10 ~66 ~-129 ~10 ~66 ~-119 minecraft:stone_bricks
fill ~-10 ~67 ~-129 ~-10 ~67 ~-128 minecraft:stone_bricks
setblock ~-10 ~67 ~-119 minecraft:stone_bricks
setblock ~-10 ~68 ~-128 minecraft:stone_bricks
setblock ~-10 ~68 ~-120 minecraft:stone_bricks
fill ~-9 ~ ~-74 ~-5 ~ ~-70 minecraft:stone_bricks
fill ~-9 ~ ~-34 ~-5 ~12 ~-33 minecraft:stone_bricks
fill ~-9 ~ ~-26 ~-5 ~2 ~-25 minecraft:stone_bricks
fill ~-9 ~1 ~-27 ~-5 ~2 ~-25 minecraft:stone_bricks
fill ~-9 ~2 ~-145 ~5 ~2 ~-145 minecraft:stone_bricks
fill ~-9 ~2 ~-103 ~-4 ~2 ~-101 minecraft:stone_bricks
fill ~-9 ~3 ~-145 ~-3 ~44 ~-145 minecraft:stone_bricks
fill ~-9 ~3 ~-103 ~-4 ~44 ~-102 minecraft:stone_bricks
fill ~-9 ~3 ~-40 ~-5 ~12 ~-33 minecraft:stone_bricks
fill ~-9 ~3 ~-27 ~-5 ~12 ~-26 minecraft:stone_bricks
fill ~-9 ~13 ~-39 ~-9 ~25 ~-33 minecraft:stone_bricks
fill ~-9 ~13 ~-27 ~-8 ~30 ~-26 minecraft:stone_bricks
fill ~-9 ~14 ~-40 ~9 ~25 ~-40 minecraft:stone_bricks
setblock ~-9 ~20 ~-161 minecraft:stone_bricks
setblock ~-9 ~26 ~-39 minecraft:stone_bricks
fill ~-9 ~26 ~-37 ~-9 ~26 ~-33 minecraft:stone_bricks
fill ~-9 ~27 ~-34 ~-8 ~30 ~-33 minecraft:stone_bricks
fill ~-9 ~45 ~-128 ~-8 ~66 ~-127 minecraft:stone_bricks
fill ~-9 ~45 ~-120 ~-8 ~66 ~-119 minecraft:stone_bricks
fill ~-9 ~46 ~-147 ~-9 ~47 ~-147 minecraft:stone_bricks
fill ~-9 ~46 ~-129 ~-7 ~66 ~-129 minecraft:stone_bricks
setblock ~-9 ~46 ~-101 minecraft:stone_bricks
fill ~-9 ~66 ~-131 ~9 ~66 ~-117 minecraft:stone_bricks
fill ~-9 ~67 ~-131 ~-6 ~67 ~-131 minecraft:stone_bricks
fill ~-9 ~67 ~-118 ~-9 ~67 ~-117 minecraft:stone_bricks
setblock ~-9 ~68 ~-131 minecraft:stone_bricks
setblock ~-9 ~68 ~-117 minecraft:stone_bricks
fill ~-8 ~ ~-32 ~-5 ~2 ~-25 minecraft:stone_bricks
fill ~-8 ~3 ~-32 ~-5 ~12 ~-26 minecraft:stone_bricks
fill ~-8 ~13 ~-40 ~9 ~25 ~-40 minecraft:stone_bricks
fill ~-8 ~13 ~-34 ~-8 ~30 ~-26 minecraft:stone_bricks
fill ~-8 ~24 ~-39 ~9 ~24 ~-33 minecraft:stone_bricks
fill ~-8 ~26 ~-162 ~8 ~26 ~-158 minecraft:stone_bricks
fill ~-8 ~27 ~-162 ~-8 ~27 ~-158 minecraft:stone_bricks
setblock ~-8 ~28 ~-162 minecraft:stone_bricks
setblock ~-8 ~28 ~-160 minecraft:stone_bricks
setblock ~-8 ~28 ~-158 minecraft:stone_bricks
fill ~-8 ~31 ~-36 ~-8 ~31 ~-35 minecraft:stone_bricks
fill ~-8 ~31 ~-25 ~-7 ~31 ~-25 minecraft:stone_bricks
setblock ~-8 ~31 ~-24 minecraft:stone_bricks
setblock ~-8 ~32 ~-35 minecraft:stone_bricks
setblock ~-8 ~32 ~-25 minecraft:stone_bricks
fill ~-8 ~45 ~-130 ~-7 ~66 ~-129 minecraft:stone_bricks
fill ~-8 ~45 ~-121 ~-8 ~66 ~-118 minecraft:stone_bricks
fill ~-8 ~66 ~-132 ~8 ~66 ~-116 minecraft:stone_bricks
fill ~-8 ~67 ~-132 ~-7 ~67 ~-131 minecraft:stone_bricks
fill ~-8 ~67 ~-116 ~-7 ~67 ~-116 minecraft:stone_bricks
setblock ~-8 ~68 ~-132 minecraft:stone_bricks
setblock ~-8 ~68 ~-116 minecraft:stone_bricks
fill ~-7 ~ ~-162 ~-6 ~18 ~-156 minecraft:stone_bricks
fill ~-7 ~1 ~-72 ~-7 ~2 ~-72 minecraft:stone_bricks
fill ~-7 ~13 ~-32 ~-7 ~30 ~-28 minecraft:stone_bricks
fill ~-7 ~14 ~-26 ~9 ~25 ~-26 minecraft:stone_bricks
fill ~-7 ~19 ~-162 ~-6 ~26 ~-161 minecraft:stone_bricks
fill ~-7 ~19 ~-25 ~7 ~22 ~-25 minecraft:stone_bricks
fill ~-7 ~21 ~-159 ~-6 ~26 ~-158 minecraft:stone_bricks
fill ~-7 ~22 ~-160 ~-5 ~26 ~-160 minecraft:stone_bricks
setblock ~-7 ~23 ~-25 minecraft:stone_bricks
fill ~-7 ~24 ~-27 ~9 ~24 ~-26 minecraft:stone_bricks
fill ~-7 ~26 ~-164 ~7 ~26 ~-156 minecraft:stone_bricks
fill ~-7 ~27 ~-164 ~-7 ~27 ~-163 minecraft:stone_bricks
fill ~-7 ~27 ~-157 ~-5 ~27 ~-157 minecraft:stone_bricks
setblock ~-7 ~27 ~-156 minecraft:stone_bricks
setblock ~-7 ~28 ~-163 minecraft:stone_bricks
setblock ~-7 ~28 ~-157 minecraft:stone_bricks
fill ~-7 ~30 ~-35 ~-7 ~30 ~-25 minecraft:stone_bricks
fill ~-7 ~31 ~-35 ~-7 ~31 ~-33 minecraft:stone_bricks
fill ~-7 ~31 ~-27 ~-6 ~31 ~-27 minecraft:stone_bricks
fill ~-7 ~31 ~-26 ~-7 ~31 ~-25 minecraft:stone_bricks
setblock ~-7 ~32 ~-34 minecraft:stone_bricks
setblock ~-7 ~32 ~-26 minecraft:stone_bricks
fill ~-7 ~45 ~-119 ~-7 ~66 ~-117 minecraft:stone_bricks
setblock ~-7 ~46 ~-147 minecraft:stone_bricks
fill ~-7 ~46 ~-131 ~-5 ~66 ~-131 minecraft:stone_bricks
fill ~-7 ~66 ~-133 ~7 ~66 ~-115 minecraft:stone_bricks
fill ~-7 ~67 ~-133 ~-6 ~67 ~-133 minecraft:stone_bricks
fill ~-7 ~67 ~-115 ~-6 ~67 ~-115 minecraft:stone_bricks
setblock ~-7 ~68 ~-133 minecraft:stone_bricks
setblock ~-7 ~68 ~-115 minecraft:stone_bricks
fill ~-6 ~ ~-164 ~-4 ~26 ~-164 minecraft:stone_bricks
fill ~-6 ~ ~-163 ~-5 ~27 ~-163 minecraft:stone_bricks
fill ~-6 ~13 ~-26 ~9 ~25 ~-26 minecraft:stone_bricks
fill ~-6 ~18 ~-25 ~7 ~22 ~-25 minecraft:stone_bricks
fill ~-6 ~21 ~-160 ~-5 ~26 ~-160 minecraft:stone_bricks
fill ~-6 ~21 ~-157 ~-5 ~26 ~-156 minecraft:stone_bricks
fill ~-6 ~24 ~-32 ~8 ~24 ~-26 minecraft:stone_bricks
fill ~-6 ~26 ~-166 ~6 ~26 ~-154 minecraft:stone_bricks
setblock ~-6 ~26 ~-40 minecraft:stone_bricks
fill ~-6 ~27 ~-166 ~-5 ~27 ~-166 minecraft:stone_bricks
setblock ~-6 ~27 ~-165 minecraft:stone_bricks
fill ~-6 ~27 ~-155 ~-6 ~27 ~-154 minecraft:stone_bricks
setblock ~-6 ~28 ~-166 minecraft:stone_bricks
setblock ~-6 ~28 ~-154 minecraft:stone_bricks
fill ~-6 ~31 ~-33 ~-6 ~31 ~-32 minecraft:stone_bricks
fill ~-6 ~31 ~-28 ~-6 ~31 ~-27 minecraft:stone_bricks
setblock ~-6 ~32 ~-33 minecraft:stone_bricks
setblock ~-6 ~32 ~-27 minecraft:stone_bricks
fill ~-6 ~45 ~-132 ~-3 ~66 ~-132 minecraft:stone_bricks
fill ~-6 ~45 ~-131 ~-5 ~66 ~-131 minecraft:stone_bricks
fill ~-6 ~45 ~-117 ~-5 ~66 ~-116 minecraft:stone_bricks
fill ~-5 ~ ~-165 ~-3 ~26 ~-165 minecraft:stone_bricks
fill ~-5 ~ ~-157 ~-5 ~2 ~-154 minecraft:stone_bricks
fill ~-5 ~3 ~-157 ~-5 ~18 ~-155 minecraft:stone_bricks
fill ~-5 ~19 ~-155 ~-3 ~26 ~-155 minecraft:stone_bricks
setblock ~-5 ~23 ~-25 minecraft:stone_bricks
setblock ~-5 ~27 ~-154 minecraft:stone_bricks
fill ~-5 ~45 ~-133 ~5 ~66 ~-133 minecraft:stone_bricks
fill ~-5 ~45 ~-115 ~-2 ~66 ~-115 minecraft:stone_bricks
setblock ~-5 ~46 ~-101 minecraft:stone_bricks
fill ~-5 ~66 ~-134 ~5 ~66 ~-114 minecraft:stone_bricks
fill ~-5 ~67 ~-114 ~-4 ~67 ~-114 minecraft:stone_bricks
fill ~-4 ~ ~-166 ~6 ~2 ~-166 minecraft:stone_bricks
fill ~-4 ~ ~-155 ~-3 ~2 ~-153 minecraft:stone_bricks
fill ~-4 ~3 ~-166 ~4 ~26 ~-166 minecraft:stone_bricks
fill ~-4 ~3 ~-155 ~-3 ~26 ~-154 minecraft:stone_bricks
fill ~-4 ~9 ~-40 ~-4 ~12 ~-26 minecraft:stone_bricks
fill ~-4 ~21 ~-156 ~-4 ~26 ~-154 minecraft:stone_bricks
fill ~-4 ~26 ~-167 ~4 ~26 ~-153 minecraft:stone_bricks
setblock ~-4 ~26 ~-40 minecraft:stone_bricks
setblock ~-4 ~26 ~-26 minecraft:stone_bricks
fill ~-4 ~27 ~-167 ~-3 ~27 ~-167 minecraft:stone_bricks
fill ~-4 ~27 ~-153 ~-3 ~27 ~-153 minecraft:stone_bricks
fill ~-4 ~46 ~-116 ~-3 ~66 ~-115 minecraft:stone_bricks
fill ~-4 ~67 ~-134 ~-4 ~67 ~-132 minecraft:stone_bricks
fill ~-3 ~6 ~-103 ~-3 ~44 ~-102 minecraft:stone_bricks
fill ~-3 ~10 ~-40 ~-3 ~12 ~-26 minecraft:stone_bricks
setblock ~-3 ~23 ~-25 minecraft:stone_bricks
setblock ~-3 ~28 ~-167 minecraft:stone_bricks
setblock ~-3 ~28 ~-153 minecraft:stone_bricks
fill ~-3 ~45 ~-134 ~3 ~66 ~-133 minecraft:stone_bricks
fill ~-3 ~45 ~-116 ~-3 ~66 ~-114 minecraft:stone_bricks
fill ~-3 ~46 ~-147 ~-3 ~47 ~-147 minecraft:stone_bricks
fill ~-3 ~66 ~-135 ~3 ~66 ~-113 minecraft:stone_bricks
fill ~-3 ~67 ~-113 ~-2 ~67 ~-113 minecraft:stone_bricks
fill ~-2 ~ ~-167 ~4 ~2 ~-166 minecraft:stone_bricks
fill ~-2 ~ ~-153 ~-2 ~2 ~-152 minecraft:stone_bricks
fill ~-2 ~1 ~-154 ~-2 ~2 ~-152 minecraft:stone_bricks
fill ~-2 ~3 ~-167 ~2 ~26 ~-166 minecraft:stone_bricks
fill ~-2 ~3 ~-154 ~4 ~26 ~-154 minecraft:stone_bricks
fill ~-2 ~3 ~-153 ~2 ~26 ~-153 minecraft:stone_bricks
fill ~-2 ~10 ~-145 ~32 ~13 ~-145 minecraft:stone_bricks
fill ~-2 ~11 ~-40 ~9 ~12 ~-33 minecraft:stone_bricks
fill ~-2 ~11 ~-31 ~8 ~12 ~-26 minecraft:stone_bricks
fill ~-2 ~14 ~-145 ~5 ~15 ~-144 minecraft:stone_bricks
fill ~-2 ~14 ~-103 ~5 ~44 ~-102 minecraft:stone_bricks
fill ~-2 ~16 ~-145 ~5 ~44 ~-145 minecraft:stone_bricks
fill ~-2 ~26 ~-168 ~2 ~26 ~-152 minecraft:stone_bricks
setblock ~-2 ~26 ~-40 minecraft:stone_bricks
setblock ~-2 ~26 ~-26 minecraft:stone_bricks
fill ~-2 ~27 ~-168 ~2 ~27 ~-168 minecraft:stone_bricks
fill ~-2 ~27 ~-152 ~-2 ~28 ~-152 minecraft:stone_bricks
setblock ~-2 ~28 ~-168 minecraft:stone_bricks
fill ~-2 ~45 ~-114 ~-2 ~66 ~-114 minecraft:stone_bricks
fill ~-1 ~8 ~-102 ~32 ~44 ~-102 minecraft:stone_bricks
fill ~-1 ~9 ~-103 ~32 ~13 ~-102 minecraft:stone_bricks
setblock ~-1 ~23 ~-25 minecraft:stone_bricks
setblock ~-1 ~46 ~-147 minecraft:stone_bricks
fill ~-1 ~48 ~-115 ~5 ~66 ~-115 minecraft:stone_bricks
fill ~-1 ~48 ~-114 ~3 ~66 ~-114 minecraft:stone_bricks
fill ~-1 ~67 ~-135 ~3 ~67 ~-135 minecraft:stone_bricks
setblock ~-1 ~68 ~-135 minecraft:stone_bricks
fill ~ ~8 ~-103 ~32 ~13 ~-102 minecraft:stone_bricks
fill ~ ~11 ~-32 ~8 ~12 ~-26 minecraft:stone_bricks
fill ~ ~25 ~-124 ~24 ~33 ~-124 minecraft:stone_bricks
setblock ~ ~26 ~-40 minecraft:stone_bricks
setblock ~ ~26 ~-26 minecraft:stone_bricks
setblock ~ ~28 ~-168 minecraft:stone_bricks
fill ~1 ~23 ~-124 ~26 ~24 ~-124 minecraft:stone_bricks
setblock ~1 ~46 ~-147 minecraft:stone_bricks
setblock ~1 ~46 ~-101 minecraft:stone_bricks
setblock ~1 ~68 ~-135 minecraft:stone_bricks
fill ~2 ~ ~-154 ~6 ~2 ~-154 minecraft:stone_bricks
fill ~2 ~ ~-153 ~4 ~2 ~-153 minecraft:stone_bricks
fill ~2 ~7 ~-103 ~32 ~13 ~-102 minecraft:stone_bricks
setblock ~2 ~26 ~-40 minecraft:stone_bricks
setblock ~2 ~28 ~-168 minecraft:stone_bricks
setblock ~2 ~28 ~-152 minecraft:stone_bricks
fill ~2 ~45 ~-114 ~3 ~66 ~-114 minecraft:stone_bricks
fill ~2 ~46 ~-115 ~5 ~66 ~-115 minecraft:stone_bricks
fill ~2 ~67 ~-113 ~3 ~67 ~-113 minecraft:stone_bricks
fill ~3 ~ ~-165 ~6 ~2 ~-165 minecraft:stone_bricks
fill ~3 ~ ~-155 ~6 ~2 ~-154 minecraft:stone_bricks
fill ~3 ~3 ~-165 ~5 ~26 ~-165 minecraft:stone_bricks
fill ~3 ~3 ~-155 ~5 ~26 ~-155 minecraft:stone_bricks
fill ~3 ~3 ~-145 ~5 ~44 ~-145 minecraft:stone_bricks
fill ~3 ~6 ~-102 ~32 ~44 ~-102 minecraft:stone_bricks
fill ~3 ~10 ~-40 ~9 ~12 ~-33 minecraft:stone_bricks
fill ~3 ~10 ~-32 ~8 ~12 ~-26 minecraft:stone_bricks
setblock ~3 ~23 ~-25 minecraft:stone_bricks
fill ~3 ~27 ~-167 ~4 ~27 ~-167 minecraft:stone_bricks
fill ~3 ~27 ~-153 ~4 ~27 ~-153 minecraft:stone_bricks
setblock ~3 ~28 ~-167 minecraft:stone_bricks
setblock ~3 ~28 ~-153 minecraft:stone_bricks
fill ~3 ~45 ~-132 ~6 ~66 ~-132 minecraft:stone_bricks
fill ~3 ~45 ~-116 ~6 ~66 ~-116 minecraft:stone_bricks
fill ~3 ~45 ~-115 ~5 ~66 ~-115 minecraft:stone_bricks
fill ~3 ~46 ~-147 ~3 ~47 ~-147 minecraft:stone_bricks
setblock ~3 ~68 ~-135 minecraft:stone_bricks
setblock ~3 ~68 ~-113 minecraft:stone_bricks
fill ~4 ~ ~-164 ~7 ~2 ~-164 minecraft:stone_bricks
fill ~4 ~ ~-156 ~55 ~18 ~-156 minecraft:stone_bricks
fill ~4 ~ ~-103 ~33 ~1 ~-101 minecraft:stone_bricks
fill ~4 ~2 ~-103 ~5 ~2 ~-101 minecraft:stone_bricks
fill ~4 ~3 ~-164 ~6 ~26 ~-164 minecraft:stone_bricks
fill ~4 ~3 ~-103 ~5 ~44 ~-102 minecraft:stone_bricks
fill ~4 ~9 ~-40 ~9 ~9 ~-26 minecraft:stone_bricks
fill ~4 ~21 ~-156 ~6 ~26 ~-156 minecraft:stone_bricks
setblock ~4 ~26 ~-40 minecraft:stone_bricks
setblock ~4 ~26 ~-26 minecraft:stone_bricks
fill ~4 ~67 ~-134 ~5 ~67 ~-134 minecraft:stone_bricks
fill ~4 ~67 ~-114 ~5 ~67 ~-114 minecraft:stone_bricks
setblock ~4 ~68 ~-134 minecraft:stone_bricks
setblock ~4 ~68 ~-114 minecraft:stone_bricks
fill ~5 ~ ~-163 ~7 ~2 ~-163 minecraft:stone_bricks
fill ~5 ~ ~-157 ~54 ~18 ~-156 minecraft:stone_bricks
fill ~5 ~ ~-74 ~9 ~ ~-70 minecraft:stone_bricks
fill ~5 ~3 ~-163 ~6 ~27 ~-163 minecraft:stone_bricks
fill ~5 ~3 ~-40 ~9 ~12 ~-33 minecraft:stone_bricks
fill ~5 ~3 ~-32 ~8 ~12 ~-26 minecraft:stone_bricks
fill ~5 ~21 ~-157 ~6 ~26 ~-156 minecraft:stone_bricks
setblock ~5 ~23 ~-25 minecraft:stone_bricks
fill ~5 ~27 ~-166 ~6 ~27 ~-166 minecraft:stone_bricks
fill ~5 ~27 ~-154 ~6 ~27 ~-154 minecraft:stone_bricks
fill ~5 ~45 ~-131 ~7 ~66 ~-131 minecraft:stone_bricks
fill ~5 ~45 ~-117 ~7 ~66 ~-117 minecraft:stone_bricks
setblock ~5 ~46 ~-147 minecraft:stone_bricks
fill ~6 ~ ~-162 ~8 ~2 ~-156 minecraft:stone_bricks
fill ~6 ~3 ~-162 ~7 ~18 ~-156 minecraft:stone_bricks
fill ~6 ~7 ~-145 ~32 ~13 ~-145 minecraft:stone_bricks
fill ~6 ~19 ~-162 ~7 ~26 ~-161 minecraft:stone_bricks
fill ~6 ~21 ~-160 ~7 ~26 ~-158 minecraft:stone_bricks
setblock ~6 ~26 ~-40 minecraft:stone_bricks
setblock ~6 ~26 ~-26 minecraft:stone_bricks
setblock ~6 ~27 ~-165 minecraft:stone_bricks
fill ~6 ~27 ~-155 ~6 ~27 ~-154 minecraft:stone_bricks
setblock ~6 ~28 ~-166 minecraft:stone_bricks
fill ~6 ~30 ~-33 ~24 ~30 ~-27 minecraft:stone_bricks
fill ~6 ~31 ~-33 ~9 ~31 ~-33 minecraft:stone_bricks
setblock ~6 ~31 ~-32 minecraft:stone_bricks
fill ~6 ~31 ~-28 ~6 ~31 ~-27 minecraft:stone_bricks
setblock ~6 ~32 ~-33 minecraft:stone_bricks
setblock ~6 ~32 ~-27 minecraft:stone_bricks
fill ~6 ~67 ~-115 ~7 ~67 ~-115 minecraft:stone_bricks
fill ~7 ~ ~-32 ~8 ~2 ~-25 minecraft:stone_bricks
fill ~7 ~1 ~-72 ~7 ~2 ~-72 minecraft:stone_bricks
fill ~7 ~2 ~-145 ~11 ~44 ~-145 minecraft:stone_bricks
fill ~7 ~2 ~-103 ~11 ~2 ~-101 minecraft:stone_bricks
fill ~7 ~3 ~-103 ~11 ~44 ~-102 minecraft:stone_bricks
fill ~7 ~13 ~-30 ~9 ~30 ~-30 minecraft:stone_bricks
fill ~7 ~13 ~-29 ~8 ~30 ~-28 minecraft:stone_bricks
fill ~7 ~14 ~-32 ~8 ~30 ~-28 minecraft:stone_bricks
fill ~7 ~27 ~-164 ~7 ~27 ~-163 minecraft:stone_bricks
setblock ~7 ~27 ~-156 minecraft:stone_bricks
setblock ~7 ~28 ~-157 minecraft:stone_bricks
fill ~7 ~30 ~-35 ~23 ~30 ~-25 minecraft:stone_bricks
fill ~7 ~31 ~-35 ~10 ~31 ~-35 minecraft:stone_bricks
fill ~7 ~31 ~-34 ~7 ~31 ~-33 minecraft:stone_bricks
fill ~7 ~31 ~-27 ~9 ~31 ~-27 minecraft:stone_bricks
fill ~7 ~31 ~-25 ~10 ~31 ~-25 minecraft:stone_bricks
setblock ~7 ~32 ~-34 minecraft:stone_bricks
fill ~7 ~45 ~-129 ~9 ~66 ~-129 minecraft:stone_bricks
fill ~7 ~45 ~-119 ~9 ~66 ~-119 minecraft:stone_bricks
setblock ~7 ~46 ~-147 minecraft:stone_bricks
fill ~7 ~46 ~-130 ~8 ~66 ~-129 minecraft:stone_bricks
fill ~7 ~46 ~-118 ~8 ~66 ~-118 minecraft:stone_bricks
fill ~7 ~67 ~-133 ~7 ~67 ~-130 minecraft:stone_bricks
fill ~7 ~67 ~-116 ~8 ~67 ~-116 minecraft:stone_bricks
setblock ~7 ~68 ~-115 minecraft:stone_bricks
fill ~8 ~ ~-34 ~9 ~30 ~-33 minecraft:stone_bricks
fill ~8 ~3 ~-160 ~54 ~5 ~-156 minecraft:stone_bricks
fill ~8 ~6 ~-160 ~11 ~18 ~-156 minecraft:stone_bricks
fill ~8 ~13 ~-31 ~8 ~30 ~-26 minecraft:stone_bricks
fill ~8 ~17 ~-161 ~54 ~18 ~-156 minecraft:stone_bricks
fill ~8 ~19 ~-161 ~54 ~19 ~-161 minecraft:stone_bricks
setblock ~8 ~26 ~-40 minecraft:stone_bricks
fill ~8 ~27 ~-162 ~8 ~27 ~-158 minecraft:stone_bricks
setblock ~8 ~28 ~-160 minecraft:stone_bricks
setblock ~8 ~28 ~-158 minecraft:stone_bricks
fill ~8 ~30 ~-36 ~22 ~30 ~-24 minecraft:stone_bricks
fill ~8 ~31 ~-36 ~8 ~31 ~-35 minecraft:stone_bricks
setblock ~8 ~32 ~-35 minecraft:stone_bricks
fill ~8 ~45 ~-130 ~8 ~66 ~-127 minecraft:stone_bricks
fill ~8 ~45 ~-121 ~10 ~66 ~-121 minecraft:stone_bricks
fill ~8 ~45 ~-120 ~9 ~66 ~-119 minecraft:stone_bricks
fill ~8 ~45 ~-118 ~8 ~66 ~-118 minecraft:stone_bricks
fill ~8 ~67 ~-131 ~9 ~67 ~-131 minecraft:stone_bricks
fill ~8 ~67 ~-117 ~9 ~67 ~-117 minecraft:stone_bricks
setblock ~8 ~68 ~-132 minecraft:stone_bricks
setblock ~8 ~68 ~-116 minecraft:stone_bricks
fill ~9 ~ ~-160 ~54 ~5 ~-156 minecraft:stone_bricks
fill ~9 ~ ~-36 ~12 ~30 ~-36 minecraft:stone_bricks
fill ~9 ~ ~-35 ~10 ~31 ~-35 minecraft:stone_bricks
fill ~9 ~ ~-27 ~9 ~2 ~-23 minecraft:stone_bricks
fill ~9 ~3 ~-27 ~9 ~30 ~-24 minecraft:stone_bricks
fill ~9 ~13 ~-37 ~9 ~26 ~-33 minecraft:stone_bricks
fill ~9 ~14 ~-39 ~9 ~25 ~-33 minecraft:stone_bricks
fill ~9 ~20 ~-161 ~9 ~21 ~-161 minecraft:stone_bricks
fill ~9 ~30 ~-37 ~21 ~30 ~-23 minecraft:stone_bricks
fill ~9 ~31 ~-37 ~10 ~31 ~-37 minecraft:stone_bricks
fill ~9 ~45 ~-128 ~9 ~66 ~-119 minecraft:stone_bricks
fill ~9 ~46 ~-147 ~9 ~47 ~-147 minecraft:stone_bricks
setblock ~9 ~46 ~-101 minecraft:stone_bricks
fill ~9 ~67 ~-118 ~9 ~67 ~-117 minecraft:stone_bricks
setblock ~9 ~68 ~-131 minecraft:stone_bricks
setblock ~9 ~68 ~-117 minecraft:stone_bricks
fill ~10 ~ ~-25 ~10 ~2 ~-22 minecraft:stone_bricks
fill ~10 ~3 ~-25 ~10 ~31 ~-24 minecraft:stone_bricks
fill ~10 ~30 ~-38 ~20 ~30 ~-22 minecraft:stone_bricks
fill ~10 ~31 ~-38 ~12 ~31 ~-38 minecraft:stone_bricks
fill ~10 ~31 ~-23 ~10 ~31 ~-22 minecraft:stone_bricks
setblock ~10 ~32 ~-37 minecraft:stone_bricks
setblock ~10 ~32 ~-23 minecraft:stone_bricks
fill ~10 ~45 ~-127 ~10 ~66 ~-121 minecraft:stone_bricks
fill ~10 ~67 ~-129 ~10 ~67 ~-128 minecraft:stone_bricks
fill ~10 ~67 ~-120 ~10 ~67 ~-119 minecraft:stone_bricks
setblock ~10 ~68 ~-120 minecraft:stone_bricks
fill ~11 ~ ~-144 ~11 ~44 ~-138 minecraft:stone_bricks
fill ~11 ~ ~-134 ~11 ~22 ~-118 minecraft:stone_bricks
fill ~11 ~ ~-113 ~11 ~2 ~-101 minecraft:stone_bricks
fill ~11 ~ ~-37 ~32 ~6 ~-37 minecraft:stone_bricks
fill ~11 ~ ~-24 ~12 ~2 ~-22 minecraft:stone_bricks
fill ~11 ~1 ~-114 ~11 ~2 ~-101 minecraft:stone_bricks
fill ~11 ~3 ~-114 ~11 ~22 ~-102 minecraft:stone_bricks
fill ~11 ~3 ~-24 ~12 ~30 ~-23 minecraft:stone_bricks
fill ~11 ~4 ~-137 ~11 ~22 ~-102 minecraft:stone_bricks
fill ~11 ~7 ~-37 ~19 ~30 ~-37 minecraft:stone_bricks
setblock ~11 ~20 ~-161 minecraft:stone_bricks
fill ~11 ~23 ~-137 ~11 ~44 ~-135 minecraft:stone_bricks
fill ~11 ~23 ~-133 ~11 ~33 ~-115 minecraft:stone_bricks
fill ~11 ~23 ~-113 ~11 ~44 ~-102 minecraft:stone_bricks
fill ~11 ~25 ~-134 ~11 ~33 ~-102 minecraft:stone_bricks
setblock ~11 ~32 ~-38 minecraft:stone_bricks
setblock ~11 ~32 ~-22 minecraft:stone_bricks
fill ~11 ~34 ~-134 ~11 ~44 ~-126 minecraft:stone_bricks
fill ~11 ~34 ~-122 ~11 ~44 ~-102 minecraft:stone_bricks
fill ~11 ~38 ~-125 ~11 ~44 ~-102 minecraft:stone_bricks
setblock ~11 ~46 ~-147 minecraft:stone_bricks
fill ~11 ~46 ~-101 ~11 ~47 ~-101 minecraft:stone_bricks
fill ~11 ~67 ~-127 ~11 ~67 ~-121 minecraft:stone_bricks
setblock ~11 ~68 ~-127 minecraft:stone_bricks
setblock ~11 ~68 ~-125 minecraft:stone_bricks
setblock ~11 ~68 ~-123 minecraft:stone_bricks
setblock ~11 ~68 ~-121 minecraft:stone_bricks
fill ~12 ~ ~-125 ~27 ~2 ~-125 minecraft:stone_bricks
fill ~12 ~3 ~-125 ~26 ~11 ~-125 minecraft:stone_bricks
fill ~12 ~6 ~-159 ~75 ~6 ~-157 minecraft:stone_bricks
fill ~12 ~7 ~-158 ~54 ~18 ~-156 minecraft:stone_bricks
fill ~12 ~8 ~-159 ~54 ~18 ~-156 minecraft:stone_bricks
fill ~12 ~10 ~-160 ~54 ~18 ~-156 minecraft:stone_bricks
fill ~12 ~30 ~-39 ~18 ~30 ~-21 minecraft:stone_bricks
fill ~12 ~31 ~-22 ~12 ~31 ~-21 minecraft:stone_bricks
setblock ~12 ~32 ~-21 minecraft:stone_bricks
fill ~13 ~ ~-38 ~32 ~4 ~-37 minecraft:stone_bricks
fill ~13 ~ ~-23 ~21 ~2 ~-23 minecraft:stone_bricks
fill ~13 ~ ~-22 ~20 ~2 ~-22 minecraft:stone_bricks
fill ~13 ~2 ~-145 ~17 ~44 ~-145 minecraft:stone_bricks
fill ~13 ~2 ~-103 ~17 ~2 ~-101 minecraft:stone_bricks
fill ~13 ~3 ~-103 ~17 ~44 ~-102 minecraft:stone_bricks
fill ~13 ~3 ~-23 ~19 ~30 ~-23 minecraft:stone_bricks
fill ~13 ~3 ~-22 ~17 ~30 ~-22 minecraft:stone_bricks
fill ~13 ~5 ~-38 ~17 ~30 ~-37 minecraft:stone_bricks
fill ~13 ~6 ~-160 ~19 ~18 ~-156 minecraft:stone_bricks
setblock ~13 ~20 ~-161 minecraft:stone_bricks
fill ~13 ~31 ~-39 ~18 ~31 ~-39 minecraft:stone_bricks
fill ~13 ~31 ~-21 ~18 ~31 ~-21 minecraft:stone_bricks
setblock ~13 ~46 ~-147 minecraft:stone_bricks
setblock ~13 ~46 ~-101 minecraft:stone_bricks
setblock ~14 ~32 ~-39 minecraft:stone_bricks
setblock ~15 ~20 ~-161 minecraft:stone_bricks
fill ~15 ~46 ~-147 ~15 ~47 ~-147 minecraft:stone_bricks
setblock ~15 ~46 ~-101 minecraft:stone_bricks
setblock ~16 ~32 ~-39 minecraft:stone_bricks
setblock ~16 ~32 ~-21 minecraft:stone_bricks
fill ~17 ~20 ~-161 ~17 ~21 ~-161 minecraft:stone_bricks
setblock ~17 ~46 ~-147 minecraft:stone_bricks
fill ~17 ~46 ~-101 ~17 ~47 ~-101 minecraft:stone_bricks
fill ~18 ~ ~-36 ~55 ~18 ~-36 minecraft:stone_bricks
fill ~18 ~ ~-24 ~22 ~2 ~-24 minecraft:stone_bricks
fill ~18 ~3 ~-24 ~21 ~30 ~-24 minecraft:stone_bricks
fill ~18 ~21 ~-36 ~21 ~30 ~-36 minecraft:stone_bricks
fill ~18 ~31 ~-38 ~20 ~31 ~-38 minecraft:stone_bricks
fill ~18 ~31 ~-22 ~20 ~31 ~-22 minecraft:stone_bricks
setblock ~18 ~32 ~-39 minecraft:stone_bricks
setblock ~18 ~32 ~-21 minecraft:stone_bricks
fill ~19 ~3 ~-145 ~32 ~44 ~-145 minecraft:stone_bricks
fill ~19 ~3 ~-103 ~32 ~44 ~-102 minecraft:stone_bricks
setblock ~19 ~20 ~-161 minecraft:stone_bricks
setblock ~19 ~32 ~-38 minecraft:stone_bricks
setblock ~19 ~32 ~-22 minecraft:stone_bricks
fill ~19 ~46 ~-147 ~32 ~46 ~-147 minecraft:stone_bricks
fill ~19 ~46 ~-101 ~32 ~46 ~-101 minecraft:stone_bricks
fill ~19 ~52 ~-148 ~33 ~52 ~-144 minecraft:stone_bricks
fill ~19 ~52 ~-104 ~33 ~52 ~-100 minecraft:stone_bricks
fill ~19 ~53 ~-148 ~19 ~53 ~-144 minecraft:stone_bricks
fill ~19 ~53 ~-104 ~19 ~53 ~-100 minecraft:stone_bricks
setblock ~19 ~54 ~-147 minecraft:stone_bricks
setblock ~19 ~54 ~-145 minecraft:stone_bricks
setblock ~19 ~54 ~-103 minecraft:stone_bricks
fill ~20 ~ ~-148 ~33 ~2 ~-145 minecraft:stone_bricks
fill ~20 ~ ~-100 ~33 ~2 ~-100 minecraft:stone_bricks
fill ~20 ~ ~-35 ~54 ~18 ~-35 minecraft:stone_bricks
fill ~20 ~ ~-25 ~23 ~2 ~-25 minecraft:stone_bricks
fill ~20 ~2 ~-103 ~33 ~2 ~-100 minecraft:stone_bricks
fill ~20 ~3 ~-147 ~32 ~52 ~-145 minecraft:stone_bricks
fill ~20 ~3 ~-101 ~32 ~52 ~-100 minecraft:stone_bricks
fill ~20 ~3 ~-25 ~21 ~30 ~-24 minecraft:stone_bricks
fill ~20 ~4 ~-148 ~32 ~52 ~-145 minecraft:stone_bricks
fill ~20 ~5 ~-38 ~32 ~6 ~-35 minecraft:stone_bricks
fill ~20 ~7 ~-159 ~54 ~18 ~-156 minecraft:stone_bricks
fill ~20 ~21 ~-35 ~21 ~31 ~-35 minecraft:stone_bricks
fill ~20 ~31 ~-23 ~21 ~31 ~-23 minecraft:stone_bricks
setblock ~20 ~32 ~-37 minecraft:stone_bricks
setblock ~20 ~32 ~-23 minecraft:stone_bricks
fill ~20 ~45 ~-144 ~32 ~52 ~-144 minecraft:stone_bricks
fill ~20 ~45 ~-104 ~32 ~52 ~-100 minecraft:stone_bricks
fill ~20 ~52 ~-150 ~32 ~52 ~-142 minecraft:stone_bricks
fill ~20 ~52 ~-106 ~32 ~52 ~-98 minecraft:stone_bricks
fill ~20 ~53 ~-150 ~20 ~53 ~-149 minecraft:stone_bricks
fill ~20 ~53 ~-142 ~20 ~54 ~-142 minecraft:stone_bricks
fill ~20 ~53 ~-106 ~20 ~53 ~-105 minecraft:stone_bricks
fill ~20 ~53 ~-99 ~22 ~53 ~-99 minecraft:stone_bricks
fill ~20 ~53 ~-98 ~20 ~54 ~-98 minecraft:stone_bricks
setblock ~20 ~54 ~-150 minecraft:stone_bricks
setblock ~20 ~54 ~-106 minecraft:stone_bricks
fill ~21 ~ ~-150 ~32 ~2 ~-145 minecraft:stone_bricks
fill ~21 ~ ~-99 ~32 ~2 ~-98 minecraft:stone_bricks
fill ~21 ~ ~-34 ~54 ~18 ~-33 minecraft:stone_bricks
fill ~21 ~ ~-27 ~24 ~2 ~-27 minecraft:stone_bricks
fill ~21 ~ ~-26 ~23 ~2 ~-25 minecraft:stone_bricks
fill ~21 ~3 ~-150 ~31 ~52 ~-145 minecraft:stone_bricks
fill ~21 ~3 ~-99 ~31 ~52 ~-98 minecraft:stone_bricks
fill ~21 ~3 ~-27 ~22 ~30 ~-26 minecraft:stone_bricks
fill ~21 ~6 ~-160 ~27 ~18 ~-156 minecraft:stone_bricks
setblock ~21 ~20 ~-161 minecraft:stone_bricks
fill ~21 ~21 ~-33 ~22 ~31 ~-33 minecraft:stone_bricks
fill ~21 ~22 ~-34 ~22 ~30 ~-33 minecraft:stone_bricks
setblock ~21 ~31 ~-37 minecraft:stone_bricks
fill ~21 ~45 ~-143 ~31 ~52 ~-142 minecraft:stone_bricks
fill ~21 ~45 ~-106 ~31 ~52 ~-98 minecraft:stone_bricks
fill ~21 ~52 ~-151 ~31 ~52 ~-141 minecraft:stone_bricks
fill ~21 ~52 ~-107 ~31 ~52 ~-97 minecraft:stone_bricks
fill ~21 ~53 ~-151 ~21 ~54 ~-151 minecraft:stone_bricks
fill ~21 ~53 ~-141 ~21 ~54 ~-141 minecraft:stone_bricks
fill ~21 ~53 ~-107 ~21 ~54 ~-107 minecraft:stone_bricks
fill ~21 ~53 ~-97 ~21 ~54 ~-97 minecraft:stone_bricks
fill ~22 ~ ~-151 ~31 ~2 ~-145 minecraft:stone_bricks
fill ~22 ~ ~-97 ~31 ~2 ~-97 minecraft:stone_bricks
fill ~22 ~ ~-32 ~54 ~2 ~-31 minecraft:stone_bricks
fill ~22 ~ ~-30 ~24 ~2 ~-27 minecraft:stone_bricks
fill ~22 ~3 ~-151 ~30 ~52 ~-145 minecraft:stone_bricks
fill ~22 ~3 ~-97 ~30 ~52 ~-97 minecraft:stone_bricks
fill ~22 ~3 ~-32 ~54 ~5 ~-32 minecraft:stone_bricks
fill ~22 ~3 ~-30 ~23 ~30 ~-28 minecraft:stone_bricks
fill ~22 ~4 ~-31 ~23 ~30 ~-28 minecraft:stone_bricks
fill ~22 ~6 ~-32 ~27 ~18 ~-32 minecraft:stone_bricks
fill ~22 ~7 ~-37 ~32 ~8 ~-33 minecraft:stone_bricks
fill ~22 ~21 ~-34 ~22 ~30 ~-26 minecraft:stone_bricks
fill ~22 ~31 ~-36 ~22 ~31 ~-35 minecraft:stone_bricks
fill ~22 ~31 ~-25 ~23 ~31 ~-25 minecraft:stone_bricks
setblock ~22 ~32 ~-35 minecraft:stone_bricks
setblock ~22 ~32 ~-25 minecraft:stone_bricks
fill ~22 ~45 ~-141 ~30 ~52 ~-141 minecraft:stone_bricks
fill ~22 ~45 ~-107 ~30 ~52 ~-97 minecraft:stone_bricks
fill ~22 ~52 ~-152 ~30 ~52 ~-140 minecraft:stone_bricks
fill ~22 ~52 ~-108 ~30 ~52 ~-96 minecraft:stone_bricks
fill ~22 ~53 ~-152 ~23 ~53 ~-152 minecraft:stone_bricks
fill ~22 ~53 ~-140 ~23 ~53 ~-140 minecraft:stone_bricks
fill ~22 ~53 ~-108 ~23 ~53 ~-108 minecraft:stone_bricks
fill ~22 ~53 ~-96 ~23 ~53 ~-96 minecraft:stone_bricks
setblock ~22 ~54 ~-152 minecraft:stone_bricks
setblock ~22 ~54 ~-140 minecraft:stone_bricks
setblock ~22 ~54 ~-108 minecraft:stone_bricks
setblock ~22 ~54 ~-96 minecraft:stone_bricks
fill ~23 ~3 ~-31 ~23 ~30 ~-28 minecraft:stone_bricks
fill ~23 ~7 ~-38 ~32 ~9 ~-33 minecraft:stone_bricks
setblock ~23 ~20 ~-161 minecraft:stone_bricks
fill ~23 ~21 ~-32 ~23 ~30 ~-28 minecraft:stone_bricks
fill ~23 ~31 ~-35 ~23 ~31 ~-33 minecraft:stone_bricks
fill ~23 ~31 ~-27 ~24 ~31 ~-27 minecraft:stone_bricks
fill ~23 ~31 ~-26 ~23 ~31 ~-25 minecraft:stone_bricks
setblock ~23 ~32 ~-34 minecraft:stone_bricks
setblock ~23 ~32 ~-26 minecraft:stone_bricks
fill ~24 ~ ~-152 ~30 ~2 ~-145 minecraft:stone_bricks
fill ~24 ~ ~-96 ~30 ~2 ~-96 minecraft:stone_bricks
fill ~24 ~3 ~-152 ~28 ~52 ~-145 minecraft:stone_bricks
fill ~24 ~3 ~-96 ~28 ~52 ~-96 minecraft:stone_bricks
fill ~24 ~17 ~-31 ~54 ~19 ~-31 minecraft:stone_bricks
fill ~24 ~31 ~-33 ~24 ~31 ~-27 minecraft:stone_bricks
setblock ~24 ~32 ~-33 minecraft:stone_bricks
setblock ~24 ~32 ~-31 minecraft:stone_bricks
setblock ~24 ~32 ~-27 minecraft:stone_bricks
fill ~24 ~45 ~-140 ~28 ~52 ~-140 minecraft:stone_bricks
fill ~24 ~45 ~-108 ~28 ~52 ~-96 minecraft:stone_bricks
fill ~24 ~52 ~-153 ~28 ~52 ~-139 minecraft:stone_bricks
fill ~24 ~52 ~-109 ~28 ~52 ~-95 minecraft:stone_bricks
fill ~24 ~53 ~-153 ~28 ~53 ~-153 minecraft:stone_bricks
fill ~24 ~53 ~-139 ~28 ~53 ~-139 minecraft:stone_bricks
fill ~25 ~-27 ~-59 ~46 ~-16 ~-40 minecraft:stone_bricks
fill ~25 ~-15 ~-59 ~29 ~-1 ~-57 minecraft:stone_bricks
fill ~25 ~ ~-144 ~33 ~2 ~-144 minecraft:stone_bricks
fill ~25 ~ ~-143 ~32 ~1 ~-142 minecraft:stone_bricks
fill ~25 ~ ~-141 ~31 ~2 ~-141 minecraft:stone_bricks
fill ~25 ~ ~-140 ~30 ~2 ~-140 minecraft:stone_bricks
fill ~25 ~ ~-138 ~27 ~1 ~-95 minecraft:stone_bricks
fill ~25 ~2 ~-143 ~32 ~2 ~-143 minecraft:stone_bricks
fill ~25 ~2 ~-137 ~27 ~2 ~-137 minecraft:stone_bricks
fill ~25 ~2 ~-135 ~27 ~2 ~-131 minecraft:stone_bricks
fill ~25 ~2 ~-129 ~27 ~2 ~-125 minecraft:stone_bricks
fill ~25 ~2 ~-122 ~27 ~2 ~-119 minecraft:stone_bricks
fill ~25 ~2 ~-117 ~27 ~2 ~-113 minecraft:stone_bricks
fill ~25 ~2 ~-111 ~27 ~2 ~-107 minecraft:stone_bricks
fill ~25 ~2 ~-105 ~32 ~2 ~-98 minecraft:stone_bricks
fill ~25 ~3 ~-144 ~32 ~52 ~-144 minecraft:stone_bricks
fill ~25 ~3 ~-143 ~31 ~52 ~-143 minecraft:stone_bricks
fill ~25 ~3 ~-141 ~30 ~52 ~-141 minecraft:stone_bricks
fill ~25 ~3 ~-140 ~28 ~52 ~-140 minecraft:stone_bricks
fill ~25 ~3 ~-139 ~26 ~44 ~-137 minecraft:stone_bricks
fill ~25 ~3 ~-135 ~26 ~44 ~-131 minecraft:stone_bricks
fill ~25 ~3 ~-129 ~26 ~44 ~-125 minecraft:stone_bricks
fill ~25 ~3 ~-123 ~26 ~44 ~-119 minecraft:stone_bricks
fill ~25 ~3 ~-117 ~26 ~44 ~-113 minecraft:stone_bricks
fill ~25 ~3 ~-111 ~26 ~44 ~-107 minecraft:stone_bricks
fill ~25 ~3 ~-105 ~31 ~52 ~-98 minecraft:stone_bricks
fill ~25 ~7 ~-142 ~31 ~13 ~-142 minecraft:stone_bricks
fill ~25 ~7 ~-136 ~26 ~13 ~-96 minecraft:stone_bricks
fill ~25 ~10 ~-38 ~32 ~11 ~-32 minecraft:stone_bricks
fill ~25 ~19 ~-142 ~31 ~24 ~-142 minecraft:stone_bricks
fill ~25 ~19 ~-136 ~26 ~24 ~-96 minecraft:stone_bricks
fill ~25 ~20 ~-161 ~25 ~21 ~-161 minecraft:stone_bricks
setblock ~25 ~20 ~-31 minecraft:stone_bricks
fill ~25 ~30 ~-142 ~31 ~35 ~-142 minecraft:stone_bricks
fill ~25 ~30 ~-136 ~26 ~35 ~-96 minecraft:stone_bricks
fill ~25 ~41 ~-142 ~31 ~52 ~-142 minecraft:stone_bricks
fill ~25 ~41 ~-136 ~26 ~44 ~-96 minecraft:stone_bricks
fill ~25 ~53 ~-109 ~28 ~53 ~-109 minecraft:stone_bricks
setblock ~25 ~54 ~-153 minecraft:stone_bricks
setblock ~25 ~54 ~-139 minecraft:stone_bricks
setblock ~25 ~54 ~-109 minecraft:stone_bricks
setblock ~25 ~54 ~-95 minecraft:stone_bricks
fill ~26 ~2 ~-138 ~27 ~2 ~-95 minecraft:stone_bricks
fill ~26 ~53 ~-95 ~28 ~53 ~-95 minecraft:stone_bricks
fill ~27 ~2 ~-142 ~32 ~2 ~-142 minecraft:stone_bricks
fill ~27 ~3 ~-142 ~31 ~52 ~-142 minecraft:stone_bricks
fill ~27 ~3 ~-107 ~30 ~52 ~-97 minecraft:stone_bricks
fill ~27 ~4 ~-108 ~28 ~52 ~-96 minecraft:stone_bricks
fill ~27 ~12 ~-37 ~32 ~13 ~-32 minecraft:stone_bricks
setblock ~27 ~20 ~-161 minecraft:stone_bricks
setblock ~27 ~20 ~-31 minecraft:stone_bricks
fill ~27 ~45 ~-139 ~27 ~45 ~-96 minecraft:stone_bricks
setblock ~27 ~46 ~-139 minecraft:stone_bricks
setblock ~27 ~46 ~-137 minecraft:stone_bricks
fill ~27 ~46 ~-135 ~27 ~47 ~-135 minecraft:stone_bricks
setblock ~27 ~46 ~-133 minecraft:stone_bricks
setblock ~27 ~46 ~-131 minecraft:stone_bricks
fill ~27 ~46 ~-129 ~27 ~47 ~-129 minecraft:stone_bricks
setblock ~27 ~46 ~-127 minecraft:stone_bricks
setblock ~27 ~46 ~-125 minecraft:stone_bricks
setblock ~27 ~46 ~-119 minecraft:stone_bricks
fill ~27 ~46 ~-117 ~27 ~47 ~-117 minecraft:stone_bricks
setblock ~27 ~46 ~-115 minecraft:stone_bricks
setblock ~27 ~46 ~-113 minecraft:stone_bricks
fill ~27 ~46 ~-111 ~27 ~47 ~-111 minecraft:stone_bricks
fill ~27 ~46 ~-109 ~27 ~46 ~-96 minecraft:stone_bricks
setblock ~27 ~54 ~-139 minecraft:stone_bricks
setblock ~27 ~54 ~-109 minecraft:stone_bricks
setblock ~27 ~54 ~-95 minecraft:stone_bricks
fill ~28 ~ ~-108 ~30 ~2 ~-96 minecraft:stone_bricks
fill ~28 ~3 ~-108 ~28 ~52 ~-96 minecraft:stone_bricks
fill ~28 ~12 ~-38 ~32 ~14 ~-32 minecraft:stone_bricks
fill ~28 ~15 ~-32 ~54 ~18 ~-32 minecraft:stone_bricks
fill ~29 ~6 ~-32 ~35 ~18 ~-32 minecraft:stone_bricks
fill ~29 ~7 ~-160 ~35 ~18 ~-156 minecraft:stone_bricks
setblock ~29 ~20 ~-161 minecraft:stone_bricks
setblock ~29 ~20 ~-31 minecraft:stone_bricks
fill ~29 ~53 ~-152 ~30 ~53 ~-152 minecraft:stone_bricks
fill ~29 ~53 ~-140 ~30 ~53 ~-140 minecraft:stone_bricks
fill ~29 ~53 ~-108 ~30 ~53 ~-108 minecraft:stone_bricks
fill ~29 ~53 ~-96 ~30 ~53 ~-96 minecraft:stone_bricks
fill ~30 ~6 ~-160 ~35 ~18 ~-156 minecraft:stone_bricks
fill ~30 ~15 ~-38 ~32 ~16 ~-32 minecraft:stone_bricks
setblock ~30 ~54 ~-152 minecraft:stone_bricks
setblock ~30 ~54 ~-140 minecraft:stone_bricks
setblock ~30 ~54 ~-108 minecraft:stone_bricks
setblock ~30 ~54 ~-96 minecraft:stone_bricks
fill ~31 ~ ~-106 ~32 ~2 ~-98 minecraft:stone_bricks
fill ~31 ~4 ~-106 ~31 ~52 ~-98 minecraft:stone_bricks
setblock ~31 ~20 ~-161 minecraft:stone_bricks
fill ~31 ~20 ~-31 ~31 ~21 ~-31 minecraft:stone_bricks
fill ~31 ~53 ~-107 ~31 ~54 ~-107 minecraft:stone_bricks
fill ~31 ~53 ~-97 ~31 ~54 ~-97 minecraft:stone_bricks
setblock ~31 ~54 ~-151 minecraft:stone_bricks
setblock ~31 ~54 ~-141 minecraft:stone_bricks
fill ~32 ~3 ~-148 ~32 ~52 ~-144 minecraft:stone_bricks
fill ~32 ~3 ~-104 ~32 ~52 ~-100 minecraft:stone_bricks
fill ~32 ~17 ~-38 ~32 ~18 ~-31 minecraft:stone_bricks
fill ~32 ~53 ~-150 ~32 ~53 ~-149 minecraft:stone_bricks
fill ~32 ~53 ~-143 ~32 ~53 ~-142 minecraft:stone_bricks
fill ~32 ~53 ~-106 ~32 ~53 ~-105 minecraft:stone_bricks
fill ~32 ~53 ~-99 ~32 ~53 ~-98 minecraft:stone_bricks
setblock ~32 ~54 ~-150 minecraft:stone_bricks
setblock ~32 ~54 ~-142 minecraft:stone_bricks
setblock ~32 ~54 ~-106 minecraft:stone_bricks
setblock ~32 ~54 ~-98 minecraft:stone_bricks
fill ~33 ~20 ~-161 ~33 ~21 ~-161 minecraft:stone_bricks
setblock ~33 ~20 ~-31 minecraft:stone_bricks
fill ~33 ~53 ~-148 ~33 ~53 ~-144 minecraft:stone_bricks
fill ~33 ~53 ~-104 ~33 ~53 ~-100 minecraft:stone_bricks
setblock ~33 ~54 ~-147 minecraft:stone_bricks
setblock ~33 ~54 ~-145 minecraft:stone_bricks
setblock ~33 ~54 ~-101 minecraft:stone_bricks
setblock ~35 ~20 ~-161 minecraft:stone_bricks
setblock ~35 ~20 ~-31 minecraft:stone_bricks
fill ~36 ~10 ~-32 ~54 ~18 ~-32 minecraft:stone_bricks
fill ~37 ~6 ~-160 ~43 ~18 ~-156 minecraft:stone_bricks
fill ~37 ~6 ~-32 ~43 ~18 ~-32 minecraft:stone_bricks
setblock ~37 ~20 ~-161 minecraft:stone_bricks
setblock ~37 ~20 ~-31 minecraft:stone_bricks
setblock ~39 ~20 ~-161 minecraft:stone_bricks
fill ~41 ~20 ~-161 ~41 ~21 ~-161 minecraft:stone_bricks
setblock ~43 ~20 ~-31 minecraft:stone_bricks
fill ~45 ~6 ~-160 ~75 ~6 ~-157 minecraft:stone_bricks
fill ~45 ~6 ~-32 ~75 ~6 ~-32 minecraft:stone_bricks
fill ~45 ~7 ~-160 ~54 ~18 ~-156 minecraft:stone_bricks
fill ~45 ~7 ~-32 ~54 ~18 ~-32 minecraft:stone_bricks
setblock ~47 ~20 ~-161 minecraft:stone_bricks
fill ~47 ~20 ~-31 ~47 ~21 ~-31 minecraft:stone_bricks
fill ~49 ~20 ~-161 ~49 ~21 ~-161 minecraft:stone_bricks
setblock ~49 ~20 ~-31 minecraft:stone_bricks
setblock ~51 ~20 ~-31 minecraft:stone_bricks
fill ~52 ~30 ~-163 ~76 ~30 ~-157 minecraft:stone_bricks
fill ~52 ~30 ~-35 ~76 ~30 ~-29 minecraft:stone_bricks
fill ~52 ~31 ~-162 ~52 ~31 ~-157 minecraft:stone_bricks
fill ~52 ~31 ~-35 ~52 ~31 ~-29 minecraft:stone_bricks
setblock ~52 ~32 ~-162 minecraft:stone_bricks
setblock ~52 ~32 ~-160 minecraft:stone_bricks
setblock ~52 ~32 ~-158 minecraft:stone_bricks
setblock ~52 ~32 ~-34 minecraft:stone_bricks
setblock ~52 ~32 ~-32 minecraft:stone_bricks
setblock ~52 ~32 ~-30 minecraft:stone_bricks
fill ~53 ~ ~-163 ~54 ~2 ~-155 minecraft:stone_bricks
fill ~53 ~ ~-30 ~54 ~2 ~-27 minecraft:stone_bricks
fill ~53 ~3 ~-163 ~54 ~18 ~-156 minecraft:stone_bricks
fill ~53 ~3 ~-31 ~54 ~30 ~-29 minecraft:stone_bricks
fill ~53 ~19 ~-163 ~54 ~30 ~-161 minecraft:stone_bricks
fill ~53 ~21 ~-160 ~54 ~30 ~-157 minecraft:stone_bricks
fill ~53 ~21 ~-35 ~54 ~30 ~-29 minecraft:stone_bricks
fill ~53 ~30 ~-165 ~75 ~30 ~-155 minecraft:stone_bricks
fill ~53 ~30 ~-37 ~75 ~30 ~-27 minecraft:stone_bricks
fill ~53 ~31 ~-164 ~55 ~31 ~-164 minecraft:stone_bricks
fill ~53 ~31 ~-156 ~55 ~31 ~-156 minecraft:stone_bricks
fill ~53 ~31 ~-155 ~53 ~32 ~-155 minecraft:stone_bricks
fill ~53 ~31 ~-36 ~55 ~31 ~-36 minecraft:stone_bricks
fill ~53 ~31 ~-28 ~55 ~31 ~-28 minecraft:stone_bricks
fill ~53 ~31 ~-27 ~53 ~32 ~-27 minecraft:stone_bricks
setblock ~53 ~32 ~-165 minecraft:stone_bricks
setblock ~53 ~32 ~-37 minecraft:stone_bricks
fill ~54 ~ ~-165 ~55 ~30 ~-164 minecraft:stone_bricks
fill ~54 ~ ~-37 ~55 ~18 ~-36 minecraft:stone_bricks
fill ~54 ~3 ~-155 ~55 ~30 ~-155 minecraft:stone_bricks
fill ~54 ~3 ~-28 ~55 ~30 ~-27 minecraft:stone_bricks
fill ~54 ~19 ~-37 ~55 ~30 ~-37 minecraft:stone_bricks
fill ~54 ~21 ~-156 ~55 ~30 ~-155 minecraft:stone_bricks
fill ~54 ~22 ~-36 ~55 ~31 ~-36 minecraft:stone_bricks
fill ~54 ~30 ~-167 ~74 ~30 ~-153 minecraft:stone_bricks
fill ~54 ~30 ~-39 ~74 ~30 ~-25 minecraft:stone_bricks
fill ~54 ~31 ~-167 ~54 ~31 ~-166 minecraft:stone_bricks
fill ~54 ~31 ~-154 ~56 ~31 ~-154 minecraft:stone_bricks
setblock ~54 ~31 ~-153 minecraft:stone_bricks
fill ~54 ~31 ~-39 ~54 ~31 ~-38 minecraft:stone_bricks
fill ~54 ~31 ~-26 ~56 ~31 ~-26 minecraft:stone_bricks
setblock ~54 ~31 ~-25 minecraft:stone_bricks
setblock ~54 ~32 ~-166 minecraft:stone_bricks
setblock ~54 ~32 ~-154 minecraft:stone_bricks
setblock ~54 ~32 ~-38 minecraft:stone_bricks
setblock ~54 ~32 ~-26 minecraft:stone_bricks
fill ~55 ~ ~-167 ~57 ~30 ~-167 minecraft:stone_bricks
fill ~55 ~ ~-166 ~56 ~31 ~-166 minecraft:stone_bricks
fill ~55 ~ ~-155 ~55 ~30 ~-153 minecraft:stone_bricks
fill ~55 ~ ~-39 ~56 ~ ~-38 minecraft:stone_bricks
fill ~55 ~ ~-28 ~55 ~2 ~-24 minecraft:stone_bricks
fill ~55 ~1 ~-39 ~55 ~18 ~-36 minecraft:stone_bricks
fill ~55 ~3 ~-26 ~56 ~30 ~-25 minecraft:stone_bricks
fill ~55 ~19 ~-39 ~57 ~30 ~-39 minecraft:stone_bricks
fill ~55 ~19 ~-38 ~56 ~31 ~-38 minecraft:stone_bricks
fill ~55 ~21 ~-36 ~55 ~33 ~-36 minecraft:stone_bricks
fill ~55 ~30 ~-168 ~73 ~30 ~-152 minecraft:stone_bricks
fill ~55 ~30 ~-40 ~73 ~30 ~-24 minecraft:stone_bricks
setblock ~55 ~31 ~-168 minecraft:stone_bricks
fill ~56 ~ ~-168 ~58 ~30 ~-168 minecraft:stone_bricks
fill ~56 ~ ~-154 ~56 ~32 ~-154 minecraft:stone_bricks
fill ~56 ~ ~-26 ~56 ~2 ~-23 minecraft:stone_bricks
fill ~56 ~1 ~-38 ~56 ~32 ~-38 minecraft:stone_bricks
fill ~56 ~3 ~-153 ~57 ~30 ~-152 minecraft:stone_bricks
fill ~56 ~3 ~-40 ~58 ~30 ~-40 minecraft:stone_bricks
fill ~56 ~3 ~-39 ~57 ~30 ~-39 minecraft:stone_bricks
fill ~56 ~3 ~-24 ~58 ~30 ~-24 minecraft:stone_bricks
fill ~56 ~26 ~-98 ~72 ~26 ~-94 minecraft:stone_bricks
fill ~56 ~27 ~-98 ~56 ~28 ~-98 minecraft:stone_bricks
fill ~56 ~27 ~-94 ~56 ~28 ~-94 minecraft:stone_bricks
fill ~56 ~30 ~-169 ~72 ~30 ~-151 minecraft:stone_bricks
fill ~56 ~30 ~-41 ~72 ~30 ~-23 minecraft:stone_bricks
setblock ~56 ~31 ~-169 minecraft:stone_bricks
setblock ~56 ~31 ~-23 minecraft:stone_bricks
fill ~57 ~ ~-169 ~60 ~30 ~-169 minecraft:stone_bricks
fill ~57 ~ ~-98 ~58 ~26 ~-98 minecraft:stone_bricks
fill ~57 ~ ~-94 ~58 ~2 ~-92 minecraft:stone_bricks
fill ~57 ~ ~-41 ~60 ~18 ~-41 minecraft:stone_bricks
fill ~57 ~ ~-25 ~57 ~2 ~-22 minecraft:stone_bricks
fill ~57 ~1 ~-151 ~60 ~2 ~-150 minecraft:stone_bricks
fill ~57 ~3 ~-151 ~60 ~18 ~-151 minecraft:stone_bricks
fill ~57 ~3 ~-97 ~58 ~26 ~-94 minecraft:stone_bricks
fill ~57 ~3 ~-25 ~57 ~30 ~-23 minecraft:stone_bricks
fill ~57 ~19 ~-151 ~59 ~30 ~-151 minecraft:stone_bricks
fill ~57 ~20 ~-41 ~59 ~30 ~-41 minecraft:stone_bricks
fill ~57 ~26 ~-100 ~71 ~26 ~-92 minecraft:stone_bricks
fill ~57 ~27 ~-99 ~59 ~27 ~-99 minecraft:stone_bricks
setblock ~57 ~27 ~-92 minecraft:stone_bricks
setblock ~57 ~28 ~-99 minecraft:stone_bricks
setblock ~57 ~28 ~-93 minecraft:stone_bricks
fill ~57 ~30 ~-170 ~71 ~30 ~-150 minecraft:stone_bricks
fill ~57 ~30 ~-42 ~71 ~30 ~-22 minecraft:stone_bricks
fill ~57 ~31 ~-170 ~58 ~31 ~-170 minecraft:stone_bricks
fill ~57 ~31 ~-150 ~58 ~31 ~-150 minecraft:stone_bricks
fill ~57 ~31 ~-42 ~58 ~31 ~-42 minecraft:stone_bricks
fill ~57 ~31 ~-22 ~58 ~31 ~-22 minecraft:stone_bricks
fill ~58 ~ ~-152 ~58 ~2 ~-150 minecraft:stone_bricks
fill ~58 ~ ~-100 ~60 ~18 ~-100 minecraft:stone_bricks
fill ~58 ~ ~-99 ~59 ~27 ~-99 minecraft:stone_bricks
fill ~58 ~ ~-23 ~60 ~2 ~-22 minecraft:stone_bricks
fill ~58 ~1 ~-40 ~58 ~32 ~-40 minecraft:stone_bricks
fill ~58 ~1 ~-24 ~58 ~2 ~-22 minecraft:stone_bricks
fill ~58 ~3 ~-152 ~58 ~31 ~-151 minecraft:stone_bricks
fill ~58 ~3 ~-93 ~59 ~26 ~-92 minecraft:stone_bricks
fill ~58 ~3 ~-23 ~60 ~31 ~-23 minecraft:stone_bricks
fill ~58 ~19 ~-41 ~59 ~31 ~-41 minecraft:stone_bricks
fill ~58 ~20 ~-100 ~59 ~26 ~-99 minecraft:stone_bricks
fill ~58 ~26 ~-102 ~70 ~26 ~-90 minecraft:stone_bricks
fill ~58 ~27 ~-102 ~59 ~27 ~-102 minecraft:stone_bricks
setblock ~58 ~27 ~-101 minecraft:stone_bricks
fill ~58 ~27 ~-91 ~58 ~27 ~-90 minecraft:stone_bricks
setblock ~58 ~28 ~-102 minecraft:stone_bricks
setblock ~58 ~28 ~-90 minecraft:stone_bricks
setblock ~58 ~32 ~-170 minecraft:stone_bricks
setblock ~58 ~32 ~-150 minecraft:stone_bricks
setblock ~58 ~32 ~-42 minecraft:stone_bricks
setblock ~58 ~32 ~-22 minecraft:stone_bricks
fill ~59 ~ ~-170 ~71 ~2 ~-170 minecraft:stone_bricks
fill ~59 ~ ~-151 ~60 ~2 ~-149 minecraft:stone_bricks
fill ~59 ~ ~-101 ~61 ~18 ~-101 minecraft:stone_bricks
fill ~59 ~ ~-93 ~59 ~2 ~-90 minecraft:stone_bricks
fill ~59 ~ ~-42 ~71 ~2 ~-42 minecraft:stone_bricks
fill ~59 ~3 ~-170 ~69 ~30 ~-170 minecraft:stone_bricks
fill ~59 ~3 ~-150 ~69 ~18 ~-150 minecraft:stone_bricks
fill ~59 ~3 ~-91 ~61 ~18 ~-91 minecraft:stone_bricks
fill ~59 ~3 ~-22 ~69 ~30 ~-22 minecraft:stone_bricks
fill ~59 ~4 ~-42 ~69 ~18 ~-42 minecraft:stone_bricks
fill ~59 ~19 ~-150 ~59 ~30 ~-150 minecraft:stone_bricks
fill ~59 ~19 ~-101 ~59 ~26 ~-99 minecraft:stone_bricks
fill ~59 ~19 ~-91 ~59 ~26 ~-91 minecraft:stone_bricks
fill ~59 ~19 ~-42 ~59 ~30 ~-41 minecraft:stone_bricks
setblock ~59 ~27 ~-90 minecraft:stone_bricks
fill ~59 ~30 ~-171 ~69 ~30 ~-149 minecraft:stone_bricks
fill ~59 ~30 ~-43 ~69 ~30 ~-21 minecraft:stone_bricks
fill ~59 ~31 ~-149 ~60 ~31 ~-149 minecraft:stone_bricks
fill ~59 ~31 ~-43 ~60 ~31 ~-43 minecraft:stone_bricks
fill ~59 ~31 ~-21 ~60 ~31 ~-21 minecraft:stone_bricks
setblock ~59 ~32 ~-171 minecraft:stone_bricks
setblock ~59 ~32 ~-149 minecraft:stone_bricks
fill ~60 ~ ~-148 ~67 ~2 ~-148 minecraft:stone_bricks
fill ~60 ~ ~-147 ~65 ~2 ~-102 minecraft:stone_bricks
fill ~60 ~ ~-92 ~60 ~18 ~-41 minecraft:stone_bricks
fill ~60 ~3 ~-149 ~67 ~18 ~-149 minecraft:stone_bricks
fill ~60 ~3 ~-148 ~64 ~5 ~-102 minecraft:stone_bricks
fill ~60 ~6 ~-148 ~64 ~18 ~-141 minecraft:stone_bricks
fill ~60 ~6 ~-140 ~63 ~18 ~-102 minecraft:stone_bricks
fill ~60 ~21 ~-151 ~60 ~31 ~-150 minecraft:stone_bricks
fill ~60 ~21 ~-102 ~68 ~26 ~-102 minecraft:stone_bricks
fill ~60 ~21 ~-101 ~61 ~28 ~-101 minecraft:stone_bricks
fill ~60 ~21 ~-100 ~60 ~26 ~-100 minecraft:stone_bricks
fill ~60 ~21 ~-92 ~60 ~26 ~-90 minecraft:stone_bricks
fill ~60 ~21 ~-42 ~69 ~30 ~-42 minecraft:stone_bricks
fill ~60 ~21 ~-41 ~60 ~33 ~-41 minecraft:stone_bricks
fill ~60 ~26 ~-103 ~68 ~26 ~-89 minecraft:stone_bricks
fill ~60 ~27 ~-103 ~61 ~27 ~-103 minecraft:stone_bricks
fill ~60 ~27 ~-89 ~61 ~27 ~-89 minecraft:stone_bricks
fill ~60 ~31 ~-171 ~60 ~31 ~-169 minecraft:stone_bricks
fill ~61 ~ ~-171 ~69 ~2 ~-170 minecraft:stone_bricks
fill ~61 ~ ~-149 ~69 ~2 ~-149 minecraft:stone_bricks
fill ~61 ~ ~-91 ~61 ~18 ~-42 minecraft:stone_bricks
fill ~61 ~ ~-21 ~69 ~2 ~-21 minecraft:stone_bricks
fill ~61 ~1 ~-150 ~71 ~2 ~-150 minecraft:stone_bricks
fill ~61 ~1 ~-22 ~71 ~2 ~-22 minecraft:stone_bricks
fill ~61 ~3 ~-171 ~67 ~30 ~-170 minecraft:stone_bricks
fill ~61 ~3 ~-21 ~67 ~30 ~-21 minecraft:stone_bricks
fill ~61 ~21 ~-150 ~69 ~30 ~-150 minecraft:stone_bricks
fill ~61 ~21 ~-149 ~67 ~30 ~-149 minecraft:stone_bricks
fill ~61 ~21 ~-91 ~61 ~27 ~-90 minecraft:stone_bricks
fill ~61 ~21 ~-43 ~67 ~30 ~-42 minecraft:stone_bricks
setblock ~61 ~28 ~-103 minecraft:stone_bricks
setblock ~61 ~28 ~-89 minecraft:stone_bricks
fill ~61 ~30 ~-172 ~67 ~30 ~-148 minecraft:stone_bricks
fill ~61 ~30 ~-44 ~67 ~30 ~-20 minecraft:stone_bricks
fill ~61 ~31 ~-172 ~67 ~31 ~-172 minecraft:stone_bricks
fill ~61 ~31 ~-148 ~67 ~31 ~-148 minecraft:stone_bricks
fill ~61 ~31 ~-44 ~67 ~31 ~-44 minecraft:stone_bricks
fill ~61 ~31 ~-20 ~67 ~31 ~-20 minecraft:stone_bricks
fill ~62 ~ ~-150 ~71 ~2 ~-150 minecraft:stone_bricks
fill ~62 ~ ~-90 ~70 ~2 ~-90 minecraft:stone_bricks
fill ~62 ~ ~-89 ~68 ~2 ~-89 minecraft:stone_bricks
fill ~62 ~ ~-87 ~65 ~2 ~-42 minecraft:stone_bricks
fill ~62 ~ ~-22 ~71 ~2 ~-22 minecraft:stone_bricks
fill ~62 ~3 ~-90 ~68 ~18 ~-90 minecraft:stone_bricks
fill ~62 ~3 ~-89 ~66 ~18 ~-89 minecraft:stone_bricks
fill ~62 ~3 ~-88 ~64 ~5 ~-42 minecraft:stone_bricks
fill ~62 ~6 ~-88 ~64 ~18 ~-85 minecraft:stone_bricks
fill ~62 ~6 ~-84 ~63 ~6 ~-21 minecraft:stone_bricks
fill ~62 ~7 ~-84 ~63 ~18 ~-42 minecraft:stone_bricks
fill ~62 ~21 ~-103 ~66 ~26 ~-102 minecraft:stone_bricks
fill ~62 ~21 ~-90 ~68 ~26 ~-90 minecraft:stone_bricks
fill ~62 ~21 ~-89 ~66 ~26 ~-89 minecraft:stone_bricks
fill ~62 ~26 ~-104 ~66 ~26 ~-88 minecraft:stone_bricks
fill ~62 ~27 ~-104 ~66 ~27 ~-104 minecraft:stone_bricks
fill ~62 ~27 ~-88 ~66 ~27 ~-88 minecraft:stone_bricks
setblock ~62 ~28 ~-104 minecraft:stone_bricks
setblock ~62 ~28 ~-88 minecraft:stone_bricks
setblock ~62 ~32 ~-172 minecraft:stone_bricks
setblock ~62 ~32 ~-148 minecraft:stone_bricks
setblock ~62 ~32 ~-44 minecraft:stone_bricks
setblock ~62 ~32 ~-20 minecraft:stone_bricks
fill ~64 ~6 ~-139 ~64 ~18 ~-133 minecraft:stone_bricks
fill ~64 ~6 ~-130 ~64 ~18 ~-125 minecraft:stone_bricks
fill ~64 ~6 ~-123 ~64 ~18 ~-117 minecraft:stone_bricks
fill ~64 ~6 ~-115 ~64 ~18 ~-109 minecraft:stone_bricks
fill ~64 ~6 ~-107 ~64 ~18 ~-102 minecraft:stone_bricks
fill ~64 ~6 ~-83 ~64 ~18 ~-77 minecraft:stone_bricks
fill ~64 ~6 ~-75 ~64 ~18 ~-69 minecraft:stone_bricks
fill ~64 ~6 ~-67 ~64 ~18 ~-61 minecraft:stone_bricks
fill ~64 ~6 ~-59 ~64 ~18 ~-53 minecraft:stone_bricks
fill ~64 ~6 ~-51 ~64 ~6 ~-21 minecraft:stone_bricks
fill ~64 ~7 ~-131 ~64 ~18 ~-125 minecraft:stone_bricks
fill ~64 ~7 ~-51 ~64 ~18 ~-42 minecraft:stone_bricks
fill ~64 ~10 ~-140 ~64 ~18 ~-102 minecraft:stone_bricks
fill ~64 ~10 ~-84 ~64 ~18 ~-42 minecraft:stone_bricks
setblock ~64 ~28 ~-104 minecraft:stone_bricks
setblock ~64 ~32 ~-172 minecraft:stone_bricks
setblock ~64 ~32 ~-148 minecraft:stone_bricks
setblock ~64 ~32 ~-44 minecraft:stone_bricks
setblock ~64 ~32 ~-20 minecraft:stone_bricks
fill ~65 ~3 ~-102 ~68 ~26 ~-102 minecraft:stone_bricks
fill ~65 ~3 ~-42 ~69 ~30 ~-42 minecraft:stone_bricks
fill ~65 ~4 ~-103 ~66 ~26 ~-102 minecraft:stone_bricks
fill ~65 ~4 ~-43 ~67 ~30 ~-42 minecraft:stone_bricks
fill ~65 ~17 ~-148 ~65 ~19 ~-102 minecraft:stone_bricks
fill ~65 ~17 ~-88 ~65 ~19 ~-42 minecraft:stone_bricks
fill ~65 ~19 ~-150 ~69 ~30 ~-150 minecraft:stone_bricks
fill ~65 ~19 ~-149 ~67 ~30 ~-149 minecraft:stone_bricks
fill ~65 ~19 ~-89 ~66 ~26 ~-89 minecraft:stone_bricks
setblock ~65 ~20 ~-147 minecraft:stone_bricks
fill ~65 ~20 ~-145 ~65 ~21 ~-145 minecraft:stone_bricks
setblock ~65 ~20 ~-143 minecraft:stone_bricks
setblock ~65 ~20 ~-141 minecraft:stone_bricks
setblock ~65 ~20 ~-139 minecraft:stone_bricks
fill ~65 ~20 ~-137 ~65 ~21 ~-137 minecraft:stone_bricks
setblock ~65 ~20 ~-135 minecraft:stone_bricks
setblock ~65 ~20 ~-133 minecraft:stone_bricks
fill ~65 ~20 ~-129 ~65 ~21 ~-129 minecraft:stone_bricks
setblock ~65 ~20 ~-127 minecraft:stone_bricks
setblock ~65 ~20 ~-125 minecraft:stone_bricks
fill ~65 ~20 ~-121 ~65 ~21 ~-121 minecraft:stone_bricks
setblock ~65 ~20 ~-117 minecraft:stone_bricks
setblock ~65 ~20 ~-115 minecraft:stone_bricks
setblock ~65 ~20 ~-111 minecraft:stone_bricks
setblock ~65 ~20 ~-109 minecraft:stone_bricks
fill ~65 ~20 ~-105 ~65 ~21 ~-105 minecraft:stone_bricks
fill ~65 ~20 ~-90 ~68 ~26 ~-90 minecraft:stone_bricks
setblock ~65 ~20 ~-87 minecraft:stone_bricks
setblock ~65 ~20 ~-85 minecraft:stone_bricks
setblock ~65 ~20 ~-83 minecraft:stone_bricks
fill ~65 ~20 ~-81 ~65 ~21 ~-81 minecraft:stone_bricks
setblock ~65 ~20 ~-79 minecraft:stone_bricks
setblock ~65 ~20 ~-77 minecraft:stone_bricks
setblock ~65 ~20 ~-75 minecraft:stone_bricks
fill ~65 ~20 ~-73 ~65 ~21 ~-73 minecraft:stone_bricks
setblock ~65 ~20 ~-71 minecraft:stone_bricks
setblock ~65 ~20 ~-69 minecraft:stone_bricks
fill ~65 ~20 ~-65 ~65 ~21 ~-65 minecraft:stone_bricks
setblock ~65 ~20 ~-63 minecraft:stone_bricks
setblock ~65 ~20 ~-61 minecraft:stone_bricks
setblock ~65 ~20 ~-59 minecraft:stone_bricks
fill ~65 ~20 ~-57 ~65 ~21 ~-57 minecraft:stone_bricks
setblock ~65 ~20 ~-55 minecraft:stone_bricks
setblock ~65 ~20 ~-53 minecraft:stone_bricks
setblock ~65 ~20 ~-51 minecraft:stone_bricks
fill ~65 ~20 ~-49 ~65 ~21 ~-49 minecraft:stone_bricks
setblock ~65 ~20 ~-45 minecraft:stone_bricks
fill ~66 ~ ~-103 ~68 ~2 ~-102 minecraft:stone_bricks
fill ~66 ~ ~-43 ~69 ~2 ~-42 minecraft:stone_bricks
fill ~66 ~3 ~-103 ~66 ~26 ~-102 minecraft:stone_bricks
fill ~66 ~3 ~-43 ~67 ~30 ~-42 minecraft:stone_bricks
fill ~66 ~19 ~-90 ~68 ~26 ~-90 minecraft:stone_bricks
setblock ~66 ~32 ~-172 minecraft:stone_bricks
setblock ~66 ~32 ~-148 minecraft:stone_bricks
setblock ~66 ~32 ~-44 minecraft:stone_bricks
setblock ~66 ~32 ~-20 minecraft:stone_bricks
fill ~67 ~ ~-91 ~70 ~2 ~-90 minecraft:stone_bricks
fill ~67 ~1 ~-101 ~70 ~2 ~-101 minecraft:stone_bricks
fill ~67 ~3 ~-91 ~69 ~26 ~-91 minecraft:stone_bricks
fill ~67 ~4 ~-101 ~69 ~26 ~-101 minecraft:stone_bricks
fill ~67 ~27 ~-103 ~68 ~27 ~-103 minecraft:stone_bricks
fill ~67 ~27 ~-89 ~68 ~27 ~-89 minecraft:stone_bricks
setblock ~67 ~28 ~-103 minecraft:stone_bricks
setblock ~67 ~28 ~-89 minecraft:stone_bricks
fill ~68 ~ ~-151 ~72 ~2 ~-151 minecraft:stone_bricks
fill ~68 ~ ~-101 ~70 ~2 ~-100 minecraft:stone_bricks
fill ~68 ~ ~-92 ~71 ~2 ~-92 minecraft:stone_bricks
fill ~68 ~ ~-41 ~72 ~2 ~-41 minecraft:stone_bricks
fill ~68 ~ ~-23 ~72 ~2 ~-23 minecraft:stone_bricks
fill ~68 ~2 ~-169 ~72 ~2 ~-169 minecraft:stone_bricks
fill ~68 ~3 ~-169 ~71 ~30 ~-169 minecraft:stone_bricks
fill ~68 ~3 ~-151 ~71 ~30 ~-151 minecraft:stone_bricks
fill ~68 ~3 ~-101 ~69 ~26 ~-100 minecraft:stone_bricks
fill ~68 ~3 ~-92 ~70 ~26 ~-92 minecraft:stone_bricks
fill ~68 ~3 ~-23 ~71 ~30 ~-23 minecraft:stone_bricks
fill ~68 ~4 ~-41 ~71 ~30 ~-41 minecraft:stone_bricks
fill ~68 ~31 ~-171 ~69 ~31 ~-171 minecraft:stone_bricks
fill ~68 ~31 ~-149 ~69 ~31 ~-149 minecraft:stone_bricks
fill ~68 ~31 ~-43 ~69 ~31 ~-43 minecraft:stone_bricks
fill ~68 ~31 ~-21 ~69 ~31 ~-21 minecraft:stone_bricks
fill ~69 ~ ~-169 ~72 ~2 ~-169 minecraft:stone_bricks
fill ~69 ~ ~-99 ~71 ~2 ~-99 minecraft:stone_bricks
fill ~69 ~ ~-93 ~71 ~2 ~-92 minecraft:stone_bricks
fill ~69 ~3 ~-99 ~70 ~27 ~-99 minecraft:stone_bricks
fill ~69 ~3 ~-93 ~70 ~26 ~-92 minecraft:stone_bricks
fill ~69 ~3 ~-41 ~71 ~30 ~-41 minecraft:stone_bricks
fill ~69 ~27 ~-102 ~70 ~27 ~-102 minecraft:stone_bricks
fill ~69 ~27 ~-90 ~70 ~27 ~-90 minecraft:stone_bricks
setblock ~69 ~32 ~-171 minecraft:stone_bricks
setblock ~69 ~32 ~-149 minecraft:stone_bricks
setblock ~69 ~32 ~-43 minecraft:stone_bricks
setblock ~69 ~32 ~-21 minecraft:stone_bricks
fill ~70 ~ ~-168 ~73 ~2 ~-168 minecraft:stone_bricks
fill ~70 ~ ~-152 ~73 ~2 ~-152 minecraft:stone_bricks
fill ~70 ~ ~-98 ~72 ~2 ~-94 minecraft:stone_bricks
fill ~70 ~ ~-40 ~73 ~2 ~-40 minecraft:stone_bricks
fill ~70 ~ ~-24 ~73 ~2 ~-24 minecraft:stone_bricks
fill ~70 ~3 ~-168 ~72 ~30 ~-168 minecraft:stone_bricks
fill ~70 ~3 ~-152 ~72 ~30 ~-152 minecraft:stone_bricks
fill ~70 ~3 ~-100 ~70 ~26 ~-92 minecraft:stone_bricks
fill ~70 ~3 ~-40 ~72 ~30 ~-40 minecraft:stone_bricks
fill ~70 ~3 ~-24 ~72 ~30 ~-24 minecraft:stone_bricks
setblock ~70 ~27 ~-101 minecraft:stone_bricks
fill ~70 ~27 ~-91 ~70 ~27 ~-90 minecraft:stone_bricks
setblock ~70 ~28 ~-102 minecraft:stone_bricks
setblock ~70 ~28 ~-90 minecraft:stone_bricks
fill ~70 ~31 ~-170 ~71 ~31 ~-170 minecraft:stone_bricks
fill ~70 ~31 ~-150 ~71 ~31 ~-150 minecraft:stone_bricks
fill ~70 ~31 ~-42 ~71 ~31 ~-42 minecraft:stone_bricks
fill ~70 ~31 ~-22 ~71 ~31 ~-22 minecraft:stone_bricks
setblock ~70 ~32 ~-170 minecraft:stone_bricks
setblock ~70 ~32 ~-150 minecraft:stone_bricks
setblock ~70 ~32 ~-42 minecraft:stone_bricks
setblock ~70 ~32 ~-22 minecraft:stone_bricks
fill ~71 ~ ~-167 ~74 ~2 ~-167 minecraft:stone_bricks
fill ~71 ~ ~-153 ~74 ~2 ~-153 minecraft:stone_bricks
fill ~71 ~ ~-39 ~74 ~2 ~-39 minecraft:stone_bricks
fill ~71 ~ ~-25 ~74 ~2 ~-25 minecraft:stone_bricks
fill ~71 ~3 ~-167 ~73 ~30 ~-167 minecraft:stone_bricks
fill ~71 ~3 ~-153 ~73 ~30 ~-153 minecraft:stone_bricks
fill ~71 ~3 ~-98 ~71 ~26 ~-94 minecraft:stone_bricks
fill ~71 ~3 ~-39 ~73 ~30 ~-39 minecraft:stone_bricks
fill ~71 ~3 ~-25 ~73 ~30 ~-25 minecraft:stone_bricks
fill ~71 ~27 ~-100 ~71 ~27 ~-99 minecraft:stone_bricks
fill ~71 ~27 ~-93 ~71 ~27 ~-92 minecraft:stone_bricks
setblock ~71 ~28 ~-99 minecraft:stone_bricks
setblock ~71 ~28 ~-93 minecraft:stone_bricks
fill ~72 ~ ~-166 ~74 ~2 ~-166 minecraft:stone_bricks
fill ~72 ~ ~-154 ~74 ~2 ~-153 minecraft:stone_bricks
fill ~72 ~ ~-38 ~74 ~2 ~-38 minecraft:stone_bricks
fill ~72 ~ ~-26 ~74 ~2 ~-25 minecraft:stone_bricks
fill ~72 ~3 ~-166 ~73 ~31 ~-166 minecraft:stone_bricks
fill ~72 ~3 ~-38 ~73 ~31 ~-38 minecraft:stone_bricks
fill ~72 ~3 ~-26 ~73 ~30 ~-25 minecraft:stone_bricks
fill ~72 ~4 ~-154 ~73 ~30 ~-153 minecraft:stone_bricks
fill ~72 ~27 ~-98 ~72 ~27 ~-94 minecraft:stone_bricks
setblock ~72 ~28 ~-98 minecraft:stone_bricks
setblock ~72 ~28 ~-96 minecraft:stone_bricks
setblock ~72 ~28 ~-94 minecraft:stone_bricks
setblock ~72 ~31 ~-169 minecraft:stone_bricks
setblock ~72 ~31 ~-151 minecraft:stone_bricks
setblock ~72 ~31 ~-41 minecraft:stone_bricks
setblock ~72 ~31 ~-23 minecraft:stone_bricks
fill ~73 ~ ~-165 ~75 ~2 ~-164 minecraft:stone_bricks
fill ~73 ~ ~-156 ~75 ~2 ~-155 minecraft:stone_bricks
fill ~73 ~ ~-37 ~75 ~2 ~-36 minecraft:stone_bricks
fill ~73 ~ ~-28 ~75 ~2 ~-27 minecraft:stone_bricks
fill ~73 ~3 ~-165 ~74 ~30 ~-164 minecraft:stone_bricks
fill ~73 ~3 ~-156 ~74 ~30 ~-155 minecraft:stone_bricks
fill ~73 ~3 ~-154 ~73 ~30 ~-153 minecraft:stone_bricks
fill ~73 ~3 ~-36 ~74 ~31 ~-36 minecraft:stone_bricks
fill ~73 ~3 ~-28 ~74 ~30 ~-27 minecraft:stone_bricks
fill ~73 ~4 ~-37 ~74 ~30 ~-36 minecraft:stone_bricks
setblock ~73 ~31 ~-168 minecraft:stone_bricks
setblock ~73 ~31 ~-24 minecraft:stone_bricks
fill ~74 ~ ~-163 ~76 ~2 ~-157 minecraft:stone_bricks
fill ~74 ~ ~-35 ~76 ~2 ~-29 minecraft:stone_bricks
fill ~74 ~3 ~-163 ~75 ~30 ~-157 minecraft:stone_bricks
fill ~74 ~3 ~-37 ~74 ~30 ~-27 minecraft:stone_bricks
fill ~74 ~31 ~-167 ~74 ~31 ~-166 minecraft:stone_bricks
fill ~74 ~31 ~-154 ~74 ~31 ~-153 minecraft:stone_bricks
fill ~74 ~31 ~-39 ~74 ~31 ~-38 minecraft:stone_bricks
setblock ~74 ~31 ~-25 minecraft:stone_bricks
setblock ~74 ~32 ~-166 minecraft:stone_bricks
setblock ~74 ~32 ~-38 minecraft:stone_bricks
setblock ~74 ~32 ~-26 minecraft:stone_bricks
fill ~75 ~3 ~-35 ~75 ~30 ~-29 minecraft:stone_bricks
fill ~75 ~31 ~-165 ~75 ~31 ~-164 minecraft:stone_bricks
fill ~75 ~31 ~-156 ~75 ~31 ~-155 minecraft:stone_bricks
fill ~75 ~31 ~-37 ~75 ~31 ~-36 minecraft:stone_bricks
fill ~75 ~31 ~-27 ~75 ~32 ~-27 minecraft:stone_bricks
setblock ~75 ~32 ~-165 minecraft:stone_bricks
setblock ~75 ~32 ~-155 minecraft:stone_bricks
setblock ~75 ~32 ~-37 minecraft:stone_bricks
fill ~76 ~31 ~-163 ~76 ~31 ~-157 minecraft:stone_bricks
fill ~76 ~31 ~-35 ~76 ~31 ~-29 minecraft:stone_bricks
setblock ~76 ~32 ~-162 minecraft:stone_bricks
setblock ~76 ~32 ~-158 minecraft:stone_bricks
setblock ~76 ~32 ~-34 minecraft:stone_bricks
setblock ~76 ~32 ~-32 minecraft:stone_bricks
setblock ~76 ~32 ~-30 minecraft:stone_bricks
fill ~78 ~-7 ~-173 ~90 ~-1 ~-6 minecraft:stone_bricks
fill ~-100 ~-4 ~-196 ~100 ~-1 ~-187 minecraft:dirt
fill ~-100 ~-4 ~-186 ~-91 ~-1 ~4 minecraft:dirt
fill ~-90 ~-4 ~-5 ~100 ~-1 ~4 minecraft:dirt
fill ~-77 ~-4 ~-173 ~77 ~-2 ~-142 minecraft:dirt
fill ~-77 ~-4 ~-141 ~-22 ~-2 ~-19 minecraft:dirt
fill ~-76 ~-1 ~-163 ~100 ~-1 ~-161 minecraft:dirt
fill ~-76 ~-1 ~-160 ~-55 ~-1 ~-157 minecraft:dirt
fill ~-76 ~-1 ~-35 ~-55 ~-1 ~4 minecraft:dirt
fill ~-75 ~-1 ~-165 ~100 ~-1 ~-161 minecraft:dirt
fill ~-75 ~-1 ~-156 ~-56 ~-1 ~-152 minecraft:dirt
fill ~-75 ~-1 ~-37 ~100 ~-1 ~-37 minecraft:dirt
fill ~-75 ~-1 ~-36 ~-56 ~-1 ~4 minecraft:dirt
fill ~-74 ~-1 ~-167 ~100 ~-1 ~-161 minecraft:dirt
fill ~-74 ~-1 ~-39 ~100 ~-1 ~-37 minecraft:dirt
fill ~-73 ~-1 ~-168 ~100 ~-1 ~-161 minecraft:dirt
fill ~-73 ~-1 ~-40 ~100 ~-1 ~-37 minecraft:dirt
fill ~-72 ~-1 ~-169 ~100 ~-1 ~-161 minecraft:dirt
fill ~-72 ~-1 ~-151 ~-61 ~-1 ~-151 minecraft:dirt
fill ~-72 ~-1 ~-98 ~100 ~-1 ~-93 minecraft:dirt
fill ~-72 ~-1 ~-41 ~-61 ~-1 ~4 minecraft:dirt
fill ~-71 ~-1 ~-170 ~100 ~-1 ~-161 minecraft:dirt
fill ~-71 ~-1 ~-150 ~-65 ~-1 ~4 minecraft:dirt
fill ~-69 ~-1 ~-171 ~100 ~-1 ~-161 minecraft:dirt
fill ~-67 ~-1 ~-172 ~100 ~-1 ~-161 minecraft:dirt
fill ~-59 ~-1 ~-151 ~59 ~-1 ~-142 minecraft:dirt
fill ~-59 ~-1 ~-102 ~59 ~-1 ~-75 minecraft:dirt
fill ~-59 ~-1 ~-43 ~59 ~-1 ~-37 minecraft:dirt
fill ~-55 ~-1 ~-155 ~100 ~-1 ~-152 minecraft:dirt
fill ~-54 ~-1 ~-138 ~59 ~-1 ~-75 minecraft:dirt
fill ~-54 ~-1 ~-74 ~-10 ~-1 ~-37 minecraft:dirt
fill ~-54 ~-1 ~-31 ~100 ~-1 ~4 minecraft:dirt
fill ~-31 ~-1 ~-141 ~-22 ~-1 ~-37 minecraft:dirt
fill ~-21 ~-4 ~-138 ~77 ~-2 ~-60 minecraft:dirt
fill ~-21 ~-4 ~-59 ~24 ~-2 ~-19 minecraft:dirt
fill ~-18 ~-4 ~-141 ~-18 ~-2 ~-19 minecraft:dirt
fill ~-14 ~-4 ~-141 ~77 ~-2 ~-60 minecraft:dirt
fill ~25 ~-4 ~-56 ~77 ~-2 ~-19 minecraft:dirt
fill ~26 ~-1 ~-141 ~59 ~-1 ~-60 minecraft:dirt
fill ~30 ~-4 ~-59 ~77 ~-2 ~-19 minecraft:dirt
fill ~32 ~-1 ~-56 ~59 ~-1 ~-37 minecraft:dirt
fill ~65 ~-1 ~-150 ~100 ~-1 ~4 minecraft:dirt
fill ~68 ~-1 ~-151 ~100 ~-1 ~4 minecraft:dirt
fill ~73 ~-1 ~-156 ~100 ~-1 ~4 minecraft:dirt
fill ~74 ~-1 ~-160 ~100 ~-1 ~4 minecraft:dirt
fill ~91 ~-4 ~-186 ~100 ~-1 ~4 minecraft:dirt
fill ~-100 ~-5 ~-196 ~100 ~-5 ~-187 minecraft:stone
fill ~-100 ~-5 ~-186 ~-91 ~-5 ~4 minecraft:stone
fill ~-99 ~-9 ~-120 ~-78 ~-9 ~-117 minecraft:stone
fill ~-99 ~-8 ~-120 ~-97 ~-1 ~-118 minecraft:stone
fill ~-90 ~-5 ~-5 ~100 ~-5 ~4 minecraft:stone
fill ~-89 ~-7 ~-185 ~89 ~-1 ~-175 minecraft:stone
fill ~-89 ~-7 ~-174 ~-79 ~-1 ~-7 minecraft:stone
fill ~-81 ~-14 ~-130 ~-71 ~-14 ~-126 minecraft:stone
fill ~-81 ~-13 ~-130 ~-72 ~-13 ~-126 minecraft:stone
fill ~-81 ~-12 ~-130 ~-73 ~-12 ~-126 minecraft:stone
fill ~-81 ~-11 ~-130 ~-74 ~-11 ~-126 minecraft:stone
fill ~-81 ~-10 ~-130 ~-75 ~-10 ~-126 minecraft:stone
fill ~-81 ~-9 ~-130 ~-76 ~-9 ~-126 minecraft:stone
fill ~-81 ~-8 ~-130 ~-77 ~-8 ~-126 minecraft:stone
fill ~-80 ~-15 ~-130 ~-70 ~-15 ~-126 minecraft:stone
fill ~-79 ~-16 ~-130 ~-69 ~-16 ~-126 minecraft:stone
fill ~-78 ~-17 ~-130 ~-68 ~-17 ~-126 minecraft:stone
fill ~-78 ~-7 ~-17 ~89 ~-1 ~-7 minecraft:stone
fill ~-77 ~-18 ~-130 ~-67 ~-18 ~-126 minecraft:stone
fill ~-77 ~-5 ~-173 ~77 ~-5 ~-142 minecraft:stone
fill ~-77 ~-5 ~-141 ~-22 ~-5 ~-19 minecraft:stone
fill ~-76 ~-19 ~-130 ~-66 ~-19 ~-126 minecraft:stone
fill ~-75 ~-20 ~-130 ~-65 ~-20 ~-126 minecraft:stone
fill ~-74 ~-21 ~-130 ~-64 ~-21 ~-126 minecraft:stone
fill ~-73 ~-22 ~-130 ~36 ~-22 ~-126 minecraft:stone
fill ~-72 ~-23 ~-130 ~36 ~-22 ~-126 minecraft:stone
fill ~-71 ~-24 ~-130 ~36 ~-22 ~-126 minecraft:stone
fill ~-70 ~-25 ~-130 ~36 ~-22 ~-126 minecraft:stone
fill ~-69 ~-26 ~-130 ~36 ~-22 ~-126 minecraft:stone
fill ~-68 ~-27 ~-130 ~36 ~-22 ~-126 minecraft:stone
fill ~-67 ~-28 ~-130 ~36 ~-22 ~-126 minecraft:stone
fill ~-34 ~-32 ~-126 ~ ~-28 ~-117 minecraft:stone
fill ~-34 ~-29 ~-152 ~34 ~-28 ~-98 minecraft:stone
fill ~-34 ~-27 ~-152 ~34 ~-16 ~-142 minecraft:stone
fill ~-34 ~-27 ~-141 ~-22 ~-16 ~-123 minecraft:stone
fill ~-34 ~-27 ~-122 ~-26 ~-27 ~-98 minecraft:stone
fill ~-34 ~-26 ~-122 ~-27 ~-16 ~-98 minecraft:stone
fill ~-26 ~-26 ~-99 ~36 ~-22 ~-98 minecraft:stone
fill ~-26 ~-21 ~-99 ~34 ~-16 ~-98 minecraft:stone
fill ~-26 ~-17 ~-122 ~34 ~-16 ~-98 minecraft:stone
fill ~-25 ~-27 ~-99 ~36 ~-22 ~-98 minecraft:stone
fill ~-21 ~-17 ~-138 ~34 ~-16 ~-98 minecraft:stone
fill ~-21 ~-5 ~-138 ~77 ~-5 ~-60 minecraft:stone
fill ~-21 ~-5 ~-59 ~24 ~-5 ~-19 minecraft:stone
fill ~-18 ~-17 ~-141 ~-18 ~-16 ~-98 minecraft:stone
fill ~-18 ~-5 ~-141 ~-18 ~-5 ~-19 minecraft:stone
fill ~-14 ~-17 ~-141 ~34 ~-16 ~-98 minecraft:stone
fill ~-14 ~-5 ~-141 ~77 ~-5 ~-60 minecraft:stone
fill ~-2 ~-10 ~-146 ~25 ~-1 ~-102 minecraft:stone
fill ~8 ~-29 ~-72 ~46 ~-28 ~-40 minecraft:stone
fill ~8 ~-27 ~-72 ~46 ~-16 ~-60 minecraft:stone
fill ~8 ~-27 ~-59 ~24 ~-16 ~-40 minecraft:stone
fill ~25 ~-27 ~-41 ~46 ~-16 ~-40 minecraft:stone
fill ~25 ~-17 ~-56 ~46 ~-16 ~-40 minecraft:stone
fill ~25 ~-5 ~-56 ~77 ~-5 ~-19 minecraft:stone
fill ~30 ~-17 ~-59 ~46 ~-16 ~-40 minecraft:stone
fill ~30 ~-5 ~-59 ~77 ~-5 ~-19 minecraft:stone
fill ~32 ~-28 ~-97 ~36 ~-22 ~-40 minecraft:stone
fill ~32 ~-27 ~-125 ~36 ~-22 ~-40 minecraft:stone
fill ~33 ~-27 ~-141 ~34 ~-22 ~-40 minecraft:stone
fill ~33 ~-21 ~-141 ~34 ~-16 ~-98 minecraft:stone
fill ~35 ~-28 ~-125 ~36 ~-22 ~-40 minecraft:stone
fill ~45 ~-27 ~-59 ~46 ~-16 ~-40 minecraft:stone
fill ~79 ~-7 ~-174 ~89 ~-1 ~-7 minecraft:stone
fill ~91 ~-5 ~-186 ~100 ~-5 ~4 minecraft:stone
fill ~-73 ~-1 ~-163 ~-55 ~-1 ~-157 minecraft:spruce_planks
fill ~-73 ~-1 ~-35 ~-55 ~-1 ~-29 minecraft:spruce_planks
fill ~-73 ~6 ~-163 ~-55 ~6 ~-157 minecraft:spruce_planks
fill ~-73 ~6 ~-35 ~-55 ~6 ~-29 minecraft:spruce_planks
fill ~-73 ~12 ~-163 ~-55 ~12 ~-157 minecraft:spruce_planks
fill ~-73 ~12 ~-35 ~-55 ~12 ~-29 minecraft:spruce_planks
fill ~-73 ~18 ~-163 ~-55 ~18 ~-157 minecraft:spruce_planks
fill ~-73 ~18 ~-35 ~-55 ~18 ~-29 minecraft:spruce_planks
fill ~-73 ~24 ~-163 ~-55 ~24 ~-157 minecraft:spruce_planks
fill ~-73 ~24 ~-35 ~-55 ~24 ~-29 minecraft:spruce_planks
fill ~-72 ~-1 ~-165 ~-56 ~-1 ~-155 minecraft:spruce_planks
fill ~-72 ~-1 ~-37 ~-56 ~-1 ~-27 minecraft:spruce_planks
fill ~-72 ~6 ~-165 ~-56 ~6 ~-155 minecraft:spruce_planks
fill ~-72 ~6 ~-37 ~-56 ~6 ~-27 minecraft:spruce_planks
fill ~-72 ~12 ~-165 ~-56 ~12 ~-155 minecraft:spruce_planks
fill ~-72 ~12 ~-37 ~-56 ~12 ~-27 minecraft:spruce_planks
fill ~-72 ~18 ~-165 ~-56 ~18 ~-155 minecraft:spruce_planks
fill ~-72 ~18 ~-37 ~-56 ~18 ~-27 minecraft:spruce_planks
fill ~-72 ~24 ~-165 ~-56 ~24 ~-155 minecraft:spruce_planks
fill ~-72 ~24 ~-37 ~-56 ~24 ~-27 minecraft:spruce_planks
fill ~-71 ~-1 ~-166 ~-57 ~-1 ~-154 minecraft:spruce_planks
fill ~-71 ~-1 ~-38 ~-57 ~-1 ~-26 minecraft:spruce_planks
fill ~-71 ~6 ~-166 ~-57 ~6 ~-154 minecraft:spruce_planks
fill ~-71 ~6 ~-38 ~-57 ~6 ~-26 minecraft:spruce_planks
fill ~-71 ~12 ~-166 ~-57 ~12 ~-154 minecraft:spruce_planks
fill ~-71 ~12 ~-38 ~-57 ~12 ~-26 minecraft:spruce_planks
fill ~-71 ~18 ~-166 ~-57 ~18 ~-154 minecraft:spruce_planks
fill ~-71 ~18 ~-38 ~-57 ~18 ~-26 minecraft:spruce_planks
fill ~-71 ~24 ~-166 ~-57 ~24 ~-154 minecraft:spruce_planks
fill ~-71 ~24 ~-38 ~-57 ~24 ~-26 minecraft:spruce_planks
fill ~-70 ~-1 ~-167 ~-58 ~-1 ~-153 minecraft:spruce_planks
fill ~-70 ~-1 ~-39 ~-56 ~-1 ~-39 minecraft:spruce_planks
fill ~-70 ~-1 ~-25 ~-58 ~-1 ~-25 minecraft:spruce_planks
fill ~-70 ~6 ~-167 ~-58 ~6 ~-153 minecraft:spruce_planks
fill ~-70 ~6 ~-39 ~-58 ~6 ~-25 minecraft:spruce_planks
fill ~-70 ~12 ~-167 ~-58 ~12 ~-153 minecraft:spruce_planks
fill ~-70 ~12 ~-39 ~-58 ~12 ~-25 minecraft:spruce_planks
fill ~-70 ~18 ~-167 ~-58 ~18 ~-153 minecraft:spruce_planks
fill ~-70 ~18 ~-39 ~-58 ~18 ~-25 minecraft:spruce_planks
fill ~-70 ~24 ~-167 ~-58 ~24 ~-153 minecraft:spruce_planks
fill ~-70 ~24 ~-39 ~-58 ~24 ~-25 minecraft:spruce_planks
fill ~-69 ~-1 ~-168 ~-59 ~-1 ~-152 minecraft:spruce_planks
fill ~-69 ~-1 ~-98 ~-59 ~-1 ~-94 minecraft:spruce_planks
fill ~-69 ~-1 ~-40 ~-59 ~-1 ~-24 minecraft:spruce_planks
fill ~-69 ~6 ~-168 ~-59 ~6 ~-152 minecraft:spruce_planks
fill ~-69 ~6 ~-40 ~-59 ~6 ~-24 minecraft:spruce_planks
fill ~-69 ~9 ~-98 ~-59 ~9 ~-94 minecraft:spruce_planks
fill ~-69 ~12 ~-168 ~-59 ~12 ~-152 minecraft:spruce_planks
fill ~-69 ~12 ~-40 ~-59 ~12 ~-24 minecraft:spruce_planks
fill ~-69 ~18 ~-168 ~-59 ~18 ~-152 minecraft:spruce_planks
fill ~-69 ~18 ~-98 ~-59 ~18 ~-94 minecraft:spruce_planks
fill ~-69 ~18 ~-40 ~-59 ~18 ~-24 minecraft:spruce_planks
fill ~-69 ~24 ~-168 ~-59 ~24 ~-152 minecraft:spruce_planks
fill ~-69 ~24 ~-40 ~-59 ~24 ~-24 minecraft:spruce_planks
fill ~-68 ~-1 ~-99 ~-60 ~-1 ~-93 minecraft:spruce_planks
fill ~-68 ~9 ~-99 ~-60 ~9 ~-93 minecraft:spruce_planks
fill ~-68 ~18 ~-99 ~-60 ~18 ~-93 minecraft:spruce_planks
fill ~-67 ~-1 ~-169 ~-61 ~-1 ~-151 minecraft:spruce_planks
fill ~-67 ~-1 ~-100 ~-61 ~-1 ~-92 minecraft:spruce_planks
fill ~-67 ~-1 ~-41 ~-61 ~-1 ~-23 minecraft:spruce_planks
fill ~-67 ~6 ~-169 ~-61 ~6 ~-151 minecraft:spruce_planks
fill ~-67 ~6 ~-41 ~-61 ~6 ~-23 minecraft:spruce_planks
fill ~-67 ~9 ~-100 ~-61 ~9 ~-92 minecraft:spruce_planks
fill ~-67 ~12 ~-169 ~-61 ~12 ~-151 minecraft:spruce_planks
fill ~-67 ~12 ~-41 ~-61 ~12 ~-23 minecraft:spruce_planks
fill ~-67 ~18 ~-169 ~-61 ~18 ~-151 minecraft:spruce_planks
fill ~-67 ~18 ~-100 ~-61 ~18 ~-92 minecraft:spruce_planks
fill ~-67 ~18 ~-41 ~-61 ~18 ~-23 minecraft:spruce_planks
fill ~-67 ~24 ~-169 ~-61 ~24 ~-151 minecraft:spruce_planks
fill ~-67 ~24 ~-41 ~-61 ~24 ~-23 minecraft:spruce_planks
fill ~-66 ~-1 ~-101 ~-62 ~-1 ~-91 minecraft:spruce_planks
fill ~-66 ~9 ~-101 ~-62 ~9 ~-91 minecraft:spruce_planks
fill ~-66 ~18 ~-101 ~-62 ~18 ~-91 minecraft:spruce_planks
fill ~-54 ~6 ~-112 ~-36 ~8 ~-112 minecraft:spruce_planks
fill ~-54 ~6 ~-111 ~-54 ~8 ~-92 minecraft:spruce_planks
fill ~-54 ~6 ~-84 ~-40 ~8 ~-84 minecraft:spruce_planks
fill ~-54 ~6 ~-83 ~-54 ~8 ~-66 minecraft:spruce_planks
fill ~-54 ~8 ~-138 ~-36 ~8 ~-119 minecraft:spruce_planks
fill ~-54 ~9 ~-137 ~-36 ~9 ~-120 minecraft:spruce_planks
fill ~-54 ~10 ~-136 ~-36 ~10 ~-121 minecraft:spruce_planks
fill ~-54 ~11 ~-135 ~-36 ~11 ~-122 minecraft:spruce_planks
fill ~-54 ~12 ~-134 ~-36 ~12 ~-123 minecraft:spruce_planks
fill ~-54 ~13 ~-133 ~-36 ~13 ~-124 minecraft:spruce_planks
fill ~-54 ~14 ~-132 ~-36 ~14 ~-125 minecraft:spruce_planks
fill ~-54 ~15 ~-131 ~-36 ~15 ~-126 minecraft:spruce_planks
fill ~-54 ~16 ~-130 ~-36 ~16 ~-127 minecraft:spruce_planks
fill ~-54 ~17 ~-129 ~-36 ~17 ~-128 minecraft:spruce_planks
fill ~-53 ~-1 ~-137 ~-37 ~-1 ~-121 minecraft:spruce_planks
fill ~-53 ~-1 ~-111 ~-37 ~-1 ~-93 minecraft:spruce_planks
fill ~-53 ~-1 ~-83 ~-41 ~-1 ~-67 minecraft:spruce_planks
fill ~-53 ~6 ~-92 ~-36 ~8 ~-92 minecraft:spruce_planks
fill ~-53 ~6 ~-66 ~-40 ~8 ~-66 minecraft:spruce_planks
fill ~-53 ~7 ~-111 ~-35 ~7 ~-92 minecraft:spruce_planks
fill ~-53 ~7 ~-83 ~-39 ~7 ~-66 minecraft:spruce_planks
fill ~-53 ~8 ~-111 ~-36 ~8 ~-92 minecraft:spruce_planks
fill ~-53 ~8 ~-83 ~-40 ~8 ~-66 minecraft:spruce_planks
fill ~-52 ~9 ~-112 ~-37 ~9 ~-92 minecraft:spruce_planks
fill ~-52 ~9 ~-84 ~-41 ~9 ~-66 minecraft:spruce_planks
fill ~-51 ~10 ~-112 ~-38 ~10 ~-92 minecraft:spruce_planks
fill ~-51 ~10 ~-84 ~-42 ~10 ~-66 minecraft:spruce_planks
fill ~-50 ~5 ~-56 ~-43 ~7 ~-56 minecraft:spruce_planks
fill ~-50 ~5 ~-55 ~-50 ~7 ~-49 minecraft:spruce_planks
fill ~-50 ~8 ~-54 ~-43 ~8 ~-50 minecraft:spruce_planks
fill ~-50 ~9 ~-53 ~-43 ~9 ~-51 minecraft:spruce_planks
fill ~-50 ~11 ~-112 ~-39 ~11 ~-92 minecraft:spruce_planks
fill ~-50 ~11 ~-84 ~-43 ~11 ~-66 minecraft:spruce_planks
fill ~-49 ~-1 ~-55 ~-44 ~-1 ~-50 minecraft:spruce_planks
fill ~-49 ~5 ~-49 ~-43 ~7 ~-49 minecraft:spruce_planks
fill ~-49 ~6 ~-55 ~-43 ~6 ~-48 minecraft:spruce_planks
fill ~-49 ~7 ~-55 ~-43 ~7 ~-49 minecraft:spruce_planks
fill ~-49 ~12 ~-112 ~-40 ~12 ~-92 minecraft:spruce_planks
fill ~-49 ~12 ~-84 ~-44 ~12 ~-66 minecraft:spruce_planks
fill ~-48 ~13 ~-112 ~-41 ~13 ~-92 minecraft:spruce_planks
fill ~-48 ~13 ~-84 ~-45 ~13 ~-66 minecraft:spruce_planks
fill ~-47 ~14 ~-112 ~-42 ~14 ~-92 minecraft:spruce_planks
fill ~-47 ~14 ~-84 ~-46 ~14 ~-66 minecraft:spruce_planks
fill ~-46 ~15 ~-112 ~-43 ~15 ~-92 minecraft:spruce_planks
fill ~-45 ~16 ~-112 ~-44 ~16 ~-92 minecraft:spruce_planks
fill ~-43 ~5 ~-55 ~-43 ~7 ~-49 minecraft:spruce_planks
fill ~-40 ~5 ~-56 ~-33 ~7 ~-56 minecraft:spruce_planks
fill ~-40 ~5 ~-55 ~-40 ~7 ~-49 minecraft:spruce_planks
fill ~-40 ~6 ~-83 ~-40 ~8 ~-66 minecraft:spruce_planks
fill ~-40 ~8 ~-54 ~-33 ~8 ~-50 minecraft:spruce_planks
fill ~-40 ~9 ~-53 ~-33 ~9 ~-51 minecraft:spruce_planks
fill ~-39 ~-1 ~-55 ~-34 ~-1 ~-50 minecraft:spruce_planks
fill ~-39 ~5 ~-49 ~-33 ~7 ~-49 minecraft:spruce_planks
fill ~-39 ~6 ~-55 ~-33 ~6 ~-48 minecraft:spruce_planks
fill ~-39 ~7 ~-55 ~-33 ~7 ~-49 minecraft:spruce_planks
fill ~-36 ~6 ~-111 ~-36 ~8 ~-92 minecraft:spruce_planks
fill ~-33 ~5 ~-55 ~-33 ~7 ~-49 minecraft:spruce_planks
fill ~-24 ~11 ~-144 ~24 ~11 ~-142 minecraft:spruce_planks
fill ~-24 ~11 ~-141 ~-22 ~11 ~-104 minecraft:spruce_planks
fill ~-21 ~-1 ~-32 ~-9 ~-1 ~-28 minecraft:spruce_planks
fill ~-21 ~9 ~-32 ~-9 ~9 ~-28 minecraft:spruce_planks
fill ~-21 ~11 ~-138 ~24 ~11 ~-104 minecraft:spruce_planks
fill ~-21 ~18 ~-32 ~-9 ~18 ~-28 minecraft:spruce_planks
fill ~-20 ~-1 ~-34 ~-10 ~-1 ~-26 minecraft:spruce_planks
fill ~-20 ~9 ~-34 ~-10 ~9 ~-26 minecraft:spruce_planks
fill ~-20 ~18 ~-34 ~-10 ~18 ~-26 minecraft:spruce_planks
fill ~-19 ~-1 ~-35 ~-11 ~-1 ~-25 minecraft:spruce_planks
fill ~-19 ~9 ~-35 ~-11 ~9 ~-25 minecraft:spruce_planks
fill ~-19 ~18 ~-35 ~-11 ~18 ~-25 minecraft:spruce_planks
fill ~-18 ~11 ~-141 ~-18 ~11 ~-104 minecraft:spruce_planks
fill ~-17 ~-1 ~-36 ~-13 ~-1 ~-24 minecraft:spruce_planks
fill ~-17 ~ ~-136 ~-13 ~ ~-134 minecraft:spruce_planks
fill ~-17 ~9 ~-36 ~-13 ~9 ~-24 minecraft:spruce_planks
fill ~-17 ~18 ~-36 ~-13 ~18 ~-24 minecraft:spruce_planks
fill ~-14 ~11 ~-141 ~24 ~11 ~-104 minecraft:spruce_planks
fill ~-8 ~12 ~-39 ~8 ~12 ~-35 minecraft:spruce_planks
fill ~-8 ~18 ~-36 ~8 ~18 ~-35 minecraft:spruce_planks
fill ~-8 ~55 ~-126 ~8 ~55 ~-122 minecraft:spruce_planks
fill ~-7 ~12 ~-34 ~7 ~12 ~-33 minecraft:spruce_planks
fill ~-7 ~12 ~-27 ~7 ~12 ~-27 minecraft:spruce_planks
fill ~-7 ~18 ~-34 ~7 ~18 ~-33 minecraft:spruce_planks
fill ~-7 ~55 ~-128 ~7 ~55 ~-120 minecraft:spruce_planks
fill ~-6 ~12 ~-32 ~6 ~12 ~-27 minecraft:spruce_planks
fill ~-6 ~18 ~-32 ~6 ~18 ~-32 minecraft:spruce_planks
fill ~-6 ~55 ~-130 ~6 ~55 ~-118 minecraft:spruce_planks
fill ~-5 ~-1 ~-162 ~5 ~-1 ~-158 minecraft:spruce_planks
fill ~-5 ~9 ~-162 ~5 ~9 ~-158 minecraft:spruce_planks
fill ~-5 ~18 ~-162 ~5 ~18 ~-158 minecraft:spruce_planks
fill ~-4 ~-1 ~-163 ~4 ~-1 ~-157 minecraft:spruce_planks
fill ~-4 ~-1 ~-23 ~8 ~-1 ~4 minecraft:spruce_planks
fill ~-4 ~9 ~-163 ~4 ~9 ~-157 minecraft:spruce_planks
fill ~-4 ~18 ~-163 ~4 ~18 ~-157 minecraft:spruce_planks
fill ~-4 ~55 ~-131 ~4 ~55 ~-117 minecraft:spruce_planks
fill ~-3 ~-1 ~-164 ~3 ~-1 ~-156 minecraft:spruce_planks
fill ~-3 ~9 ~-164 ~3 ~9 ~-156 minecraft:spruce_planks
fill ~-3 ~18 ~-164 ~3 ~18 ~-156 minecraft:spruce_planks
fill ~-2 ~-1 ~-165 ~2 ~-1 ~-155 minecraft:spruce_planks
fill ~-2 ~9 ~-165 ~2 ~9 ~-155 minecraft:spruce_planks
fill ~-2 ~18 ~-165 ~2 ~18 ~-155 minecraft:spruce_planks
fill ~-2 ~55 ~-132 ~2 ~55 ~-116 minecraft:spruce_planks
fill ~9 ~-1 ~-32 ~21 ~-1 ~-28 minecraft:spruce_planks
fill ~9 ~9 ~-32 ~21 ~9 ~-28 minecraft:spruce_planks
fill ~9 ~18 ~-32 ~23 ~18 ~-32 minecraft:spruce_planks
fill ~9 ~18 ~-31 ~21 ~18 ~-28 minecraft:spruce_planks
fill ~10 ~-28 ~-70 ~31 ~-28 ~-42 minecraft:spruce_planks
fill ~10 ~-27 ~-70 ~31 ~-18 ~-60 minecraft:spruce_planks
fill ~10 ~-27 ~-59 ~24 ~-18 ~-42 minecraft:spruce_planks
fill ~10 ~-1 ~-34 ~20 ~-1 ~-26 minecraft:spruce_planks
fill ~10 ~9 ~-34 ~20 ~9 ~-26 minecraft:spruce_planks
fill ~10 ~18 ~-34 ~20 ~18 ~-26 minecraft:spruce_planks
fill ~11 ~-1 ~-35 ~19 ~-1 ~-25 minecraft:spruce_planks
fill ~11 ~9 ~-35 ~19 ~9 ~-25 minecraft:spruce_planks
fill ~11 ~18 ~-35 ~19 ~18 ~-25 minecraft:spruce_planks
fill ~13 ~-1 ~-36 ~17 ~-1 ~-24 minecraft:spruce_planks
fill ~13 ~9 ~-36 ~17 ~9 ~-24 minecraft:spruce_planks
fill ~13 ~18 ~-36 ~17 ~18 ~-24 minecraft:spruce_planks
setblock ~23 ~ ~-106 minecraft:spruce_planks
fill ~25 ~-27 ~-56 ~44 ~-18 ~-42 minecraft:spruce_planks
fill ~30 ~-27 ~-59 ~44 ~-18 ~-42 minecraft:spruce_planks
fill ~32 ~-28 ~-67 ~44 ~-18 ~-42 minecraft:spruce_planks
fill ~32 ~-21 ~-70 ~44 ~-18 ~-42 minecraft:spruce_planks
fill ~32 ~5 ~-56 ~39 ~7 ~-56 minecraft:spruce_planks
fill ~32 ~5 ~-55 ~32 ~7 ~-49 minecraft:spruce_planks
fill ~32 ~8 ~-54 ~39 ~8 ~-50 minecraft:spruce_planks
fill ~32 ~9 ~-53 ~39 ~9 ~-51 minecraft:spruce_planks
fill ~33 ~-1 ~-55 ~38 ~-1 ~-50 minecraft:spruce_planks
fill ~33 ~5 ~-49 ~39 ~7 ~-49 minecraft:spruce_planks
fill ~33 ~6 ~-55 ~39 ~6 ~-48 minecraft:spruce_planks
fill ~33 ~7 ~-55 ~39 ~7 ~-49 minecraft:spruce_planks
fill ~36 ~1 ~-137 ~36 ~9 ~-120 minecraft:spruce_planks
fill ~36 ~7 ~-138 ~54 ~9 ~-138 minecraft:spruce_planks
fill ~36 ~10 ~-136 ~54 ~10 ~-121 minecraft:spruce_planks
fill ~36 ~11 ~-135 ~54 ~11 ~-122 minecraft:spruce_planks
fill ~36 ~12 ~-134 ~54 ~12 ~-123 minecraft:spruce_planks
fill ~36 ~13 ~-133 ~54 ~13 ~-124 minecraft:spruce_planks
fill ~36 ~14 ~-132 ~54 ~14 ~-125 minecraft:spruce_planks
fill ~36 ~15 ~-131 ~54 ~15 ~-126 minecraft:spruce_planks
fill ~36 ~16 ~-130 ~54 ~16 ~-127 minecraft:spruce_planks
fill ~36 ~17 ~-129 ~54 ~17 ~-128 minecraft:spruce_planks
fill ~37 ~-28 ~-70 ~44 ~-18 ~-42 minecraft:spruce_planks
fill ~37 ~-1 ~-137 ~53 ~-1 ~-121 minecraft:spruce_planks
fill ~37 ~1 ~-138 ~54 ~9 ~-138 minecraft:spruce_planks
fill ~37 ~1 ~-120 ~54 ~9 ~-120 minecraft:spruce_planks
fill ~37 ~8 ~-137 ~54 ~8 ~-119 minecraft:spruce_planks
fill ~37 ~9 ~-137 ~54 ~9 ~-120 minecraft:spruce_planks
fill ~38 ~6 ~-112 ~54 ~8 ~-112 minecraft:spruce_planks
fill ~38 ~6 ~-111 ~38 ~8 ~-92 minecraft:spruce_planks
fill ~39 ~-1 ~-111 ~53 ~-1 ~-93 minecraft:spruce_planks
fill ~39 ~5 ~-55 ~39 ~7 ~-49 minecraft:spruce_planks
fill ~39 ~6 ~-92 ~54 ~8 ~-92 minecraft:spruce_planks
fill ~39 ~7 ~-111 ~55 ~7 ~-92 minecraft:spruce_planks
fill ~39 ~8 ~-111 ~54 ~8 ~-92 minecraft:spruce_planks
fill ~40 ~9 ~-112 ~53 ~9 ~-92 minecraft:spruce_planks
fill ~41 ~10 ~-112 ~52 ~10 ~-92 minecraft:spruce_planks
fill ~42 ~5 ~-56 ~49 ~7 ~-56 minecraft:spruce_planks
fill ~42 ~5 ~-55 ~42 ~7 ~-49 minecraft:spruce_planks
fill ~42 ~8 ~-54 ~49 ~8 ~-50 minecraft:spruce_planks
fill ~42 ~9 ~-53 ~49 ~9 ~-51 minecraft:spruce_planks
fill ~42 ~11 ~-112 ~51 ~11 ~-92 minecraft:spruce_planks
fill ~43 ~-1 ~-55 ~48 ~-1 ~-50 minecraft:spruce_planks
fill ~43 ~5 ~-49 ~49 ~7 ~-49 minecraft:spruce_planks
fill ~43 ~6 ~-55 ~49 ~6 ~-48 minecraft:spruce_planks
fill ~43 ~7 ~-55 ~49 ~7 ~-49 minecraft:spruce_planks
fill ~43 ~12 ~-112 ~50 ~12 ~-92 minecraft:spruce_planks
fill ~44 ~13 ~-112 ~49 ~13 ~-92 minecraft:spruce_planks
fill ~45 ~14 ~-112 ~48 ~14 ~-92 minecraft:spruce_planks
fill ~46 ~15 ~-112 ~47 ~15 ~-92 minecraft:spruce_planks
fill ~49 ~5 ~-55 ~49 ~7 ~-49 minecraft:spruce_planks
fill ~54 ~1 ~-137 ~54 ~9 ~-120 minecraft:spruce_planks
fill ~54 ~6 ~-111 ~54 ~8 ~-92 minecraft:spruce_planks
fill ~55 ~-1 ~-163 ~73 ~-1 ~-157 minecraft:spruce_planks
fill ~55 ~-1 ~-35 ~73 ~-1 ~-29 minecraft:spruce_planks
fill ~55 ~6 ~-163 ~73 ~6 ~-157 minecraft:spruce_planks
fill ~55 ~6 ~-35 ~73 ~6 ~-29 minecraft:spruce_planks
fill ~55 ~12 ~-163 ~73 ~12 ~-157 minecraft:spruce_planks
fill ~55 ~12 ~-35 ~73 ~12 ~-29 minecraft:spruce_planks
fill ~55 ~18 ~-163 ~73 ~18 ~-157 minecraft:spruce_planks
fill ~55 ~18 ~-35 ~73 ~18 ~-29 minecraft:spruce_planks
fill ~55 ~24 ~-163 ~73 ~24 ~-157 minecraft:spruce_planks
fill ~55 ~24 ~-35 ~73 ~24 ~-29 minecraft:spruce_planks
fill ~56 ~-1 ~-165 ~72 ~-1 ~-155 minecraft:spruce_planks
fill ~56 ~-1 ~-37 ~72 ~-1 ~-27 minecraft:spruce_planks
fill ~56 ~6 ~-165 ~72 ~6 ~-155 minecraft:spruce_planks
fill ~56 ~6 ~-37 ~72 ~6 ~-27 minecraft:spruce_planks
fill ~56 ~12 ~-165 ~72 ~12 ~-155 minecraft:spruce_planks
fill ~56 ~12 ~-37 ~72 ~12 ~-27 minecraft:spruce_planks
fill ~56 ~18 ~-165 ~72 ~18 ~-155 minecraft:spruce_planks
fill ~56 ~18 ~-37 ~72 ~18 ~-27 minecraft:spruce_planks
fill ~56 ~24 ~-165 ~72 ~24 ~-155 minecraft:spruce_planks
fill ~56 ~24 ~-37 ~72 ~24 ~-27 minecraft:spruce_planks
fill ~57 ~-1 ~-166 ~71 ~-1 ~-154 minecraft:spruce_planks
fill ~57 ~-1 ~-38 ~71 ~-1 ~-26 minecraft:spruce_planks
fill ~57 ~6 ~-166 ~71 ~6 ~-154 minecraft:spruce_planks
fill ~57 ~6 ~-38 ~71 ~6 ~-26 minecraft:spruce_planks
fill ~57 ~12 ~-166 ~71 ~12 ~-154 minecraft:spruce_planks
fill ~57 ~12 ~-38 ~71 ~12 ~-26 minecraft:spruce_planks
fill ~57 ~18 ~-166 ~71 ~18 ~-154 minecraft:spruce_planks
fill ~57 ~18 ~-38 ~71 ~18 ~-26 minecraft:spruce_planks
fill ~57 ~24 ~-166 ~71 ~24 ~-154 minecraft:spruce_planks
fill ~57 ~24 ~-38 ~71 ~24 ~-26 minecraft:spruce_planks
fill ~58 ~-1 ~-167 ~70 ~-1 ~-153 minecraft:spruce_planks
fill ~58 ~-1 ~-39 ~70 ~-1 ~-25 minecraft:spruce_planks
fill ~58 ~6 ~-167 ~70 ~6 ~-153 minecraft:spruce_planks
fill ~58 ~6 ~-39 ~70 ~6 ~-25 minecraft:spruce_planks
fill ~58 ~12 ~-167 ~70 ~12 ~-153 minecraft:spruce_planks
fill ~58 ~12 ~-39 ~70 ~12 ~-25 minecraft:spruce_planks
fill ~58 ~18 ~-167 ~70 ~18 ~-153 minecraft:spruce_planks
fill ~58 ~18 ~-39 ~70 ~18 ~-25 minecraft:spruce_planks
fill ~58 ~24 ~-167 ~70 ~24 ~-153 minecraft:spruce_planks
fill ~58 ~24 ~-39 ~70 ~24 ~-25 minecraft:spruce_planks
fill ~59 ~-1 ~-168 ~69 ~-1 ~-152 minecraft:spruce_planks
fill ~59 ~-1 ~-98 ~69 ~-1 ~-94 minecraft:spruce_planks
fill ~59 ~-1 ~-40 ~69 ~-1 ~-24 minecraft:spruce_planks
fill ~59 ~6 ~-168 ~69 ~6 ~-152 minecraft:spruce_planks
fill ~59 ~6 ~-40 ~69 ~6 ~-24 minecraft:spruce_planks
fill ~59 ~9 ~-98 ~69 ~9 ~-94 minecraft:spruce_planks
fill ~59 ~12 ~-168 ~69 ~12 ~-152 minecraft:spruce_planks
fill ~59 ~12 ~-40 ~69 ~12 ~-24 minecraft:spruce_planks
fill ~59 ~18 ~-168 ~69 ~18 ~-152 minecraft:spruce_planks
fill ~59 ~18 ~-98 ~69 ~18 ~-94 minecraft:spruce_planks
fill ~59 ~18 ~-40 ~69 ~18 ~-24 minecraft:spruce_planks
fill ~59 ~24 ~-168 ~69 ~24 ~-152 minecraft:spruce_planks
fill ~59 ~24 ~-40 ~69 ~24 ~-24 minecraft:spruce_planks
fill ~60 ~-1 ~-99 ~68 ~-1 ~-93 minecraft:spruce_planks
fill ~60 ~9 ~-99 ~68 ~9 ~-93 minecraft:spruce_planks
fill ~60 ~18 ~-99 ~68 ~18 ~-93 minecraft:spruce_planks
fill ~61 ~-1 ~-169 ~67 ~-1 ~-151 minecraft:spruce_planks
fill ~61 ~-1 ~-100 ~67 ~-1 ~-92 minecraft:spruce_planks
fill ~61 ~-1 ~-41 ~67 ~-1 ~-23 minecraft:spruce_planks
fill ~61 ~6 ~-169 ~67 ~6 ~-151 minecraft:spruce_planks
fill ~61 ~6 ~-41 ~67 ~6 ~-23 minecraft:spruce_planks
fill ~61 ~9 ~-100 ~67 ~9 ~-92 minecraft:spruce_planks
fill ~61 ~12 ~-169 ~67 ~12 ~-151 minecraft:spruce_planks
fill ~61 ~12 ~-41 ~67 ~12 ~-23 minecraft:spruce_planks
fill ~61 ~18 ~-169 ~67 ~18 ~-151 minecraft:spruce_planks
fill ~61 ~18 ~-100 ~67 ~18 ~-92 minecraft:spruce_planks
fill ~61 ~18 ~-41 ~67 ~18 ~-23 minecraft:spruce_planks
fill ~61 ~24 ~-169 ~67 ~24 ~-151 minecraft:spruce_planks
fill ~61 ~24 ~-41 ~67 ~24 ~-23 minecraft:spruce_planks
fill ~62 ~-1 ~-101 ~66 ~-1 ~-91 minecraft:spruce_planks
fill ~62 ~9 ~-101 ~66 ~9 ~-91 minecraft:spruce_planks
fill ~62 ~18 ~-101 ~66 ~18 ~-91 minecraft:spruce_planks
fill ~-100 ~-1 ~-196 ~100 ~-1 ~-173 minecraft:grass_block
fill ~-100 ~-1 ~-172 ~-68 ~-1 ~-172 minecraft:grass_block
fill ~-100 ~-1 ~-171 ~-70 ~-1 ~-171 minecraft:grass_block
fill ~-100 ~-1 ~-170 ~-72 ~-1 ~-170 minecraft:grass_block
fill ~-100 ~-1 ~-169 ~-73 ~-1 ~-169 minecraft:grass_block
fill ~-100 ~-1 ~-168 ~-74 ~-1 ~-168 minecraft:grass_block
fill ~-100 ~-1 ~-167 ~-75 ~-1 ~-166 minecraft:grass_block
fill ~-100 ~-1 ~-165 ~-76 ~-1 ~-164 minecraft:grass_block
fill ~-100 ~-1 ~-163 ~-77 ~-1 ~4 minecraft:grass_block
fill ~-76 ~-1 ~-156 ~-76 ~-1 ~-36 minecraft:grass_block
fill ~-76 ~-1 ~-28 ~-76 ~-1 ~4 minecraft:grass_block
fill ~-75 ~-1 ~-154 ~-75 ~-1 ~-38 minecraft:grass_block
fill ~-75 ~-1 ~-26 ~-75 ~-1 ~4 minecraft:grass_block
fill ~-74 ~-1 ~-152 ~-74 ~-1 ~-40 minecraft:grass_block
fill ~-74 ~-1 ~-24 ~-74 ~-1 ~4 minecraft:grass_block
fill ~-73 ~-1 ~-151 ~-73 ~-1 ~-41 minecraft:grass_block
fill ~-73 ~-1 ~-23 ~-73 ~-1 ~4 minecraft:grass_block
fill ~-72 ~-1 ~-150 ~-72 ~-1 ~-99 minecraft:grass_block
fill ~-72 ~-1 ~-93 ~-72 ~-1 ~-42 minecraft:grass_block
fill ~-72 ~-1 ~-22 ~-72 ~-1 ~4 minecraft:grass_block
fill ~-71 ~-1 ~-149 ~-70 ~-1 ~-103 minecraft:grass_block
fill ~-71 ~-1 ~-102 ~-71 ~-1 ~-101 minecraft:grass_block
fill ~-71 ~-1 ~-91 ~-71 ~-1 ~-43 minecraft:grass_block
fill ~-71 ~-1 ~-21 ~-70 ~-1 ~4 minecraft:grass_block
fill ~-70 ~-1 ~-89 ~-69 ~-1 ~-44 minecraft:grass_block
setblock ~-70 ~-1 ~-43 minecraft:grass_block
fill ~-69 ~-1 ~-148 ~-68 ~-1 ~-104 minecraft:grass_block
setblock ~-69 ~-1 ~-103 minecraft:grass_block
fill ~-69 ~-1 ~-20 ~-68 ~-1 ~4 minecraft:grass_block
fill ~-68 ~-1 ~-88 ~-67 ~-1 ~-45 minecraft:grass_block
setblock ~-68 ~-1 ~-44 minecraft:grass_block
fill ~-67 ~-1 ~-147 ~-66 ~-1 ~-105 minecraft:grass_block
setblock ~-67 ~-1 ~-104 minecraft:grass_block
fill ~-67 ~-1 ~-19 ~-5 ~-1 ~4 minecraft:grass_block
fill ~-66 ~-1 ~-87 ~-66 ~-1 ~-45 minecraft:grass_block
fill ~-60 ~-1 ~-172 ~60 ~-1 ~-172 minecraft:grass_block
fill ~-60 ~-1 ~-20 ~-5 ~-1 ~4 minecraft:grass_block
fill ~-59 ~-1 ~-148 ~-34 ~-1 ~-139 minecraft:grass_block
fill ~-59 ~-1 ~-138 ~-55 ~-1 ~-103 minecraft:grass_block
fill ~-59 ~-1 ~-89 ~-20 ~-1 ~-85 minecraft:grass_block
fill ~-59 ~-1 ~-84 ~-55 ~-1 ~-44 minecraft:grass_block
fill ~-58 ~-1 ~-171 ~58 ~-1 ~-171 minecraft:grass_block
fill ~-58 ~-1 ~-149 ~-33 ~-1 ~-149 minecraft:grass_block
fill ~-58 ~-1 ~-97 ~-55 ~-1 ~-95 minecraft:grass_block
fill ~-58 ~-1 ~-43 ~58 ~-1 ~-43 minecraft:grass_block
fill ~-58 ~-1 ~-21 ~-19 ~-1 ~4 minecraft:grass_block
fill ~-57 ~-1 ~-153 ~-56 ~-1 ~-152 minecraft:grass_block
fill ~-57 ~-1 ~-102 ~-55 ~-1 ~-101 minecraft:grass_block
fill ~-57 ~-1 ~-91 ~-10 ~-1 ~-91 minecraft:grass_block
fill ~-57 ~-1 ~-90 ~-15 ~-1 ~-90 minecraft:grass_block
fill ~-57 ~-1 ~-40 ~-11 ~-1 ~-40 minecraft:grass_block
fill ~-57 ~-1 ~-39 ~-56 ~-1 ~-39 minecraft:grass_block
fill ~-56 ~-1 ~-170 ~56 ~-1 ~-170 minecraft:grass_block
fill ~-56 ~-1 ~-151 ~-32 ~-1 ~-151 minecraft:grass_block
fill ~-56 ~-1 ~-150 ~-33 ~-1 ~-149 minecraft:grass_block
fill ~-56 ~-1 ~-100 ~-55 ~-1 ~-99 minecraft:grass_block
fill ~-56 ~-1 ~-93 ~-55 ~-1 ~-40 minecraft:grass_block
fill ~-56 ~-1 ~-22 ~-21 ~-1 ~4 minecraft:grass_block
fill ~-55 ~-1 ~-169 ~55 ~-1 ~-169 minecraft:grass_block
fill ~-55 ~-1 ~-152 ~-31 ~-1 ~-152 minecraft:grass_block
fill ~-55 ~-1 ~-98 ~-55 ~-1 ~-40 minecraft:grass_block
fill ~-55 ~-1 ~-23 ~-22 ~-1 ~4 minecraft:grass_block
fill ~-54 ~-1 ~-168 ~-3 ~-1 ~-168 minecraft:grass_block
fill ~-54 ~-1 ~-119 ~-28 ~-1 ~-113 minecraft:grass_block
fill ~-54 ~-1 ~-65 ~59 ~-1 ~-60 minecraft:grass_block
fill ~-54 ~-1 ~-59 ~24 ~-1 ~-57 minecraft:grass_block
fill ~-54 ~-1 ~-56 ~-51 ~-1 ~-40 minecraft:grass_block
fill ~-54 ~-1 ~-24 ~-23 ~-1 ~4 minecraft:grass_block
fill ~-53 ~-1 ~-167 ~-5 ~-1 ~-167 minecraft:grass_block
fill ~-53 ~-1 ~-166 ~-7 ~-1 ~-166 minecraft:grass_block
fill ~-53 ~-1 ~-154 ~-7 ~-1 ~-154 minecraft:grass_block
fill ~-53 ~-1 ~-153 ~-29 ~-1 ~-153 minecraft:grass_block
fill ~-53 ~-1 ~-39 ~-19 ~-1 ~-39 minecraft:grass_block
fill ~-53 ~-1 ~-38 ~-33 ~-1 ~-38 minecraft:grass_block
fill ~-53 ~-1 ~-26 ~-24 ~-1 ~4 minecraft:grass_block
fill ~-52 ~-1 ~-165 ~-7 ~-1 ~-165 minecraft:grass_block
fill ~-52 ~-1 ~-164 ~-8 ~-1 ~-164 minecraft:grass_block
fill ~-52 ~-1 ~-155 ~-9 ~-1 ~-154 minecraft:grass_block
fill ~-52 ~-1 ~-37 ~-33 ~-1 ~-37 minecraft:grass_block
fill ~-52 ~-1 ~-28 ~-25 ~-1 ~4 minecraft:grass_block
fill ~-51 ~-1 ~-163 ~-8 ~-1 ~-163 minecraft:grass_block
fill ~-51 ~-1 ~-162 ~-9 ~-1 ~-162 minecraft:grass_block
fill ~-51 ~-1 ~-30 ~-25 ~-1 ~4 minecraft:grass_block
fill ~-50 ~-1 ~-48 ~59 ~-1 ~-44 minecraft:grass_block
fill ~-50 ~-1 ~-42 ~56 ~-1 ~-42 minecraft:grass_block
fill ~-50 ~-1 ~-41 ~-11 ~-1 ~-40 minecraft:grass_block
fill ~-42 ~-1 ~-56 ~-41 ~-1 ~-37 minecraft:grass_block
fill ~-39 ~-1 ~-84 ~59 ~-1 ~-75 minecraft:grass_block
fill ~-39 ~-1 ~-74 ~-10 ~-1 ~-57 minecraft:grass_block
