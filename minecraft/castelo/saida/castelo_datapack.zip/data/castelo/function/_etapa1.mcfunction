execute as @e[type=minecraft:marker,tag=castelo_origem,limit=1] at @s run function castelo:_blocos1
tellraw @a [{"text":"[Castelo] ","color":"gold"},{"text":"Construindo... 12%","color":"gray"}]
schedule function castelo:_etapa2 1t
