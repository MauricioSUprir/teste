kill @e[type=minecraft:marker,tag=castelo_origem]
summon minecraft:marker ~ ~ ~ {Tags:["castelo_origem"]}
forceload add ~-100 ~-196 ~100 ~4
tellraw @a [{"text":"[Castelo] ","color":"gold"},{"text":"Carregando a área... a construção começa em 3 segundos.","color":"white"}]
schedule function castelo:_etapa1 3s
