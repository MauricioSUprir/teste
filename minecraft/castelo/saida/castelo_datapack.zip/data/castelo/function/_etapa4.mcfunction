execute as @e[type=minecraft:marker,tag=castelo_origem,limit=1] at @s run function castelo:_blocos4
tellraw @a [{"text":"[Castelo] ","color":"gold"},{"text":"Construindo... 50%","color":"gray"}]
schedule function castelo:_etapa5 1t
