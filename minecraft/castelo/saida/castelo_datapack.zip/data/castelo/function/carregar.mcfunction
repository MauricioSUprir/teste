tellraw @a [{"text":"[Castelo] ","color":"gold"},{"text":"Datapack carregado! Fique num lugar aberto e digite /function castelo:construir","color":"white"}]
