setblock ~9 ~19 ~-39 minecraft:mossy_stone_bricks
setblock ~9 ~19 ~-35 minecraft:mossy_stone_bricks
fill ~9 ~20 ~-34 ~9 ~20 ~-33 minecraft:mossy_stone_bricks
setblock ~9 ~21 ~-103 minecraft:mossy_stone_bricks
fill ~9 ~21 ~-25 ~10 ~21 ~-25 minecraft:mossy_stone_bricks
setblock ~9 ~23 ~-40 minecraft:mossy_stone_bricks
fill ~9 ~24 ~-103 ~9 ~25 ~-103 minecraft:mossy_stone_bricks
setblock ~9 ~25 ~-102 minecraft:mossy_stone_bricks
setblock ~9 ~26 ~-24 minecraft:mossy_stone_bricks
setblock ~9 ~27 ~-36 minecraft:mossy_stone_bricks
setblock ~9 ~28 ~-146 minecraft:mossy_stone_bricks
setblock ~9 ~28 ~-35 minecraft:mossy_stone_bricks
setblock ~9 ~31 ~-23 minecraft:mossy_stone_bricks
setblock ~9 ~38 ~-145 minecraft:mossy_stone_bricks
fill ~9 ~38 ~-103 ~9 ~39 ~-103 minecraft:mossy_stone_bricks
setblock ~9 ~40 ~-146 minecraft:mossy_stone_bricks
setblock ~9 ~44 ~-145 minecraft:mossy_stone_bricks
setblock ~9 ~51 ~-125 minecraft:mossy_stone_bricks
setblock ~9 ~51 ~-119 minecraft:mossy_stone_bricks
setblock ~9 ~52 ~-123 minecraft:mossy_stone_bricks
setblock ~9 ~58 ~-119 minecraft:mossy_stone_bricks
fill ~9 ~59 ~-126 ~9 ~61 ~-126 minecraft:mossy_stone_bricks
setblock ~9 ~60 ~-128 minecraft:mossy_stone_bricks
setblock ~9 ~61 ~-119 minecraft:mossy_stone_bricks
fill ~9 ~64 ~-125 ~9 ~64 ~-124 minecraft:mossy_stone_bricks
setblock ~9 ~65 ~-124 minecraft:mossy_stone_bricks
setblock ~9 ~67 ~-130 minecraft:mossy_stone_bricks
setblock ~10 ~1 ~-145 minecraft:mossy_stone_bricks
setblock ~10 ~1 ~-35 minecraft:mossy_stone_bricks
fill ~10 ~4 ~-146 ~12 ~5 ~-146 minecraft:mossy_stone_bricks
setblock ~10 ~6 ~-160 minecraft:mossy_stone_bricks
setblock ~10 ~6 ~-25 minecraft:mossy_stone_bricks
setblock ~10 ~10 ~-146 minecraft:mossy_stone_bricks
setblock ~10 ~10 ~-35 minecraft:mossy_stone_bricks
setblock ~10 ~13 ~-103 minecraft:mossy_stone_bricks
setblock ~10 ~14 ~-25 minecraft:mossy_stone_bricks
setblock ~10 ~16 ~-24 minecraft:mossy_stone_bricks
setblock ~10 ~17 ~-145 minecraft:mossy_stone_bricks
setblock ~10 ~17 ~-35 minecraft:mossy_stone_bricks
setblock ~10 ~17 ~-25 minecraft:mossy_stone_bricks
setblock ~10 ~25 ~-25 minecraft:mossy_stone_bricks
setblock ~10 ~27 ~-102 minecraft:mossy_stone_bricks
setblock ~10 ~27 ~-24 minecraft:mossy_stone_bricks
setblock ~10 ~28 ~-103 minecraft:mossy_stone_bricks
setblock ~10 ~37 ~-145 minecraft:mossy_stone_bricks
setblock ~10 ~37 ~-103 minecraft:mossy_stone_bricks
setblock ~10 ~43 ~-145 minecraft:mossy_stone_bricks
fill ~10 ~44 ~-135 ~11 ~44 ~-134 minecraft:mossy_stone_bricks
setblock ~10 ~44 ~-124 minecraft:mossy_stone_bricks
setblock ~10 ~44 ~-109 minecraft:mossy_stone_bricks
setblock ~10 ~45 ~-147 minecraft:mossy_stone_bricks
setblock ~10 ~55 ~-127 minecraft:mossy_stone_bricks
setblock ~10 ~55 ~-123 minecraft:mossy_stone_bricks
setblock ~10 ~68 ~-128 minecraft:mossy_stone_bricks
setblock ~11 ~ ~-139 minecraft:mossy_stone_bricks
setblock ~11 ~ ~-118 minecraft:mossy_stone_bricks
setblock ~11 ~ ~-111 minecraft:mossy_stone_bricks
setblock ~11 ~1 ~-130 minecraft:mossy_stone_bricks
setblock ~11 ~1 ~-122 minecraft:mossy_stone_bricks
setblock ~11 ~3 ~-104 minecraft:mossy_stone_bricks
setblock ~11 ~4 ~-156 minecraft:mossy_stone_bricks
setblock ~11 ~4 ~-132 minecraft:mossy_stone_bricks
fill ~11 ~4 ~-124 ~11 ~4 ~-123 minecraft:mossy_stone_bricks
fill ~11 ~4 ~-107 ~11 ~4 ~-106 minecraft:mossy_stone_bricks
setblock ~11 ~4 ~-103 minecraft:mossy_stone_bricks
setblock ~11 ~4 ~-23 minecraft:mossy_stone_bricks
setblock ~11 ~5 ~-138 minecraft:mossy_stone_bricks
setblock ~11 ~5 ~-112 minecraft:mossy_stone_bricks
fill ~11 ~5 ~-107 ~11 ~6 ~-107 minecraft:mossy_stone_bricks
setblock ~11 ~5 ~-104 minecraft:mossy_stone_bricks
fill ~11 ~5 ~-102 ~13 ~5 ~-102 minecraft:mossy_stone_bricks
setblock ~11 ~6 ~-156 minecraft:mossy_stone_bricks
setblock ~11 ~6 ~-131 minecraft:mossy_stone_bricks
fill ~11 ~6 ~-119 ~11 ~7 ~-119 minecraft:mossy_stone_bricks
fill ~11 ~7 ~-124 ~11 ~8 ~-124 minecraft:mossy_stone_bricks
fill ~11 ~7 ~-114 ~11 ~7 ~-113 minecraft:mossy_stone_bricks
setblock ~11 ~7 ~-23 minecraft:mossy_stone_bricks
fill ~11 ~8 ~-125 ~12 ~8 ~-125 minecraft:mossy_stone_bricks
fill ~11 ~8 ~-110 ~11 ~8 ~-109 minecraft:mossy_stone_bricks
setblock ~11 ~9 ~-139 minecraft:mossy_stone_bricks
setblock ~11 ~9 ~-134 minecraft:mossy_stone_bricks
setblock ~11 ~9 ~-130 minecraft:mossy_stone_bricks
fill ~11 ~9 ~-117 ~11 ~9 ~-116 minecraft:mossy_stone_bricks
fill ~11 ~11 ~-156 ~11 ~12 ~-156 minecraft:mossy_stone_bricks
setblock ~11 ~12 ~-138 minecraft:mossy_stone_bricks
setblock ~11 ~12 ~-131 minecraft:mossy_stone_bricks
setblock ~11 ~12 ~-129 minecraft:mossy_stone_bricks
setblock ~11 ~12 ~-125 minecraft:mossy_stone_bricks
setblock ~11 ~12 ~-118 minecraft:mossy_stone_bricks
setblock ~11 ~13 ~-37 minecraft:mossy_stone_bricks
fill ~11 ~13 ~-24 ~11 ~13 ~-23 minecraft:mossy_stone_bricks
fill ~11 ~14 ~-139 ~11 ~15 ~-139 minecraft:mossy_stone_bricks
setblock ~11 ~14 ~-135 minecraft:mossy_stone_bricks
setblock ~11 ~14 ~-124 minecraft:mossy_stone_bricks
setblock ~11 ~14 ~-113 minecraft:mossy_stone_bricks
setblock ~11 ~14 ~-111 minecraft:mossy_stone_bricks
fill ~11 ~14 ~-102 ~12 ~14 ~-102 minecraft:mossy_stone_bricks
setblock ~11 ~14 ~-23 minecraft:mossy_stone_bricks
setblock ~11 ~15 ~-144 minecraft:mossy_stone_bricks
setblock ~11 ~15 ~-133 minecraft:mossy_stone_bricks
setblock ~11 ~15 ~-112 minecraft:mossy_stone_bricks
setblock ~11 ~15 ~-24 minecraft:mossy_stone_bricks
setblock ~11 ~16 ~-145 minecraft:mossy_stone_bricks
setblock ~11 ~16 ~-140 minecraft:mossy_stone_bricks
setblock ~11 ~16 ~-113 minecraft:mossy_stone_bricks
fill ~11 ~17 ~-146 ~13 ~17 ~-146 minecraft:mossy_stone_bricks
setblock ~11 ~17 ~-129 minecraft:mossy_stone_bricks
fill ~11 ~17 ~-111 ~11 ~18 ~-111 minecraft:mossy_stone_bricks
setblock ~11 ~17 ~-105 minecraft:mossy_stone_bricks
fill ~11 ~17 ~-23 ~12 ~17 ~-23 minecraft:mossy_stone_bricks
setblock ~11 ~18 ~-142 minecraft:mossy_stone_bricks
setblock ~11 ~18 ~-126 minecraft:mossy_stone_bricks
setblock ~11 ~18 ~-107 minecraft:mossy_stone_bricks
setblock ~11 ~19 ~-113 minecraft:mossy_stone_bricks
setblock ~11 ~20 ~-142 minecraft:mossy_stone_bricks
fill ~11 ~21 ~-131 ~11 ~22 ~-131 minecraft:mossy_stone_bricks
fill ~11 ~21 ~-117 ~11 ~22 ~-117 minecraft:mossy_stone_bricks
setblock ~11 ~21 ~-23 minecraft:mossy_stone_bricks
setblock ~11 ~24 ~-105 minecraft:mossy_stone_bricks
fill ~11 ~25 ~-138 ~11 ~25 ~-137 minecraft:mossy_stone_bricks
setblock ~11 ~25 ~-135 minecraft:mossy_stone_bricks
setblock ~11 ~25 ~-120 minecraft:mossy_stone_bricks
setblock ~11 ~26 ~-134 minecraft:mossy_stone_bricks
setblock ~11 ~26 ~-130 minecraft:mossy_stone_bricks
fill ~11 ~26 ~-127 ~11 ~26 ~-126 minecraft:mossy_stone_bricks
fill ~11 ~26 ~-102 ~12 ~26 ~-102 minecraft:mossy_stone_bricks
setblock ~11 ~27 ~-108 minecraft:mossy_stone_bricks
fill ~11 ~27 ~-37 ~11 ~28 ~-37 minecraft:mossy_stone_bricks
setblock ~11 ~28 ~-135 minecraft:mossy_stone_bricks
fill ~11 ~28 ~-128 ~11 ~29 ~-128 minecraft:mossy_stone_bricks
setblock ~11 ~28 ~-125 minecraft:mossy_stone_bricks
setblock ~11 ~29 ~-139 minecraft:mossy_stone_bricks
fill ~11 ~29 ~-103 ~11 ~29 ~-102 minecraft:mossy_stone_bricks
setblock ~11 ~30 ~-134 minecraft:mossy_stone_bricks
fill ~11 ~30 ~-129 ~11 ~31 ~-129 minecraft:mossy_stone_bricks
fill ~11 ~30 ~-114 ~11 ~31 ~-114 minecraft:mossy_stone_bricks
setblock ~11 ~30 ~-106 minecraft:mossy_stone_bricks
setblock ~11 ~31 ~-137 minecraft:mossy_stone_bricks
setblock ~11 ~31 ~-131 minecraft:mossy_stone_bricks
fill ~11 ~31 ~-120 ~11 ~31 ~-119 minecraft:mossy_stone_bricks
fill ~11 ~31 ~-113 ~11 ~31 ~-111 minecraft:mossy_stone_bricks
setblock ~11 ~31 ~-38 minecraft:mossy_stone_bricks
fill ~11 ~32 ~-139 ~11 ~33 ~-139 minecraft:mossy_stone_bricks
fill ~11 ~32 ~-134 ~11 ~33 ~-134 minecraft:mossy_stone_bricks
fill ~11 ~32 ~-128 ~11 ~33 ~-128 minecraft:mossy_stone_bricks
setblock ~11 ~34 ~-141 minecraft:mossy_stone_bricks
setblock ~11 ~34 ~-129 minecraft:mossy_stone_bricks
setblock ~11 ~34 ~-121 minecraft:mossy_stone_bricks
setblock ~11 ~34 ~-104 minecraft:mossy_stone_bricks
fill ~11 ~34 ~-102 ~11 ~35 ~-102 minecraft:mossy_stone_bricks
setblock ~11 ~35 ~-130 minecraft:mossy_stone_bricks
setblock ~11 ~35 ~-127 minecraft:mossy_stone_bricks
setblock ~11 ~35 ~-120 minecraft:mossy_stone_bricks
setblock ~11 ~37 ~-104 minecraft:mossy_stone_bricks
setblock ~11 ~38 ~-135 minecraft:mossy_stone_bricks
fill ~11 ~38 ~-117 ~11 ~39 ~-117 minecraft:mossy_stone_bricks
setblock ~11 ~38 ~-111 minecraft:mossy_stone_bricks
fill ~11 ~38 ~-103 ~11 ~39 ~-103 minecraft:mossy_stone_bricks
setblock ~11 ~39 ~-144 minecraft:mossy_stone_bricks
setblock ~11 ~39 ~-140 minecraft:mossy_stone_bricks
setblock ~11 ~40 ~-106 minecraft:mossy_stone_bricks
fill ~11 ~40 ~-102 ~13 ~40 ~-102 minecraft:mossy_stone_bricks
setblock ~11 ~41 ~-134 minecraft:mossy_stone_bricks
setblock ~11 ~41 ~-120 minecraft:mossy_stone_bricks
setblock ~11 ~42 ~-121 minecraft:mossy_stone_bricks
setblock ~11 ~42 ~-111 minecraft:mossy_stone_bricks
setblock ~11 ~43 ~-117 minecraft:mossy_stone_bricks
setblock ~11 ~44 ~-138 minecraft:mossy_stone_bricks
setblock ~11 ~44 ~-131 minecraft:mossy_stone_bricks
fill ~11 ~44 ~-104 ~12 ~44 ~-104 minecraft:mossy_stone_bricks
setblock ~12 ~1 ~-145 minecraft:mossy_stone_bricks
setblock ~12 ~1 ~-36 minecraft:mossy_stone_bricks
setblock ~12 ~3 ~-156 minecraft:mossy_stone_bricks
setblock ~12 ~5 ~-37 minecraft:mossy_stone_bricks
setblock ~12 ~5 ~-24 minecraft:mossy_stone_bricks
setblock ~12 ~7 ~-159 minecraft:mossy_stone_bricks
setblock ~12 ~7 ~-156 minecraft:mossy_stone_bricks
setblock ~12 ~7 ~-146 minecraft:mossy_stone_bricks
setblock ~12 ~9 ~-125 minecraft:mossy_stone_bricks
setblock ~12 ~10 ~-156 minecraft:mossy_stone_bricks
setblock ~12 ~15 ~-160 minecraft:mossy_stone_bricks
setblock ~12 ~18 ~-23 minecraft:mossy_stone_bricks
setblock ~12 ~22 ~-36 minecraft:mossy_stone_bricks
setblock ~12 ~22 ~-23 minecraft:mossy_stone_bricks
setblock ~12 ~23 ~-37 minecraft:mossy_stone_bricks
setblock ~12 ~31 ~-102 minecraft:mossy_stone_bricks
fill ~12 ~31 ~-39 ~12 ~32 ~-39 minecraft:mossy_stone_bricks
setblock ~12 ~31 ~-21 minecraft:mossy_stone_bricks
fill ~12 ~35 ~-146 ~12 ~35 ~-145 minecraft:mossy_stone_bricks
setblock ~12 ~35 ~-103 minecraft:mossy_stone_bricks
setblock ~12 ~44 ~-130 minecraft:mossy_stone_bricks
setblock ~12 ~44 ~-128 minecraft:mossy_stone_bricks
setblock ~12 ~44 ~-120 minecraft:mossy_stone_bricks
fill ~13 ~1 ~-156 ~14 ~1 ~-156 minecraft:mossy_stone_bricks
fill ~13 ~4 ~-102 ~13 ~5 ~-102 minecraft:mossy_stone_bricks
setblock ~13 ~7 ~-145 minecraft:mossy_stone_bricks
setblock ~13 ~7 ~-23 minecraft:mossy_stone_bricks
setblock ~13 ~8 ~-146 minecraft:mossy_stone_bricks
setblock ~13 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~13 ~12 ~-102 minecraft:mossy_stone_bricks
fill ~13 ~16 ~-145 ~14 ~16 ~-145 minecraft:mossy_stone_bricks
setblock ~13 ~17 ~-38 minecraft:mossy_stone_bricks
fill ~13 ~18 ~-145 ~14 ~18 ~-145 minecraft:mossy_stone_bricks
fill ~13 ~22 ~-38 ~14 ~22 ~-38 minecraft:mossy_stone_bricks
setblock ~13 ~24 ~-146 minecraft:mossy_stone_bricks
setblock ~13 ~26 ~-146 minecraft:mossy_stone_bricks
setblock ~13 ~27 ~-37 minecraft:mossy_stone_bricks
setblock ~13 ~28 ~-102 minecraft:mossy_stone_bricks
setblock ~13 ~32 ~-146 minecraft:mossy_stone_bricks
setblock ~13 ~35 ~-102 minecraft:mossy_stone_bricks
setblock ~13 ~38 ~-102 minecraft:mossy_stone_bricks
setblock ~13 ~44 ~-146 minecraft:mossy_stone_bricks
setblock ~13 ~44 ~-129 minecraft:mossy_stone_bricks
fill ~13 ~44 ~-113 ~14 ~44 ~-113 minecraft:mossy_stone_bricks
setblock ~13 ~45 ~-147 minecraft:mossy_stone_bricks
setblock ~14 ~3 ~-145 minecraft:mossy_stone_bricks
setblock ~14 ~3 ~-103 minecraft:mossy_stone_bricks
setblock ~14 ~6 ~-23 minecraft:mossy_stone_bricks
fill ~14 ~9 ~-145 ~15 ~9 ~-145 minecraft:mossy_stone_bricks
setblock ~14 ~10 ~-156 minecraft:mossy_stone_bricks
fill ~14 ~10 ~-125 ~14 ~11 ~-125 minecraft:mossy_stone_bricks
setblock ~14 ~10 ~-103 minecraft:mossy_stone_bricks
setblock ~14 ~14 ~-23 minecraft:mossy_stone_bricks
setblock ~14 ~15 ~-103 minecraft:mossy_stone_bricks
setblock ~14 ~15 ~-38 minecraft:mossy_stone_bricks
setblock ~14 ~17 ~-161 minecraft:mossy_stone_bricks
setblock ~14 ~18 ~-160 minecraft:mossy_stone_bricks
setblock ~14 ~22 ~-23 minecraft:mossy_stone_bricks
setblock ~14 ~23 ~-22 minecraft:mossy_stone_bricks
setblock ~14 ~24 ~-103 minecraft:mossy_stone_bricks
fill ~14 ~25 ~-22 ~15 ~25 ~-22 minecraft:mossy_stone_bricks
setblock ~14 ~26 ~-37 minecraft:mossy_stone_bricks
fill ~14 ~27 ~-145 ~15 ~27 ~-145 minecraft:mossy_stone_bricks
setblock ~14 ~27 ~-23 minecraft:mossy_stone_bricks
setblock ~14 ~30 ~-39 minecraft:mossy_stone_bricks
fill ~14 ~32 ~-124 ~14 ~33 ~-124 minecraft:mossy_stone_bricks
setblock ~14 ~36 ~-103 minecraft:mossy_stone_bricks
setblock ~14 ~44 ~-136 minecraft:mossy_stone_bricks
setblock ~14 ~44 ~-127 minecraft:mossy_stone_bricks
setblock ~14 ~44 ~-109 minecraft:mossy_stone_bricks
setblock ~15 ~ ~-156 minecraft:mossy_stone_bricks
fill ~15 ~1 ~-37 ~16 ~1 ~-37 minecraft:mossy_stone_bricks
setblock ~15 ~4 ~-103 minecraft:mossy_stone_bricks
setblock ~15 ~17 ~-102 minecraft:mossy_stone_bricks
setblock ~15 ~17 ~-22 minecraft:mossy_stone_bricks
setblock ~15 ~18 ~-38 minecraft:mossy_stone_bricks
fill ~15 ~21 ~-146 ~16 ~21 ~-146 minecraft:mossy_stone_bricks
setblock ~15 ~21 ~-145 minecraft:mossy_stone_bricks
setblock ~15 ~23 ~-37 minecraft:mossy_stone_bricks
fill ~15 ~26 ~-145 ~15 ~27 ~-145 minecraft:mossy_stone_bricks
setblock ~15 ~26 ~-103 minecraft:mossy_stone_bricks
fill ~15 ~27 ~-146 ~15 ~27 ~-145 minecraft:mossy_stone_bricks
setblock ~15 ~27 ~-124 minecraft:mossy_stone_bricks
setblock ~15 ~27 ~-22 minecraft:mossy_stone_bricks
setblock ~15 ~28 ~-103 minecraft:mossy_stone_bricks
setblock ~15 ~30 ~-102 minecraft:mossy_stone_bricks
setblock ~15 ~30 ~-28 minecraft:mossy_stone_bricks
setblock ~15 ~32 ~-145 minecraft:mossy_stone_bricks
fill ~15 ~32 ~-103 ~15 ~32 ~-102 minecraft:mossy_stone_bricks
fill ~15 ~35 ~-146 ~15 ~36 ~-146 minecraft:mossy_stone_bricks
setblock ~15 ~40 ~-145 minecraft:mossy_stone_bricks
setblock ~15 ~44 ~-142 minecraft:mossy_stone_bricks
setblock ~16 ~3 ~-103 minecraft:mossy_stone_bricks
fill ~16 ~4 ~-37 ~17 ~4 ~-37 minecraft:mossy_stone_bricks
fill ~16 ~4 ~-23 ~16 ~5 ~-23 minecraft:mossy_stone_bricks
setblock ~16 ~5 ~-160 minecraft:mossy_stone_bricks
setblock ~16 ~5 ~-146 minecraft:mossy_stone_bricks
setblock ~16 ~7 ~-38 minecraft:mossy_stone_bricks
fill ~16 ~10 ~-103 ~18 ~10 ~-103 minecraft:mossy_stone_bricks
setblock ~16 ~13 ~-156 minecraft:mossy_stone_bricks
setblock ~16 ~13 ~-23 minecraft:mossy_stone_bricks
setblock ~16 ~16 ~-146 minecraft:mossy_stone_bricks
setblock ~16 ~17 ~-38 minecraft:mossy_stone_bricks
setblock ~16 ~18 ~-103 minecraft:mossy_stone_bricks
setblock ~16 ~18 ~-22 minecraft:mossy_stone_bricks
setblock ~16 ~20 ~-22 minecraft:mossy_stone_bricks
setblock ~16 ~21 ~-103 minecraft:mossy_stone_bricks
fill ~16 ~25 ~-102 ~18 ~25 ~-102 minecraft:mossy_stone_bricks
fill ~16 ~26 ~-22 ~17 ~26 ~-22 minecraft:mossy_stone_bricks
setblock ~16 ~29 ~-23 minecraft:mossy_stone_bricks
fill ~16 ~30 ~-22 ~16 ~30 ~-21 minecraft:mossy_stone_bricks
fill ~16 ~34 ~-103 ~16 ~35 ~-103 minecraft:mossy_stone_bricks
setblock ~16 ~38 ~-102 minecraft:mossy_stone_bricks
setblock ~16 ~42 ~-103 minecraft:mossy_stone_bricks
fill ~16 ~44 ~-139 ~17 ~44 ~-139 minecraft:mossy_stone_bricks
setblock ~16 ~44 ~-125 minecraft:mossy_stone_bricks
setblock ~17 ~3 ~-125 minecraft:mossy_stone_bricks
setblock ~17 ~4 ~-156 minecraft:mossy_stone_bricks
setblock ~17 ~4 ~-103 minecraft:mossy_stone_bricks
setblock ~17 ~8 ~-146 minecraft:mossy_stone_bricks
fill ~17 ~9 ~-145 ~17 ~10 ~-145 minecraft:mossy_stone_bricks
setblock ~17 ~13 ~-146 minecraft:mossy_stone_bricks
setblock ~17 ~14 ~-103 minecraft:mossy_stone_bricks
setblock ~17 ~15 ~-37 minecraft:mossy_stone_bricks
setblock ~17 ~15 ~-22 minecraft:mossy_stone_bricks
setblock ~17 ~17 ~-37 minecraft:mossy_stone_bricks
fill ~17 ~20 ~-145 ~18 ~20 ~-145 minecraft:mossy_stone_bricks
setblock ~17 ~22 ~-23 minecraft:mossy_stone_bricks
fill ~17 ~24 ~-146 ~17 ~25 ~-146 minecraft:mossy_stone_bricks
fill ~17 ~24 ~-103 ~17 ~24 ~-102 minecraft:mossy_stone_bricks
setblock ~17 ~24 ~-38 minecraft:mossy_stone_bricks
setblock ~17 ~30 ~-35 minecraft:mossy_stone_bricks
setblock ~17 ~30 ~-30 minecraft:mossy_stone_bricks
setblock ~17 ~35 ~-102 minecraft:mossy_stone_bricks
fill ~17 ~40 ~-146 ~18 ~40 ~-146 minecraft:mossy_stone_bricks
setblock ~17 ~40 ~-103 minecraft:mossy_stone_bricks
setblock ~17 ~42 ~-102 minecraft:mossy_stone_bricks
setblock ~18 ~1 ~-24 minecraft:mossy_stone_bricks
setblock ~18 ~2 ~-156 minecraft:mossy_stone_bricks
fill ~18 ~3 ~-38 ~19 ~3 ~-38 minecraft:mossy_stone_bricks
fill ~18 ~10 ~-37 ~18 ~10 ~-36 minecraft:mossy_stone_bricks
setblock ~18 ~13 ~-160 minecraft:mossy_stone_bricks
setblock ~18 ~16 ~-37 minecraft:mossy_stone_bricks
setblock ~18 ~20 ~-102 minecraft:mossy_stone_bricks
setblock ~18 ~23 ~-124 minecraft:mossy_stone_bricks
setblock ~18 ~24 ~-145 minecraft:mossy_stone_bricks
fill ~18 ~25 ~-37 ~19 ~25 ~-37 minecraft:mossy_stone_bricks
setblock ~18 ~25 ~-24 minecraft:mossy_stone_bricks
setblock ~18 ~26 ~-37 minecraft:mossy_stone_bricks
fill ~18 ~29 ~-24 ~19 ~29 ~-24 minecraft:mossy_stone_bricks
setblock ~18 ~41 ~-145 minecraft:mossy_stone_bricks
setblock ~18 ~41 ~-103 minecraft:mossy_stone_bricks
setblock ~18 ~44 ~-129 minecraft:mossy_stone_bricks
setblock ~18 ~44 ~-124 minecraft:mossy_stone_bricks
setblock ~18 ~44 ~-111 minecraft:mossy_stone_bricks
setblock ~19 ~ ~-156 minecraft:mossy_stone_bricks
setblock ~19 ~ ~-36 minecraft:mossy_stone_bricks
setblock ~19 ~2 ~-24 minecraft:mossy_stone_bricks
fill ~19 ~5 ~-103 ~19 ~5 ~-102 minecraft:mossy_stone_bricks
fill ~19 ~6 ~-37 ~20 ~6 ~-37 minecraft:mossy_stone_bricks
fill ~19 ~6 ~-23 ~19 ~7 ~-23 minecraft:mossy_stone_bricks
setblock ~19 ~7 ~-102 minecraft:mossy_stone_bricks
setblock ~19 ~8 ~-125 minecraft:mossy_stone_bricks
setblock ~19 ~14 ~-160 minecraft:mossy_stone_bricks
fill ~19 ~18 ~-145 ~20 ~18 ~-145 minecraft:mossy_stone_bricks
fill ~19 ~18 ~-103 ~20 ~18 ~-103 minecraft:mossy_stone_bricks
setblock ~19 ~19 ~-102 minecraft:mossy_stone_bricks
setblock ~19 ~21 ~-24 minecraft:mossy_stone_bricks
setblock ~19 ~24 ~-103 minecraft:mossy_stone_bricks
setblock ~19 ~25 ~-36 minecraft:mossy_stone_bricks
setblock ~19 ~26 ~-124 minecraft:mossy_stone_bricks
setblock ~19 ~30 ~-103 minecraft:mossy_stone_bricks
setblock ~19 ~31 ~-145 minecraft:mossy_stone_bricks
setblock ~19 ~32 ~-102 minecraft:mossy_stone_bricks
fill ~19 ~39 ~-146 ~19 ~39 ~-145 minecraft:mossy_stone_bricks
setblock ~19 ~40 ~-102 minecraft:mossy_stone_bricks
setblock ~19 ~44 ~-132 minecraft:mossy_stone_bricks
setblock ~19 ~44 ~-128 minecraft:mossy_stone_bricks
setblock ~19 ~44 ~-112 minecraft:mossy_stone_bricks
fill ~19 ~44 ~-106 ~20 ~44 ~-106 minecraft:mossy_stone_bricks
setblock ~19 ~44 ~-105 minecraft:mossy_stone_bricks
setblock ~20 ~3 ~-148 minecraft:mossy_stone_bricks
setblock ~20 ~3 ~-100 minecraft:mossy_stone_bricks
setblock ~20 ~6 ~-25 minecraft:mossy_stone_bricks
setblock ~20 ~7 ~-36 minecraft:mossy_stone_bricks
setblock ~20 ~9 ~-36 minecraft:mossy_stone_bricks
fill ~20 ~10 ~-25 ~21 ~10 ~-24 minecraft:mossy_stone_bricks
fill ~20 ~11 ~-36 ~20 ~11 ~-35 minecraft:mossy_stone_bricks
fill ~20 ~11 ~-25 ~20 ~12 ~-25 minecraft:mossy_stone_bricks
fill ~20 ~12 ~-148 ~20 ~13 ~-148 minecraft:mossy_stone_bricks
fill ~20 ~12 ~-103 ~20 ~14 ~-103 minecraft:mossy_stone_bricks
setblock ~20 ~13 ~-160 minecraft:mossy_stone_bricks
setblock ~20 ~15 ~-148 minecraft:mossy_stone_bricks
setblock ~20 ~15 ~-101 minecraft:mossy_stone_bricks
fill ~20 ~16 ~-156 ~21 ~16 ~-156 minecraft:mossy_stone_bricks
setblock ~20 ~16 ~-100 minecraft:mossy_stone_bricks
setblock ~20 ~18 ~-100 minecraft:mossy_stone_bricks
fill ~20 ~21 ~-36 ~21 ~21 ~-36 minecraft:mossy_stone_bricks
fill ~20 ~23 ~-148 ~20 ~23 ~-147 minecraft:mossy_stone_bricks
setblock ~20 ~26 ~-35 minecraft:mossy_stone_bricks
setblock ~20 ~27 ~-124 minecraft:mossy_stone_bricks
setblock ~20 ~28 ~-35 minecraft:mossy_stone_bricks
setblock ~20 ~29 ~-103 minecraft:mossy_stone_bricks
fill ~20 ~29 ~-101 ~20 ~30 ~-101 minecraft:mossy_stone_bricks
setblock ~20 ~30 ~-100 minecraft:mossy_stone_bricks
fill ~20 ~31 ~-148 ~20 ~31 ~-147 minecraft:mossy_stone_bricks
setblock ~20 ~31 ~-103 minecraft:mossy_stone_bricks
setblock ~20 ~39 ~-103 minecraft:mossy_stone_bricks
setblock ~20 ~41 ~-100 minecraft:mossy_stone_bricks
setblock ~20 ~44 ~-125 minecraft:mossy_stone_bricks
setblock ~20 ~44 ~-119 minecraft:mossy_stone_bricks
setblock ~20 ~44 ~-113 minecraft:mossy_stone_bricks
fill ~20 ~44 ~-110 ~20 ~44 ~-109 minecraft:mossy_stone_bricks
fill ~20 ~45 ~-103 ~20 ~45 ~-102 minecraft:mossy_stone_bricks
fill ~20 ~49 ~-104 ~20 ~50 ~-104 minecraft:mossy_stone_bricks
fill ~20 ~53 ~-143 ~22 ~53 ~-143 minecraft:mossy_stone_bricks
setblock ~21 ~1 ~-125 minecraft:mossy_stone_bricks
setblock ~21 ~4 ~-149 minecraft:mossy_stone_bricks
setblock ~21 ~5 ~-103 minecraft:mossy_stone_bricks
setblock ~21 ~5 ~-34 minecraft:mossy_stone_bricks
setblock ~21 ~5 ~-26 minecraft:mossy_stone_bricks
setblock ~21 ~7 ~-24 minecraft:mossy_stone_bricks
fill ~21 ~8 ~-98 ~21 ~9 ~-98 minecraft:mossy_stone_bricks
setblock ~21 ~8 ~-27 minecraft:mossy_stone_bricks
setblock ~21 ~9 ~-149 minecraft:mossy_stone_bricks
setblock ~21 ~13 ~-99 minecraft:mossy_stone_bricks
setblock ~21 ~13 ~-25 minecraft:mossy_stone_bricks
setblock ~21 ~14 ~-24 minecraft:mossy_stone_bricks
setblock ~21 ~15 ~-33 minecraft:mossy_stone_bricks
setblock ~21 ~15 ~-27 minecraft:mossy_stone_bricks
setblock ~21 ~16 ~-149 minecraft:mossy_stone_bricks
setblock ~21 ~17 ~-161 minecraft:mossy_stone_bricks
setblock ~21 ~17 ~-26 minecraft:mossy_stone_bricks
setblock ~21 ~27 ~-35 minecraft:mossy_stone_bricks
setblock ~21 ~30 ~-149 minecraft:mossy_stone_bricks
setblock ~21 ~31 ~-98 minecraft:mossy_stone_bricks
fill ~21 ~32 ~-149 ~21 ~34 ~-149 minecraft:mossy_stone_bricks
setblock ~21 ~32 ~-103 minecraft:mossy_stone_bricks
setblock ~21 ~37 ~-150 minecraft:mossy_stone_bricks
setblock ~21 ~40 ~-149 minecraft:mossy_stone_bricks
fill ~21 ~40 ~-99 ~21 ~40 ~-98 minecraft:mossy_stone_bricks
setblock ~21 ~41 ~-145 minecraft:mossy_stone_bricks
setblock ~21 ~44 ~-137 minecraft:mossy_stone_bricks
fill ~21 ~44 ~-116 ~22 ~44 ~-115 minecraft:mossy_stone_bricks
setblock ~21 ~47 ~-142 minecraft:mossy_stone_bricks
setblock ~21 ~48 ~-149 minecraft:mossy_stone_bricks
setblock ~21 ~52 ~-150 minecraft:mossy_stone_bricks
fill ~22 ~1 ~-30 ~22 ~1 ~-28 minecraft:mossy_stone_bricks
setblock ~22 ~3 ~-31 minecraft:mossy_stone_bricks
setblock ~22 ~4 ~-156 minecraft:mossy_stone_bricks
setblock ~22 ~4 ~-32 minecraft:mossy_stone_bricks
fill ~22 ~4 ~-29 ~22 ~4 ~-28 minecraft:mossy_stone_bricks
setblock ~22 ~4 ~-26 minecraft:mossy_stone_bricks
setblock ~22 ~5 ~-160 minecraft:mossy_stone_bricks
setblock ~22 ~6 ~-145 minecraft:mossy_stone_bricks
fill ~22 ~6 ~-30 ~22 ~6 ~-29 minecraft:mossy_stone_bricks
fill ~22 ~7 ~-38 ~22 ~8 ~-38 minecraft:mossy_stone_bricks
fill ~22 ~9 ~-145 ~24 ~9 ~-145 minecraft:mossy_stone_bricks
setblock ~22 ~11 ~-27 minecraft:mossy_stone_bricks
setblock ~22 ~12 ~-36 minecraft:mossy_stone_bricks
setblock ~22 ~13 ~-27 minecraft:mossy_stone_bricks
fill ~22 ~14 ~-156 ~24 ~14 ~-156 minecraft:mossy_stone_bricks
fill ~22 ~14 ~-31 ~23 ~14 ~-31 minecraft:mossy_stone_bricks
setblock ~22 ~17 ~-156 minecraft:mossy_stone_bricks
setblock ~22 ~17 ~-31 minecraft:mossy_stone_bricks
fill ~22 ~18 ~-159 ~22 ~18 ~-158 minecraft:mossy_stone_bricks
fill ~22 ~18 ~-32 ~23 ~18 ~-32 minecraft:mossy_stone_bricks
fill ~22 ~20 ~-97 ~23 ~20 ~-97 minecraft:mossy_stone_bricks
setblock ~22 ~21 ~-103 minecraft:mossy_stone_bricks
setblock ~22 ~21 ~-32 minecraft:mossy_stone_bricks
setblock ~22 ~21 ~-27 minecraft:mossy_stone_bricks
fill ~22 ~25 ~-124 ~24 ~25 ~-124 minecraft:mossy_stone_bricks
fill ~22 ~25 ~-103 ~23 ~25 ~-103 minecraft:mossy_stone_bricks
fill ~22 ~28 ~-145 ~22 ~29 ~-145 minecraft:mossy_stone_bricks
fill ~22 ~31 ~-124 ~23 ~31 ~-124 minecraft:mossy_stone_bricks
setblock ~22 ~31 ~-103 minecraft:mossy_stone_bricks
setblock ~22 ~31 ~-24 minecraft:mossy_stone_bricks
fill ~22 ~32 ~-97 ~22 ~33 ~-97 minecraft:mossy_stone_bricks
setblock ~22 ~37 ~-97 minecraft:mossy_stone_bricks
setblock ~22 ~38 ~-103 minecraft:mossy_stone_bricks
fill ~22 ~40 ~-145 ~23 ~40 ~-145 minecraft:mossy_stone_bricks
setblock ~22 ~43 ~-145 minecraft:mossy_stone_bricks
fill ~22 ~44 ~-117 ~22 ~44 ~-115 minecraft:mossy_stone_bricks
fill ~23 ~ ~-125 ~24 ~ ~-125 minecraft:mossy_stone_bricks
setblock ~23 ~1 ~-103 minecraft:mossy_stone_bricks
setblock ~23 ~4 ~-103 minecraft:mossy_stone_bricks
setblock ~23 ~4 ~-97 minecraft:mossy_stone_bricks
setblock ~23 ~7 ~-151 minecraft:mossy_stone_bricks
setblock ~23 ~7 ~-30 minecraft:mossy_stone_bricks
setblock ~23 ~9 ~-30 minecraft:mossy_stone_bricks
setblock ~23 ~10 ~-103 minecraft:mossy_stone_bricks
setblock ~23 ~11 ~-97 minecraft:mossy_stone_bricks
fill ~23 ~17 ~-103 ~24 ~17 ~-103 minecraft:mossy_stone_bricks
setblock ~23 ~17 ~-29 minecraft:mossy_stone_bricks
fill ~23 ~18 ~-30 ~23 ~19 ~-30 minecraft:mossy_stone_bricks
setblock ~23 ~21 ~-31 minecraft:mossy_stone_bricks
setblock ~23 ~22 ~-30 minecraft:mossy_stone_bricks
setblock ~23 ~24 ~-145 minecraft:mossy_stone_bricks
setblock ~23 ~27 ~-28 minecraft:mossy_stone_bricks
setblock ~23 ~34 ~-103 minecraft:mossy_stone_bricks
setblock ~23 ~35 ~-151 minecraft:mossy_stone_bricks
fill ~23 ~37 ~-151 ~23 ~38 ~-151 minecraft:mossy_stone_bricks
setblock ~23 ~42 ~-151 minecraft:mossy_stone_bricks
setblock ~23 ~44 ~-151 minecraft:mossy_stone_bricks
setblock ~23 ~44 ~-132 minecraft:mossy_stone_bricks
setblock ~23 ~44 ~-111 minecraft:mossy_stone_bricks
setblock ~23 ~45 ~-107 minecraft:mossy_stone_bricks
setblock ~23 ~46 ~-141 minecraft:mossy_stone_bricks
setblock ~23 ~52 ~-144 minecraft:mossy_stone_bricks
setblock ~23 ~52 ~-101 minecraft:mossy_stone_bricks
setblock ~23 ~52 ~-99 minecraft:mossy_stone_bricks
setblock ~24 ~1 ~-125 minecraft:mossy_stone_bricks
setblock ~24 ~5 ~-125 minecraft:mossy_stone_bricks
setblock ~24 ~7 ~-32 minecraft:mossy_stone_bricks
setblock ~24 ~12 ~-152 minecraft:mossy_stone_bricks
setblock ~24 ~14 ~-103 minecraft:mossy_stone_bricks
fill ~24 ~18 ~-158 ~25 ~18 ~-158 minecraft:mossy_stone_bricks
setblock ~24 ~23 ~-96 minecraft:mossy_stone_bricks
setblock ~24 ~27 ~-145 minecraft:mossy_stone_bricks
setblock ~24 ~30 ~-96 minecraft:mossy_stone_bricks
setblock ~24 ~31 ~-145 minecraft:mossy_stone_bricks
setblock ~24 ~32 ~-29 minecraft:mossy_stone_bricks
setblock ~24 ~37 ~-103 minecraft:mossy_stone_bricks
setblock ~24 ~40 ~-152 minecraft:mossy_stone_bricks
fill ~24 ~41 ~-96 ~24 ~43 ~-96 minecraft:mossy_stone_bricks
setblock ~24 ~42 ~-145 minecraft:mossy_stone_bricks
setblock ~24 ~44 ~-136 minecraft:mossy_stone_bricks
fill ~24 ~44 ~-126 ~24 ~44 ~-125 minecraft:mossy_stone_bricks
setblock ~24 ~44 ~-123 minecraft:mossy_stone_bricks
setblock ~24 ~44 ~-118 minecraft:mossy_stone_bricks
setblock ~24 ~46 ~-152 minecraft:mossy_stone_bricks
setblock ~24 ~49 ~-108 minecraft:mossy_stone_bricks
setblock ~24 ~52 ~-149 minecraft:mossy_stone_bricks
fill ~24 ~53 ~-95 ~25 ~53 ~-95 minecraft:mossy_stone_bricks
setblock ~25 ~-26 ~-59 minecraft:mossy_stone_bricks
fill ~25 ~-22 ~-57 ~25 ~-21 ~-43 minecraft:mossy_stone_bricks
fill ~25 ~-8 ~-144 ~25 ~-3 ~-138 minecraft:mossy_stone_bricks
setblock ~25 ~ ~-116 minecraft:mossy_stone_bricks
setblock ~25 ~ ~-108 minecraft:mossy_stone_bricks
setblock ~25 ~1 ~-135 minecraft:mossy_stone_bricks
fill ~25 ~1 ~-131 ~25 ~1 ~-130 minecraft:mossy_stone_bricks
setblock ~25 ~2 ~-138 minecraft:mossy_stone_bricks
fill ~25 ~2 ~-132 ~25 ~3 ~-132 minecraft:mossy_stone_bricks
fill ~25 ~2 ~-127 ~25 ~3 ~-127 minecraft:mossy_stone_bricks
setblock ~25 ~2 ~-114 minecraft:mossy_stone_bricks
setblock ~25 ~3 ~-116 minecraft:mossy_stone_bricks
fill ~25 ~4 ~-117 ~26 ~4 ~-117 minecraft:mossy_stone_bricks
setblock ~25 ~4 ~-38 minecraft:mossy_stone_bricks
setblock ~25 ~5 ~-134 minecraft:mossy_stone_bricks
fill ~25 ~5 ~-123 ~25 ~6 ~-123 minecraft:mossy_stone_bricks
setblock ~25 ~5 ~-119 minecraft:mossy_stone_bricks
setblock ~25 ~5 ~-111 minecraft:mossy_stone_bricks
setblock ~25 ~6 ~-128 minecraft:mossy_stone_bricks
setblock ~25 ~6 ~-125 minecraft:mossy_stone_bricks
setblock ~25 ~6 ~-109 minecraft:mossy_stone_bricks
setblock ~25 ~7 ~-143 minecraft:mossy_stone_bricks
fill ~25 ~7 ~-107 ~25 ~7 ~-106 minecraft:mossy_stone_bricks
setblock ~25 ~8 ~-115 minecraft:mossy_stone_bricks
fill ~25 ~8 ~-106 ~25 ~9 ~-106 minecraft:mossy_stone_bricks
setblock ~25 ~9 ~-127 minecraft:mossy_stone_bricks
fill ~25 ~9 ~-116 ~25 ~10 ~-116 minecraft:mossy_stone_bricks
fill ~25 ~9 ~-113 ~26 ~9 ~-113 minecraft:mossy_stone_bricks
setblock ~25 ~9 ~-112 minecraft:mossy_stone_bricks
fill ~25 ~10 ~-133 ~25 ~10 ~-132 minecraft:mossy_stone_bricks
setblock ~25 ~13 ~-156 minecraft:mossy_stone_bricks
setblock ~25 ~13 ~-132 minecraft:mossy_stone_bricks
fill ~25 ~13 ~-127 ~25 ~14 ~-127 minecraft:mossy_stone_bricks
setblock ~25 ~13 ~-107 minecraft:mossy_stone_bricks
setblock ~25 ~13 ~-32 minecraft:mossy_stone_bricks
setblock ~25 ~14 ~-120 minecraft:mossy_stone_bricks
setblock ~25 ~14 ~-108 minecraft:mossy_stone_bricks
fill ~25 ~15 ~-132 ~25 ~16 ~-132 minecraft:mossy_stone_bricks
setblock ~25 ~15 ~-129 minecraft:mossy_stone_bricks
setblock ~25 ~15 ~-126 minecraft:mossy_stone_bricks
setblock ~25 ~16 ~-141 minecraft:mossy_stone_bricks
setblock ~25 ~16 ~-123 minecraft:mossy_stone_bricks
setblock ~25 ~16 ~-120 minecraft:mossy_stone_bricks
setblock ~25 ~16 ~-116 minecraft:mossy_stone_bricks
setblock ~25 ~16 ~-113 minecraft:mossy_stone_bricks
setblock ~25 ~16 ~-109 minecraft:mossy_stone_bricks
setblock ~25 ~17 ~-156 minecraft:mossy_stone_bricks
setblock ~25 ~19 ~-125 minecraft:mossy_stone_bricks
setblock ~25 ~19 ~-104 minecraft:mossy_stone_bricks
fill ~25 ~20 ~-133 ~25 ~20 ~-132 minecraft:mossy_stone_bricks
setblock ~25 ~20 ~-107 minecraft:mossy_stone_bricks
setblock ~25 ~21 ~-140 minecraft:mossy_stone_bricks
setblock ~25 ~21 ~-134 minecraft:mossy_stone_bricks
fill ~25 ~21 ~-125 ~26 ~21 ~-125 minecraft:mossy_stone_bricks
fill ~25 ~21 ~-120 ~25 ~21 ~-119 minecraft:mossy_stone_bricks
setblock ~25 ~21 ~-109 minecraft:mossy_stone_bricks
setblock ~25 ~23 ~-144 minecraft:mossy_stone_bricks
setblock ~25 ~23 ~-133 minecraft:mossy_stone_bricks
setblock ~25 ~24 ~-136 minecraft:mossy_stone_bricks
setblock ~25 ~24 ~-119 minecraft:mossy_stone_bricks
setblock ~25 ~24 ~-109 minecraft:mossy_stone_bricks
fill ~25 ~25 ~-113 ~25 ~26 ~-113 minecraft:mossy_stone_bricks
setblock ~25 ~25 ~-105 minecraft:mossy_stone_bricks
fill ~25 ~26 ~-133 ~25 ~27 ~-133 minecraft:mossy_stone_bricks
setblock ~25 ~26 ~-125 minecraft:mossy_stone_bricks
fill ~25 ~26 ~-114 ~25 ~26 ~-113 minecraft:mossy_stone_bricks
setblock ~25 ~27 ~-96 minecraft:mossy_stone_bricks
setblock ~25 ~28 ~-137 minecraft:mossy_stone_bricks
setblock ~25 ~28 ~-127 minecraft:mossy_stone_bricks
setblock ~25 ~29 ~-132 minecraft:mossy_stone_bricks
fill ~25 ~31 ~-139 ~26 ~31 ~-139 minecraft:mossy_stone_bricks
fill ~25 ~31 ~-136 ~25 ~32 ~-136 minecraft:mossy_stone_bricks
fill ~25 ~31 ~-119 ~25 ~32 ~-119 minecraft:mossy_stone_bricks
fill ~25 ~31 ~-106 ~25 ~32 ~-106 minecraft:mossy_stone_bricks
setblock ~25 ~32 ~-141 minecraft:mossy_stone_bricks
fill ~25 ~32 ~-120 ~25 ~32 ~-119 minecraft:mossy_stone_bricks
setblock ~25 ~32 ~-109 minecraft:mossy_stone_bricks
setblock ~25 ~34 ~-126 minecraft:mossy_stone_bricks
setblock ~25 ~34 ~-122 minecraft:mossy_stone_bricks
setblock ~25 ~35 ~-141 minecraft:mossy_stone_bricks
setblock ~25 ~35 ~-128 minecraft:mossy_stone_bricks
setblock ~25 ~35 ~-113 minecraft:mossy_stone_bricks
setblock ~25 ~35 ~-106 minecraft:mossy_stone_bricks
fill ~25 ~36 ~-121 ~26 ~36 ~-121 minecraft:mossy_stone_bricks
setblock ~25 ~37 ~-137 minecraft:mossy_stone_bricks
fill ~25 ~37 ~-96 ~26 ~37 ~-96 minecraft:mossy_stone_bricks
setblock ~25 ~38 ~-138 minecraft:mossy_stone_bricks
setblock ~25 ~38 ~-135 minecraft:mossy_stone_bricks
fill ~25 ~38 ~-127 ~25 ~40 ~-127 minecraft:mossy_stone_bricks
setblock ~25 ~39 ~-104 minecraft:mossy_stone_bricks
setblock ~25 ~40 ~-135 minecraft:mossy_stone_bricks
setblock ~25 ~40 ~-133 minecraft:mossy_stone_bricks
setblock ~25 ~41 ~-116 minecraft:mossy_stone_bricks
setblock ~25 ~41 ~-111 minecraft:mossy_stone_bricks
setblock ~25 ~42 ~-152 minecraft:mossy_stone_bricks
fill ~25 ~42 ~-119 ~26 ~42 ~-119 minecraft:mossy_stone_bricks
setblock ~25 ~42 ~-112 minecraft:mossy_stone_bricks
fill ~25 ~43 ~-144 ~25 ~43 ~-143 minecraft:mossy_stone_bricks
fill ~25 ~43 ~-139 ~25 ~44 ~-139 minecraft:mossy_stone_bricks
setblock ~25 ~43 ~-136 minecraft:mossy_stone_bricks
setblock ~25 ~43 ~-125 minecraft:mossy_stone_bricks
setblock ~25 ~43 ~-122 minecraft:mossy_stone_bricks
setblock ~25 ~43 ~-107 minecraft:mossy_stone_bricks
setblock ~25 ~43 ~-104 minecraft:mossy_stone_bricks
setblock ~25 ~47 ~-96 minecraft:mossy_stone_bricks
setblock ~25 ~48 ~-140 minecraft:mossy_stone_bricks
fill ~26 ~-22 ~-59 ~26 ~-22 ~-58 minecraft:mossy_stone_bricks
fill ~26 ~2 ~-156 ~27 ~2 ~-156 minecraft:mossy_stone_bricks
setblock ~26 ~3 ~-160 minecraft:mossy_stone_bricks
setblock ~26 ~3 ~-135 minecraft:mossy_stone_bricks
setblock ~26 ~3 ~-127 minecraft:mossy_stone_bricks
setblock ~26 ~4 ~-126 minecraft:mossy_stone_bricks
setblock ~26 ~4 ~-115 minecraft:mossy_stone_bricks
fill ~26 ~4 ~-113 ~26 ~4 ~-112 minecraft:mossy_stone_bricks
setblock ~26 ~4 ~-96 minecraft:mossy_stone_bricks
setblock ~26 ~6 ~-120 minecraft:mossy_stone_bricks
setblock ~26 ~7 ~-136 minecraft:mossy_stone_bricks
setblock ~26 ~7 ~-133 minecraft:mossy_stone_bricks
setblock ~26 ~7 ~-110 minecraft:mossy_stone_bricks
setblock ~26 ~8 ~-123 minecraft:mossy_stone_bricks
setblock ~26 ~9 ~-133 minecraft:mossy_stone_bricks
setblock ~26 ~9 ~-126 minecraft:mossy_stone_bricks
setblock ~26 ~9 ~-115 minecraft:mossy_stone_bricks
setblock ~26 ~9 ~-109 minecraft:mossy_stone_bricks
setblock ~26 ~12 ~-134 minecraft:mossy_stone_bricks
setblock ~26 ~12 ~-117 minecraft:mossy_stone_bricks
setblock ~26 ~13 ~-139 minecraft:mossy_stone_bricks
setblock ~26 ~13 ~-123 minecraft:mossy_stone_bricks
setblock ~26 ~13 ~-121 minecraft:mossy_stone_bricks
setblock ~26 ~13 ~-116 minecraft:mossy_stone_bricks
setblock ~26 ~13 ~-96 minecraft:mossy_stone_bricks
fill ~26 ~16 ~-133 ~26 ~17 ~-133 minecraft:mossy_stone_bricks
fill ~26 ~16 ~-96 ~26 ~17 ~-96 minecraft:mossy_stone_bricks
setblock ~26 ~17 ~-36 minecraft:mossy_stone_bricks
fill ~26 ~18 ~-137 ~26 ~18 ~-136 minecraft:mossy_stone_bricks
fill ~26 ~18 ~-113 ~26 ~18 ~-112 minecraft:mossy_stone_bricks
setblock ~26 ~19 ~-133 minecraft:mossy_stone_bricks
fill ~26 ~19 ~-129 ~26 ~19 ~-128 minecraft:mossy_stone_bricks
fill ~26 ~19 ~-115 ~26 ~20 ~-115 minecraft:mossy_stone_bricks
fill ~26 ~20 ~-127 ~26 ~21 ~-127 minecraft:mossy_stone_bricks
setblock ~26 ~23 ~-152 minecraft:mossy_stone_bricks
fill ~26 ~23 ~-135 ~26 ~24 ~-135 minecraft:mossy_stone_bricks
fill ~26 ~23 ~-111 ~26 ~23 ~-110 minecraft:mossy_stone_bricks
setblock ~26 ~24 ~-137 minecraft:mossy_stone_bricks
fill ~26 ~24 ~-124 ~26 ~30 ~-124 minecraft:mossy_stone_bricks
fill ~26 ~24 ~-112 ~26 ~29 ~-112 minecraft:mossy_stone_bricks
setblock ~26 ~24 ~-96 minecraft:mossy_stone_bricks
fill ~26 ~26 ~-132 ~26 ~26 ~-130 minecraft:mossy_stone_bricks
setblock ~26 ~27 ~-128 minecraft:mossy_stone_bricks
setblock ~26 ~27 ~-110 minecraft:mossy_stone_bricks
setblock ~26 ~29 ~-129 minecraft:mossy_stone_bricks
setblock ~26 ~29 ~-123 minecraft:mossy_stone_bricks
fill ~26 ~30 ~-152 ~28 ~30 ~-152 minecraft:mossy_stone_bricks
setblock ~26 ~30 ~-135 minecraft:mossy_stone_bricks
setblock ~26 ~30 ~-121 minecraft:mossy_stone_bricks
fill ~26 ~31 ~-134 ~26 ~32 ~-134 minecraft:mossy_stone_bricks
setblock ~26 ~32 ~-128 minecraft:mossy_stone_bricks
setblock ~26 ~32 ~-125 minecraft:mossy_stone_bricks
setblock ~26 ~34 ~-133 minecraft:mossy_stone_bricks
setblock ~26 ~35 ~-152 minecraft:mossy_stone_bricks
setblock ~26 ~35 ~-117 minecraft:mossy_stone_bricks
fill ~26 ~36 ~-137 ~26 ~36 ~-136 minecraft:mossy_stone_bricks
setblock ~26 ~37 ~-132 minecraft:mossy_stone_bricks
setblock ~26 ~37 ~-128 minecraft:mossy_stone_bricks
fill ~26 ~37 ~-119 ~26 ~38 ~-118 minecraft:mossy_stone_bricks
fill ~26 ~39 ~-137 ~26 ~40 ~-136 minecraft:mossy_stone_bricks
fill ~26 ~40 ~-139 ~26 ~41 ~-139 minecraft:mossy_stone_bricks
setblock ~26 ~41 ~-125 minecraft:mossy_stone_bricks
setblock ~26 ~41 ~-123 minecraft:mossy_stone_bricks
setblock ~26 ~42 ~-136 minecraft:mossy_stone_bricks
setblock ~26 ~42 ~-126 minecraft:mossy_stone_bricks
setblock ~26 ~42 ~-121 minecraft:mossy_stone_bricks
setblock ~26 ~42 ~-116 minecraft:mossy_stone_bricks
setblock ~26 ~45 ~-108 minecraft:mossy_stone_bricks
setblock ~26 ~47 ~-152 minecraft:mossy_stone_bricks
setblock ~26 ~52 ~-103 minecraft:mossy_stone_bricks
setblock ~26 ~52 ~-99 minecraft:mossy_stone_bricks
setblock ~27 ~6 ~-108 minecraft:mossy_stone_bricks
setblock ~27 ~9 ~-96 minecraft:mossy_stone_bricks
setblock ~27 ~10 ~-156 minecraft:mossy_stone_bricks
setblock ~27 ~11 ~-96 minecraft:mossy_stone_bricks
setblock ~27 ~14 ~-156 minecraft:mossy_stone_bricks
setblock ~27 ~14 ~-140 minecraft:mossy_stone_bricks
fill ~27 ~15 ~-96 ~28 ~15 ~-96 minecraft:mossy_stone_bricks
setblock ~27 ~15 ~-32 minecraft:mossy_stone_bricks
setblock ~27 ~17 ~-156 minecraft:mossy_stone_bricks
setblock ~27 ~17 ~-140 minecraft:mossy_stone_bricks
fill ~27 ~18 ~-108 ~28 ~18 ~-108 minecraft:mossy_stone_bricks
setblock ~27 ~18 ~-32 minecraft:mossy_stone_bricks
setblock ~27 ~24 ~-108 minecraft:mossy_stone_bricks
setblock ~27 ~27 ~-140 minecraft:mossy_stone_bricks
fill ~27 ~31 ~-108 ~28 ~31 ~-108 minecraft:mossy_stone_bricks
setblock ~27 ~32 ~-140 minecraft:mossy_stone_bricks
fill ~27 ~33 ~-96 ~28 ~33 ~-96 minecraft:mossy_stone_bricks
setblock ~27 ~44 ~-121 minecraft:mossy_stone_bricks
fill ~27 ~46 ~-123 ~27 ~47 ~-123 minecraft:mossy_stone_bricks
setblock ~27 ~49 ~-96 minecraft:mossy_stone_bricks
setblock ~27 ~52 ~-149 minecraft:mossy_stone_bricks
setblock ~27 ~54 ~-153 minecraft:mossy_stone_bricks
fill ~28 ~-24 ~-57 ~28 ~-24 ~-43 minecraft:mossy_stone_bricks
setblock ~28 ~ ~-156 minecraft:mossy_stone_bricks
setblock ~28 ~3 ~-32 minecraft:mossy_stone_bricks
setblock ~28 ~4 ~-152 minecraft:mossy_stone_bricks
setblock ~28 ~5 ~-156 minecraft:mossy_stone_bricks
setblock ~28 ~8 ~-156 minecraft:mossy_stone_bricks
setblock ~28 ~10 ~-160 minecraft:mossy_stone_bricks
setblock ~28 ~10 ~-152 minecraft:mossy_stone_bricks
setblock ~28 ~10 ~-140 minecraft:mossy_stone_bricks
setblock ~28 ~12 ~-152 minecraft:mossy_stone_bricks
fill ~28 ~17 ~-31 ~28 ~18 ~-31 minecraft:mossy_stone_bricks
setblock ~28 ~18 ~-140 minecraft:mossy_stone_bricks
setblock ~28 ~19 ~-152 minecraft:mossy_stone_bricks
setblock ~28 ~35 ~-152 minecraft:mossy_stone_bricks
setblock ~28 ~35 ~-96 minecraft:mossy_stone_bricks
setblock ~28 ~37 ~-140 minecraft:mossy_stone_bricks
setblock ~28 ~39 ~-96 minecraft:mossy_stone_bricks
setblock ~28 ~43 ~-96 minecraft:mossy_stone_bricks
setblock ~28 ~46 ~-140 minecraft:mossy_stone_bricks
fill ~28 ~47 ~-108 ~28 ~49 ~-108 minecraft:mossy_stone_bricks
setblock ~28 ~50 ~-140 minecraft:mossy_stone_bricks
setblock ~28 ~52 ~-153 minecraft:mossy_stone_bricks
setblock ~28 ~52 ~-148 minecraft:mossy_stone_bricks
setblock ~28 ~52 ~-102 minecraft:mossy_stone_bricks
fill ~29 ~-25 ~-57 ~43 ~-25 ~-43 minecraft:mossy_stone_bricks
fill ~29 ~-22 ~-59 ~43 ~-22 ~-59 minecraft:mossy_stone_bricks
fill ~29 ~-19 ~-59 ~43 ~-19 ~-59 minecraft:mossy_stone_bricks
setblock ~29 ~2 ~-38 minecraft:mossy_stone_bricks
setblock ~29 ~3 ~-141 minecraft:mossy_stone_bricks
setblock ~29 ~6 ~-160 minecraft:mossy_stone_bricks
setblock ~29 ~8 ~-151 minecraft:mossy_stone_bricks
setblock ~29 ~10 ~-38 minecraft:mossy_stone_bricks
setblock ~29 ~14 ~-32 minecraft:mossy_stone_bricks
setblock ~29 ~15 ~-107 minecraft:mossy_stone_bricks
setblock ~29 ~17 ~-107 minecraft:mossy_stone_bricks
setblock ~29 ~33 ~-97 minecraft:mossy_stone_bricks
setblock ~29 ~36 ~-141 minecraft:mossy_stone_bricks
setblock ~29 ~36 ~-107 minecraft:mossy_stone_bricks
setblock ~29 ~39 ~-151 minecraft:mossy_stone_bricks
setblock ~29 ~43 ~-151 minecraft:mossy_stone_bricks
fill ~29 ~44 ~-141 ~29 ~45 ~-141 minecraft:mossy_stone_bricks
setblock ~29 ~46 ~-97 minecraft:mossy_stone_bricks
setblock ~29 ~52 ~-103 minecraft:mossy_stone_bricks
setblock ~30 ~2 ~-156 minecraft:mossy_stone_bricks
setblock ~30 ~5 ~-107 minecraft:mossy_stone_bricks
setblock ~30 ~7 ~-38 minecraft:mossy_stone_bricks
setblock ~30 ~7 ~-32 minecraft:mossy_stone_bricks
setblock ~30 ~9 ~-97 minecraft:mossy_stone_bricks
setblock ~30 ~9 ~-38 minecraft:mossy_stone_bricks
setblock ~30 ~12 ~-141 minecraft:mossy_stone_bricks
setblock ~30 ~14 ~-97 minecraft:mossy_stone_bricks
setblock ~30 ~17 ~-36 minecraft:mossy_stone_bricks
fill ~30 ~18 ~-157 ~30 ~18 ~-156 minecraft:mossy_stone_bricks
setblock ~30 ~18 ~-151 minecraft:mossy_stone_bricks
setblock ~30 ~18 ~-31 minecraft:mossy_stone_bricks
setblock ~30 ~22 ~-97 minecraft:mossy_stone_bricks
setblock ~30 ~24 ~-141 minecraft:mossy_stone_bricks
setblock ~30 ~30 ~-97 minecraft:mossy_stone_bricks
setblock ~30 ~34 ~-151 minecraft:mossy_stone_bricks
setblock ~30 ~37 ~-151 minecraft:mossy_stone_bricks
setblock ~30 ~40 ~-141 minecraft:mossy_stone_bricks
setblock ~30 ~41 ~-107 minecraft:mossy_stone_bricks
setblock ~30 ~44 ~-151 minecraft:mossy_stone_bricks
setblock ~30 ~46 ~-141 minecraft:mossy_stone_bricks
setblock ~30 ~48 ~-141 minecraft:mossy_stone_bricks
setblock ~30 ~50 ~-141 minecraft:mossy_stone_bricks
setblock ~30 ~52 ~-108 minecraft:mossy_stone_bricks
setblock ~31 ~2 ~-38 minecraft:mossy_stone_bricks
fill ~31 ~3 ~-142 ~31 ~4 ~-142 minecraft:mossy_stone_bricks
setblock ~31 ~3 ~-106 minecraft:mossy_stone_bricks
setblock ~31 ~5 ~-149 minecraft:mossy_stone_bricks
fill ~31 ~5 ~-32 ~32 ~5 ~-32 minecraft:mossy_stone_bricks
fill ~31 ~7 ~-106 ~31 ~8 ~-106 minecraft:mossy_stone_bricks
setblock ~31 ~8 ~-150 minecraft:mossy_stone_bricks
setblock ~31 ~8 ~-142 minecraft:mossy_stone_bricks
setblock ~31 ~11 ~-143 minecraft:mossy_stone_bricks
setblock ~31 ~14 ~-150 minecraft:mossy_stone_bricks
setblock ~31 ~19 ~-161 minecraft:mossy_stone_bricks
setblock ~31 ~19 ~-99 minecraft:mossy_stone_bricks
setblock ~31 ~26 ~-142 minecraft:mossy_stone_bricks
setblock ~31 ~26 ~-98 minecraft:mossy_stone_bricks
setblock ~31 ~30 ~-149 minecraft:mossy_stone_bricks
setblock ~31 ~36 ~-150 minecraft:mossy_stone_bricks
fill ~31 ~36 ~-105 ~31 ~37 ~-105 minecraft:mossy_stone_bricks
fill ~31 ~37 ~-98 ~31 ~38 ~-98 minecraft:mossy_stone_bricks
setblock ~31 ~43 ~-149 minecraft:mossy_stone_bricks
setblock ~31 ~47 ~-149 minecraft:mossy_stone_bricks
fill ~31 ~49 ~-106 ~31 ~50 ~-106 minecraft:mossy_stone_bricks
setblock ~31 ~53 ~-151 minecraft:mossy_stone_bricks
setblock ~31 ~53 ~-141 minecraft:mossy_stone_bricks
setblock ~32 ~3 ~-160 minecraft:mossy_stone_bricks
setblock ~32 ~3 ~-103 minecraft:mossy_stone_bricks
setblock ~32 ~3 ~-37 minecraft:mossy_stone_bricks
setblock ~32 ~4 ~-102 minecraft:mossy_stone_bricks
setblock ~32 ~6 ~-144 minecraft:mossy_stone_bricks
setblock ~32 ~6 ~-102 minecraft:mossy_stone_bricks
fill ~32 ~7 ~-104 ~32 ~7 ~-103 minecraft:mossy_stone_bricks
setblock ~32 ~8 ~-160 minecraft:mossy_stone_bricks
setblock ~32 ~8 ~-145 minecraft:mossy_stone_bricks
setblock ~32 ~8 ~-101 minecraft:mossy_stone_bricks
fill ~32 ~9 ~-148 ~32 ~10 ~-148 minecraft:mossy_stone_bricks
setblock ~32 ~9 ~-100 minecraft:mossy_stone_bricks
fill ~32 ~12 ~-156 ~33 ~12 ~-156 minecraft:mossy_stone_bricks
fill ~32 ~13 ~-145 ~32 ~13 ~-144 minecraft:mossy_stone_bricks
setblock ~32 ~14 ~-156 minecraft:mossy_stone_bricks
fill ~32 ~14 ~-146 ~32 ~15 ~-146 minecraft:mossy_stone_bricks
fill ~32 ~14 ~-32 ~33 ~14 ~-32 minecraft:mossy_stone_bricks
setblock ~32 ~15 ~-160 minecraft:mossy_stone_bricks
fill ~32 ~15 ~-147 ~32 ~15 ~-146 minecraft:mossy_stone_bricks
setblock ~32 ~15 ~-100 minecraft:mossy_stone_bricks
fill ~32 ~17 ~-161 ~33 ~17 ~-161 minecraft:mossy_stone_bricks
fill ~32 ~17 ~-147 ~32 ~18 ~-147 minecraft:mossy_stone_bricks
setblock ~32 ~17 ~-104 minecraft:mossy_stone_bricks
fill ~32 ~18 ~-35 ~32 ~18 ~-34 minecraft:mossy_stone_bricks
fill ~32 ~20 ~-104 ~32 ~20 ~-103 minecraft:mossy_stone_bricks
setblock ~32 ~26 ~-100 minecraft:mossy_stone_bricks
fill ~32 ~27 ~-145 ~32 ~27 ~-144 minecraft:mossy_stone_bricks
setblock ~32 ~29 ~-147 minecraft:mossy_stone_bricks
setblock ~32 ~29 ~-101 minecraft:mossy_stone_bricks
fill ~32 ~30 ~-100 ~32 ~31 ~-100 minecraft:mossy_stone_bricks
setblock ~32 ~34 ~-148 minecraft:mossy_stone_bricks
setblock ~32 ~34 ~-144 minecraft:mossy_stone_bricks
setblock ~32 ~34 ~-103 minecraft:mossy_stone_bricks
setblock ~32 ~36 ~-144 minecraft:mossy_stone_bricks
setblock ~32 ~37 ~-100 minecraft:mossy_stone_bricks
setblock ~32 ~40 ~-101 minecraft:mossy_stone_bricks
setblock ~32 ~42 ~-144 minecraft:mossy_stone_bricks
setblock ~32 ~45 ~-101 minecraft:mossy_stone_bricks
setblock ~32 ~46 ~-148 minecraft:mossy_stone_bricks
fill ~32 ~46 ~-146 ~32 ~47 ~-146 minecraft:mossy_stone_bricks
fill ~32 ~50 ~-103 ~32 ~50 ~-102 minecraft:mossy_stone_bricks
setblock ~32 ~52 ~-148 minecraft:mossy_stone_bricks
setblock ~32 ~52 ~-99 minecraft:mossy_stone_bricks
setblock ~33 ~54 ~-103 minecraft:mossy_stone_bricks
setblock ~34 ~2 ~-156 minecraft:mossy_stone_bricks
setblock ~34 ~15 ~-36 minecraft:mossy_stone_bricks
setblock ~34 ~18 ~-32 minecraft:mossy_stone_bricks
setblock ~35 ~ ~-156 minecraft:mossy_stone_bricks
setblock ~35 ~7 ~-32 minecraft:mossy_stone_bricks
setblock ~35 ~9 ~-36 minecraft:mossy_stone_bricks
fill ~35 ~11 ~-36 ~36 ~11 ~-36 minecraft:mossy_stone_bricks
setblock ~35 ~15 ~-160 minecraft:mossy_stone_bricks
setblock ~35 ~15 ~-32 minecraft:mossy_stone_bricks
fill ~35 ~17 ~-31 ~36 ~17 ~-31 minecraft:mossy_stone_bricks
setblock ~35 ~18 ~-31 minecraft:mossy_stone_bricks
setblock ~36 ~12 ~-36 minecraft:mossy_stone_bricks
setblock ~36 ~15 ~-36 minecraft:mossy_stone_bricks
setblock ~36 ~17 ~-156 minecraft:mossy_stone_bricks
setblock ~36 ~18 ~-157 minecraft:mossy_stone_bricks
setblock ~36 ~18 ~-32 minecraft:mossy_stone_bricks
setblock ~37 ~4 ~-36 minecraft:mossy_stone_bricks
setblock ~37 ~10 ~-160 minecraft:mossy_stone_bricks
setblock ~37 ~18 ~-34 minecraft:mossy_stone_bricks
setblock ~38 ~ ~-156 minecraft:mossy_stone_bricks
setblock ~38 ~2 ~-156 minecraft:mossy_stone_bricks
setblock ~38 ~4 ~-160 minecraft:mossy_stone_bricks
setblock ~38 ~6 ~-156 minecraft:mossy_stone_bricks
setblock ~38 ~7 ~-160 minecraft:mossy_stone_bricks
fill ~38 ~10 ~-36 ~38 ~11 ~-36 minecraft:mossy_stone_bricks
setblock ~38 ~15 ~-156 minecraft:mossy_stone_bricks
setblock ~38 ~15 ~-36 minecraft:mossy_stone_bricks
setblock ~39 ~1 ~-36 minecraft:mossy_stone_bricks
setblock ~39 ~5 ~-32 minecraft:mossy_stone_bricks
fill ~39 ~9 ~-156 ~40 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~39 ~14 ~-156 minecraft:mossy_stone_bricks
setblock ~39 ~19 ~-161 minecraft:mossy_stone_bricks
fill ~39 ~20 ~-31 ~39 ~21 ~-31 minecraft:mossy_stone_bricks
setblock ~40 ~3 ~-156 minecraft:mossy_stone_bricks
fill ~40 ~7 ~-36 ~41 ~7 ~-36 minecraft:mossy_stone_bricks
setblock ~40 ~19 ~-31 minecraft:mossy_stone_bricks
setblock ~41 ~1 ~-156 minecraft:mossy_stone_bricks
setblock ~41 ~6 ~-156 minecraft:mossy_stone_bricks
setblock ~41 ~9 ~-160 minecraft:mossy_stone_bricks
fill ~41 ~9 ~-36 ~42 ~9 ~-36 minecraft:mossy_stone_bricks
setblock ~41 ~14 ~-156 minecraft:mossy_stone_bricks
fill ~41 ~15 ~-36 ~41 ~16 ~-36 minecraft:mossy_stone_bricks
setblock ~41 ~18 ~-160 minecraft:mossy_stone_bricks
setblock ~41 ~18 ~-34 minecraft:mossy_stone_bricks
setblock ~41 ~20 ~-31 minecraft:mossy_stone_bricks
setblock ~42 ~ ~-156 minecraft:mossy_stone_bricks
setblock ~42 ~11 ~-32 minecraft:mossy_stone_bricks
setblock ~42 ~16 ~-36 minecraft:mossy_stone_bricks
fill ~42 ~18 ~-161 ~43 ~18 ~-161 minecraft:mossy_stone_bricks
setblock ~42 ~18 ~-35 minecraft:mossy_stone_bricks
setblock ~43 ~3 ~-160 minecraft:mossy_stone_bricks
setblock ~43 ~5 ~-160 minecraft:mossy_stone_bricks
setblock ~43 ~9 ~-32 minecraft:mossy_stone_bricks
setblock ~43 ~13 ~-36 minecraft:mossy_stone_bricks
setblock ~44 ~4 ~-156 minecraft:mossy_stone_bricks
setblock ~44 ~7 ~-156 minecraft:mossy_stone_bricks
setblock ~44 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~44 ~9 ~-33 minecraft:mossy_stone_bricks
setblock ~44 ~18 ~-35 minecraft:mossy_stone_bricks
setblock ~44 ~18 ~-32 minecraft:mossy_stone_bricks
setblock ~45 ~7 ~-36 minecraft:mossy_stone_bricks
fill ~45 ~18 ~-34 ~46 ~18 ~-34 minecraft:mossy_stone_bricks
fill ~45 ~19 ~-31 ~45 ~20 ~-31 minecraft:mossy_stone_bricks
setblock ~45 ~20 ~-161 minecraft:mossy_stone_bricks
setblock ~46 ~ ~-36 minecraft:mossy_stone_bricks
setblock ~46 ~3 ~-36 minecraft:mossy_stone_bricks
setblock ~46 ~6 ~-36 minecraft:mossy_stone_bricks
setblock ~46 ~14 ~-156 minecraft:mossy_stone_bricks
setblock ~46 ~17 ~-161 minecraft:mossy_stone_bricks
fill ~47 ~3 ~-160 ~47 ~4 ~-160 minecraft:mossy_stone_bricks
setblock ~47 ~9 ~-156 minecraft:mossy_stone_bricks
setblock ~48 ~9 ~-160 minecraft:mossy_stone_bricks
setblock ~48 ~14 ~-32 minecraft:mossy_stone_bricks
setblock ~48 ~15 ~-160 minecraft:mossy_stone_bricks
setblock ~48 ~18 ~-160 minecraft:mossy_stone_bricks
setblock ~49 ~ ~-36 minecraft:mossy_stone_bricks
setblock ~49 ~3 ~-160 minecraft:mossy_stone_bricks
setblock ~49 ~4 ~-32 minecraft:mossy_stone_bricks
setblock ~49 ~6 ~-32 minecraft:mossy_stone_bricks
setblock ~49 ~12 ~-36 minecraft:mossy_stone_bricks
setblock ~49 ~16 ~-36 minecraft:mossy_stone_bricks
setblock ~49 ~18 ~-32 minecraft:mossy_stone_bricks
setblock ~50 ~7 ~-156 minecraft:mossy_stone_bricks
setblock ~50 ~11 ~-160 minecraft:mossy_stone_bricks
setblock ~50 ~11 ~-36 minecraft:mossy_stone_bricks
setblock ~50 ~15 ~-160 minecraft:mossy_stone_bricks
setblock ~50 ~17 ~-31 minecraft:mossy_stone_bricks
fill ~50 ~18 ~-156 ~50 ~19 ~-156 minecraft:mossy_stone_bricks
setblock ~51 ~3 ~-32 minecraft:mossy_stone_bricks
setblock ~51 ~4 ~-160 minecraft:mossy_stone_bricks
fill ~51 ~18 ~-159 ~51 ~18 ~-158 minecraft:mossy_stone_bricks
setblock ~51 ~20 ~-161 minecraft:mossy_stone_bricks
setblock ~52 ~3 ~-36 minecraft:mossy_stone_bricks
setblock ~52 ~4 ~-32 minecraft:mossy_stone_bricks
setblock ~52 ~5 ~-160 minecraft:mossy_stone_bricks
setblock ~52 ~8 ~-36 minecraft:mossy_stone_bricks
setblock ~52 ~12 ~-32 minecraft:mossy_stone_bricks
setblock ~52 ~15 ~-36 minecraft:mossy_stone_bricks
setblock ~52 ~16 ~-156 minecraft:mossy_stone_bricks
fill ~52 ~18 ~-32 ~53 ~18 ~-32 minecraft:mossy_stone_bricks
fill ~52 ~18 ~-31 ~52 ~19 ~-31 minecraft:mossy_stone_bricks
setblock ~52 ~30 ~-29 minecraft:mossy_stone_bricks
setblock ~52 ~31 ~-163 minecraft:mossy_stone_bricks
setblock ~52 ~31 ~-157 minecraft:mossy_stone_bricks
fill ~53 ~3 ~-30 ~54 ~3 ~-30 minecraft:mossy_stone_bricks
setblock ~53 ~5 ~-163 minecraft:mossy_stone_bricks
setblock ~53 ~6 ~-162 minecraft:mossy_stone_bricks
setblock ~53 ~7 ~-31 minecraft:mossy_stone_bricks
fill ~53 ~9 ~-162 ~53 ~10 ~-162 minecraft:mossy_stone_bricks
setblock ~53 ~13 ~-36 minecraft:mossy_stone_bricks
setblock ~53 ~14 ~-156 minecraft:mossy_stone_bricks
fill ~53 ~15 ~-162 ~54 ~15 ~-162 minecraft:mossy_stone_bricks
setblock ~53 ~18 ~-158 minecraft:mossy_stone_bricks
setblock ~53 ~22 ~-35 minecraft:mossy_stone_bricks
fill ~53 ~25 ~-35 ~54 ~25 ~-35 minecraft:mossy_stone_bricks
setblock ~53 ~27 ~-160 minecraft:mossy_stone_bricks
setblock ~53 ~27 ~-32 minecraft:mossy_stone_bricks
setblock ~53 ~30 ~-163 minecraft:mossy_stone_bricks
setblock ~53 ~30 ~-160 minecraft:mossy_stone_bricks
fill ~54 ~1 ~-34 ~54 ~2 ~-34 minecraft:mossy_stone_bricks
fill ~54 ~2 ~-157 ~54 ~3 ~-157 minecraft:mossy_stone_bricks
setblock ~54 ~3 ~-159 minecraft:mossy_stone_bricks
setblock ~54 ~4 ~-28 minecraft:mossy_stone_bricks
setblock ~54 ~5 ~-165 minecraft:mossy_stone_bricks
setblock ~54 ~7 ~-155 minecraft:mossy_stone_bricks
fill ~54 ~8 ~-161 ~54 ~8 ~-160 minecraft:mossy_stone_bricks
fill ~54 ~9 ~-159 ~54 ~9 ~-158 minecraft:mossy_stone_bricks
setblock ~54 ~10 ~-155 minecraft:mossy_stone_bricks
setblock ~54 ~11 ~-158 minecraft:mossy_stone_bricks
fill ~54 ~11 ~-37 ~55 ~11 ~-37 minecraft:mossy_stone_bricks
setblock ~54 ~11 ~-35 minecraft:mossy_stone_bricks
fill ~54 ~13 ~-157 ~54 ~15 ~-157 minecraft:mossy_stone_bricks
setblock ~54 ~13 ~-29 minecraft:mossy_stone_bricks
setblock ~54 ~15 ~-155 minecraft:mossy_stone_bricks
fill ~54 ~16 ~-159 ~54 ~16 ~-158 minecraft:mossy_stone_bricks
setblock ~54 ~17 ~-32 minecraft:mossy_stone_bricks
setblock ~54 ~17 ~-29 minecraft:mossy_stone_bricks
fill ~54 ~18 ~-156 ~54 ~18 ~-155 minecraft:mossy_stone_bricks
setblock ~54 ~18 ~-35 minecraft:mossy_stone_bricks
fill ~54 ~19 ~-29 ~54 ~19 ~-28 minecraft:mossy_stone_bricks
setblock ~54 ~21 ~-160 minecraft:mossy_stone_bricks
setblock ~54 ~22 ~-165 minecraft:mossy_stone_bricks
setblock ~54 ~22 ~-37 minecraft:mossy_stone_bricks
setblock ~54 ~23 ~-161 minecraft:mossy_stone_bricks
fill ~54 ~23 ~-156 ~54 ~23 ~-155 minecraft:mossy_stone_bricks
setblock ~54 ~26 ~-159 minecraft:mossy_stone_bricks
setblock ~54 ~26 ~-28 minecraft:mossy_stone_bricks
setblock ~54 ~27 ~-165 minecraft:mossy_stone_bricks
setblock ~54 ~27 ~-161 minecraft:mossy_stone_bricks
setblock ~54 ~28 ~-162 minecraft:mossy_stone_bricks
setblock ~54 ~29 ~-161 minecraft:mossy_stone_bricks
setblock ~54 ~29 ~-33 minecraft:mossy_stone_bricks
setblock ~55 ~2 ~-28 minecraft:mossy_stone_bricks
setblock ~55 ~3 ~-167 minecraft:mossy_stone_bricks
setblock ~55 ~4 ~-153 minecraft:mossy_stone_bricks
setblock ~55 ~4 ~-38 minecraft:mossy_stone_bricks
setblock ~55 ~4 ~-25 minecraft:mossy_stone_bricks
setblock ~55 ~5 ~-36 minecraft:mossy_stone_bricks
setblock ~55 ~6 ~-153 minecraft:mossy_stone_bricks
setblock ~55 ~6 ~-25 minecraft:mossy_stone_bricks
setblock ~55 ~7 ~-167 minecraft:mossy_stone_bricks
setblock ~55 ~8 ~-28 minecraft:mossy_stone_bricks
setblock ~55 ~9 ~-27 minecraft:mossy_stone_bricks
setblock ~55 ~9 ~-25 minecraft:mossy_stone_bricks
fill ~55 ~10 ~-154 ~55 ~10 ~-153 minecraft:mossy_stone_bricks
setblock ~55 ~10 ~-39 minecraft:mossy_stone_bricks
setblock ~55 ~10 ~-36 minecraft:mossy_stone_bricks
setblock ~55 ~11 ~-154 minecraft:mossy_stone_bricks
fill ~55 ~13 ~-156 ~55 ~13 ~-155 minecraft:mossy_stone_bricks
setblock ~55 ~14 ~-36 minecraft:mossy_stone_bricks
setblock ~55 ~17 ~-28 minecraft:mossy_stone_bricks
setblock ~55 ~18 ~-38 minecraft:mossy_stone_bricks
setblock ~55 ~20 ~-166 minecraft:mossy_stone_bricks
setblock ~55 ~22 ~-164 minecraft:mossy_stone_bricks
setblock ~55 ~22 ~-36 minecraft:mossy_stone_bricks
setblock ~55 ~23 ~-154 minecraft:mossy_stone_bricks
setblock ~55 ~24 ~-153 minecraft:mossy_stone_bricks
setblock ~55 ~25 ~-166 minecraft:mossy_stone_bricks
setblock ~55 ~25 ~-26 minecraft:mossy_stone_bricks
setblock ~55 ~26 ~-153 minecraft:mossy_stone_bricks
setblock ~55 ~28 ~-167 minecraft:mossy_stone_bricks
setblock ~55 ~28 ~-37 minecraft:mossy_stone_bricks
setblock ~55 ~30 ~-159 minecraft:mossy_stone_bricks
setblock ~55 ~30 ~-29 minecraft:mossy_stone_bricks
setblock ~55 ~31 ~-24 minecraft:mossy_stone_bricks
setblock ~56 ~8 ~-168 minecraft:mossy_stone_bricks
setblock ~56 ~8 ~-166 minecraft:mossy_stone_bricks
setblock ~56 ~8 ~-24 minecraft:mossy_stone_bricks
setblock ~56 ~9 ~-40 minecraft:mossy_stone_bricks
setblock ~56 ~11 ~-26 minecraft:mossy_stone_bricks
setblock ~56 ~12 ~-168 minecraft:mossy_stone_bricks
setblock ~56 ~12 ~-24 minecraft:mossy_stone_bricks
fill ~56 ~13 ~-152 ~56 ~14 ~-152 minecraft:mossy_stone_bricks
setblock ~56 ~15 ~-24 minecraft:mossy_stone_bricks
setblock ~56 ~16 ~-40 minecraft:mossy_stone_bricks
setblock ~56 ~19 ~-40 minecraft:mossy_stone_bricks
setblock ~56 ~21 ~-38 minecraft:mossy_stone_bricks
setblock ~56 ~22 ~-40 minecraft:mossy_stone_bricks
setblock ~56 ~26 ~-38 minecraft:mossy_stone_bricks
setblock ~56 ~28 ~-166 minecraft:mossy_stone_bricks
setblock ~56 ~28 ~-24 minecraft:mossy_stone_bricks
setblock ~57 ~1 ~-98 minecraft:mossy_stone_bricks
fill ~57 ~3 ~-95 ~57 ~3 ~-94 minecraft:mossy_stone_bricks
setblock ~57 ~4 ~-167 minecraft:mossy_stone_bricks
setblock ~57 ~4 ~-96 minecraft:mossy_stone_bricks
setblock ~57 ~4 ~-25 minecraft:mossy_stone_bricks
setblock ~57 ~6 ~-151 minecraft:mossy_stone_bricks
setblock ~57 ~6 ~-95 minecraft:mossy_stone_bricks
setblock ~57 ~7 ~-94 minecraft:mossy_stone_bricks
setblock ~57 ~8 ~-25 minecraft:mossy_stone_bricks
setblock ~57 ~10 ~-153 minecraft:mossy_stone_bricks
setblock ~57 ~10 ~-39 minecraft:mossy_stone_bricks
setblock ~57 ~12 ~-94 minecraft:mossy_stone_bricks
setblock ~57 ~12 ~-41 minecraft:mossy_stone_bricks
setblock ~57 ~14 ~-169 minecraft:mossy_stone_bricks
setblock ~57 ~14 ~-39 minecraft:mossy_stone_bricks
setblock ~57 ~15 ~-23 minecraft:mossy_stone_bricks
setblock ~57 ~16 ~-169 minecraft:mossy_stone_bricks
setblock ~57 ~16 ~-97 minecraft:mossy_stone_bricks
setblock ~57 ~17 ~-151 minecraft:mossy_stone_bricks
fill ~57 ~17 ~-41 ~59 ~17 ~-41 minecraft:mossy_stone_bricks
fill ~57 ~18 ~-97 ~57 ~19 ~-97 minecraft:mossy_stone_bricks
setblock ~57 ~19 ~-153 minecraft:mossy_stone_bricks
setblock ~57 ~19 ~-41 minecraft:mossy_stone_bricks
setblock ~57 ~20 ~-151 minecraft:mossy_stone_bricks
setblock ~57 ~26 ~-39 minecraft:mossy_stone_bricks
setblock ~57 ~27 ~-100 minecraft:mossy_stone_bricks
setblock ~57 ~27 ~-25 minecraft:mossy_stone_bricks
fill ~57 ~30 ~-31 ~57 ~30 ~-30 minecraft:mossy_stone_bricks
setblock ~58 ~ ~-168 minecraft:mossy_stone_bricks
setblock ~58 ~ ~-40 minecraft:mossy_stone_bricks
setblock ~58 ~ ~-24 minecraft:mossy_stone_bricks
setblock ~58 ~3 ~-99 minecraft:mossy_stone_bricks
fill ~58 ~4 ~-169 ~58 ~5 ~-169 minecraft:mossy_stone_bricks
setblock ~58 ~4 ~-152 minecraft:mossy_stone_bricks
fill ~58 ~5 ~-100 ~58 ~6 ~-100 minecraft:mossy_stone_bricks
setblock ~58 ~6 ~-96 minecraft:mossy_stone_bricks
setblock ~58 ~7 ~-168 minecraft:mossy_stone_bricks
setblock ~58 ~8 ~-99 minecraft:mossy_stone_bricks
setblock ~58 ~10 ~-97 minecraft:mossy_stone_bricks
setblock ~58 ~18 ~-169 minecraft:mossy_stone_bricks
fill ~58 ~19 ~-100 ~59 ~19 ~-100 minecraft:mossy_stone_bricks
setblock ~58 ~19 ~-40 minecraft:mossy_stone_bricks
setblock ~58 ~20 ~-23 minecraft:mossy_stone_bricks
setblock ~58 ~22 ~-99 minecraft:mossy_stone_bricks
setblock ~58 ~24 ~-99 minecraft:mossy_stone_bricks
setblock ~58 ~24 ~-97 minecraft:mossy_stone_bricks
fill ~58 ~24 ~-93 ~58 ~24 ~-92 minecraft:mossy_stone_bricks
setblock ~58 ~25 ~-40 minecraft:mossy_stone_bricks
setblock ~58 ~26 ~-101 minecraft:mossy_stone_bricks
fill ~58 ~26 ~-24 ~58 ~27 ~-24 minecraft:mossy_stone_bricks
setblock ~58 ~27 ~-90 minecraft:mossy_stone_bricks
setblock ~58 ~28 ~-23 minecraft:mossy_stone_bricks
setblock ~58 ~30 ~-160 minecraft:mossy_stone_bricks
setblock ~59 ~1 ~-151 minecraft:mossy_stone_bricks
setblock ~59 ~2 ~-41 minecraft:mossy_stone_bricks
setblock ~59 ~7 ~-150 minecraft:mossy_stone_bricks
setblock ~59 ~11 ~-22 minecraft:mossy_stone_bricks
fill ~59 ~13 ~-41 ~60 ~13 ~-41 minecraft:mossy_stone_bricks
fill ~59 ~14 ~-22 ~60 ~14 ~-22 minecraft:mossy_stone_bricks
fill ~59 ~16 ~-101 ~59 ~17 ~-101 minecraft:mossy_stone_bricks
setblock ~59 ~16 ~-93 minecraft:mossy_stone_bricks
setblock ~59 ~16 ~-91 minecraft:mossy_stone_bricks
fill ~59 ~16 ~-41 ~59 ~17 ~-41 minecraft:mossy_stone_bricks
setblock ~59 ~21 ~-170 minecraft:mossy_stone_bricks
fill ~59 ~21 ~-42 ~59 ~21 ~-41 minecraft:mossy_stone_bricks
setblock ~59 ~22 ~-169 minecraft:mossy_stone_bricks
setblock ~59 ~23 ~-99 minecraft:mossy_stone_bricks
setblock ~59 ~23 ~-91 minecraft:mossy_stone_bricks
fill ~59 ~24 ~-150 ~60 ~24 ~-150 minecraft:mossy_stone_bricks
setblock ~59 ~24 ~-42 minecraft:mossy_stone_bricks
setblock ~59 ~25 ~-23 minecraft:mossy_stone_bricks
setblock ~59 ~26 ~-96 minecraft:mossy_stone_bricks
setblock ~59 ~28 ~-42 minecraft:mossy_stone_bricks
setblock ~59 ~29 ~-169 minecraft:mossy_stone_bricks
setblock ~59 ~30 ~-30 minecraft:mossy_stone_bricks
fill ~59 ~30 ~-21 ~60 ~30 ~-21 minecraft:mossy_stone_bricks
setblock ~59 ~31 ~-171 minecraft:mossy_stone_bricks
setblock ~59 ~32 ~-43 minecraft:mossy_stone_bricks
setblock ~59 ~32 ~-21 minecraft:mossy_stone_bricks
setblock ~60 ~ ~-143 minecraft:mossy_stone_bricks
setblock ~60 ~ ~-137 minecraft:mossy_stone_bricks
setblock ~60 ~ ~-135 minecraft:mossy_stone_bricks
setblock ~60 ~ ~-133 minecraft:mossy_stone_bricks
setblock ~60 ~ ~-120 minecraft:mossy_stone_bricks
setblock ~60 ~ ~-112 minecraft:mossy_stone_bricks
setblock ~60 ~ ~-110 minecraft:mossy_stone_bricks
setblock ~60 ~ ~-55 minecraft:mossy_stone_bricks
setblock ~60 ~ ~-50 minecraft:mossy_stone_bricks
setblock ~60 ~1 ~-146 minecraft:mossy_stone_bricks
setblock ~60 ~1 ~-108 minecraft:mossy_stone_bricks
fill ~60 ~1 ~-68 ~60 ~1 ~-67 minecraft:mossy_stone_bricks
fill ~60 ~1 ~-53 ~60 ~1 ~-52 minecraft:mossy_stone_bricks
fill ~60 ~1 ~-49 ~60 ~2 ~-49 minecraft:mossy_stone_bricks
setblock ~60 ~1 ~-46 minecraft:mossy_stone_bricks
setblock ~60 ~2 ~-140 minecraft:mossy_stone_bricks
setblock ~60 ~2 ~-130 minecraft:mossy_stone_bricks
setblock ~60 ~2 ~-70 minecraft:mossy_stone_bricks
setblock ~60 ~2 ~-68 minecraft:mossy_stone_bricks
fill ~60 ~2 ~-54 ~60 ~3 ~-54 minecraft:mossy_stone_bricks
setblock ~60 ~3 ~-146 minecraft:mossy_stone_bricks
setblock ~60 ~3 ~-137 minecraft:mossy_stone_bricks
setblock ~60 ~3 ~-116 minecraft:mossy_stone_bricks
setblock ~60 ~3 ~-86 minecraft:mossy_stone_bricks
fill ~60 ~3 ~-53 ~60 ~4 ~-53 minecraft:mossy_stone_bricks
setblock ~60 ~4 ~-143 minecraft:mossy_stone_bricks
fill ~60 ~4 ~-123 ~60 ~5 ~-123 minecraft:mossy_stone_bricks
fill ~60 ~4 ~-108 ~60 ~4 ~-107 minecraft:mossy_stone_bricks
setblock ~60 ~4 ~-90 minecraft:mossy_stone_bricks
setblock ~60 ~4 ~-88 minecraft:mossy_stone_bricks
setblock ~60 ~4 ~-76 minecraft:mossy_stone_bricks
setblock ~60 ~4 ~-68 minecraft:mossy_stone_bricks
setblock ~60 ~4 ~-23 minecraft:mossy_stone_bricks
setblock ~60 ~5 ~-113 minecraft:mossy_stone_bricks
setblock ~60 ~5 ~-82 minecraft:mossy_stone_bricks
fill ~60 ~5 ~-63 ~60 ~5 ~-62 minecraft:mossy_stone_bricks
setblock ~60 ~6 ~-141 minecraft:mossy_stone_bricks
setblock ~60 ~6 ~-131 minecraft:mossy_stone_bricks
setblock ~60 ~6 ~-116 minecraft:mossy_stone_bricks
setblock ~60 ~6 ~-90 minecraft:mossy_stone_bricks
fill ~60 ~6 ~-85 ~60 ~6 ~-84 minecraft:mossy_stone_bricks
fill ~60 ~6 ~-79 ~60 ~7 ~-79 minecraft:mossy_stone_bricks
setblock ~60 ~7 ~-169 minecraft:mossy_stone_bricks
setblock ~60 ~7 ~-128 minecraft:mossy_stone_bricks
setblock ~60 ~7 ~-107 minecraft:mossy_stone_bricks
setblock ~60 ~7 ~-76 minecraft:mossy_stone_bricks
setblock ~60 ~7 ~-74 minecraft:mossy_stone_bricks
setblock ~60 ~7 ~-54 minecraft:mossy_stone_bricks
setblock ~60 ~7 ~-47 minecraft:mossy_stone_bricks
fill ~60 ~8 ~-151 ~60 ~9 ~-151 minecraft:mossy_stone_bricks
setblock ~60 ~8 ~-145 minecraft:mossy_stone_bricks
fill ~60 ~8 ~-110 ~60 ~9 ~-110 minecraft:mossy_stone_bricks
setblock ~60 ~8 ~-100 minecraft:mossy_stone_bricks
setblock ~60 ~8 ~-73 minecraft:mossy_stone_bricks
setblock ~60 ~8 ~-70 minecraft:mossy_stone_bricks
setblock ~60 ~8 ~-46 minecraft:mossy_stone_bricks
setblock ~60 ~9 ~-170 minecraft:mossy_stone_bricks
fill ~60 ~9 ~-149 ~60 ~9 ~-148 minecraft:mossy_stone_bricks
setblock ~60 ~9 ~-137 minecraft:mossy_stone_bricks
setblock ~60 ~9 ~-118 minecraft:mossy_stone_bricks
setblock ~60 ~9 ~-106 minecraft:mossy_stone_bricks
setblock ~60 ~9 ~-102 minecraft:mossy_stone_bricks
fill ~60 ~9 ~-77 ~60 ~9 ~-76 minecraft:mossy_stone_bricks
setblock ~60 ~9 ~-68 minecraft:mossy_stone_bricks
setblock ~60 ~10 ~-126 minecraft:mossy_stone_bricks
setblock ~60 ~10 ~-107 minecraft:mossy_stone_bricks
setblock ~60 ~10 ~-92 minecraft:mossy_stone_bricks
setblock ~60 ~10 ~-86 minecraft:mossy_stone_bricks
setblock ~60 ~10 ~-57 minecraft:mossy_stone_bricks
setblock ~60 ~10 ~-52 minecraft:mossy_stone_bricks
setblock ~60 ~10 ~-43 minecraft:mossy_stone_bricks
setblock ~60 ~10 ~-22 minecraft:mossy_stone_bricks
setblock ~60 ~11 ~-169 minecraft:mossy_stone_bricks
setblock ~60 ~11 ~-139 minecraft:mossy_stone_bricks
setblock ~60 ~11 ~-132 minecraft:mossy_stone_bricks
setblock ~60 ~11 ~-113 minecraft:mossy_stone_bricks
setblock ~60 ~11 ~-71 minecraft:mossy_stone_bricks
fill ~60 ~11 ~-58 ~60 ~12 ~-58 minecraft:mossy_stone_bricks
setblock ~60 ~11 ~-44 minecraft:mossy_stone_bricks
setblock ~60 ~12 ~-118 minecraft:mossy_stone_bricks
fill ~60 ~12 ~-82 ~60 ~12 ~-81 minecraft:mossy_stone_bricks
setblock ~60 ~12 ~-69 minecraft:mossy_stone_bricks
setblock ~60 ~12 ~-55 minecraft:mossy_stone_bricks
setblock ~60 ~13 ~-139 minecraft:mossy_stone_bricks
setblock ~60 ~13 ~-133 minecraft:mossy_stone_bricks
setblock ~60 ~13 ~-121 minecraft:mossy_stone_bricks
setblock ~60 ~13 ~-76 minecraft:mossy_stone_bricks
setblock ~60 ~13 ~-67 minecraft:mossy_stone_bricks
setblock ~60 ~14 ~-130 minecraft:mossy_stone_bricks
fill ~60 ~14 ~-119 ~60 ~14 ~-118 minecraft:mossy_stone_bricks
setblock ~60 ~14 ~-107 minecraft:mossy_stone_bricks
setblock ~60 ~14 ~-102 minecraft:mossy_stone_bricks
fill ~60 ~14 ~-68 ~60 ~15 ~-68 minecraft:mossy_stone_bricks
setblock ~60 ~14 ~-57 minecraft:mossy_stone_bricks
setblock ~60 ~14 ~-50 minecraft:mossy_stone_bricks
setblock ~60 ~14 ~-43 minecraft:mossy_stone_bricks
setblock ~60 ~14 ~-41 minecraft:mossy_stone_bricks
setblock ~60 ~15 ~-117 minecraft:mossy_stone_bricks
fill ~60 ~15 ~-108 ~60 ~16 ~-108 minecraft:mossy_stone_bricks
setblock ~60 ~15 ~-86 minecraft:mossy_stone_bricks
setblock ~60 ~15 ~-60 minecraft:mossy_stone_bricks
setblock ~60 ~15 ~-55 minecraft:mossy_stone_bricks
setblock ~60 ~15 ~-47 minecraft:mossy_stone_bricks
setblock ~60 ~16 ~-145 minecraft:mossy_stone_bricks
fill ~60 ~16 ~-131 ~60 ~17 ~-131 minecraft:mossy_stone_bricks
setblock ~60 ~16 ~-121 minecraft:mossy_stone_bricks
setblock ~60 ~16 ~-110 minecraft:mossy_stone_bricks
setblock ~60 ~16 ~-100 minecraft:mossy_stone_bricks
setblock ~60 ~16 ~-79 minecraft:mossy_stone_bricks
setblock ~60 ~16 ~-70 minecraft:mossy_stone_bricks
setblock ~60 ~16 ~-51 minecraft:mossy_stone_bricks
setblock ~60 ~17 ~-149 minecraft:mossy_stone_bricks
setblock ~60 ~17 ~-143 minecraft:mossy_stone_bricks
setblock ~60 ~17 ~-136 minecraft:mossy_stone_bricks
fill ~60 ~17 ~-132 ~60 ~17 ~-131 minecraft:mossy_stone_bricks
setblock ~60 ~17 ~-81 minecraft:mossy_stone_bricks
setblock ~60 ~17 ~-64 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-148 ~60 ~19 ~-148 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-146 ~60 ~19 ~-146 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-140 ~60 ~19 ~-140 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-127 ~60 ~19 ~-127 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-124 ~60 ~19 ~-124 minecraft:mossy_stone_bricks
setblock ~60 ~18 ~-100 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-86 ~60 ~19 ~-85 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-68 ~61 ~18 ~-67 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-57 ~61 ~18 ~-57 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-52 ~60 ~19 ~-52 minecraft:mossy_stone_bricks
fill ~60 ~18 ~-50 ~60 ~19 ~-50 minecraft:mossy_stone_bricks
fill ~60 ~22 ~-23 ~60 ~23 ~-23 minecraft:mossy_stone_bricks
setblock ~60 ~23 ~-90 minecraft:mossy_stone_bricks
setblock ~60 ~24 ~-92 minecraft:mossy_stone_bricks
setblock ~60 ~27 ~-169 minecraft:mossy_stone_bricks
setblock ~60 ~30 ~-166 minecraft:mossy_stone_bricks
setblock ~60 ~30 ~-43 minecraft:mossy_stone_bricks
setblock ~60 ~31 ~-149 minecraft:mossy_stone_bricks
setblock ~61 ~ ~-150 minecraft:mossy_stone_bricks
setblock ~61 ~ ~-22 minecraft:mossy_stone_bricks
setblock ~61 ~3 ~-170 minecraft:mossy_stone_bricks
setblock ~61 ~3 ~-150 minecraft:mossy_stone_bricks
fill ~61 ~5 ~-101 ~61 ~6 ~-101 minecraft:mossy_stone_bricks
setblock ~61 ~6 ~-21 minecraft:mossy_stone_bricks
setblock ~61 ~10 ~-171 minecraft:mossy_stone_bricks
setblock ~61 ~10 ~-150 minecraft:mossy_stone_bricks
setblock ~61 ~13 ~-91 minecraft:mossy_stone_bricks
setblock ~61 ~16 ~-171 minecraft:mossy_stone_bricks
setblock ~61 ~16 ~-42 minecraft:mossy_stone_bricks
setblock ~61 ~18 ~-144 minecraft:mossy_stone_bricks
setblock ~61 ~18 ~-132 minecraft:mossy_stone_bricks
setblock ~61 ~18 ~-122 minecraft:mossy_stone_bricks
fill ~61 ~18 ~-116 ~62 ~18 ~-116 minecraft:mossy_stone_bricks
setblock ~61 ~18 ~-88 minecraft:mossy_stone_bricks
setblock ~61 ~18 ~-85 minecraft:mossy_stone_bricks
setblock ~61 ~18 ~-83 minecraft:mossy_stone_bricks
setblock ~61 ~18 ~-80 minecraft:mossy_stone_bricks
setblock ~61 ~18 ~-47 minecraft:mossy_stone_bricks
setblock ~61 ~18 ~-43 minecraft:mossy_stone_bricks
fill ~61 ~22 ~-22 ~61 ~22 ~-21 minecraft:mossy_stone_bricks
setblock ~61 ~23 ~-43 minecraft:mossy_stone_bricks
setblock ~61 ~29 ~-170 minecraft:mossy_stone_bricks
setblock ~61 ~30 ~-164 minecraft:mossy_stone_bricks
setblock ~61 ~30 ~-160 minecraft:mossy_stone_bricks
setblock ~61 ~30 ~-157 minecraft:mossy_stone_bricks
setblock ~61 ~30 ~-154 minecraft:mossy_stone_bricks
fill ~61 ~30 ~-31 ~61 ~30 ~-30 minecraft:mossy_stone_bricks
setblock ~62 ~ ~-170 minecraft:mossy_stone_bricks
setblock ~62 ~1 ~-150 minecraft:mossy_stone_bricks
fill ~62 ~1 ~-22 ~62 ~2 ~-22 minecraft:mossy_stone_bricks
setblock ~62 ~3 ~-42 minecraft:mossy_stone_bricks
fill ~62 ~4 ~-22 ~63 ~4 ~-22 minecraft:mossy_stone_bricks
setblock ~62 ~6 ~-171 minecraft:mossy_stone_bricks
setblock ~62 ~8 ~-150 minecraft:mossy_stone_bricks
setblock ~62 ~8 ~-90 minecraft:mossy_stone_bricks
setblock ~62 ~9 ~-42 minecraft:mossy_stone_bricks
fill ~62 ~10 ~-90 ~63 ~10 ~-90 minecraft:mossy_stone_bricks
setblock ~62 ~11 ~-150 minecraft:mossy_stone_bricks
setblock ~62 ~13 ~-171 minecraft:mossy_stone_bricks
setblock ~62 ~13 ~-102 minecraft:mossy_stone_bricks
fill ~62 ~17 ~-102 ~63 ~17 ~-102 minecraft:mossy_stone_bricks
setblock ~62 ~18 ~-150 minecraft:mossy_stone_bricks
setblock ~62 ~18 ~-133 minecraft:mossy_stone_bricks
setblock ~62 ~18 ~-121 minecraft:mossy_stone_bricks
setblock ~62 ~18 ~-77 minecraft:mossy_stone_bricks
fill ~62 ~18 ~-60 ~64 ~18 ~-60 minecraft:mossy_stone_bricks
fill ~62 ~18 ~-50 ~62 ~18 ~-49 minecraft:mossy_stone_bricks
fill ~62 ~22 ~-103 ~62 ~22 ~-102 minecraft:mossy_stone_bricks
setblock ~62 ~22 ~-42 minecraft:mossy_stone_bricks
setblock ~62 ~23 ~-150 minecraft:mossy_stone_bricks
fill ~62 ~23 ~-21 ~63 ~23 ~-21 minecraft:mossy_stone_bricks
setblock ~62 ~25 ~-43 minecraft:mossy_stone_bricks
setblock ~62 ~28 ~-21 minecraft:mossy_stone_bricks
setblock ~62 ~30 ~-165 minecraft:mossy_stone_bricks
setblock ~62 ~30 ~-156 minecraft:mossy_stone_bricks
fill ~62 ~30 ~-153 ~63 ~30 ~-153 minecraft:mossy_stone_bricks
fill ~62 ~30 ~-40 ~62 ~30 ~-39 minecraft:mossy_stone_bricks
setblock ~63 ~5 ~-21 minecraft:mossy_stone_bricks
setblock ~63 ~6 ~-52 minecraft:mossy_stone_bricks
setblock ~63 ~7 ~-108 minecraft:mossy_stone_bricks
setblock ~63 ~7 ~-90 minecraft:mossy_stone_bricks
setblock ~63 ~8 ~-76 minecraft:mossy_stone_bricks
setblock ~63 ~8 ~-52 minecraft:mossy_stone_bricks
setblock ~63 ~9 ~-22 minecraft:mossy_stone_bricks
setblock ~63 ~13 ~-170 minecraft:mossy_stone_bricks
fill ~63 ~13 ~-21 ~63 ~14 ~-21 minecraft:mossy_stone_bricks
fill ~63 ~15 ~-102 ~63 ~17 ~-102 minecraft:mossy_stone_bricks
fill ~63 ~17 ~-171 ~63 ~17 ~-170 minecraft:mossy_stone_bricks
setblock ~63 ~18 ~-149 minecraft:mossy_stone_bricks
setblock ~63 ~18 ~-131 minecraft:mossy_stone_bricks
setblock ~63 ~18 ~-126 minecraft:mossy_stone_bricks
fill ~63 ~18 ~-80 ~65 ~18 ~-80 minecraft:mossy_stone_bricks
fill ~63 ~18 ~-61 ~63 ~18 ~-60 minecraft:mossy_stone_bricks
fill ~63 ~18 ~-48 ~64 ~18 ~-48 minecraft:mossy_stone_bricks
setblock ~63 ~18 ~-21 minecraft:mossy_stone_bricks
fill ~63 ~21 ~-102 ~64 ~21 ~-102 minecraft:mossy_stone_bricks
setblock ~63 ~22 ~-22 minecraft:mossy_stone_bricks
setblock ~63 ~26 ~-103 minecraft:mossy_stone_bricks
setblock ~63 ~28 ~-170 minecraft:mossy_stone_bricks
setblock ~63 ~29 ~-150 minecraft:mossy_stone_bricks
setblock ~63 ~30 ~-20 minecraft:mossy_stone_bricks
fill ~64 ~2 ~-42 ~64 ~3 ~-42 minecraft:mossy_stone_bricks
setblock ~64 ~3 ~-141 minecraft:mossy_stone_bricks
setblock ~64 ~3 ~-133 minecraft:mossy_stone_bricks
setblock ~64 ~3 ~-116 minecraft:mossy_stone_bricks
setblock ~64 ~3 ~-102 minecraft:mossy_stone_bricks
setblock ~64 ~3 ~-82 minecraft:mossy_stone_bricks
setblock ~64 ~3 ~-64 minecraft:mossy_stone_bricks
fill ~64 ~3 ~-21 ~65 ~3 ~-21 minecraft:mossy_stone_bricks
setblock ~64 ~4 ~-147 minecraft:mossy_stone_bricks
setblock ~64 ~4 ~-140 minecraft:mossy_stone_bricks
fill ~64 ~4 ~-62 ~64 ~6 ~-62 minecraft:mossy_stone_bricks
setblock ~64 ~4 ~-55 minecraft:mossy_stone_bricks
setblock ~64 ~4 ~-52 minecraft:mossy_stone_bricks
setblock ~64 ~4 ~-46 minecraft:mossy_stone_bricks
setblock ~64 ~4 ~-21 minecraft:mossy_stone_bricks
setblock ~64 ~5 ~-145 minecraft:mossy_stone_bricks
fill ~64 ~5 ~-137 ~64 ~5 ~-136 minecraft:mossy_stone_bricks
setblock ~64 ~5 ~-85 minecraft:mossy_stone_bricks
fill ~64 ~5 ~-57 ~64 ~5 ~-56 minecraft:mossy_stone_bricks
setblock ~64 ~5 ~-45 minecraft:mossy_stone_bricks
setblock ~64 ~6 ~-171 minecraft:mossy_stone_bricks
fill ~64 ~7 ~-129 ~64 ~7 ~-128 minecraft:mossy_stone_bricks
setblock ~64 ~7 ~-110 minecraft:mossy_stone_bricks
setblock ~64 ~7 ~-71 minecraft:mossy_stone_bricks
setblock ~64 ~7 ~-45 minecraft:mossy_stone_bricks
setblock ~64 ~8 ~-171 minecraft:mossy_stone_bricks
setblock ~64 ~8 ~-115 minecraft:mossy_stone_bricks
setblock ~64 ~8 ~-54 minecraft:mossy_stone_bricks
setblock ~64 ~8 ~-21 minecraft:mossy_stone_bricks
fill ~64 ~9 ~-143 ~64 ~10 ~-143 minecraft:mossy_stone_bricks
setblock ~64 ~9 ~-129 minecraft:mossy_stone_bricks
setblock ~64 ~9 ~-125 minecraft:mossy_stone_bricks
setblock ~64 ~10 ~-148 minecraft:mossy_stone_bricks
setblock ~64 ~10 ~-146 minecraft:mossy_stone_bricks
setblock ~64 ~10 ~-142 minecraft:mossy_stone_bricks
setblock ~64 ~10 ~-105 minecraft:mossy_stone_bricks
setblock ~64 ~10 ~-68 minecraft:mossy_stone_bricks
setblock ~64 ~10 ~-66 minecraft:mossy_stone_bricks
setblock ~64 ~10 ~-50 minecraft:mossy_stone_bricks
fill ~64 ~10 ~-45 ~64 ~11 ~-45 minecraft:mossy_stone_bricks
setblock ~64 ~11 ~-132 minecraft:mossy_stone_bricks
setblock ~64 ~11 ~-111 minecraft:mossy_stone_bricks
setblock ~64 ~11 ~-106 minecraft:mossy_stone_bricks
setblock ~64 ~11 ~-80 minecraft:mossy_stone_bricks
setblock ~64 ~11 ~-62 minecraft:mossy_stone_bricks
setblock ~64 ~11 ~-60 minecraft:mossy_stone_bricks
setblock ~64 ~11 ~-52 minecraft:mossy_stone_bricks
setblock ~64 ~12 ~-87 minecraft:mossy_stone_bricks
setblock ~64 ~12 ~-77 minecraft:mossy_stone_bricks
setblock ~64 ~12 ~-72 minecraft:mossy_stone_bricks
setblock ~64 ~12 ~-66 minecraft:mossy_stone_bricks
fill ~64 ~12 ~-59 ~64 ~13 ~-59 minecraft:mossy_stone_bricks
setblock ~64 ~13 ~-150 minecraft:mossy_stone_bricks
setblock ~64 ~13 ~-147 minecraft:mossy_stone_bricks
fill ~64 ~13 ~-141 ~64 ~13 ~-140 minecraft:mossy_stone_bricks
setblock ~64 ~13 ~-128 minecraft:mossy_stone_bricks
setblock ~64 ~13 ~-123 minecraft:mossy_stone_bricks
setblock ~64 ~13 ~-81 minecraft:mossy_stone_bricks
setblock ~64 ~13 ~-65 minecraft:mossy_stone_bricks
fill ~64 ~13 ~-61 ~64 ~14 ~-61 minecraft:mossy_stone_bricks
setblock ~64 ~13 ~-58 minecraft:mossy_stone_bricks
setblock ~64 ~14 ~-138 minecraft:mossy_stone_bricks
setblock ~64 ~14 ~-122 minecraft:mossy_stone_bricks
setblock ~64 ~14 ~-106 minecraft:mossy_stone_bricks
setblock ~64 ~14 ~-102 minecraft:mossy_stone_bricks
setblock ~64 ~14 ~-87 minecraft:mossy_stone_bricks
setblock ~64 ~14 ~-78 minecraft:mossy_stone_bricks
setblock ~64 ~14 ~-51 minecraft:mossy_stone_bricks
setblock ~64 ~14 ~-45 minecraft:mossy_stone_bricks
setblock ~64 ~15 ~-147 minecraft:mossy_stone_bricks
setblock ~64 ~15 ~-142 minecraft:mossy_stone_bricks
setblock ~64 ~15 ~-140 minecraft:mossy_stone_bricks
setblock ~64 ~15 ~-129 minecraft:mossy_stone_bricks
setblock ~64 ~15 ~-76 minecraft:mossy_stone_bricks
setblock ~64 ~15 ~-72 minecraft:mossy_stone_bricks
setblock ~64 ~15 ~-68 minecraft:mossy_stone_bricks
setblock ~64 ~15 ~-48 minecraft:mossy_stone_bricks
fill ~64 ~18 ~-137 ~65 ~18 ~-137 minecraft:mossy_stone_bricks
setblock ~64 ~18 ~-132 minecraft:mossy_stone_bricks
setblock ~64 ~18 ~-122 minecraft:mossy_stone_bricks
setblock ~64 ~18 ~-119 minecraft:mossy_stone_bricks
setblock ~64 ~18 ~-114 minecraft:mossy_stone_bricks
setblock ~64 ~18 ~-82 minecraft:mossy_stone_bricks
fill ~64 ~18 ~-66 ~65 ~18 ~-66 minecraft:mossy_stone_bricks
fill ~64 ~18 ~-65 ~64 ~18 ~-64 minecraft:mossy_stone_bricks
setblock ~64 ~18 ~-59 minecraft:mossy_stone_bricks
setblock ~64 ~18 ~-56 minecraft:mossy_stone_bricks
fill ~64 ~18 ~-52 ~64 ~18 ~-51 minecraft:mossy_stone_bricks
setblock ~64 ~22 ~-171 minecraft:mossy_stone_bricks
setblock ~64 ~25 ~-149 minecraft:mossy_stone_bricks
setblock ~64 ~27 ~-104 minecraft:mossy_stone_bricks
setblock ~64 ~27 ~-43 minecraft:mossy_stone_bricks
setblock ~64 ~30 ~-165 minecraft:mossy_stone_bricks
setblock ~64 ~30 ~-148 minecraft:mossy_stone_bricks
setblock ~64 ~30 ~-43 minecraft:mossy_stone_bricks
setblock ~65 ~1 ~-150 minecraft:mossy_stone_bricks
setblock ~65 ~2 ~-170 minecraft:mossy_stone_bricks
setblock ~65 ~2 ~-90 minecraft:mossy_stone_bricks
setblock ~65 ~3 ~-103 minecraft:mossy_stone_bricks
fill ~65 ~4 ~-42 ~65 ~5 ~-42 minecraft:mossy_stone_bricks
setblock ~65 ~6 ~-102 minecraft:mossy_stone_bricks
setblock ~65 ~10 ~-149 minecraft:mossy_stone_bricks
setblock ~65 ~11 ~-22 minecraft:mossy_stone_bricks
setblock ~65 ~12 ~-21 minecraft:mossy_stone_bricks
setblock ~65 ~15 ~-43 minecraft:mossy_stone_bricks
setblock ~65 ~16 ~-90 minecraft:mossy_stone_bricks
setblock ~65 ~17 ~-125 minecraft:mossy_stone_bricks
setblock ~65 ~17 ~-120 minecraft:mossy_stone_bricks
setblock ~65 ~17 ~-110 minecraft:mossy_stone_bricks
setblock ~65 ~17 ~-52 minecraft:mossy_stone_bricks
setblock ~65 ~18 ~-131 minecraft:mossy_stone_bricks
setblock ~65 ~18 ~-108 minecraft:mossy_stone_bricks
setblock ~65 ~18 ~-105 minecraft:mossy_stone_bricks
setblock ~65 ~18 ~-87 minecraft:mossy_stone_bricks
setblock ~65 ~18 ~-85 minecraft:mossy_stone_bricks
setblock ~65 ~18 ~-75 minecraft:mossy_stone_bricks
setblock ~65 ~18 ~-49 minecraft:mossy_stone_bricks
fill ~65 ~18 ~-21 ~66 ~18 ~-21 minecraft:mossy_stone_bricks
setblock ~65 ~19 ~-148 minecraft:mossy_stone_bricks
setblock ~65 ~19 ~-146 minecraft:mossy_stone_bricks
setblock ~65 ~19 ~-125 minecraft:mossy_stone_bricks
setblock ~65 ~19 ~-88 minecraft:mossy_stone_bricks
fill ~65 ~19 ~-69 ~65 ~19 ~-68 minecraft:mossy_stone_bricks
setblock ~65 ~19 ~-63 minecraft:mossy_stone_bricks
setblock ~65 ~19 ~-50 minecraft:mossy_stone_bricks
setblock ~65 ~20 ~-131 minecraft:mossy_stone_bricks
setblock ~65 ~20 ~-123 minecraft:mossy_stone_bricks
fill ~65 ~20 ~-113 ~65 ~21 ~-113 minecraft:mossy_stone_bricks
setblock ~65 ~20 ~-107 minecraft:mossy_stone_bricks
setblock ~65 ~20 ~-89 minecraft:mossy_stone_bricks
setblock ~65 ~20 ~-67 minecraft:mossy_stone_bricks
setblock ~65 ~22 ~-90 minecraft:mossy_stone_bricks
setblock ~65 ~22 ~-22 minecraft:mossy_stone_bricks
setblock ~65 ~26 ~-101 minecraft:mossy_stone_bricks
setblock ~65 ~26 ~-92 minecraft:mossy_stone_bricks
setblock ~65 ~27 ~-170 minecraft:mossy_stone_bricks
fill ~65 ~30 ~-156 ~65 ~30 ~-155 minecraft:mossy_stone_bricks
setblock ~65 ~30 ~-27 minecraft:mossy_stone_bricks
fill ~65 ~30 ~-20 ~66 ~30 ~-20 minecraft:mossy_stone_bricks
setblock ~66 ~ ~-22 minecraft:mossy_stone_bricks
setblock ~66 ~2 ~-150 minecraft:mossy_stone_bricks
fill ~66 ~3 ~-170 ~67 ~3 ~-170 minecraft:mossy_stone_bricks
setblock ~66 ~3 ~-42 minecraft:mossy_stone_bricks
setblock ~66 ~4 ~-149 minecraft:mossy_stone_bricks
setblock ~66 ~5 ~-22 minecraft:mossy_stone_bricks
fill ~66 ~6 ~-149 ~66 ~7 ~-149 minecraft:mossy_stone_bricks
fill ~66 ~6 ~-90 ~67 ~6 ~-90 minecraft:mossy_stone_bricks
setblock ~66 ~7 ~-89 minecraft:mossy_stone_bricks
setblock ~66 ~8 ~-171 minecraft:mossy_stone_bricks
fill ~66 ~8 ~-43 ~67 ~8 ~-43 minecraft:mossy_stone_bricks
setblock ~66 ~10 ~-171 minecraft:mossy_stone_bricks
setblock ~66 ~12 ~-43 minecraft:mossy_stone_bricks
setblock ~66 ~13 ~-90 minecraft:mossy_stone_bricks
setblock ~66 ~14 ~-21 minecraft:mossy_stone_bricks
setblock ~66 ~15 ~-89 minecraft:mossy_stone_bricks
fill ~66 ~15 ~-42 ~66 ~16 ~-42 minecraft:mossy_stone_bricks
fill ~66 ~16 ~-103 ~66 ~16 ~-102 minecraft:mossy_stone_bricks
setblock ~66 ~19 ~-170 minecraft:mossy_stone_bricks
setblock ~66 ~19 ~-89 minecraft:mossy_stone_bricks
fill ~66 ~19 ~-43 ~66 ~20 ~-43 minecraft:mossy_stone_bricks
setblock ~66 ~20 ~-42 minecraft:mossy_stone_bricks
setblock ~66 ~24 ~-89 minecraft:mossy_stone_bricks
setblock ~66 ~25 ~-170 minecraft:mossy_stone_bricks
setblock ~66 ~26 ~-99 minecraft:mossy_stone_bricks
setblock ~66 ~28 ~-104 minecraft:mossy_stone_bricks
fill ~66 ~30 ~-160 ~66 ~30 ~-159 minecraft:mossy_stone_bricks
setblock ~66 ~30 ~-155 minecraft:mossy_stone_bricks
setblock ~66 ~30 ~-44 minecraft:mossy_stone_bricks
fill ~66 ~30 ~-24 ~66 ~30 ~-23 minecraft:mossy_stone_bricks
setblock ~66 ~31 ~-172 minecraft:mossy_stone_bricks
setblock ~66 ~31 ~-148 minecraft:mossy_stone_bricks
setblock ~67 ~ ~-101 minecraft:mossy_stone_bricks
setblock ~67 ~3 ~-90 minecraft:mossy_stone_bricks
fill ~67 ~7 ~-150 ~67 ~7 ~-149 minecraft:mossy_stone_bricks
setblock ~67 ~9 ~-43 minecraft:mossy_stone_bricks
setblock ~67 ~9 ~-22 minecraft:mossy_stone_bricks
setblock ~67 ~10 ~-42 minecraft:mossy_stone_bricks
setblock ~67 ~13 ~-21 minecraft:mossy_stone_bricks
setblock ~67 ~17 ~-43 minecraft:mossy_stone_bricks
setblock ~67 ~19 ~-90 minecraft:mossy_stone_bricks
setblock ~67 ~19 ~-21 minecraft:mossy_stone_bricks
setblock ~67 ~20 ~-171 minecraft:mossy_stone_bricks
setblock ~67 ~21 ~-42 minecraft:mossy_stone_bricks
setblock ~67 ~22 ~-171 minecraft:mossy_stone_bricks
fill ~67 ~26 ~-92 ~68 ~26 ~-92 minecraft:mossy_stone_bricks
fill ~67 ~28 ~-171 ~67 ~28 ~-170 minecraft:mossy_stone_bricks
setblock ~67 ~30 ~-172 minecraft:mossy_stone_bricks
fill ~67 ~30 ~-152 ~67 ~30 ~-151 minecraft:mossy_stone_bricks
setblock ~68 ~4 ~-92 minecraft:mossy_stone_bricks
setblock ~68 ~5 ~-151 minecraft:mossy_stone_bricks
setblock ~68 ~6 ~-150 minecraft:mossy_stone_bricks
setblock ~68 ~10 ~-23 minecraft:mossy_stone_bricks
setblock ~68 ~13 ~-169 minecraft:mossy_stone_bricks
setblock ~68 ~13 ~-100 minecraft:mossy_stone_bricks
setblock ~68 ~14 ~-90 minecraft:mossy_stone_bricks
setblock ~68 ~14 ~-22 minecraft:mossy_stone_bricks
setblock ~68 ~16 ~-41 minecraft:mossy_stone_bricks
setblock ~68 ~16 ~-22 minecraft:mossy_stone_bricks
setblock ~68 ~20 ~-151 minecraft:mossy_stone_bricks
setblock ~68 ~23 ~-151 minecraft:mossy_stone_bricks
setblock ~68 ~23 ~-42 minecraft:mossy_stone_bricks
setblock ~68 ~24 ~-100 minecraft:mossy_stone_bricks
setblock ~68 ~25 ~-169 minecraft:mossy_stone_bricks
setblock ~68 ~26 ~-151 minecraft:mossy_stone_bricks
fill ~68 ~26 ~-103 ~68 ~27 ~-103 minecraft:mossy_stone_bricks
setblock ~68 ~28 ~-170 minecraft:mossy_stone_bricks
setblock ~68 ~29 ~-151 minecraft:mossy_stone_bricks
setblock ~68 ~30 ~-154 minecraft:mossy_stone_bricks
setblock ~68 ~30 ~-32 minecraft:mossy_stone_bricks
setblock ~69 ~ ~-23 minecraft:mossy_stone_bricks
setblock ~69 ~7 ~-150 minecraft:mossy_stone_bricks
fill ~69 ~8 ~-151 ~69 ~10 ~-151 minecraft:mossy_stone_bricks
setblock ~69 ~8 ~-42 minecraft:mossy_stone_bricks
setblock ~69 ~9 ~-101 minecraft:mossy_stone_bricks
setblock ~69 ~11 ~-170 minecraft:mossy_stone_bricks
setblock ~69 ~11 ~-91 minecraft:mossy_stone_bricks
setblock ~69 ~16 ~-169 minecraft:mossy_stone_bricks
setblock ~69 ~16 ~-91 minecraft:mossy_stone_bricks
setblock ~69 ~17 ~-101 minecraft:mossy_stone_bricks
setblock ~69 ~19 ~-169 minecraft:mossy_stone_bricks
setblock ~69 ~19 ~-101 minecraft:mossy_stone_bricks
setblock ~69 ~20 ~-93 minecraft:mossy_stone_bricks
setblock ~69 ~20 ~-41 minecraft:mossy_stone_bricks
setblock ~69 ~21 ~-170 minecraft:mossy_stone_bricks
fill ~69 ~22 ~-150 ~69 ~23 ~-150 minecraft:mossy_stone_bricks
setblock ~69 ~23 ~-23 minecraft:mossy_stone_bricks
setblock ~69 ~24 ~-93 minecraft:mossy_stone_bricks
setblock ~69 ~24 ~-91 minecraft:mossy_stone_bricks
setblock ~69 ~28 ~-151 minecraft:mossy_stone_bricks
setblock ~69 ~28 ~-23 minecraft:mossy_stone_bricks
setblock ~69 ~29 ~-41 minecraft:mossy_stone_bricks
setblock ~69 ~30 ~-168 minecraft:mossy_stone_bricks
setblock ~69 ~30 ~-158 minecraft:mossy_stone_bricks
setblock ~69 ~30 ~-152 minecraft:mossy_stone_bricks
setblock ~69 ~30 ~-33 minecraft:mossy_stone_bricks
setblock ~70 ~2 ~-152 minecraft:mossy_stone_bricks
setblock ~70 ~3 ~-99 minecraft:mossy_stone_bricks
setblock ~70 ~5 ~-23 minecraft:mossy_stone_bricks
fill ~70 ~6 ~-98 ~71 ~6 ~-98 minecraft:mossy_stone_bricks
setblock ~70 ~7 ~-99 minecraft:mossy_stone_bricks
setblock ~70 ~8 ~-100 minecraft:mossy_stone_bricks
fill ~70 ~8 ~-98 ~70 ~8 ~-97 minecraft:mossy_stone_bricks
setblock ~70 ~8 ~-93 minecraft:mossy_stone_bricks
setblock ~70 ~11 ~-152 minecraft:mossy_stone_bricks
setblock ~70 ~11 ~-99 minecraft:mossy_stone_bricks
setblock ~70 ~11 ~-95 minecraft:mossy_stone_bricks
fill ~70 ~11 ~-92 ~70 ~12 ~-92 minecraft:mossy_stone_bricks
setblock ~70 ~11 ~-24 minecraft:mossy_stone_bricks
fill ~70 ~14 ~-169 ~71 ~14 ~-169 minecraft:mossy_stone_bricks
setblock ~70 ~15 ~-41 minecraft:mossy_stone_bricks
setblock ~70 ~16 ~-23 minecraft:mossy_stone_bricks
setblock ~70 ~17 ~-24 minecraft:mossy_stone_bricks
fill ~70 ~18 ~-151 ~70 ~19 ~-151 minecraft:mossy_stone_bricks
setblock ~70 ~18 ~-99 minecraft:mossy_stone_bricks
setblock ~70 ~19 ~-95 minecraft:mossy_stone_bricks
setblock ~70 ~19 ~-93 minecraft:mossy_stone_bricks
setblock ~70 ~20 ~-97 minecraft:mossy_stone_bricks
fill ~70 ~21 ~-96 ~70 ~23 ~-96 minecraft:mossy_stone_bricks
fill ~70 ~22 ~-100 ~70 ~23 ~-100 minecraft:mossy_stone_bricks
setblock ~70 ~25 ~-168 minecraft:mossy_stone_bricks
setblock ~70 ~25 ~-95 minecraft:mossy_stone_bricks
setblock ~70 ~28 ~-168 minecraft:mossy_stone_bricks
setblock ~70 ~28 ~-24 minecraft:mossy_stone_bricks
setblock ~70 ~30 ~-167 minecraft:mossy_stone_bricks
fill ~70 ~30 ~-38 ~70 ~30 ~-37 minecraft:mossy_stone_bricks
setblock ~70 ~30 ~-34 minecraft:mossy_stone_bricks
setblock ~70 ~30 ~-28 minecraft:mossy_stone_bricks
setblock ~71 ~2 ~-25 minecraft:mossy_stone_bricks
setblock ~71 ~4 ~-151 minecraft:mossy_stone_bricks
setblock ~71 ~6 ~-151 minecraft:mossy_stone_bricks
setblock ~71 ~6 ~-95 minecraft:mossy_stone_bricks
setblock ~71 ~7 ~-97 minecraft:mossy_stone_bricks
setblock ~71 ~10 ~-23 minecraft:mossy_stone_bricks
setblock ~71 ~11 ~-41 minecraft:mossy_stone_bricks
setblock ~71 ~13 ~-167 minecraft:mossy_stone_bricks
setblock ~71 ~14 ~-153 minecraft:mossy_stone_bricks
setblock ~71 ~14 ~-97 minecraft:mossy_stone_bricks
setblock ~71 ~17 ~-95 minecraft:mossy_stone_bricks
setblock ~71 ~18 ~-97 minecraft:mossy_stone_bricks
setblock ~71 ~18 ~-94 minecraft:mossy_stone_bricks
setblock ~71 ~19 ~-96 minecraft:mossy_stone_bricks
setblock ~71 ~20 ~-23 minecraft:mossy_stone_bricks
setblock ~71 ~21 ~-94 minecraft:mossy_stone_bricks
fill ~71 ~24 ~-169 ~71 ~25 ~-169 minecraft:mossy_stone_bricks
fill ~71 ~24 ~-96 ~71 ~24 ~-95 minecraft:mossy_stone_bricks
fill ~71 ~26 ~-99 ~71 ~26 ~-98 minecraft:mossy_stone_bricks
setblock ~71 ~26 ~-92 minecraft:mossy_stone_bricks
setblock ~71 ~27 ~-39 minecraft:mossy_stone_bricks
setblock ~71 ~28 ~-41 minecraft:mossy_stone_bricks
fill ~71 ~30 ~-150 ~71 ~31 ~-150 minecraft:mossy_stone_bricks
setblock ~71 ~30 ~-35 minecraft:mossy_stone_bricks
setblock ~72 ~1 ~-38 minecraft:mossy_stone_bricks
setblock ~72 ~2 ~-166 minecraft:mossy_stone_bricks
setblock ~72 ~3 ~-154 minecraft:mossy_stone_bricks
setblock ~72 ~7 ~-168 minecraft:mossy_stone_bricks
setblock ~72 ~8 ~-152 minecraft:mossy_stone_bricks
setblock ~72 ~13 ~-168 minecraft:mossy_stone_bricks
fill ~72 ~13 ~-38 ~73 ~13 ~-38 minecraft:mossy_stone_bricks
setblock ~72 ~13 ~-24 minecraft:mossy_stone_bricks
setblock ~72 ~14 ~-38 minecraft:mossy_stone_bricks
setblock ~72 ~17 ~-40 minecraft:mossy_stone_bricks
fill ~72 ~22 ~-166 ~72 ~23 ~-166 minecraft:mossy_stone_bricks
setblock ~72 ~24 ~-24 minecraft:mossy_stone_bricks
setblock ~72 ~25 ~-154 minecraft:mossy_stone_bricks
setblock ~72 ~26 ~-98 minecraft:mossy_stone_bricks
setblock ~72 ~27 ~-152 minecraft:mossy_stone_bricks
fill ~72 ~27 ~-95 ~72 ~27 ~-94 minecraft:mossy_stone_bricks
setblock ~72 ~30 ~-169 minecraft:mossy_stone_bricks
setblock ~72 ~30 ~-160 minecraft:mossy_stone_bricks
setblock ~72 ~30 ~-152 minecraft:mossy_stone_bricks
setblock ~72 ~30 ~-37 minecraft:mossy_stone_bricks
setblock ~73 ~1 ~-37 minecraft:mossy_stone_bricks
setblock ~73 ~3 ~-167 minecraft:mossy_stone_bricks
setblock ~73 ~5 ~-154 minecraft:mossy_stone_bricks
setblock ~73 ~7 ~-154 minecraft:mossy_stone_bricks
setblock ~73 ~9 ~-166 minecraft:mossy_stone_bricks
setblock ~73 ~9 ~-164 minecraft:mossy_stone_bricks
setblock ~73 ~10 ~-38 minecraft:mossy_stone_bricks
setblock ~73 ~13 ~-164 minecraft:mossy_stone_bricks
setblock ~73 ~14 ~-165 minecraft:mossy_stone_bricks
setblock ~73 ~15 ~-167 minecraft:mossy_stone_bricks
setblock ~73 ~15 ~-26 minecraft:mossy_stone_bricks
setblock ~73 ~16 ~-156 minecraft:mossy_stone_bricks
setblock ~73 ~17 ~-26 minecraft:mossy_stone_bricks
setblock ~73 ~19 ~-26 minecraft:mossy_stone_bricks
setblock ~73 ~20 ~-153 minecraft:mossy_stone_bricks
setblock ~73 ~21 ~-26 minecraft:mossy_stone_bricks
fill ~73 ~22 ~-153 ~73 ~23 ~-153 minecraft:mossy_stone_bricks
setblock ~73 ~23 ~-164 minecraft:mossy_stone_bricks
fill ~73 ~23 ~-36 ~74 ~23 ~-36 minecraft:mossy_stone_bricks
setblock ~73 ~24 ~-38 minecraft:mossy_stone_bricks
setblock ~73 ~27 ~-153 minecraft:mossy_stone_bricks
setblock ~73 ~29 ~-155 minecraft:mossy_stone_bricks
fill ~74 ~1 ~-161 ~74 ~2 ~-161 minecraft:mossy_stone_bricks
fill ~74 ~2 ~-160 ~74 ~5 ~-160 minecraft:mossy_stone_bricks
fill ~74 ~2 ~-158 ~74 ~3 ~-158 minecraft:mossy_stone_bricks
setblock ~74 ~2 ~-34 minecraft:mossy_stone_bricks
fill ~74 ~2 ~-32 ~74 ~2 ~-31 minecraft:mossy_stone_bricks
fill ~74 ~4 ~-37 ~74 ~5 ~-37 minecraft:mossy_stone_bricks
setblock ~74 ~4 ~-31 minecraft:mossy_stone_bricks
setblock ~74 ~5 ~-155 minecraft:mossy_stone_bricks
fill ~74 ~5 ~-36 ~74 ~5 ~-33 minecraft:mossy_stone_bricks
setblock ~74 ~7 ~-155 minecraft:mossy_stone_bricks
setblock ~74 ~8 ~-162 minecraft:mossy_stone_bricks
setblock ~74 ~8 ~-31 minecraft:mossy_stone_bricks
fill ~74 ~10 ~-158 ~74 ~11 ~-158 minecraft:mossy_stone_bricks
fill ~74 ~10 ~-36 ~74 ~10 ~-35 minecraft:mossy_stone_bricks
setblock ~74 ~10 ~-31 minecraft:mossy_stone_bricks
fill ~74 ~10 ~-29 ~74 ~10 ~-28 minecraft:mossy_stone_bricks
setblock ~74 ~11 ~-35 minecraft:mossy_stone_bricks
setblock ~74 ~13 ~-156 minecraft:mossy_stone_bricks
setblock ~74 ~15 ~-159 minecraft:mossy_stone_bricks
setblock ~74 ~16 ~-31 minecraft:mossy_stone_bricks
setblock ~74 ~18 ~-27 minecraft:mossy_stone_bricks
setblock ~74 ~19 ~-165 minecraft:mossy_stone_bricks
setblock ~74 ~19 ~-36 minecraft:mossy_stone_bricks
setblock ~74 ~20 ~-37 minecraft:mossy_stone_bricks
fill ~74 ~21 ~-158 ~74 ~22 ~-158 minecraft:mossy_stone_bricks
setblock ~74 ~21 ~-30 minecraft:mossy_stone_bricks
setblock ~74 ~23 ~-34 minecraft:mossy_stone_bricks
fill ~74 ~25 ~-30 ~74 ~25 ~-29 minecraft:mossy_stone_bricks
fill ~74 ~26 ~-30 ~74 ~27 ~-30 minecraft:mossy_stone_bricks
fill ~74 ~27 ~-156 ~74 ~28 ~-156 minecraft:mossy_stone_bricks
fill ~74 ~28 ~-161 ~74 ~28 ~-160 minecraft:mossy_stone_bricks
setblock ~74 ~29 ~-162 minecraft:mossy_stone_bricks
setblock ~74 ~29 ~-32 minecraft:mossy_stone_bricks
setblock ~74 ~31 ~-26 minecraft:mossy_stone_bricks
setblock ~74 ~32 ~-154 minecraft:mossy_stone_bricks
setblock ~75 ~7 ~-162 minecraft:mossy_stone_bricks
fill ~75 ~7 ~-35 ~75 ~8 ~-35 minecraft:mossy_stone_bricks
setblock ~75 ~8 ~-158 minecraft:mossy_stone_bricks
setblock ~75 ~9 ~-163 minecraft:mossy_stone_bricks
setblock ~75 ~10 ~-159 minecraft:mossy_stone_bricks
setblock ~75 ~11 ~-29 minecraft:mossy_stone_bricks
setblock ~75 ~14 ~-158 minecraft:mossy_stone_bricks
setblock ~75 ~15 ~-157 minecraft:mossy_stone_bricks
setblock ~75 ~15 ~-31 minecraft:mossy_stone_bricks
setblock ~75 ~17 ~-30 minecraft:mossy_stone_bricks
setblock ~75 ~22 ~-163 minecraft:mossy_stone_bricks
setblock ~75 ~22 ~-159 minecraft:mossy_stone_bricks
fill ~75 ~22 ~-33 ~75 ~22 ~-32 minecraft:mossy_stone_bricks
setblock ~75 ~23 ~-161 minecraft:mossy_stone_bricks
setblock ~75 ~23 ~-31 minecraft:mossy_stone_bricks
setblock ~75 ~25 ~-161 minecraft:mossy_stone_bricks
setblock ~75 ~26 ~-157 minecraft:mossy_stone_bricks
setblock ~75 ~28 ~-158 minecraft:mossy_stone_bricks
fill ~75 ~30 ~-36 ~75 ~30 ~-35 minecraft:mossy_stone_bricks
setblock ~76 ~31 ~-32 minecraft:mossy_stone_bricks
fill ~-80 ~-13 ~-129 ~-74 ~-13 ~-127 minecraft:deepslate_tiles
fill ~-80 ~-12 ~-128 ~-75 ~-12 ~-127 minecraft:deepslate_tiles
fill ~-80 ~-9 ~-129 ~-78 ~-9 ~-127 minecraft:deepslate_tiles
fill ~-79 ~-14 ~-129 ~-73 ~-14 ~-127 minecraft:deepslate_tiles
fill ~-78 ~-15 ~-129 ~-72 ~-15 ~-127 minecraft:deepslate_tiles
fill ~-77 ~-16 ~-128 ~-71 ~-16 ~-127 minecraft:deepslate_tiles
fill ~-77 ~-10 ~-129 ~-77 ~-10 ~-127 minecraft:deepslate_tiles
fill ~-76 ~-17 ~-129 ~-70 ~-17 ~-127 minecraft:deepslate_tiles
fill ~-76 ~-11 ~-129 ~-76 ~-11 ~-127 minecraft:deepslate_tiles
fill ~-75 ~-18 ~-129 ~-69 ~-18 ~-127 minecraft:deepslate_tiles
fill ~-75 ~-12 ~-129 ~-75 ~-12 ~-127 minecraft:deepslate_tiles
fill ~-74 ~-19 ~-129 ~-68 ~-19 ~-127 minecraft:deepslate_tiles
fill ~-74 ~31 ~-164 ~-73 ~31 ~-164 minecraft:deepslate_tiles
fill ~-74 ~31 ~-163 ~-74 ~31 ~-156 minecraft:deepslate_tiles
fill ~-74 ~31 ~-36 ~-73 ~31 ~-36 minecraft:deepslate_tiles
fill ~-74 ~31 ~-35 ~-74 ~31 ~-28 minecraft:deepslate_tiles
fill ~-74 ~32 ~-162 ~-73 ~32 ~-162 minecraft:deepslate_tiles
fill ~-74 ~32 ~-161 ~-74 ~32 ~-158 minecraft:deepslate_tiles
fill ~-74 ~32 ~-34 ~-73 ~32 ~-34 minecraft:deepslate_tiles
fill ~-74 ~32 ~-33 ~-74 ~32 ~-30 minecraft:deepslate_tiles
fill ~-73 ~-20 ~-129 ~-67 ~-20 ~-127 minecraft:deepslate_tiles
fill ~-73 ~31 ~-166 ~-72 ~31 ~-166 minecraft:deepslate_tiles
fill ~-73 ~31 ~-165 ~-73 ~32 ~-164 minecraft:deepslate_tiles
fill ~-73 ~31 ~-156 ~-73 ~31 ~-154 minecraft:deepslate_tiles
fill ~-73 ~31 ~-38 ~-72 ~31 ~-38 minecraft:deepslate_tiles
fill ~-73 ~31 ~-37 ~-73 ~32 ~-36 minecraft:deepslate_tiles
fill ~-73 ~31 ~-28 ~-73 ~31 ~-26 minecraft:deepslate_tiles
fill ~-73 ~32 ~-163 ~-73 ~33 ~-162 minecraft:deepslate_tiles
fill ~-73 ~32 ~-158 ~-73 ~32 ~-155 minecraft:deepslate_tiles
fill ~-73 ~32 ~-35 ~-73 ~33 ~-34 minecraft:deepslate_tiles
fill ~-73 ~32 ~-30 ~-73 ~32 ~-27 minecraft:deepslate_tiles
fill ~-73 ~33 ~-164 ~-72 ~33 ~-164 minecraft:deepslate_tiles
fill ~-73 ~33 ~-161 ~-73 ~33 ~-156 minecraft:deepslate_tiles
fill ~-73 ~33 ~-36 ~-72 ~33 ~-36 minecraft:deepslate_tiles
fill ~-73 ~33 ~-33 ~-73 ~33 ~-28 minecraft:deepslate_tiles
fill ~-73 ~34 ~-162 ~-72 ~34 ~-161 minecraft:deepslate_tiles
fill ~-73 ~34 ~-160 ~-73 ~34 ~-158 minecraft:deepslate_tiles
fill ~-73 ~34 ~-34 ~-72 ~34 ~-33 minecraft:deepslate_tiles
fill ~-73 ~34 ~-32 ~-73 ~34 ~-30 minecraft:deepslate_tiles
fill ~-72 ~-21 ~-129 ~-66 ~-21 ~-127 minecraft:deepslate_tiles
fill ~-72 ~31 ~-167 ~-71 ~31 ~-167 minecraft:deepslate_tiles
fill ~-72 ~31 ~-154 ~-72 ~31 ~-153 minecraft:deepslate_tiles
fill ~-72 ~31 ~-39 ~-71 ~31 ~-39 minecraft:deepslate_tiles
fill ~-72 ~31 ~-26 ~-72 ~31 ~-25 minecraft:deepslate_tiles
fill ~-72 ~32 ~-166 ~-71 ~32 ~-166 minecraft:deepslate_tiles
fill ~-72 ~32 ~-165 ~-72 ~33 ~-165 minecraft:deepslate_tiles
fill ~-72 ~32 ~-155 ~-72 ~32 ~-154 minecraft:deepslate_tiles
fill ~-72 ~32 ~-38 ~-71 ~32 ~-38 minecraft:deepslate_tiles
fill ~-72 ~32 ~-37 ~-72 ~33 ~-37 minecraft:deepslate_tiles
fill ~-72 ~32 ~-27 ~-72 ~32 ~-26 minecraft:deepslate_tiles
fill ~-72 ~33 ~-156 ~-72 ~33 ~-155 minecraft:deepslate_tiles
fill ~-72 ~33 ~-28 ~-72 ~33 ~-27 minecraft:deepslate_tiles
fill ~-72 ~34 ~-164 ~-71 ~34 ~-164 minecraft:deepslate_tiles
fill ~-72 ~34 ~-163 ~-72 ~35 ~-161 minecraft:deepslate_tiles
fill ~-72 ~34 ~-159 ~-72 ~34 ~-156 minecraft:deepslate_tiles
fill ~-72 ~34 ~-36 ~-71 ~34 ~-36 minecraft:deepslate_tiles
fill ~-72 ~34 ~-35 ~-72 ~35 ~-33 minecraft:deepslate_tiles
fill ~-72 ~34 ~-31 ~-72 ~34 ~-28 minecraft:deepslate_tiles
fill ~-72 ~35 ~-160 ~-72 ~35 ~-157 minecraft:deepslate_tiles
fill ~-72 ~35 ~-32 ~-72 ~35 ~-29 minecraft:deepslate_tiles
fill ~-72 ~36 ~-161 ~-71 ~36 ~-159 minecraft:deepslate_tiles
fill ~-72 ~36 ~-33 ~-71 ~36 ~-31 minecraft:deepslate_tiles
fill ~-71 ~-22 ~-129 ~-65 ~-22 ~-127 minecraft:deepslate_tiles
fill ~-71 ~-16 ~-129 ~-71 ~-16 ~-127 minecraft:deepslate_tiles
fill ~-71 ~31 ~-168 ~-70 ~31 ~-168 minecraft:deepslate_tiles
fill ~-71 ~31 ~-153 ~-71 ~31 ~-152 minecraft:deepslate_tiles
fill ~-71 ~31 ~-40 ~-70 ~31 ~-40 minecraft:deepslate_tiles
fill ~-71 ~31 ~-25 ~-71 ~31 ~-24 minecraft:deepslate_tiles
fill ~-71 ~32 ~-167 ~-70 ~32 ~-167 minecraft:deepslate_tiles
fill ~-71 ~32 ~-154 ~-71 ~32 ~-153 minecraft:deepslate_tiles
fill ~-71 ~32 ~-39 ~-70 ~32 ~-39 minecraft:deepslate_tiles
fill ~-71 ~32 ~-26 ~-71 ~32 ~-25 minecraft:deepslate_tiles
fill ~-71 ~33 ~-165 ~-71 ~35 ~-165 minecraft:deepslate_tiles
fill ~-71 ~33 ~-155 ~-71 ~34 ~-154 minecraft:deepslate_tiles
fill ~-71 ~33 ~-38 ~-71 ~34 ~-37 minecraft:deepslate_tiles
fill ~-71 ~33 ~-27 ~-71 ~34 ~-26 minecraft:deepslate_tiles
fill ~-71 ~34 ~-166 ~-70 ~34 ~-166 minecraft:deepslate_tiles
fill ~-71 ~34 ~-156 ~-71 ~34 ~-154 minecraft:deepslate_tiles
fill ~-71 ~34 ~-28 ~-71 ~34 ~-26 minecraft:deepslate_tiles
fill ~-71 ~35 ~-164 ~-71 ~36 ~-163 minecraft:deepslate_tiles
fill ~-71 ~35 ~-157 ~-71 ~35 ~-155 minecraft:deepslate_tiles
fill ~-71 ~35 ~-37 ~-70 ~35 ~-37 minecraft:deepslate_tiles
fill ~-71 ~35 ~-36 ~-71 ~36 ~-35 minecraft:deepslate_tiles
fill ~-71 ~35 ~-29 ~-71 ~35 ~-27 minecraft:deepslate_tiles
fill ~-71 ~36 ~-162 ~-71 ~36 ~-156 minecraft:deepslate_tiles
fill ~-71 ~36 ~-34 ~-71 ~36 ~-28 minecraft:deepslate_tiles
fill ~-71 ~37 ~-163 ~-70 ~37 ~-163 minecraft:deepslate_tiles
fill ~-71 ~37 ~-162 ~-71 ~37 ~-157 minecraft:deepslate_tiles
fill ~-71 ~37 ~-35 ~-70 ~37 ~-35 minecraft:deepslate_tiles
fill ~-71 ~37 ~-34 ~-71 ~37 ~-29 minecraft:deepslate_tiles
fill ~-71 ~38 ~-161 ~-70 ~38 ~-159 minecraft:deepslate_tiles
fill ~-71 ~38 ~-33 ~-70 ~38 ~-31 minecraft:deepslate_tiles
fill ~-70 ~-23 ~-129 ~-31 ~-23 ~-127 minecraft:deepslate_tiles
fill ~-70 ~27 ~-99 ~-69 ~27 ~-99 minecraft:deepslate_tiles
fill ~-70 ~27 ~-98 ~-70 ~27 ~-93 minecraft:deepslate_tiles
fill ~-70 ~28 ~-98 ~-69 ~28 ~-98 minecraft:deepslate_tiles
fill ~-70 ~28 ~-97 ~-70 ~28 ~-94 minecraft:deepslate_tiles
fill ~-70 ~31 ~-169 ~-68 ~31 ~-169 minecraft:deepslate_tiles
fill ~-70 ~31 ~-152 ~-70 ~31 ~-151 minecraft:deepslate_tiles
fill ~-70 ~31 ~-41 ~-68 ~31 ~-41 minecraft:deepslate_tiles
fill ~-70 ~31 ~-24 ~-70 ~31 ~-23 minecraft:deepslate_tiles
fill ~-70 ~32 ~-168 ~-69 ~32 ~-168 minecraft:deepslate_tiles
fill ~-70 ~32 ~-153 ~-70 ~32 ~-152 minecraft:deepslate_tiles
fill ~-70 ~32 ~-40 ~-69 ~32 ~-40 minecraft:deepslate_tiles
fill ~-70 ~32 ~-25 ~-70 ~32 ~-24 minecraft:deepslate_tiles
fill ~-70 ~33 ~-167 ~-69 ~34 ~-167 minecraft:deepslate_tiles
fill ~-70 ~33 ~-153 ~-69 ~34 ~-153 minecraft:deepslate_tiles
fill ~-70 ~33 ~-39 ~-69 ~34 ~-39 minecraft:deepslate_tiles
fill ~-70 ~33 ~-25 ~-69 ~34 ~-25 minecraft:deepslate_tiles
fill ~-70 ~34 ~-154 ~-70 ~34 ~-153 minecraft:deepslate_tiles
fill ~-70 ~34 ~-38 ~-70 ~35 ~-38 minecraft:deepslate_tiles
fill ~-70 ~34 ~-26 ~-70 ~34 ~-25 minecraft:deepslate_tiles
fill ~-70 ~35 ~-166 ~-69 ~35 ~-166 minecraft:deepslate_tiles
fill ~-70 ~35 ~-165 ~-70 ~36 ~-165 minecraft:deepslate_tiles
fill ~-70 ~35 ~-155 ~-70 ~35 ~-154 minecraft:deepslate_tiles
fill ~-70 ~35 ~-27 ~-70 ~35 ~-26 minecraft:deepslate_tiles
fill ~-70 ~36 ~-164 ~-70 ~37 ~-164 minecraft:deepslate_tiles
fill ~-70 ~36 ~-156 ~-70 ~36 ~-155 minecraft:deepslate_tiles
fill ~-70 ~36 ~-37 ~-69 ~36 ~-37 minecraft:deepslate_tiles
fill ~-70 ~36 ~-36 ~-70 ~37 ~-36 minecraft:deepslate_tiles
fill ~-70 ~36 ~-28 ~-70 ~36 ~-27 minecraft:deepslate_tiles
fill ~-70 ~37 ~-157 ~-70 ~37 ~-156 minecraft:deepslate_tiles
fill ~-70 ~37 ~-29 ~-70 ~37 ~-28 minecraft:deepslate_tiles
fill ~-70 ~38 ~-163 ~-69 ~38 ~-163 minecraft:deepslate_tiles
fill ~-70 ~38 ~-162 ~-70 ~38 ~-157 minecraft:deepslate_tiles
fill ~-70 ~38 ~-35 ~-69 ~38 ~-35 minecraft:deepslate_tiles
fill ~-70 ~38 ~-34 ~-70 ~38 ~-29 minecraft:deepslate_tiles
fill ~-70 ~39 ~-162 ~-69 ~39 ~-162 minecraft:deepslate_tiles
fill ~-70 ~39 ~-161 ~-70 ~39 ~-158 minecraft:deepslate_tiles
fill ~-70 ~39 ~-34 ~-69 ~39 ~-34 minecraft:deepslate_tiles
fill ~-70 ~39 ~-33 ~-70 ~39 ~-30 minecraft:deepslate_tiles
fill ~-70 ~40 ~-160 ~-69 ~40 ~-160 minecraft:deepslate_tiles
fill ~-69 ~-24 ~-129 ~-31 ~-23 ~-127 minecraft:deepslate_tiles
fill ~-69 ~27 ~-93 ~-69 ~28 ~-92 minecraft:deepslate_tiles
fill ~-69 ~28 ~-100 ~-68 ~28 ~-100 minecraft:deepslate_tiles
fill ~-69 ~28 ~-99 ~-69 ~29 ~-98 minecraft:deepslate_tiles
fill ~-69 ~28 ~-94 ~-69 ~28 ~-92 minecraft:deepslate_tiles
fill ~-69 ~29 ~-97 ~-69 ~29 ~-93 minecraft:deepslate_tiles
fill ~-69 ~30 ~-97 ~-68 ~30 ~-97 minecraft:deepslate_tiles
fill ~-69 ~30 ~-96 ~-69 ~30 ~-95 minecraft:deepslate_tiles
fill ~-69 ~31 ~-151 ~-68 ~32 ~-151 minecraft:deepslate_tiles
fill ~-69 ~31 ~-23 ~-68 ~32 ~-23 minecraft:deepslate_tiles
fill ~-69 ~32 ~-169 ~-66 ~32 ~-169 minecraft:deepslate_tiles
fill ~-69 ~32 ~-152 ~-69 ~32 ~-151 minecraft:deepslate_tiles
fill ~-69 ~32 ~-41 ~-66 ~32 ~-41 minecraft:deepslate_tiles
fill ~-69 ~32 ~-24 ~-69 ~32 ~-23 minecraft:deepslate_tiles
fill ~-69 ~33 ~-168 ~-68 ~33 ~-168 minecraft:deepslate_tiles
fill ~-69 ~33 ~-152 ~-68 ~33 ~-152 minecraft:deepslate_tiles
fill ~-69 ~33 ~-40 ~-68 ~33 ~-40 minecraft:deepslate_tiles
fill ~-69 ~33 ~-24 ~-68 ~33 ~-24 minecraft:deepslate_tiles
fill ~-69 ~35 ~-167 ~-67 ~35 ~-167 minecraft:deepslate_tiles
fill ~-69 ~35 ~-154 ~-69 ~35 ~-153 minecraft:deepslate_tiles
fill ~-69 ~35 ~-39 ~-67 ~35 ~-39 minecraft:deepslate_tiles
fill ~-69 ~35 ~-38 ~-69 ~36 ~-38 minecraft:deepslate_tiles
fill ~-69 ~35 ~-26 ~-69 ~35 ~-25 minecraft:deepslate_tiles
fill ~-69 ~36 ~-166 ~-68 ~36 ~-166 minecraft:deepslate_tiles
fill ~-69 ~36 ~-165 ~-69 ~38 ~-165 minecraft:deepslate_tiles
fill ~-69 ~36 ~-155 ~-69 ~36 ~-154 minecraft:deepslate_tiles
fill ~-69 ~36 ~-27 ~-69 ~36 ~-26 minecraft:deepslate_tiles
fill ~-69 ~37 ~-164 ~-69 ~39 ~-164 minecraft:deepslate_tiles
fill ~-69 ~37 ~-156 ~-69 ~38 ~-155 minecraft:deepslate_tiles
fill ~-69 ~37 ~-37 ~-68 ~38 ~-37 minecraft:deepslate_tiles
fill ~-69 ~37 ~-36 ~-69 ~39 ~-36 minecraft:deepslate_tiles
fill ~-69 ~37 ~-28 ~-69 ~38 ~-27 minecraft:deepslate_tiles
fill ~-69 ~38 ~-157 ~-69 ~38 ~-155 minecraft:deepslate_tiles
fill ~-69 ~38 ~-29 ~-69 ~38 ~-27 minecraft:deepslate_tiles
fill ~-69 ~39 ~-163 ~-69 ~40 ~-162 minecraft:deepslate_tiles
fill ~-69 ~39 ~-158 ~-69 ~39 ~-156 minecraft:deepslate_tiles
fill ~-69 ~39 ~-35 ~-69 ~40 ~-34 minecraft:deepslate_tiles
fill ~-69 ~39 ~-30 ~-69 ~39 ~-28 minecraft:deepslate_tiles
fill ~-69 ~40 ~-161 ~-69 ~40 ~-157 minecraft:deepslate_tiles
fill ~-69 ~40 ~-32 ~-69 ~40 ~-29 minecraft:deepslate_tiles
fill ~-69 ~41 ~-162 ~-68 ~41 ~-162 minecraft:deepslate_tiles
fill ~-69 ~41 ~-161 ~-69 ~41 ~-158 minecraft:deepslate_tiles
fill ~-69 ~41 ~-34 ~-68 ~41 ~-34 minecraft:deepslate_tiles
fill ~-69 ~41 ~-33 ~-69 ~41 ~-30 minecraft:deepslate_tiles
fill ~-68 ~-25 ~-129 ~-31 ~-23 ~-127 minecraft:deepslate_tiles
fill ~-68 ~27 ~-101 ~-67 ~28 ~-101 minecraft:deepslate_tiles
fill ~-68 ~27 ~-91 ~-67 ~28 ~-91 minecraft:deepslate_tiles
fill ~-68 ~28 ~-92 ~-68 ~28 ~-91 minecraft:deepslate_tiles
fill ~-68 ~29 ~-100 ~-67 ~29 ~-100 minecraft:deepslate_tiles
fill ~-68 ~29 ~-99 ~-68 ~30 ~-99 minecraft:deepslate_tiles
fill ~-68 ~29 ~-93 ~-68 ~29 ~-92 minecraft:deepslate_tiles
fill ~-68 ~30 ~-98 ~-68 ~31 ~-97 minecraft:deepslate_tiles
fill ~-68 ~30 ~-95 ~-68 ~30 ~-93 minecraft:deepslate_tiles
fill ~-68 ~31 ~-170 ~-60 ~31 ~-170 minecraft:deepslate_tiles
fill ~-68 ~31 ~-150 ~-60 ~31 ~-150 minecraft:deepslate_tiles
fill ~-68 ~31 ~-96 ~-68 ~31 ~-94 minecraft:deepslate_tiles
fill ~-68 ~31 ~-42 ~-60 ~31 ~-42 minecraft:deepslate_tiles
fill ~-68 ~31 ~-22 ~-60 ~31 ~-22 minecraft:deepslate_tiles
fill ~-68 ~32 ~-97 ~-67 ~32 ~-95 minecraft:deepslate_tiles
fill ~-68 ~33 ~-169 ~-60 ~33 ~-169 minecraft:deepslate_tiles
fill ~-68 ~33 ~-151 ~-60 ~33 ~-151 minecraft:deepslate_tiles
fill ~-68 ~33 ~-41 ~-60 ~33 ~-41 minecraft:deepslate_tiles
fill ~-68 ~33 ~-23 ~-60 ~33 ~-23 minecraft:deepslate_tiles
fill ~-68 ~34 ~-168 ~-65 ~34 ~-168 minecraft:deepslate_tiles
fill ~-68 ~34 ~-167 ~-68 ~36 ~-167 minecraft:deepslate_tiles
fill ~-68 ~34 ~-153 ~-68 ~34 ~-152 minecraft:deepslate_tiles
fill ~-68 ~34 ~-40 ~-65 ~34 ~-40 minecraft:deepslate_tiles
fill ~-68 ~34 ~-39 ~-68 ~36 ~-39 minecraft:deepslate_tiles
fill ~-68 ~34 ~-25 ~-68 ~34 ~-24 minecraft:deepslate_tiles
fill ~-68 ~35 ~-153 ~-67 ~36 ~-153 minecraft:deepslate_tiles
fill ~-68 ~35 ~-25 ~-67 ~36 ~-25 minecraft:deepslate_tiles
fill ~-68 ~36 ~-154 ~-68 ~36 ~-153 minecraft:deepslate_tiles
fill ~-68 ~36 ~-38 ~-68 ~37 ~-38 minecraft:deepslate_tiles
fill ~-68 ~36 ~-26 ~-68 ~36 ~-25 minecraft:deepslate_tiles
fill ~-68 ~37 ~-166 ~-67 ~37 ~-166 minecraft:deepslate_tiles
fill ~-68 ~37 ~-165 ~-68 ~39 ~-165 minecraft:deepslate_tiles
fill ~-68 ~37 ~-155 ~-68 ~37 ~-154 minecraft:deepslate_tiles
fill ~-68 ~37 ~-27 ~-68 ~37 ~-26 minecraft:deepslate_tiles
fill ~-68 ~38 ~-155 ~-67 ~39 ~-155 minecraft:deepslate_tiles
fill ~-68 ~38 ~-27 ~-67 ~39 ~-27 minecraft:deepslate_tiles
fill ~-68 ~39 ~-164 ~-68 ~40 ~-164 minecraft:deepslate_tiles
fill ~-68 ~39 ~-156 ~-68 ~39 ~-155 minecraft:deepslate_tiles
fill ~-68 ~39 ~-37 ~-66 ~39 ~-37 minecraft:deepslate_tiles
fill ~-68 ~39 ~-36 ~-68 ~40 ~-36 minecraft:deepslate_tiles
fill ~-68 ~39 ~-28 ~-68 ~39 ~-27 minecraft:deepslate_tiles
fill ~-68 ~40 ~-163 ~-68 ~41 ~-163 minecraft:deepslate_tiles
fill ~-68 ~40 ~-157 ~-68 ~40 ~-156 minecraft:deepslate_tiles
fill ~-68 ~40 ~-35 ~-68 ~41 ~-35 minecraft:deepslate_tiles
fill ~-68 ~40 ~-29 ~-68 ~40 ~-28 minecraft:deepslate_tiles
fill ~-68 ~41 ~-158 ~-68 ~41 ~-157 minecraft:deepslate_tiles
fill ~-68 ~41 ~-30 ~-68 ~41 ~-29 minecraft:deepslate_tiles
fill ~-68 ~42 ~-161 ~-68 ~42 ~-158 minecraft:deepslate_tiles
fill ~-68 ~42 ~-34 ~-68 ~42 ~-30 minecraft:deepslate_tiles
fill ~-68 ~43 ~-161 ~-67 ~43 ~-161 minecraft:deepslate_tiles
fill ~-68 ~43 ~-160 ~-68 ~43 ~-159 minecraft:deepslate_tiles
fill ~-68 ~43 ~-33 ~-67 ~43 ~-33 minecraft:deepslate_tiles
fill ~-68 ~43 ~-32 ~-68 ~43 ~-31 minecraft:deepslate_tiles
fill ~-67 ~-26 ~-129 ~-31 ~-23 ~-127 minecraft:deepslate_tiles
fill ~-67 ~27 ~-102 ~-61 ~27 ~-102 minecraft:deepslate_tiles
fill ~-67 ~29 ~-101 ~-61 ~29 ~-101 minecraft:deepslate_tiles
fill ~-67 ~29 ~-92 ~-67 ~29 ~-91 minecraft:deepslate_tiles
fill ~-67 ~30 ~-100 ~-65 ~30 ~-100 minecraft:deepslate_tiles
fill ~-67 ~30 ~-99 ~-67 ~31 ~-99 minecraft:deepslate_tiles
fill ~-67 ~30 ~-93 ~-67 ~30 ~-92 minecraft:deepslate_tiles
fill ~-67 ~31 ~-98 ~-67 ~33 ~-98 minecraft:deepslate_tiles
fill ~-67 ~31 ~-94 ~-67 ~31 ~-93 minecraft:deepslate_tiles
fill ~-67 ~32 ~-151 ~-66 ~33 ~-151 minecraft:deepslate_tiles
fill ~-67 ~32 ~-94 ~-67 ~33 ~-94 minecraft:deepslate_tiles
fill ~-67 ~32 ~-23 ~-66 ~33 ~-23 minecraft:deepslate_tiles
fill ~-67 ~33 ~-97 ~-67 ~33 ~-94 minecraft:deepslate_tiles
fill ~-67 ~34 ~-152 ~-65 ~35 ~-152 minecraft:deepslate_tiles
fill ~-67 ~34 ~-96 ~-66 ~34 ~-96 minecraft:deepslate_tiles
fill ~-67 ~34 ~-24 ~-65 ~35 ~-24 minecraft:deepslate_tiles
fill ~-67 ~35 ~-40 ~-61 ~35 ~-40 minecraft:deepslate_tiles
fill ~-67 ~36 ~-167 ~-60 ~36 ~-167 minecraft:deepslate_tiles
fill ~-67 ~36 ~-39 ~-60 ~36 ~-39 minecraft:deepslate_tiles
fill ~-67 ~37 ~-167 ~-61 ~37 ~-167 minecraft:deepslate_tiles
fill ~-67 ~37 ~-154 ~-67 ~37 ~-153 minecraft:deepslate_tiles
fill ~-67 ~37 ~-39 ~-61 ~37 ~-39 minecraft:deepslate_tiles
fill ~-67 ~37 ~-38 ~-67 ~38 ~-38 minecraft:deepslate_tiles
fill ~-67 ~37 ~-26 ~-67 ~37 ~-25 minecraft:deepslate_tiles
fill ~-67 ~38 ~-166 ~-61 ~38 ~-166 minecraft:deepslate_tiles
fill ~-67 ~38 ~-165 ~-67 ~40 ~-165 minecraft:deepslate_tiles
fill ~-67 ~38 ~-154 ~-61 ~38 ~-154 minecraft:deepslate_tiles
fill ~-67 ~38 ~-37 ~-67 ~40 ~-37 minecraft:deepslate_tiles
fill ~-67 ~38 ~-26 ~-61 ~38 ~-26 minecraft:deepslate_tiles
fill ~-67 ~40 ~-164 ~-67 ~41 ~-164 minecraft:deepslate_tiles
fill ~-67 ~40 ~-156 ~-67 ~40 ~-155 minecraft:deepslate_tiles
fill ~-67 ~40 ~-36 ~-67 ~41 ~-36 minecraft:deepslate_tiles
fill ~-67 ~40 ~-28 ~-67 ~40 ~-27 minecraft:deepslate_tiles
fill ~-67 ~41 ~-163 ~-67 ~43 ~-163 minecraft:deepslate_tiles
fill ~-67 ~41 ~-156 ~-66 ~41 ~-156 minecraft:deepslate_tiles
fill ~-67 ~41 ~-35 ~-67 ~43 ~-35 minecraft:deepslate_tiles
fill ~-67 ~41 ~-29 ~-67 ~41 ~-28 minecraft:deepslate_tiles
fill ~-67 ~42 ~-157 ~-67 ~43 ~-157 minecraft:deepslate_tiles
fill ~-67 ~42 ~-29 ~-67 ~43 ~-29 minecraft:deepslate_tiles
fill ~-67 ~43 ~-162 ~-67 ~44 ~-161 minecraft:deepslate_tiles
fill ~-67 ~43 ~-159 ~-67 ~43 ~-157 minecraft:deepslate_tiles
fill ~-67 ~43 ~-34 ~-67 ~44 ~-33 minecraft:deepslate_tiles
fill ~-67 ~43 ~-31 ~-67 ~43 ~-29 minecraft:deepslate_tiles
fill ~-67 ~44 ~-160 ~-67 ~44 ~-158 minecraft:deepslate_tiles
fill ~-67 ~44 ~-32 ~-67 ~44 ~-30 minecraft:deepslate_tiles
fill ~-67 ~45 ~-161 ~-66 ~45 ~-159 minecraft:deepslate_tiles
fill ~-67 ~45 ~-33 ~-66 ~45 ~-31 minecraft:deepslate_tiles
fill ~-66 ~-27 ~-129 ~-31 ~-23 ~-127 minecraft:deepslate_tiles
fill ~-66 ~27 ~-90 ~-61 ~27 ~-90 minecraft:deepslate_tiles
fill ~-66 ~28 ~-102 ~-62 ~28 ~-102 minecraft:deepslate_tiles
fill ~-66 ~28 ~-101 ~-66 ~29 ~-101 minecraft:deepslate_tiles
fill ~-66 ~28 ~-91 ~-66 ~28 ~-90 minecraft:deepslate_tiles
fill ~-66 ~29 ~-91 ~-61 ~29 ~-91 minecraft:deepslate_tiles
fill ~-66 ~30 ~-92 ~-65 ~31 ~-92 minecraft:deepslate_tiles
fill ~-66 ~31 ~-100 ~-62 ~31 ~-100 minecraft:deepslate_tiles
fill ~-66 ~31 ~-99 ~-66 ~33 ~-99 minecraft:deepslate_tiles
fill ~-66 ~31 ~-93 ~-66 ~31 ~-92 minecraft:deepslate_tiles
fill ~-66 ~32 ~-170 ~-62 ~32 ~-170 minecraft:deepslate_tiles
fill ~-66 ~32 ~-150 ~-62 ~32 ~-150 minecraft:deepslate_tiles
fill ~-66 ~32 ~-93 ~-62 ~33 ~-93 minecraft:deepslate_tiles
fill ~-66 ~32 ~-42 ~-62 ~32 ~-42 minecraft:deepslate_tiles
fill ~-66 ~32 ~-22 ~-62 ~32 ~-22 minecraft:deepslate_tiles
fill ~-66 ~33 ~-98 ~-66 ~34 ~-98 minecraft:deepslate_tiles
fill ~-66 ~33 ~-94 ~-66 ~33 ~-93 minecraft:deepslate_tiles
fill ~-66 ~34 ~-169 ~-62 ~34 ~-169 minecraft:deepslate_tiles
fill ~-66 ~34 ~-151 ~-62 ~34 ~-151 minecraft:deepslate_tiles
fill ~-66 ~34 ~-97 ~-66 ~34 ~-94 minecraft:deepslate_tiles
fill ~-66 ~34 ~-41 ~-62 ~34 ~-41 minecraft:deepslate_tiles
fill ~-66 ~34 ~-23 ~-62 ~34 ~-23 minecraft:deepslate_tiles
fill ~-66 ~35 ~-168 ~-61 ~35 ~-168 minecraft:deepslate_tiles
fill ~-66 ~35 ~-97 ~-65 ~35 ~-97 minecraft:deepslate_tiles
fill ~-66 ~35 ~-96 ~-66 ~35 ~-95 minecraft:deepslate_tiles
fill ~-66 ~36 ~-153 ~-60 ~36 ~-153 minecraft:deepslate_tiles
fill ~-66 ~36 ~-25 ~-60 ~36 ~-25 minecraft:deepslate_tiles
fill ~-66 ~37 ~-153 ~-61 ~37 ~-153 minecraft:deepslate_tiles
fill ~-66 ~37 ~-25 ~-61 ~37 ~-25 minecraft:deepslate_tiles
fill ~-66 ~38 ~-38 ~-61 ~38 ~-38 minecraft:deepslate_tiles
fill ~-66 ~39 ~-166 ~-62 ~39 ~-166 minecraft:deepslate_tiles
fill ~-66 ~39 ~-165 ~-66 ~41 ~-165 minecraft:deepslate_tiles
fill ~-66 ~39 ~-154 ~-62 ~39 ~-154 minecraft:deepslate_tiles
fill ~-66 ~39 ~-38 ~-62 ~39 ~-38 minecraft:deepslate_tiles
fill ~-66 ~39 ~-27 ~-66 ~39 ~-26 minecraft:deepslate_tiles
fill ~-66 ~40 ~-155 ~-61 ~40 ~-155 minecraft:deepslate_tiles
fill ~-66 ~40 ~-37 ~-61 ~40 ~-37 minecraft:deepslate_tiles
fill ~-66 ~40 ~-27 ~-61 ~40 ~-27 minecraft:deepslate_tiles
fill ~-66 ~41 ~-164 ~-66 ~42 ~-164 minecraft:deepslate_tiles
fill ~-66 ~41 ~-155 ~-62 ~41 ~-155 minecraft:deepslate_tiles
fill ~-66 ~41 ~-37 ~-62 ~41 ~-37 minecraft:deepslate_tiles
fill ~-66 ~41 ~-36 ~-66 ~42 ~-36 minecraft:deepslate_tiles
fill ~-66 ~41 ~-28 ~-66 ~41 ~-27 minecraft:deepslate_tiles
fill ~-66 ~42 ~-156 ~-62 ~42 ~-156 minecraft:deepslate_tiles
fill ~-66 ~42 ~-28 ~-62 ~42 ~-28 minecraft:deepslate_tiles
fill ~-66 ~43 ~-163 ~-65 ~44 ~-163 minecraft:deepslate_tiles
fill ~-66 ~43 ~-157 ~-65 ~44 ~-157 minecraft:deepslate_tiles
fill ~-66 ~43 ~-35 ~-65 ~44 ~-35 minecraft:deepslate_tiles
fill ~-66 ~43 ~-29 ~-65 ~44 ~-29 minecraft:deepslate_tiles
fill ~-66 ~44 ~-162 ~-66 ~45 ~-162 minecraft:deepslate_tiles
fill ~-66 ~44 ~-158 ~-66 ~44 ~-157 minecraft:deepslate_tiles
fill ~-66 ~44 ~-34 ~-66 ~45 ~-34 minecraft:deepslate_tiles
fill ~-66 ~44 ~-30 ~-66 ~44 ~-29 minecraft:deepslate_tiles
fill ~-66 ~45 ~-30 ~-62 ~45 ~-30 minecraft:deepslate_tiles
fill ~-66 ~46 ~-161 ~-65 ~46 ~-161 minecraft:deepslate_tiles
fill ~-66 ~46 ~-160 ~-66 ~46 ~-159 minecraft:deepslate_tiles
fill ~-66 ~46 ~-33 ~-65 ~46 ~-33 minecraft:deepslate_tiles
fill ~-66 ~46 ~-32 ~-66 ~46 ~-31 minecraft:deepslate_tiles
fill ~-66 ~47 ~-160 ~-65 ~47 ~-160 minecraft:deepslate_tiles
fill ~-66 ~47 ~-32 ~-65 ~47 ~-32 minecraft:deepslate_tiles
fill ~-65 ~28 ~-90 ~-62 ~28 ~-90 minecraft:deepslate_tiles
fill ~-65 ~30 ~-101 ~-63 ~30 ~-101 minecraft:deepslate_tiles
fill ~-65 ~30 ~-91 ~-63 ~30 ~-91 minecraft:deepslate_tiles
fill ~-65 ~32 ~-100 ~-63 ~32 ~-99 minecraft:deepslate_tiles
fill ~-65 ~32 ~-92 ~-63 ~32 ~-92 minecraft:deepslate_tiles
fill ~-65 ~33 ~-99 ~-62 ~33 ~-99 minecraft:deepslate_tiles
fill ~-65 ~34 ~-98 ~-62 ~34 ~-98 minecraft:deepslate_tiles
fill ~-65 ~34 ~-94 ~-62 ~34 ~-94 minecraft:deepslate_tiles
fill ~-65 ~35 ~-98 ~-63 ~35 ~-98 minecraft:deepslate_tiles
fill ~-65 ~35 ~-95 ~-65 ~35 ~-94 minecraft:deepslate_tiles
fill ~-65 ~36 ~-152 ~-63 ~36 ~-152 minecraft:deepslate_tiles
fill ~-65 ~36 ~-97 ~-63 ~37 ~-97 minecraft:deepslate_tiles
fill ~-65 ~36 ~-96 ~-65 ~37 ~-95 minecraft:deepslate_tiles
fill ~-65 ~36 ~-40 ~-63 ~36 ~-39 minecraft:deepslate_tiles
fill ~-65 ~36 ~-24 ~-63 ~36 ~-24 minecraft:deepslate_tiles
fill ~-65 ~38 ~-167 ~-63 ~38 ~-166 minecraft:deepslate_tiles
fill ~-65 ~38 ~-153 ~-63 ~38 ~-153 minecraft:deepslate_tiles
fill ~-65 ~38 ~-39 ~-63 ~38 ~-38 minecraft:deepslate_tiles
fill ~-65 ~38 ~-25 ~-63 ~38 ~-25 minecraft:deepslate_tiles
fill ~-65 ~39 ~-26 ~-62 ~39 ~-26 minecraft:deepslate_tiles
fill ~-65 ~40 ~-165 ~-61 ~40 ~-165 minecraft:deepslate_tiles
fill ~-65 ~41 ~-165 ~-62 ~41 ~-165 minecraft:deepslate_tiles
fill ~-65 ~41 ~-27 ~-62 ~41 ~-27 minecraft:deepslate_tiles
fill ~-65 ~42 ~-164 ~-62 ~42 ~-164 minecraft:deepslate_tiles
fill ~-65 ~42 ~-36 ~-62 ~42 ~-36 minecraft:deepslate_tiles
fill ~-65 ~43 ~-164 ~-63 ~43 ~-164 minecraft:deepslate_tiles
fill ~-65 ~43 ~-156 ~-63 ~43 ~-156 minecraft:deepslate_tiles
fill ~-65 ~43 ~-36 ~-63 ~43 ~-36 minecraft:deepslate_tiles
fill ~-65 ~43 ~-28 ~-63 ~43 ~-28 minecraft:deepslate_tiles
fill ~-65 ~45 ~-163 ~-63 ~45 ~-162 minecraft:deepslate_tiles
fill ~-65 ~45 ~-158 ~-62 ~45 ~-158 minecraft:deepslate_tiles
fill ~-65 ~45 ~-157 ~-63 ~45 ~-157 minecraft:deepslate_tiles
fill ~-65 ~45 ~-35 ~-63 ~45 ~-34 minecraft:deepslate_tiles
fill ~-65 ~45 ~-29 ~-63 ~45 ~-29 minecraft:deepslate_tiles
fill ~-65 ~46 ~-162 ~-63 ~46 ~-162 minecraft:deepslate_tiles
fill ~-65 ~46 ~-159 ~-65 ~46 ~-158 minecraft:deepslate_tiles
fill ~-65 ~46 ~-34 ~-63 ~46 ~-34 minecraft:deepslate_tiles
fill ~-65 ~46 ~-31 ~-65 ~46 ~-30 minecraft:deepslate_tiles
fill ~-65 ~47 ~-161 ~-63 ~48 ~-161 minecraft:deepslate_tiles
fill ~-65 ~47 ~-31 ~-63 ~48 ~-31 minecraft:deepslate_tiles
fill ~-65 ~48 ~-160 ~-63 ~48 ~-159 minecraft:deepslate_tiles
fill ~-65 ~48 ~-33 ~-63 ~48 ~-31 minecraft:deepslate_tiles
fill ~-64 ~31 ~-92 ~-62 ~31 ~-92 minecraft:deepslate_tiles
fill ~-64 ~34 ~-99 ~-64 ~34 ~-98 minecraft:deepslate_tiles
setblock ~-64 ~34 ~-93 minecraft:deepslate_tiles
fill ~-64 ~35 ~-152 ~-61 ~35 ~-152 minecraft:deepslate_tiles
fill ~-64 ~35 ~-94 ~-63 ~35 ~-94 minecraft:deepslate_tiles
fill ~-64 ~35 ~-24 ~-61 ~35 ~-24 minecraft:deepslate_tiles
fill ~-64 ~36 ~-168 ~-63 ~36 ~-167 minecraft:deepslate_tiles
fill ~-64 ~36 ~-95 ~-63 ~37 ~-95 minecraft:deepslate_tiles
fill ~-64 ~37 ~-96 ~-63 ~37 ~-95 minecraft:deepslate_tiles
fill ~-64 ~38 ~-96 ~-64 ~40 ~-96 minecraft:deepslate_tiles
fill ~-64 ~40 ~-166 ~-64 ~40 ~-165 minecraft:deepslate_tiles
setblock ~-64 ~40 ~-154 minecraft:deepslate_tiles
fill ~-64 ~40 ~-38 ~-64 ~40 ~-37 minecraft:deepslate_tiles
setblock ~-64 ~40 ~-26 minecraft:deepslate_tiles
fill ~-64 ~44 ~-163 ~-62 ~44 ~-163 minecraft:deepslate_tiles
fill ~-64 ~44 ~-157 ~-62 ~44 ~-157 minecraft:deepslate_tiles
fill ~-64 ~44 ~-35 ~-62 ~44 ~-35 minecraft:deepslate_tiles
fill ~-64 ~44 ~-29 ~-62 ~44 ~-29 minecraft:deepslate_tiles
fill ~-64 ~46 ~-158 ~-63 ~46 ~-158 minecraft:deepslate_tiles
fill ~-64 ~46 ~-30 ~-63 ~46 ~-30 minecraft:deepslate_tiles
fill ~-64 ~47 ~-162 ~-64 ~47 ~-161 minecraft:deepslate_tiles
fill ~-64 ~47 ~-159 ~-63 ~48 ~-159 minecraft:deepslate_tiles
setblock ~-64 ~47 ~-158 minecraft:deepslate_tiles
fill ~-64 ~47 ~-34 ~-64 ~47 ~-33 minecraft:deepslate_tiles
setblock ~-64 ~47 ~-30 minecraft:deepslate_tiles
fill ~-64 ~49 ~-160 ~-64 ~52 ~-160 minecraft:deepslate_tiles
fill ~-64 ~49 ~-32 ~-64 ~52 ~-32 minecraft:deepslate_tiles
fill ~-63 ~30 ~-100 ~-61 ~30 ~-100 minecraft:deepslate_tiles
fill ~-63 ~30 ~-92 ~-61 ~30 ~-92 minecraft:deepslate_tiles
fill ~-63 ~34 ~-168 ~-60 ~34 ~-168 minecraft:deepslate_tiles
fill ~-63 ~34 ~-152 ~-60 ~34 ~-152 minecraft:deepslate_tiles
fill ~-63 ~34 ~-40 ~-60 ~34 ~-40 minecraft:deepslate_tiles
fill ~-63 ~34 ~-24 ~-60 ~34 ~-24 minecraft:deepslate_tiles
fill ~-63 ~35 ~-97 ~-62 ~35 ~-97 minecraft:deepslate_tiles
fill ~-63 ~35 ~-95 ~-62 ~35 ~-95 minecraft:deepslate_tiles
fill ~-63 ~36 ~-96 ~-63 ~37 ~-95 minecraft:deepslate_tiles
fill ~-63 ~43 ~-163 ~-61 ~43 ~-163 minecraft:deepslate_tiles
fill ~-63 ~43 ~-157 ~-61 ~43 ~-157 minecraft:deepslate_tiles
fill ~-63 ~43 ~-35 ~-61 ~43 ~-35 minecraft:deepslate_tiles
fill ~-63 ~43 ~-29 ~-61 ~43 ~-29 minecraft:deepslate_tiles
fill ~-63 ~46 ~-161 ~-62 ~46 ~-161 minecraft:deepslate_tiles
fill ~-63 ~46 ~-159 ~-62 ~46 ~-159 minecraft:deepslate_tiles
fill ~-63 ~46 ~-33 ~-62 ~46 ~-33 minecraft:deepslate_tiles
fill ~-63 ~46 ~-31 ~-62 ~46 ~-31 minecraft:deepslate_tiles
fill ~-63 ~47 ~-160 ~-62 ~47 ~-160 minecraft:deepslate_tiles
fill ~-63 ~47 ~-33 ~-63 ~48 ~-31 minecraft:deepslate_tiles
fill ~-62 ~28 ~-101 ~-60 ~28 ~-101 minecraft:deepslate_tiles
fill ~-62 ~28 ~-91 ~-60 ~28 ~-91 minecraft:deepslate_tiles
fill ~-62 ~31 ~-99 ~-61 ~31 ~-99 minecraft:deepslate_tiles
fill ~-62 ~31 ~-93 ~-61 ~31 ~-93 minecraft:deepslate_tiles
fill ~-62 ~32 ~-169 ~-59 ~32 ~-169 minecraft:deepslate_tiles
fill ~-62 ~32 ~-151 ~-59 ~32 ~-151 minecraft:deepslate_tiles
fill ~-62 ~32 ~-99 ~-62 ~33 ~-99 minecraft:deepslate_tiles
fill ~-62 ~32 ~-41 ~-59 ~32 ~-41 minecraft:deepslate_tiles
fill ~-62 ~32 ~-23 ~-59 ~32 ~-23 minecraft:deepslate_tiles
fill ~-62 ~33 ~-98 ~-61 ~33 ~-98 minecraft:deepslate_tiles
fill ~-62 ~33 ~-94 ~-61 ~33 ~-94 minecraft:deepslate_tiles
fill ~-62 ~34 ~-97 ~-62 ~34 ~-94 minecraft:deepslate_tiles
fill ~-62 ~35 ~-96 ~-62 ~35 ~-95 minecraft:deepslate_tiles
fill ~-62 ~39 ~-165 ~-60 ~39 ~-165 minecraft:deepslate_tiles
fill ~-62 ~39 ~-155 ~-60 ~39 ~-155 minecraft:deepslate_tiles
fill ~-62 ~39 ~-37 ~-60 ~39 ~-37 minecraft:deepslate_tiles
fill ~-62 ~39 ~-27 ~-60 ~39 ~-27 minecraft:deepslate_tiles
fill ~-62 ~41 ~-164 ~-61 ~41 ~-164 minecraft:deepslate_tiles
fill ~-62 ~41 ~-156 ~-61 ~41 ~-156 minecraft:deepslate_tiles
fill ~-62 ~41 ~-36 ~-61 ~41 ~-36 minecraft:deepslate_tiles
fill ~-62 ~41 ~-28 ~-61 ~41 ~-28 minecraft:deepslate_tiles
fill ~-62 ~44 ~-158 ~-61 ~44 ~-158 minecraft:deepslate_tiles
fill ~-62 ~44 ~-34 ~-61 ~44 ~-34 minecraft:deepslate_tiles
fill ~-62 ~44 ~-30 ~-61 ~44 ~-30 minecraft:deepslate_tiles
fill ~-62 ~45 ~-162 ~-62 ~45 ~-158 minecraft:deepslate_tiles
fill ~-62 ~45 ~-34 ~-62 ~45 ~-30 minecraft:deepslate_tiles
fill ~-62 ~46 ~-160 ~-62 ~46 ~-159 minecraft:deepslate_tiles
fill ~-62 ~46 ~-32 ~-62 ~46 ~-31 minecraft:deepslate_tiles
setblock ~-62 ~47 ~-32 minecraft:deepslate_tiles
fill ~-61 ~27 ~-91 ~-60 ~28 ~-91 minecraft:deepslate_tiles
fill ~-61 ~29 ~-100 ~-60 ~29 ~-100 minecraft:deepslate_tiles
fill ~-61 ~29 ~-92 ~-60 ~29 ~-92 minecraft:deepslate_tiles
fill ~-61 ~30 ~-99 ~-60 ~30 ~-99 minecraft:deepslate_tiles
fill ~-61 ~30 ~-93 ~-60 ~30 ~-93 minecraft:deepslate_tiles
fill ~-61 ~31 ~-98 ~-60 ~31 ~-98 minecraft:deepslate_tiles
fill ~-61 ~31 ~-94 ~-60 ~31 ~-94 minecraft:deepslate_tiles
fill ~-61 ~32 ~-98 ~-61 ~33 ~-94 minecraft:deepslate_tiles
setblock ~-61 ~34 ~-96 minecraft:deepslate_tiles
fill ~-61 ~35 ~-167 ~-59 ~35 ~-167 minecraft:deepslate_tiles
fill ~-61 ~35 ~-153 ~-59 ~35 ~-153 minecraft:deepslate_tiles
fill ~-61 ~35 ~-25 ~-59 ~35 ~-25 minecraft:deepslate_tiles
fill ~-61 ~37 ~-166 ~-60 ~37 ~-166 minecraft:deepslate_tiles
fill ~-61 ~37 ~-38 ~-60 ~37 ~-38 minecraft:deepslate_tiles
fill ~-61 ~37 ~-26 ~-60 ~37 ~-26 minecraft:deepslate_tiles
fill ~-61 ~38 ~-165 ~-59 ~38 ~-165 minecraft:deepslate_tiles
fill ~-61 ~38 ~-155 ~-59 ~38 ~-155 minecraft:deepslate_tiles
fill ~-61 ~38 ~-37 ~-59 ~38 ~-37 minecraft:deepslate_tiles
fill ~-61 ~38 ~-27 ~-59 ~38 ~-27 minecraft:deepslate_tiles
fill ~-61 ~40 ~-164 ~-60 ~40 ~-164 minecraft:deepslate_tiles
fill ~-61 ~40 ~-156 ~-60 ~40 ~-156 minecraft:deepslate_tiles
fill ~-61 ~40 ~-36 ~-60 ~40 ~-36 minecraft:deepslate_tiles
fill ~-61 ~40 ~-28 ~-60 ~40 ~-28 minecraft:deepslate_tiles
fill ~-61 ~41 ~-163 ~-60 ~41 ~-163 minecraft:deepslate_tiles
fill ~-61 ~41 ~-157 ~-60 ~41 ~-157 minecraft:deepslate_tiles
fill ~-61 ~41 ~-35 ~-60 ~41 ~-35 minecraft:deepslate_tiles
fill ~-61 ~41 ~-29 ~-60 ~41 ~-29 minecraft:deepslate_tiles
fill ~-61 ~42 ~-163 ~-61 ~43 ~-163 minecraft:deepslate_tiles
fill ~-61 ~42 ~-157 ~-61 ~43 ~-157 minecraft:deepslate_tiles
fill ~-61 ~42 ~-35 ~-61 ~43 ~-35 minecraft:deepslate_tiles
fill ~-61 ~42 ~-29 ~-61 ~43 ~-29 minecraft:deepslate_tiles
fill ~-61 ~43 ~-162 ~-61 ~44 ~-161 minecraft:deepslate_tiles
fill ~-61 ~43 ~-159 ~-60 ~43 ~-159 minecraft:deepslate_tiles
fill ~-61 ~43 ~-158 ~-61 ~43 ~-157 minecraft:deepslate_tiles
fill ~-61 ~43 ~-34 ~-61 ~44 ~-33 minecraft:deepslate_tiles
fill ~-61 ~43 ~-31 ~-60 ~43 ~-31 minecraft:deepslate_tiles
fill ~-61 ~43 ~-30 ~-61 ~43 ~-29 minecraft:deepslate_tiles
fill ~-61 ~44 ~-160 ~-61 ~44 ~-158 minecraft:deepslate_tiles
fill ~-61 ~44 ~-32 ~-61 ~44 ~-30 minecraft:deepslate_tiles
fill ~-61 ~45 ~-161 ~-61 ~45 ~-159 minecraft:deepslate_tiles
fill ~-61 ~45 ~-33 ~-61 ~45 ~-31 minecraft:deepslate_tiles
fill ~-60 ~27 ~-101 ~-60 ~28 ~-101 minecraft:deepslate_tiles
fill ~-60 ~28 ~-100 ~-59 ~28 ~-100 minecraft:deepslate_tiles
fill ~-60 ~28 ~-92 ~-59 ~28 ~-92 minecraft:deepslate_tiles
fill ~-60 ~29 ~-99 ~-59 ~29 ~-99 minecraft:deepslate_tiles
fill ~-60 ~29 ~-93 ~-59 ~29 ~-93 minecraft:deepslate_tiles
fill ~-60 ~30 ~-98 ~-60 ~31 ~-97 minecraft:deepslate_tiles
fill ~-60 ~30 ~-95 ~-59 ~30 ~-95 minecraft:deepslate_tiles
fill ~-60 ~30 ~-94 ~-60 ~30 ~-93 minecraft:deepslate_tiles
fill ~-60 ~31 ~-151 ~-58 ~31 ~-151 minecraft:deepslate_tiles
fill ~-60 ~31 ~-96 ~-60 ~31 ~-94 minecraft:deepslate_tiles
fill ~-60 ~31 ~-41 ~-58 ~31 ~-41 minecraft:deepslate_tiles
fill ~-60 ~31 ~-23 ~-58 ~31 ~-23 minecraft:deepslate_tiles
fill ~-60 ~32 ~-97 ~-60 ~32 ~-95 minecraft:deepslate_tiles
fill ~-60 ~33 ~-168 ~-59 ~33 ~-168 minecraft:deepslate_tiles
fill ~-60 ~33 ~-152 ~-59 ~33 ~-152 minecraft:deepslate_tiles
fill ~-60 ~33 ~-40 ~-59 ~33 ~-40 minecraft:deepslate_tiles
fill ~-60 ~33 ~-24 ~-59 ~33 ~-24 minecraft:deepslate_tiles
fill ~-60 ~34 ~-167 ~-58 ~34 ~-167 minecraft:deepslate_tiles
fill ~-60 ~34 ~-153 ~-58 ~34 ~-153 minecraft:deepslate_tiles
fill ~-60 ~34 ~-39 ~-58 ~34 ~-39 minecraft:deepslate_tiles
fill ~-60 ~34 ~-25 ~-58 ~34 ~-25 minecraft:deepslate_tiles
fill ~-60 ~35 ~-39 ~-59 ~35 ~-39 minecraft:deepslate_tiles
fill ~-60 ~36 ~-166 ~-59 ~36 ~-166 minecraft:deepslate_tiles
fill ~-60 ~36 ~-154 ~-59 ~36 ~-154 minecraft:deepslate_tiles
fill ~-60 ~36 ~-38 ~-59 ~36 ~-38 minecraft:deepslate_tiles
fill ~-60 ~36 ~-26 ~-59 ~36 ~-26 minecraft:deepslate_tiles
fill ~-60 ~37 ~-165 ~-59 ~38 ~-165 minecraft:deepslate_tiles
fill ~-60 ~37 ~-155 ~-59 ~38 ~-155 minecraft:deepslate_tiles
setblock ~-60 ~37 ~-154 minecraft:deepslate_tiles
fill ~-60 ~37 ~-37 ~-59 ~38 ~-37 minecraft:deepslate_tiles
fill ~-60 ~37 ~-27 ~-59 ~38 ~-27 minecraft:deepslate_tiles
fill ~-60 ~39 ~-164 ~-59 ~39 ~-164 minecraft:deepslate_tiles
fill ~-60 ~39 ~-156 ~-59 ~39 ~-156 minecraft:deepslate_tiles
fill ~-60 ~39 ~-36 ~-59 ~39 ~-36 minecraft:deepslate_tiles
fill ~-60 ~39 ~-28 ~-59 ~39 ~-28 minecraft:deepslate_tiles
fill ~-60 ~40 ~-163 ~-59 ~40 ~-163 minecraft:deepslate_tiles
fill ~-60 ~40 ~-157 ~-59 ~40 ~-157 minecraft:deepslate_tiles
fill ~-60 ~40 ~-35 ~-59 ~40 ~-35 minecraft:deepslate_tiles
fill ~-60 ~40 ~-29 ~-59 ~40 ~-29 minecraft:deepslate_tiles
fill ~-60 ~41 ~-162 ~-59 ~41 ~-162 minecraft:deepslate_tiles
fill ~-60 ~41 ~-34 ~-59 ~41 ~-34 minecraft:deepslate_tiles
fill ~-60 ~41 ~-30 ~-59 ~41 ~-30 minecraft:deepslate_tiles
fill ~-60 ~42 ~-162 ~-60 ~42 ~-158 minecraft:deepslate_tiles
fill ~-60 ~42 ~-34 ~-60 ~42 ~-30 minecraft:deepslate_tiles
fill ~-60 ~43 ~-161 ~-60 ~43 ~-159 minecraft:deepslate_tiles
fill ~-60 ~43 ~-33 ~-60 ~43 ~-31 minecraft:deepslate_tiles
fill ~-59 ~27 ~-100 ~-59 ~28 ~-99 minecraft:deepslate_tiles
fill ~-59 ~27 ~-93 ~-58 ~27 ~-93 minecraft:deepslate_tiles
fill ~-59 ~27 ~-92 ~-59 ~28 ~-92 minecraft:deepslate_tiles
fill ~-59 ~28 ~-98 ~-58 ~28 ~-98 minecraft:deepslate_tiles
fill ~-59 ~28 ~-94 ~-58 ~28 ~-94 minecraft:deepslate_tiles
fill ~-59 ~28 ~-93 ~-59 ~28 ~-92 minecraft:deepslate_tiles
fill ~-59 ~29 ~-98 ~-59 ~29 ~-93 minecraft:deepslate_tiles
fill ~-59 ~30 ~-97 ~-59 ~30 ~-95 minecraft:deepslate_tiles
fill ~-59 ~31 ~-169 ~-58 ~31 ~-169 minecraft:deepslate_tiles
fill ~-59 ~32 ~-168 ~-58 ~32 ~-168 minecraft:deepslate_tiles
fill ~-59 ~32 ~-152 ~-58 ~32 ~-152 minecraft:deepslate_tiles
fill ~-59 ~32 ~-40 ~-58 ~32 ~-40 minecraft:deepslate_tiles
fill ~-59 ~32 ~-24 ~-58 ~32 ~-24 minecraft:deepslate_tiles
fill ~-59 ~33 ~-167 ~-58 ~34 ~-167 minecraft:deepslate_tiles
fill ~-59 ~33 ~-153 ~-58 ~34 ~-153 minecraft:deepslate_tiles
fill ~-59 ~33 ~-39 ~-58 ~34 ~-39 minecraft:deepslate_tiles
fill ~-59 ~33 ~-25 ~-58 ~34 ~-25 minecraft:deepslate_tiles
fill ~-59 ~35 ~-166 ~-58 ~35 ~-166 minecraft:deepslate_tiles
fill ~-59 ~35 ~-154 ~-58 ~35 ~-154 minecraft:deepslate_tiles
fill ~-59 ~35 ~-38 ~-58 ~35 ~-38 minecraft:deepslate_tiles
fill ~-59 ~35 ~-26 ~-58 ~35 ~-26 minecraft:deepslate_tiles
fill ~-59 ~36 ~-165 ~-58 ~36 ~-165 minecraft:deepslate_tiles
fill ~-59 ~36 ~-155 ~-58 ~36 ~-155 minecraft:deepslate_tiles
fill ~-59 ~36 ~-37 ~-58 ~36 ~-37 minecraft:deepslate_tiles
fill ~-59 ~36 ~-27 ~-58 ~36 ~-27 minecraft:deepslate_tiles
fill ~-59 ~37 ~-164 ~-58 ~37 ~-164 minecraft:deepslate_tiles
fill ~-59 ~37 ~-156 ~-58 ~37 ~-156 minecraft:deepslate_tiles
fill ~-59 ~37 ~-36 ~-58 ~37 ~-36 minecraft:deepslate_tiles
fill ~-59 ~37 ~-28 ~-58 ~37 ~-28 minecraft:deepslate_tiles
fill ~-59 ~38 ~-164 ~-59 ~39 ~-163 minecraft:deepslate_tiles
fill ~-59 ~38 ~-157 ~-58 ~38 ~-157 minecraft:deepslate_tiles
fill ~-59 ~38 ~-156 ~-59 ~38 ~-155 minecraft:deepslate_tiles
fill ~-59 ~38 ~-36 ~-59 ~39 ~-35 minecraft:deepslate_tiles
fill ~-59 ~38 ~-29 ~-58 ~38 ~-29 minecraft:deepslate_tiles
fill ~-59 ~38 ~-28 ~-59 ~38 ~-27 minecraft:deepslate_tiles
fill ~-59 ~39 ~-162 ~-58 ~39 ~-162 minecraft:deepslate_tiles
fill ~-59 ~39 ~-158 ~-58 ~39 ~-158 minecraft:deepslate_tiles
fill ~-59 ~39 ~-157 ~-59 ~39 ~-156 minecraft:deepslate_tiles
fill ~-59 ~39 ~-34 ~-58 ~39 ~-34 minecraft:deepslate_tiles
fill ~-59 ~39 ~-30 ~-58 ~39 ~-30 minecraft:deepslate_tiles
fill ~-59 ~39 ~-29 ~-59 ~39 ~-28 minecraft:deepslate_tiles
fill ~-59 ~40 ~-162 ~-59 ~40 ~-157 minecraft:deepslate_tiles
fill ~-59 ~40 ~-34 ~-59 ~40 ~-29 minecraft:deepslate_tiles
fill ~-59 ~41 ~-161 ~-59 ~41 ~-158 minecraft:deepslate_tiles
fill ~-59 ~41 ~-33 ~-59 ~41 ~-30 minecraft:deepslate_tiles
fill ~-58 ~27 ~-99 ~-58 ~27 ~-98 minecraft:deepslate_tiles
fill ~-58 ~27 ~-94 ~-58 ~27 ~-93 minecraft:deepslate_tiles
fill ~-58 ~31 ~-168 ~-57 ~31 ~-168 minecraft:deepslate_tiles
fill ~-58 ~31 ~-152 ~-58 ~31 ~-151 minecraft:deepslate_tiles
fill ~-58 ~31 ~-40 ~-58 ~32 ~-40 minecraft:deepslate_tiles
fill ~-58 ~31 ~-24 ~-57 ~31 ~-24 minecraft:deepslate_tiles
fill ~-58 ~32 ~-167 ~-57 ~32 ~-167 minecraft:deepslate_tiles
fill ~-58 ~32 ~-25 ~-57 ~32 ~-25 minecraft:deepslate_tiles
fill ~-58 ~34 ~-166 ~-57 ~34 ~-166 minecraft:deepslate_tiles
fill ~-58 ~34 ~-154 ~-57 ~34 ~-154 minecraft:deepslate_tiles
fill ~-58 ~34 ~-38 ~-57 ~34 ~-38 minecraft:deepslate_tiles
fill ~-58 ~34 ~-26 ~-57 ~34 ~-26 minecraft:deepslate_tiles
fill ~-58 ~35 ~-165 ~-57 ~35 ~-165 minecraft:deepslate_tiles
fill ~-58 ~35 ~-155 ~-57 ~35 ~-155 minecraft:deepslate_tiles
fill ~-58 ~35 ~-37 ~-57 ~35 ~-37 minecraft:deepslate_tiles
fill ~-58 ~35 ~-27 ~-57 ~35 ~-27 minecraft:deepslate_tiles
fill ~-58 ~36 ~-164 ~-57 ~36 ~-164 minecraft:deepslate_tiles
fill ~-58 ~36 ~-156 ~-57 ~36 ~-156 minecraft:deepslate_tiles
fill ~-58 ~36 ~-36 ~-57 ~36 ~-36 minecraft:deepslate_tiles
fill ~-58 ~36 ~-28 ~-57 ~36 ~-28 minecraft:deepslate_tiles
fill ~-58 ~37 ~-163 ~-57 ~37 ~-163 minecraft:deepslate_tiles
fill ~-58 ~37 ~-157 ~-57 ~37 ~-157 minecraft:deepslate_tiles
fill ~-58 ~37 ~-35 ~-57 ~37 ~-35 minecraft:deepslate_tiles
fill ~-58 ~37 ~-29 ~-57 ~37 ~-29 minecraft:deepslate_tiles
fill ~-58 ~38 ~-163 ~-58 ~38 ~-157 minecraft:deepslate_tiles
fill ~-58 ~38 ~-35 ~-58 ~38 ~-29 minecraft:deepslate_tiles
fill ~-58 ~39 ~-161 ~-58 ~39 ~-158 minecraft:deepslate_tiles
fill ~-58 ~39 ~-33 ~-58 ~39 ~-30 minecraft:deepslate_tiles
setblock ~-58 ~40 ~-160 minecraft:deepslate_tiles
setblock ~-58 ~40 ~-32 minecraft:deepslate_tiles
fill ~-57 ~31 ~-167 ~-56 ~31 ~-167 minecraft:deepslate_tiles
fill ~-57 ~31 ~-25 ~-56 ~31 ~-25 minecraft:deepslate_tiles
fill ~-57 ~32 ~-166 ~-56 ~32 ~-166 minecraft:deepslate_tiles
fill ~-57 ~32 ~-26 ~-56 ~32 ~-26 minecraft:deepslate_tiles
fill ~-57 ~33 ~-166 ~-57 ~34 ~-165 minecraft:deepslate_tiles
fill ~-57 ~33 ~-155 ~-56 ~33 ~-155 minecraft:deepslate_tiles
fill ~-57 ~33 ~-154 ~-57 ~34 ~-154 minecraft:deepslate_tiles
fill ~-57 ~33 ~-38 ~-57 ~34 ~-37 minecraft:deepslate_tiles
fill ~-57 ~33 ~-27 ~-56 ~33 ~-27 minecraft:deepslate_tiles
fill ~-57 ~33 ~-26 ~-57 ~34 ~-26 minecraft:deepslate_tiles
fill ~-57 ~34 ~-164 ~-56 ~34 ~-164 minecraft:deepslate_tiles
fill ~-57 ~34 ~-156 ~-56 ~34 ~-156 minecraft:deepslate_tiles
fill ~-57 ~34 ~-155 ~-57 ~34 ~-154 minecraft:deepslate_tiles
fill ~-57 ~34 ~-36 ~-56 ~34 ~-36 minecraft:deepslate_tiles
fill ~-57 ~34 ~-28 ~-56 ~34 ~-28 minecraft:deepslate_tiles
fill ~-57 ~34 ~-27 ~-57 ~34 ~-26 minecraft:deepslate_tiles
fill ~-57 ~35 ~-164 ~-57 ~36 ~-163 minecraft:deepslate_tiles
fill ~-57 ~35 ~-157 ~-56 ~35 ~-157 minecraft:deepslate_tiles
fill ~-57 ~35 ~-156 ~-57 ~35 ~-155 minecraft:deepslate_tiles
fill ~-57 ~35 ~-36 ~-57 ~36 ~-35 minecraft:deepslate_tiles
fill ~-57 ~35 ~-29 ~-56 ~35 ~-29 minecraft:deepslate_tiles
fill ~-57 ~35 ~-28 ~-57 ~35 ~-27 minecraft:deepslate_tiles
fill ~-57 ~36 ~-162 ~-57 ~36 ~-156 minecraft:deepslate_tiles
fill ~-57 ~36 ~-34 ~-57 ~36 ~-28 minecraft:deepslate_tiles
fill ~-57 ~37 ~-162 ~-57 ~37 ~-157 minecraft:deepslate_tiles
fill ~-57 ~37 ~-34 ~-57 ~37 ~-29 minecraft:deepslate_tiles
fill ~-57 ~38 ~-161 ~-57 ~38 ~-159 minecraft:deepslate_tiles
fill ~-57 ~38 ~-33 ~-57 ~38 ~-31 minecraft:deepslate_tiles
fill ~-56 ~31 ~-166 ~-55 ~31 ~-166 minecraft:deepslate_tiles
fill ~-56 ~31 ~-154 ~-55 ~31 ~-154 minecraft:deepslate_tiles
fill ~-56 ~31 ~-38 ~-54 ~31 ~-38 minecraft:deepslate_tiles
fill ~-56 ~31 ~-26 ~-55 ~31 ~-26 minecraft:deepslate_tiles
fill ~-56 ~32 ~-165 ~-55 ~32 ~-165 minecraft:deepslate_tiles
fill ~-56 ~32 ~-155 ~-55 ~32 ~-155 minecraft:deepslate_tiles
setblock ~-56 ~32 ~-154 minecraft:deepslate_tiles
fill ~-56 ~32 ~-38 ~-56 ~32 ~-37 minecraft:deepslate_tiles
fill ~-56 ~32 ~-27 ~-55 ~32 ~-27 minecraft:deepslate_tiles
fill ~-56 ~33 ~-165 ~-56 ~33 ~-164 minecraft:deepslate_tiles
fill ~-56 ~33 ~-156 ~-55 ~33 ~-156 minecraft:deepslate_tiles
fill ~-56 ~33 ~-37 ~-56 ~33 ~-36 minecraft:deepslate_tiles
fill ~-56 ~33 ~-28 ~-55 ~33 ~-28 minecraft:deepslate_tiles
fill ~-56 ~34 ~-163 ~-56 ~35 ~-161 minecraft:deepslate_tiles
fill ~-56 ~34 ~-159 ~-55 ~34 ~-158 minecraft:deepslate_tiles
fill ~-56 ~34 ~-157 ~-56 ~34 ~-156 minecraft:deepslate_tiles
fill ~-56 ~34 ~-35 ~-56 ~35 ~-33 minecraft:deepslate_tiles
fill ~-56 ~34 ~-31 ~-55 ~34 ~-30 minecraft:deepslate_tiles
fill ~-56 ~34 ~-29 ~-56 ~34 ~-28 minecraft:deepslate_tiles
fill ~-56 ~35 ~-160 ~-56 ~35 ~-157 minecraft:deepslate_tiles
fill ~-56 ~35 ~-32 ~-56 ~35 ~-29 minecraft:deepslate_tiles
fill ~-56 ~36 ~-161 ~-56 ~36 ~-159 minecraft:deepslate_tiles
fill ~-56 ~36 ~-33 ~-56 ~36 ~-31 minecraft:deepslate_tiles
fill ~-55 ~31 ~-165 ~-55 ~32 ~-164 minecraft:deepslate_tiles
fill ~-55 ~31 ~-155 ~-55 ~31 ~-154 minecraft:deepslate_tiles
fill ~-55 ~31 ~-37 ~-55 ~32 ~-36 minecraft:deepslate_tiles
fill ~-55 ~31 ~-28 ~-54 ~31 ~-28 minecraft:deepslate_tiles
fill ~-55 ~31 ~-27 ~-55 ~31 ~-26 minecraft:deepslate_tiles
fill ~-55 ~32 ~-163 ~-55 ~33 ~-162 minecraft:deepslate_tiles
fill ~-55 ~32 ~-158 ~-54 ~32 ~-158 minecraft:deepslate_tiles
fill ~-55 ~32 ~-157 ~-55 ~32 ~-155 minecraft:deepslate_tiles
fill ~-55 ~32 ~-35 ~-55 ~33 ~-34 minecraft:deepslate_tiles
fill ~-55 ~32 ~-30 ~-54 ~32 ~-30 minecraft:deepslate_tiles
fill ~-55 ~32 ~-29 ~-55 ~32 ~-27 minecraft:deepslate_tiles
fill ~-55 ~33 ~-164 ~-55 ~33 ~-156 minecraft:deepslate_tiles
fill ~-55 ~33 ~-36 ~-55 ~33 ~-28 minecraft:deepslate_tiles
fill ~-55 ~34 ~-162 ~-55 ~34 ~-158 minecraft:deepslate_tiles
fill ~-55 ~34 ~-34 ~-55 ~34 ~-30 minecraft:deepslate_tiles
fill ~-54 ~31 ~-164 ~-54 ~31 ~-156 minecraft:deepslate_tiles
fill ~-54 ~31 ~-36 ~-54 ~31 ~-28 minecraft:deepslate_tiles
fill ~-54 ~32 ~-162 ~-54 ~32 ~-158 minecraft:deepslate_tiles
fill ~-54 ~32 ~-34 ~-54 ~32 ~-30 minecraft:deepslate_tiles
fill ~-31 ~53 ~-149 ~-30 ~53 ~-149 minecraft:deepslate_tiles
fill ~-31 ~53 ~-148 ~-31 ~53 ~-143 minecraft:deepslate_tiles
fill ~-31 ~53 ~-105 ~-30 ~53 ~-105 minecraft:deepslate_tiles
fill ~-31 ~53 ~-104 ~-31 ~53 ~-99 minecraft:deepslate_tiles
fill ~-31 ~54 ~-148 ~-30 ~54 ~-147 minecraft:deepslate_tiles
fill ~-31 ~54 ~-146 ~-31 ~54 ~-144 minecraft:deepslate_tiles
fill ~-31 ~54 ~-104 ~-30 ~54 ~-103 minecraft:deepslate_tiles
fill ~-31 ~54 ~-102 ~-31 ~54 ~-100 minecraft:deepslate_tiles
fill ~-30 ~53 ~-150 ~-29 ~53 ~-150 minecraft:deepslate_tiles
fill ~-30 ~53 ~-143 ~-30 ~53 ~-142 minecraft:deepslate_tiles
fill ~-30 ~53 ~-106 ~-29 ~53 ~-106 minecraft:deepslate_tiles
fill ~-30 ~53 ~-99 ~-30 ~53 ~-98 minecraft:deepslate_tiles
fill ~-30 ~54 ~-149 ~-29 ~54 ~-149 minecraft:deepslate_tiles
fill ~-30 ~54 ~-145 ~-30 ~54 ~-143 minecraft:deepslate_tiles
fill ~-30 ~54 ~-105 ~-29 ~54 ~-105 minecraft:deepslate_tiles
fill ~-30 ~54 ~-101 ~-30 ~54 ~-99 minecraft:deepslate_tiles
fill ~-30 ~55 ~-148 ~-29 ~55 ~-148 minecraft:deepslate_tiles
fill ~-30 ~55 ~-147 ~-30 ~55 ~-144 minecraft:deepslate_tiles
fill ~-30 ~55 ~-104 ~-29 ~55 ~-104 minecraft:deepslate_tiles
fill ~-30 ~55 ~-103 ~-30 ~55 ~-100 minecraft:deepslate_tiles
fill ~-30 ~56 ~-147 ~-29 ~56 ~-147 minecraft:deepslate_tiles
fill ~-30 ~56 ~-146 ~-30 ~56 ~-145 minecraft:deepslate_tiles
fill ~-30 ~56 ~-103 ~-29 ~56 ~-103 minecraft:deepslate_tiles
fill ~-30 ~56 ~-102 ~-30 ~56 ~-101 minecraft:deepslate_tiles
fill ~-29 ~53 ~-151 ~-23 ~53 ~-151 minecraft:deepslate_tiles
fill ~-29 ~53 ~-142 ~-29 ~53 ~-141 minecraft:deepslate_tiles
fill ~-29 ~53 ~-107 ~-23 ~53 ~-107 minecraft:deepslate_tiles
fill ~-29 ~53 ~-98 ~-29 ~53 ~-97 minecraft:deepslate_tiles
fill ~-29 ~54 ~-150 ~-27 ~54 ~-150 minecraft:deepslate_tiles
fill ~-29 ~54 ~-143 ~-29 ~54 ~-142 minecraft:deepslate_tiles
fill ~-29 ~54 ~-106 ~-27 ~54 ~-106 minecraft:deepslate_tiles
fill ~-29 ~54 ~-99 ~-29 ~54 ~-98 minecraft:deepslate_tiles
fill ~-29 ~55 ~-149 ~-28 ~56 ~-149 minecraft:deepslate_tiles
fill ~-29 ~55 ~-144 ~-29 ~56 ~-143 minecraft:deepslate_tiles
fill ~-29 ~55 ~-105 ~-28 ~56 ~-105 minecraft:deepslate_tiles
fill ~-29 ~55 ~-100 ~-29 ~56 ~-99 minecraft:deepslate_tiles
fill ~-29 ~56 ~-148 ~-29 ~57 ~-147 minecraft:deepslate_tiles
fill ~-29 ~56 ~-145 ~-29 ~56 ~-143 minecraft:deepslate_tiles
fill ~-29 ~56 ~-104 ~-29 ~57 ~-103 minecraft:deepslate_tiles
fill ~-29 ~56 ~-101 ~-29 ~56 ~-99 minecraft:deepslate_tiles
fill ~-29 ~57 ~-146 ~-29 ~57 ~-144 minecraft:deepslate_tiles
fill ~-29 ~57 ~-101 ~-29 ~57 ~-100 minecraft:deepslate_tiles
fill ~-29 ~58 ~-147 ~-28 ~58 ~-145 minecraft:deepslate_tiles
fill ~-29 ~58 ~-103 ~-28 ~58 ~-101 minecraft:deepslate_tiles
fill ~-28 ~53 ~-141 ~-23 ~53 ~-141 minecraft:deepslate_tiles
fill ~-28 ~53 ~-97 ~-23 ~53 ~-97 minecraft:deepslate_tiles
fill ~-28 ~54 ~-151 ~-24 ~54 ~-151 minecraft:deepslate_tiles
fill ~-28 ~54 ~-142 ~-27 ~54 ~-141 minecraft:deepslate_tiles
fill ~-28 ~54 ~-107 ~-24 ~54 ~-107 minecraft:deepslate_tiles
fill ~-28 ~54 ~-98 ~-27 ~54 ~-97 minecraft:deepslate_tiles
fill ~-28 ~55 ~-150 ~-24 ~55 ~-150 minecraft:deepslate_tiles
fill ~-28 ~55 ~-143 ~-28 ~55 ~-142 minecraft:deepslate_tiles
fill ~-28 ~55 ~-106 ~-24 ~55 ~-106 minecraft:deepslate_tiles
fill ~-28 ~55 ~-99 ~-28 ~55 ~-98 minecraft:deepslate_tiles
fill ~-28 ~56 ~-143 ~-27 ~57 ~-143 minecraft:deepslate_tiles
fill ~-28 ~56 ~-99 ~-27 ~57 ~-99 minecraft:deepslate_tiles
fill ~-28 ~57 ~-149 ~-24 ~57 ~-149 minecraft:deepslate_tiles
fill ~-28 ~57 ~-148 ~-28 ~58 ~-148 minecraft:deepslate_tiles
fill ~-28 ~57 ~-144 ~-28 ~57 ~-143 minecraft:deepslate_tiles
fill ~-28 ~57 ~-105 ~-24 ~57 ~-105 minecraft:deepslate_tiles
fill ~-28 ~57 ~-104 ~-28 ~58 ~-104 minecraft:deepslate_tiles
fill ~-28 ~57 ~-100 ~-28 ~57 ~-99 minecraft:deepslate_tiles
fill ~-28 ~58 ~-144 ~-24 ~58 ~-144 minecraft:deepslate_tiles
fill ~-28 ~58 ~-100 ~-24 ~58 ~-100 minecraft:deepslate_tiles
fill ~-28 ~59 ~-147 ~-27 ~59 ~-147 minecraft:deepslate_tiles
fill ~-28 ~59 ~-146 ~-28 ~59 ~-145 minecraft:deepslate_tiles
fill ~-28 ~59 ~-103 ~-27 ~59 ~-103 minecraft:deepslate_tiles
fill ~-28 ~59 ~-102 ~-28 ~59 ~-101 minecraft:deepslate_tiles
fill ~-28 ~60 ~-146 ~-27 ~60 ~-146 minecraft:deepslate_tiles
fill ~-28 ~60 ~-102 ~-27 ~60 ~-102 minecraft:deepslate_tiles
fill ~-27 ~55 ~-142 ~-24 ~55 ~-142 minecraft:deepslate_tiles
fill ~-27 ~55 ~-98 ~-24 ~55 ~-98 minecraft:deepslate_tiles
fill ~-27 ~56 ~-150 ~-25 ~56 ~-150 minecraft:deepslate_tiles
fill ~-27 ~56 ~-149 ~-27 ~58 ~-149 minecraft:deepslate_tiles
fill ~-27 ~56 ~-142 ~-25 ~56 ~-142 minecraft:deepslate_tiles
fill ~-27 ~56 ~-106 ~-25 ~56 ~-106 minecraft:deepslate_tiles
fill ~-27 ~56 ~-105 ~-27 ~58 ~-105 minecraft:deepslate_tiles
fill ~-27 ~56 ~-98 ~-25 ~56 ~-98 minecraft:deepslate_tiles
fill ~-27 ~58 ~-148 ~-24 ~58 ~-148 minecraft:deepslate_tiles
fill ~-27 ~58 ~-143 ~-25 ~58 ~-143 minecraft:deepslate_tiles
fill ~-27 ~58 ~-104 ~-24 ~58 ~-104 minecraft:deepslate_tiles
fill ~-27 ~58 ~-99 ~-25 ~58 ~-99 minecraft:deepslate_tiles
fill ~-27 ~59 ~-148 ~-25 ~59 ~-148 minecraft:deepslate_tiles
fill ~-27 ~59 ~-145 ~-27 ~59 ~-144 minecraft:deepslate_tiles
fill ~-27 ~59 ~-104 ~-25 ~59 ~-104 minecraft:deepslate_tiles
fill ~-27 ~59 ~-101 ~-27 ~59 ~-100 minecraft:deepslate_tiles
fill ~-27 ~60 ~-147 ~-25 ~61 ~-147 minecraft:deepslate_tiles
fill ~-27 ~60 ~-145 ~-25 ~61 ~-145 minecraft:deepslate_tiles
fill ~-27 ~60 ~-103 ~-25 ~61 ~-103 minecraft:deepslate_tiles
fill ~-27 ~60 ~-101 ~-25 ~61 ~-101 minecraft:deepslate_tiles
fill ~-27 ~61 ~-146 ~-25 ~61 ~-145 minecraft:deepslate_tiles
fill ~-27 ~61 ~-102 ~-25 ~61 ~-101 minecraft:deepslate_tiles
