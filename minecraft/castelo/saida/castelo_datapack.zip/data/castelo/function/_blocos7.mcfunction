setblock ~-21 ~-1 ~-122 minecraft:polished_diorite
setblock ~-21 ~-1 ~-120 minecraft:polished_diorite
setblock ~-21 ~-1 ~-118 minecraft:polished_diorite
setblock ~-21 ~-1 ~-116 minecraft:polished_diorite
fill ~-21 ~-1 ~-114 ~-21 ~ ~-114 minecraft:polished_diorite
setblock ~-21 ~-1 ~-112 minecraft:polished_diorite
setblock ~-21 ~-1 ~-110 minecraft:polished_diorite
setblock ~-21 ~-1 ~-108 minecraft:polished_diorite
setblock ~-21 ~-1 ~-106 minecraft:polished_diorite
setblock ~-21 ~-1 ~-104 minecraft:polished_diorite
setblock ~-20 ~-1 ~-143 minecraft:polished_diorite
setblock ~-20 ~-1 ~-137 minecraft:polished_diorite
setblock ~-20 ~-1 ~-135 minecraft:polished_diorite
setblock ~-20 ~-1 ~-133 minecraft:polished_diorite
setblock ~-20 ~-1 ~-131 minecraft:polished_diorite
setblock ~-20 ~-1 ~-129 minecraft:polished_diorite
setblock ~-20 ~-1 ~-127 minecraft:polished_diorite
setblock ~-20 ~-1 ~-125 minecraft:polished_diorite
setblock ~-20 ~-1 ~-123 minecraft:polished_diorite
setblock ~-20 ~-1 ~-121 minecraft:polished_diorite
setblock ~-20 ~-1 ~-119 minecraft:polished_diorite
setblock ~-20 ~-1 ~-117 minecraft:polished_diorite
fill ~-20 ~-1 ~-115 ~-20 ~ ~-115 minecraft:polished_diorite
fill ~-20 ~-1 ~-113 ~-20 ~ ~-113 minecraft:polished_diorite
setblock ~-20 ~-1 ~-111 minecraft:polished_diorite
setblock ~-20 ~-1 ~-109 minecraft:polished_diorite
setblock ~-20 ~-1 ~-107 minecraft:polished_diorite
setblock ~-20 ~-1 ~-105 minecraft:polished_diorite
fill ~-19 ~-1 ~-144 ~-19 ~ ~-144 minecraft:polished_diorite
setblock ~-19 ~-1 ~-142 minecraft:polished_diorite
setblock ~-19 ~-1 ~-138 minecraft:polished_diorite
setblock ~-19 ~-1 ~-136 minecraft:polished_diorite
setblock ~-19 ~-1 ~-134 minecraft:polished_diorite
setblock ~-19 ~-1 ~-132 minecraft:polished_diorite
setblock ~-19 ~-1 ~-130 minecraft:polished_diorite
setblock ~-19 ~-1 ~-128 minecraft:polished_diorite
setblock ~-19 ~-1 ~-126 minecraft:polished_diorite
setblock ~-19 ~-1 ~-124 minecraft:polished_diorite
setblock ~-19 ~-1 ~-122 minecraft:polished_diorite
setblock ~-19 ~-1 ~-120 minecraft:polished_diorite
setblock ~-19 ~-1 ~-118 minecraft:polished_diorite
setblock ~-19 ~-1 ~-116 minecraft:polished_diorite
fill ~-19 ~-1 ~-114 ~-19 ~1 ~-114 minecraft:polished_diorite
setblock ~-19 ~-1 ~-112 minecraft:polished_diorite
setblock ~-19 ~-1 ~-110 minecraft:polished_diorite
setblock ~-19 ~-1 ~-108 minecraft:polished_diorite
setblock ~-19 ~-1 ~-106 minecraft:polished_diorite
setblock ~-19 ~-1 ~-104 minecraft:polished_diorite
setblock ~-18 ~-1 ~-143 minecraft:polished_diorite
setblock ~-18 ~-1 ~-141 minecraft:polished_diorite
setblock ~-18 ~-1 ~-139 minecraft:polished_diorite
setblock ~-18 ~-1 ~-137 minecraft:polished_diorite
setblock ~-18 ~-1 ~-135 minecraft:polished_diorite
setblock ~-18 ~-1 ~-133 minecraft:polished_diorite
setblock ~-18 ~-1 ~-131 minecraft:polished_diorite
setblock ~-18 ~-1 ~-129 minecraft:polished_diorite
setblock ~-18 ~-1 ~-127 minecraft:polished_diorite
setblock ~-18 ~-1 ~-125 minecraft:polished_diorite
setblock ~-18 ~-1 ~-123 minecraft:polished_diorite
setblock ~-18 ~-1 ~-121 minecraft:polished_diorite
setblock ~-18 ~-1 ~-119 minecraft:polished_diorite
setblock ~-18 ~-1 ~-117 minecraft:polished_diorite
fill ~-18 ~-1 ~-115 ~-18 ~ ~-115 minecraft:polished_diorite
fill ~-18 ~-1 ~-113 ~-18 ~ ~-113 minecraft:polished_diorite
setblock ~-18 ~-1 ~-111 minecraft:polished_diorite
setblock ~-18 ~-1 ~-109 minecraft:polished_diorite
setblock ~-18 ~-1 ~-107 minecraft:polished_diorite
setblock ~-18 ~-1 ~-105 minecraft:polished_diorite
fill ~-17 ~-1 ~-144 ~-17 ~ ~-144 minecraft:polished_diorite
setblock ~-17 ~-1 ~-142 minecraft:polished_diorite
setblock ~-17 ~-1 ~-138 minecraft:polished_diorite
setblock ~-17 ~-1 ~-136 minecraft:polished_diorite
setblock ~-17 ~-1 ~-134 minecraft:polished_diorite
setblock ~-17 ~-1 ~-132 minecraft:polished_diorite
setblock ~-17 ~-1 ~-130 minecraft:polished_diorite
setblock ~-17 ~-1 ~-128 minecraft:polished_diorite
setblock ~-17 ~-1 ~-126 minecraft:polished_diorite
setblock ~-17 ~-1 ~-124 minecraft:polished_diorite
setblock ~-17 ~-1 ~-122 minecraft:polished_diorite
setblock ~-17 ~-1 ~-120 minecraft:polished_diorite
setblock ~-17 ~-1 ~-118 minecraft:polished_diorite
setblock ~-17 ~-1 ~-116 minecraft:polished_diorite
fill ~-17 ~-1 ~-114 ~-17 ~ ~-114 minecraft:polished_diorite
setblock ~-17 ~-1 ~-112 minecraft:polished_diorite
setblock ~-17 ~-1 ~-110 minecraft:polished_diorite
setblock ~-17 ~-1 ~-108 minecraft:polished_diorite
setblock ~-17 ~-1 ~-106 minecraft:polished_diorite
setblock ~-17 ~-1 ~-104 minecraft:polished_diorite
setblock ~-16 ~-1 ~-143 minecraft:polished_diorite
setblock ~-16 ~-1 ~-137 minecraft:polished_diorite
setblock ~-16 ~-1 ~-135 minecraft:polished_diorite
setblock ~-16 ~-1 ~-133 minecraft:polished_diorite
setblock ~-16 ~-1 ~-131 minecraft:polished_diorite
setblock ~-16 ~-1 ~-129 minecraft:polished_diorite
setblock ~-16 ~-1 ~-127 minecraft:polished_diorite
setblock ~-16 ~-1 ~-125 minecraft:polished_diorite
setblock ~-16 ~-1 ~-123 minecraft:polished_diorite
setblock ~-16 ~-1 ~-121 minecraft:polished_diorite
setblock ~-16 ~-1 ~-119 minecraft:polished_diorite
setblock ~-16 ~-1 ~-117 minecraft:polished_diorite
fill ~-16 ~-1 ~-115 ~-16 ~ ~-115 minecraft:polished_diorite
fill ~-16 ~-1 ~-113 ~-16 ~ ~-113 minecraft:polished_diorite
setblock ~-16 ~-1 ~-111 minecraft:polished_diorite
setblock ~-16 ~-1 ~-109 minecraft:polished_diorite
setblock ~-16 ~-1 ~-107 minecraft:polished_diorite
setblock ~-16 ~-1 ~-105 minecraft:polished_diorite
fill ~-15 ~-1 ~-144 ~-15 ~ ~-144 minecraft:polished_diorite
setblock ~-15 ~-1 ~-142 minecraft:polished_diorite
setblock ~-15 ~-1 ~-138 minecraft:polished_diorite
setblock ~-15 ~-1 ~-136 minecraft:polished_diorite
setblock ~-15 ~-1 ~-134 minecraft:polished_diorite
setblock ~-15 ~-1 ~-132 minecraft:polished_diorite
setblock ~-15 ~-1 ~-130 minecraft:polished_diorite
setblock ~-15 ~-1 ~-128 minecraft:polished_diorite
setblock ~-15 ~-1 ~-126 minecraft:polished_diorite
setblock ~-15 ~-1 ~-124 minecraft:polished_diorite
setblock ~-15 ~-1 ~-122 minecraft:polished_diorite
setblock ~-15 ~-1 ~-120 minecraft:polished_diorite
setblock ~-15 ~-1 ~-118 minecraft:polished_diorite
setblock ~-15 ~-1 ~-116 minecraft:polished_diorite
fill ~-15 ~-1 ~-114 ~-15 ~ ~-114 minecraft:polished_diorite
setblock ~-15 ~-1 ~-112 minecraft:polished_diorite
setblock ~-15 ~-1 ~-110 minecraft:polished_diorite
setblock ~-15 ~-1 ~-108 minecraft:polished_diorite
setblock ~-15 ~-1 ~-106 minecraft:polished_diorite
setblock ~-15 ~-1 ~-104 minecraft:polished_diorite
setblock ~-14 ~-1 ~-143 minecraft:polished_diorite
setblock ~-14 ~-1 ~-141 minecraft:polished_diorite
setblock ~-14 ~-1 ~-139 minecraft:polished_diorite
setblock ~-14 ~-1 ~-137 minecraft:polished_diorite
setblock ~-14 ~-1 ~-135 minecraft:polished_diorite
setblock ~-14 ~-1 ~-133 minecraft:polished_diorite
setblock ~-14 ~-1 ~-131 minecraft:polished_diorite
setblock ~-14 ~-1 ~-129 minecraft:polished_diorite
setblock ~-14 ~-1 ~-127 minecraft:polished_diorite
setblock ~-14 ~-1 ~-125 minecraft:polished_diorite
setblock ~-14 ~-1 ~-123 minecraft:polished_diorite
setblock ~-14 ~-1 ~-121 minecraft:polished_diorite
setblock ~-14 ~-1 ~-119 minecraft:polished_diorite
setblock ~-14 ~-1 ~-117 minecraft:polished_diorite
fill ~-14 ~-1 ~-115 ~-14 ~ ~-115 minecraft:polished_diorite
fill ~-14 ~-1 ~-113 ~-14 ~ ~-113 minecraft:polished_diorite
setblock ~-14 ~-1 ~-111 minecraft:polished_diorite
setblock ~-14 ~-1 ~-109 minecraft:polished_diorite
setblock ~-14 ~-1 ~-107 minecraft:polished_diorite
setblock ~-14 ~-1 ~-105 minecraft:polished_diorite
fill ~-13 ~-1 ~-144 ~-13 ~ ~-144 minecraft:polished_diorite
setblock ~-13 ~-1 ~-142 minecraft:polished_diorite
setblock ~-13 ~-1 ~-140 minecraft:polished_diorite
setblock ~-13 ~-1 ~-138 minecraft:polished_diorite
setblock ~-13 ~-1 ~-136 minecraft:polished_diorite
setblock ~-13 ~-1 ~-134 minecraft:polished_diorite
setblock ~-13 ~-1 ~-132 minecraft:polished_diorite
setblock ~-13 ~-1 ~-130 minecraft:polished_diorite
setblock ~-13 ~-1 ~-128 minecraft:polished_diorite
setblock ~-13 ~-1 ~-126 minecraft:polished_diorite
setblock ~-13 ~-1 ~-124 minecraft:polished_diorite
setblock ~-13 ~-1 ~-122 minecraft:polished_diorite
setblock ~-13 ~-1 ~-120 minecraft:polished_diorite
setblock ~-13 ~-1 ~-118 minecraft:polished_diorite
setblock ~-13 ~-1 ~-116 minecraft:polished_diorite
setblock ~-13 ~-1 ~-114 minecraft:polished_diorite
setblock ~-13 ~-1 ~-112 minecraft:polished_diorite
setblock ~-13 ~-1 ~-110 minecraft:polished_diorite
setblock ~-13 ~-1 ~-108 minecraft:polished_diorite
setblock ~-13 ~-1 ~-106 minecraft:polished_diorite
setblock ~-13 ~-1 ~-104 minecraft:polished_diorite
setblock ~-12 ~-1 ~-143 minecraft:polished_diorite
setblock ~-12 ~-1 ~-141 minecraft:polished_diorite
setblock ~-12 ~-1 ~-139 minecraft:polished_diorite
setblock ~-12 ~-1 ~-137 minecraft:polished_diorite
setblock ~-12 ~-1 ~-135 minecraft:polished_diorite
setblock ~-12 ~-1 ~-133 minecraft:polished_diorite
setblock ~-12 ~-1 ~-131 minecraft:polished_diorite
setblock ~-12 ~-1 ~-129 minecraft:polished_diorite
setblock ~-12 ~-1 ~-127 minecraft:polished_diorite
setblock ~-12 ~-1 ~-125 minecraft:polished_diorite
setblock ~-12 ~-1 ~-123 minecraft:polished_diorite
setblock ~-12 ~-1 ~-121 minecraft:polished_diorite
setblock ~-12 ~-1 ~-119 minecraft:polished_diorite
setblock ~-12 ~-1 ~-117 minecraft:polished_diorite
setblock ~-12 ~-1 ~-115 minecraft:polished_diorite
setblock ~-12 ~-1 ~-113 minecraft:polished_diorite
setblock ~-12 ~-1 ~-111 minecraft:polished_diorite
setblock ~-12 ~-1 ~-109 minecraft:polished_diorite
setblock ~-12 ~-1 ~-107 minecraft:polished_diorite
setblock ~-12 ~-1 ~-105 minecraft:polished_diorite
setblock ~-11 ~-1 ~-144 minecraft:polished_diorite
setblock ~-11 ~-1 ~-142 minecraft:polished_diorite
setblock ~-11 ~-1 ~-140 minecraft:polished_diorite
setblock ~-11 ~-1 ~-138 minecraft:polished_diorite
setblock ~-11 ~-1 ~-136 minecraft:polished_diorite
setblock ~-11 ~-1 ~-134 minecraft:polished_diorite
setblock ~-11 ~-1 ~-132 minecraft:polished_diorite
setblock ~-11 ~-1 ~-130 minecraft:polished_diorite
setblock ~-11 ~-1 ~-128 minecraft:polished_diorite
setblock ~-11 ~-1 ~-126 minecraft:polished_diorite
setblock ~-11 ~-1 ~-124 minecraft:polished_diorite
setblock ~-11 ~-1 ~-122 minecraft:polished_diorite
setblock ~-11 ~-1 ~-120 minecraft:polished_diorite
setblock ~-11 ~-1 ~-118 minecraft:polished_diorite
setblock ~-11 ~-1 ~-116 minecraft:polished_diorite
setblock ~-11 ~-1 ~-114 minecraft:polished_diorite
setblock ~-11 ~-1 ~-112 minecraft:polished_diorite
setblock ~-11 ~-1 ~-110 minecraft:polished_diorite
setblock ~-11 ~-1 ~-108 minecraft:polished_diorite
setblock ~-11 ~-1 ~-106 minecraft:polished_diorite
setblock ~-11 ~-1 ~-104 minecraft:polished_diorite
setblock ~-10 ~-1 ~-143 minecraft:polished_diorite
setblock ~-10 ~-1 ~-141 minecraft:polished_diorite
setblock ~-10 ~-1 ~-139 minecraft:polished_diorite
setblock ~-10 ~-1 ~-137 minecraft:polished_diorite
setblock ~-10 ~-1 ~-135 minecraft:polished_diorite
setblock ~-10 ~-1 ~-133 minecraft:polished_diorite
setblock ~-10 ~-1 ~-131 minecraft:polished_diorite
setblock ~-10 ~-1 ~-129 minecraft:polished_diorite
setblock ~-10 ~-1 ~-127 minecraft:polished_diorite
setblock ~-10 ~-1 ~-125 minecraft:polished_diorite
setblock ~-10 ~-1 ~-123 minecraft:polished_diorite
setblock ~-10 ~-1 ~-121 minecraft:polished_diorite
setblock ~-10 ~-1 ~-119 minecraft:polished_diorite
setblock ~-10 ~-1 ~-117 minecraft:polished_diorite
setblock ~-10 ~-1 ~-115 minecraft:polished_diorite
setblock ~-10 ~-1 ~-113 minecraft:polished_diorite
setblock ~-10 ~-1 ~-111 minecraft:polished_diorite
setblock ~-10 ~-1 ~-109 minecraft:polished_diorite
setblock ~-10 ~-1 ~-107 minecraft:polished_diorite
setblock ~-10 ~-1 ~-105 minecraft:polished_diorite
setblock ~-9 ~-1 ~-144 minecraft:polished_diorite
setblock ~-9 ~-1 ~-142 minecraft:polished_diorite
setblock ~-9 ~-1 ~-140 minecraft:polished_diorite
setblock ~-9 ~-1 ~-138 minecraft:polished_diorite
fill ~-9 ~-1 ~-136 ~-9 ~ ~-136 minecraft:polished_diorite
fill ~-9 ~-1 ~-134 ~-9 ~ ~-134 minecraft:polished_diorite
fill ~-9 ~-1 ~-132 ~-9 ~ ~-132 minecraft:polished_diorite
fill ~-9 ~-1 ~-130 ~-9 ~ ~-130 minecraft:polished_diorite
fill ~-9 ~-1 ~-128 ~-9 ~ ~-128 minecraft:polished_diorite
fill ~-9 ~-1 ~-126 ~-9 ~ ~-126 minecraft:polished_diorite
fill ~-9 ~-1 ~-124 ~-9 ~ ~-124 minecraft:polished_diorite
fill ~-9 ~-1 ~-122 ~-9 ~ ~-122 minecraft:polished_diorite
fill ~-9 ~-1 ~-120 ~-9 ~ ~-120 minecraft:polished_diorite
fill ~-9 ~-1 ~-118 ~-9 ~ ~-118 minecraft:polished_diorite
fill ~-9 ~-1 ~-116 ~-9 ~ ~-116 minecraft:polished_diorite
fill ~-9 ~-1 ~-114 ~-9 ~ ~-114 minecraft:polished_diorite
fill ~-9 ~-1 ~-112 ~-9 ~ ~-112 minecraft:polished_diorite
fill ~-9 ~-1 ~-110 ~-9 ~ ~-110 minecraft:polished_diorite
fill ~-9 ~-1 ~-108 ~-9 ~ ~-108 minecraft:polished_diorite
setblock ~-9 ~-1 ~-106 minecraft:polished_diorite
setblock ~-9 ~-1 ~-104 minecraft:polished_diorite
setblock ~-8 ~-1 ~-143 minecraft:polished_diorite
setblock ~-8 ~-1 ~-141 minecraft:polished_diorite
setblock ~-8 ~-1 ~-139 minecraft:polished_diorite
setblock ~-8 ~-1 ~-137 minecraft:polished_diorite
setblock ~-8 ~-1 ~-135 minecraft:polished_diorite
setblock ~-8 ~-1 ~-133 minecraft:polished_diorite
setblock ~-8 ~-1 ~-131 minecraft:polished_diorite
setblock ~-8 ~-1 ~-129 minecraft:polished_diorite
setblock ~-8 ~-1 ~-127 minecraft:polished_diorite
setblock ~-8 ~-1 ~-125 minecraft:polished_diorite
setblock ~-8 ~-1 ~-123 minecraft:polished_diorite
setblock ~-8 ~-1 ~-121 minecraft:polished_diorite
setblock ~-8 ~-1 ~-119 minecraft:polished_diorite
setblock ~-8 ~-1 ~-117 minecraft:polished_diorite
setblock ~-8 ~-1 ~-115 minecraft:polished_diorite
setblock ~-8 ~-1 ~-113 minecraft:polished_diorite
setblock ~-8 ~-1 ~-111 minecraft:polished_diorite
setblock ~-8 ~-1 ~-109 minecraft:polished_diorite
setblock ~-8 ~-1 ~-107 minecraft:polished_diorite
setblock ~-8 ~-1 ~-105 minecraft:polished_diorite
setblock ~-7 ~-1 ~-144 minecraft:polished_diorite
setblock ~-7 ~-1 ~-142 minecraft:polished_diorite
setblock ~-7 ~-1 ~-140 minecraft:polished_diorite
setblock ~-7 ~-1 ~-138 minecraft:polished_diorite
setblock ~-7 ~-1 ~-136 minecraft:polished_diorite
setblock ~-7 ~-1 ~-134 minecraft:polished_diorite
setblock ~-7 ~-1 ~-132 minecraft:polished_diorite
setblock ~-7 ~-1 ~-130 minecraft:polished_diorite
setblock ~-7 ~-1 ~-128 minecraft:polished_diorite
setblock ~-7 ~-1 ~-126 minecraft:polished_diorite
setblock ~-7 ~-1 ~-124 minecraft:polished_diorite
setblock ~-7 ~-1 ~-122 minecraft:polished_diorite
setblock ~-7 ~-1 ~-120 minecraft:polished_diorite
setblock ~-7 ~-1 ~-118 minecraft:polished_diorite
setblock ~-7 ~-1 ~-116 minecraft:polished_diorite
setblock ~-7 ~-1 ~-114 minecraft:polished_diorite
setblock ~-7 ~-1 ~-112 minecraft:polished_diorite
setblock ~-7 ~-1 ~-110 minecraft:polished_diorite
setblock ~-7 ~-1 ~-108 minecraft:polished_diorite
setblock ~-7 ~-1 ~-106 minecraft:polished_diorite
setblock ~-7 ~-1 ~-104 minecraft:polished_diorite
setblock ~-6 ~-1 ~-143 minecraft:polished_diorite
setblock ~-6 ~-1 ~-141 minecraft:polished_diorite
setblock ~-6 ~-1 ~-139 minecraft:polished_diorite
setblock ~-6 ~-1 ~-137 minecraft:polished_diorite
setblock ~-6 ~-1 ~-135 minecraft:polished_diorite
setblock ~-6 ~-1 ~-133 minecraft:polished_diorite
setblock ~-6 ~-1 ~-131 minecraft:polished_diorite
setblock ~-6 ~-1 ~-129 minecraft:polished_diorite
setblock ~-6 ~-1 ~-127 minecraft:polished_diorite
setblock ~-6 ~-1 ~-125 minecraft:polished_diorite
setblock ~-6 ~-1 ~-123 minecraft:polished_diorite
setblock ~-6 ~-1 ~-121 minecraft:polished_diorite
setblock ~-6 ~-1 ~-119 minecraft:polished_diorite
setblock ~-6 ~-1 ~-117 minecraft:polished_diorite
setblock ~-6 ~-1 ~-115 minecraft:polished_diorite
setblock ~-6 ~-1 ~-113 minecraft:polished_diorite
setblock ~-6 ~-1 ~-111 minecraft:polished_diorite
setblock ~-6 ~-1 ~-109 minecraft:polished_diorite
setblock ~-6 ~-1 ~-107 minecraft:polished_diorite
setblock ~-6 ~-1 ~-105 minecraft:polished_diorite
setblock ~-5 ~-1 ~-144 minecraft:polished_diorite
setblock ~-5 ~-1 ~-142 minecraft:polished_diorite
setblock ~-5 ~-1 ~-140 minecraft:polished_diorite
setblock ~-5 ~-1 ~-138 minecraft:polished_diorite
setblock ~-5 ~-1 ~-136 minecraft:polished_diorite
setblock ~-5 ~-1 ~-134 minecraft:polished_diorite
setblock ~-5 ~-1 ~-132 minecraft:polished_diorite
setblock ~-5 ~-1 ~-130 minecraft:polished_diorite
setblock ~-5 ~-1 ~-128 minecraft:polished_diorite
setblock ~-5 ~-1 ~-126 minecraft:polished_diorite
setblock ~-5 ~-1 ~-124 minecraft:polished_diorite
setblock ~-5 ~-1 ~-122 minecraft:polished_diorite
setblock ~-5 ~-1 ~-120 minecraft:polished_diorite
setblock ~-5 ~-1 ~-118 minecraft:polished_diorite
setblock ~-5 ~-1 ~-116 minecraft:polished_diorite
setblock ~-5 ~-1 ~-114 minecraft:polished_diorite
setblock ~-5 ~-1 ~-112 minecraft:polished_diorite
setblock ~-5 ~-1 ~-110 minecraft:polished_diorite
setblock ~-5 ~-1 ~-108 minecraft:polished_diorite
setblock ~-5 ~-1 ~-106 minecraft:polished_diorite
setblock ~-5 ~-1 ~-104 minecraft:polished_diorite
setblock ~-4 ~-1 ~-143 minecraft:polished_diorite
setblock ~-4 ~-1 ~-141 minecraft:polished_diorite
fill ~-4 ~-1 ~-139 ~-4 ~ ~-139 minecraft:polished_diorite
setblock ~-4 ~-1 ~-137 minecraft:polished_diorite
setblock ~-4 ~-1 ~-135 minecraft:polished_diorite
setblock ~-4 ~-1 ~-133 minecraft:polished_diorite
setblock ~-4 ~-1 ~-131 minecraft:polished_diorite
setblock ~-4 ~-1 ~-129 minecraft:polished_diorite
setblock ~-4 ~-1 ~-127 minecraft:polished_diorite
setblock ~-4 ~-1 ~-125 minecraft:polished_diorite
setblock ~-4 ~-1 ~-123 minecraft:polished_diorite
setblock ~-4 ~-1 ~-121 minecraft:polished_diorite
setblock ~-4 ~-1 ~-119 minecraft:polished_diorite
setblock ~-4 ~-1 ~-117 minecraft:polished_diorite
setblock ~-4 ~-1 ~-115 minecraft:polished_diorite
setblock ~-4 ~-1 ~-113 minecraft:polished_diorite
setblock ~-4 ~-1 ~-111 minecraft:polished_diorite
setblock ~-4 ~-1 ~-109 minecraft:polished_diorite
setblock ~-4 ~-1 ~-107 minecraft:polished_diorite
setblock ~-4 ~-1 ~-105 minecraft:polished_diorite
setblock ~-3 ~-1 ~-144 minecraft:polished_diorite
setblock ~-3 ~-1 ~-142 minecraft:polished_diorite
setblock ~-3 ~-1 ~-140 minecraft:polished_diorite
setblock ~-3 ~-1 ~-138 minecraft:polished_diorite
setblock ~-3 ~-1 ~-136 minecraft:polished_diorite
setblock ~-3 ~-1 ~-134 minecraft:polished_diorite
setblock ~-3 ~-1 ~-132 minecraft:polished_diorite
setblock ~-3 ~-1 ~-130 minecraft:polished_diorite
setblock ~-3 ~-1 ~-128 minecraft:polished_diorite
setblock ~-3 ~-1 ~-126 minecraft:polished_diorite
setblock ~-3 ~-1 ~-124 minecraft:polished_diorite
setblock ~-3 ~-1 ~-122 minecraft:polished_diorite
setblock ~-3 ~-1 ~-120 minecraft:polished_diorite
setblock ~-3 ~-1 ~-118 minecraft:polished_diorite
setblock ~-3 ~-1 ~-116 minecraft:polished_diorite
setblock ~-3 ~-1 ~-114 minecraft:polished_diorite
setblock ~-3 ~-1 ~-112 minecraft:polished_diorite
setblock ~-3 ~-1 ~-110 minecraft:polished_diorite
setblock ~-3 ~-1 ~-108 minecraft:polished_diorite
setblock ~-3 ~-1 ~-106 minecraft:polished_diorite
setblock ~-3 ~-1 ~-104 minecraft:polished_diorite
fill ~-10 ~33 ~-144 ~10 ~33 ~-104 minecraft:white_concrete
fill ~-10 ~33 ~-142 ~-9 ~33 ~-141 minecraft:black_concrete
fill ~-10 ~33 ~-138 ~-9 ~33 ~-137 minecraft:black_concrete
fill ~-10 ~33 ~-134 ~-9 ~33 ~-133 minecraft:black_concrete
fill ~-10 ~33 ~-130 ~-9 ~33 ~-129 minecraft:black_concrete
fill ~-10 ~33 ~-126 ~-9 ~33 ~-125 minecraft:black_concrete
fill ~-10 ~33 ~-122 ~-9 ~33 ~-121 minecraft:black_concrete
fill ~-10 ~33 ~-118 ~-9 ~33 ~-117 minecraft:black_concrete
fill ~-10 ~33 ~-114 ~-9 ~33 ~-113 minecraft:black_concrete
fill ~-10 ~33 ~-110 ~-9 ~33 ~-109 minecraft:black_concrete
fill ~-10 ~33 ~-106 ~-9 ~33 ~-105 minecraft:black_concrete
fill ~-8 ~33 ~-144 ~-7 ~33 ~-143 minecraft:black_concrete
fill ~-8 ~33 ~-140 ~-7 ~33 ~-139 minecraft:black_concrete
fill ~-8 ~33 ~-136 ~-7 ~33 ~-135 minecraft:black_concrete
fill ~-8 ~33 ~-132 ~-7 ~33 ~-131 minecraft:black_concrete
fill ~-8 ~33 ~-128 ~-7 ~33 ~-127 minecraft:black_concrete
fill ~-8 ~33 ~-124 ~-7 ~33 ~-123 minecraft:black_concrete
fill ~-8 ~33 ~-120 ~-7 ~33 ~-119 minecraft:black_concrete
fill ~-8 ~33 ~-116 ~-7 ~33 ~-115 minecraft:black_concrete
fill ~-8 ~33 ~-112 ~-7 ~33 ~-111 minecraft:black_concrete
fill ~-8 ~33 ~-108 ~-7 ~33 ~-107 minecraft:black_concrete
fill ~-8 ~33 ~-104 ~-7 ~33 ~-104 minecraft:black_concrete
fill ~-6 ~33 ~-142 ~-5 ~33 ~-141 minecraft:black_concrete
fill ~-6 ~33 ~-138 ~-5 ~33 ~-137 minecraft:black_concrete
fill ~-6 ~33 ~-134 ~-5 ~33 ~-133 minecraft:black_concrete
fill ~-6 ~33 ~-130 ~-5 ~33 ~-129 minecraft:black_concrete
fill ~-6 ~33 ~-126 ~-5 ~33 ~-125 minecraft:black_concrete
fill ~-6 ~33 ~-122 ~-5 ~33 ~-121 minecraft:black_concrete
fill ~-6 ~33 ~-118 ~-5 ~33 ~-117 minecraft:black_concrete
fill ~-6 ~33 ~-114 ~-5 ~33 ~-113 minecraft:black_concrete
fill ~-6 ~33 ~-110 ~-5 ~33 ~-109 minecraft:black_concrete
fill ~-6 ~33 ~-106 ~-5 ~33 ~-105 minecraft:black_concrete
fill ~-4 ~33 ~-144 ~-3 ~33 ~-143 minecraft:black_concrete
fill ~-4 ~33 ~-140 ~-3 ~33 ~-139 minecraft:black_concrete
fill ~-4 ~33 ~-136 ~-3 ~33 ~-135 minecraft:black_concrete
fill ~-4 ~33 ~-132 ~-3 ~33 ~-131 minecraft:black_concrete
fill ~-4 ~33 ~-128 ~-3 ~33 ~-127 minecraft:black_concrete
fill ~-4 ~33 ~-124 ~-3 ~33 ~-123 minecraft:black_concrete
fill ~-4 ~33 ~-120 ~-3 ~33 ~-119 minecraft:black_concrete
fill ~-4 ~33 ~-116 ~-3 ~33 ~-115 minecraft:black_concrete
fill ~-4 ~33 ~-112 ~-3 ~33 ~-111 minecraft:black_concrete
fill ~-4 ~33 ~-108 ~-3 ~33 ~-107 minecraft:black_concrete
fill ~-4 ~33 ~-104 ~-3 ~33 ~-104 minecraft:black_concrete
fill ~-2 ~33 ~-142 ~-1 ~33 ~-141 minecraft:black_concrete
fill ~-2 ~33 ~-138 ~-1 ~33 ~-137 minecraft:black_concrete
fill ~-2 ~33 ~-134 ~-1 ~33 ~-133 minecraft:black_concrete
fill ~-2 ~33 ~-130 ~-1 ~33 ~-129 minecraft:black_concrete
fill ~-2 ~33 ~-126 ~-1 ~33 ~-125 minecraft:black_concrete
fill ~-2 ~33 ~-122 ~-1 ~33 ~-121 minecraft:black_concrete
fill ~-2 ~33 ~-118 ~-1 ~33 ~-117 minecraft:black_concrete
fill ~-2 ~33 ~-114 ~-1 ~33 ~-113 minecraft:black_concrete
fill ~-2 ~33 ~-110 ~-1 ~33 ~-109 minecraft:black_concrete
fill ~-2 ~33 ~-106 ~-1 ~33 ~-105 minecraft:black_concrete
fill ~ ~33 ~-144 ~1 ~33 ~-143 minecraft:black_concrete
fill ~ ~33 ~-140 ~1 ~33 ~-139 minecraft:black_concrete
fill ~ ~33 ~-136 ~1 ~33 ~-135 minecraft:black_concrete
fill ~ ~33 ~-132 ~1 ~33 ~-131 minecraft:black_concrete
fill ~ ~33 ~-128 ~1 ~33 ~-127 minecraft:black_concrete
fill ~ ~33 ~-124 ~1 ~33 ~-123 minecraft:black_concrete
fill ~ ~33 ~-120 ~1 ~33 ~-119 minecraft:black_concrete
fill ~ ~33 ~-116 ~1 ~33 ~-115 minecraft:black_concrete
fill ~ ~33 ~-112 ~1 ~33 ~-111 minecraft:black_concrete
fill ~ ~33 ~-108 ~1 ~33 ~-107 minecraft:black_concrete
fill ~ ~33 ~-104 ~1 ~33 ~-104 minecraft:black_concrete
fill ~2 ~33 ~-142 ~3 ~33 ~-141 minecraft:black_concrete
fill ~2 ~33 ~-138 ~3 ~33 ~-137 minecraft:black_concrete
fill ~2 ~33 ~-134 ~3 ~33 ~-133 minecraft:black_concrete
fill ~2 ~33 ~-130 ~3 ~33 ~-129 minecraft:black_concrete
fill ~2 ~33 ~-126 ~3 ~33 ~-125 minecraft:black_concrete
fill ~2 ~33 ~-122 ~3 ~33 ~-121 minecraft:black_concrete
fill ~2 ~33 ~-118 ~3 ~33 ~-117 minecraft:black_concrete
fill ~2 ~33 ~-114 ~3 ~33 ~-113 minecraft:black_concrete
fill ~2 ~33 ~-110 ~3 ~33 ~-109 minecraft:black_concrete
fill ~2 ~33 ~-106 ~3 ~33 ~-105 minecraft:black_concrete
fill ~4 ~33 ~-144 ~5 ~33 ~-143 minecraft:black_concrete
fill ~4 ~33 ~-140 ~5 ~33 ~-139 minecraft:black_concrete
fill ~4 ~33 ~-136 ~5 ~33 ~-135 minecraft:black_concrete
fill ~4 ~33 ~-132 ~5 ~33 ~-131 minecraft:black_concrete
fill ~4 ~33 ~-128 ~5 ~33 ~-127 minecraft:black_concrete
fill ~4 ~33 ~-124 ~5 ~33 ~-123 minecraft:black_concrete
fill ~4 ~33 ~-120 ~5 ~33 ~-119 minecraft:black_concrete
fill ~4 ~33 ~-116 ~5 ~33 ~-115 minecraft:black_concrete
fill ~4 ~33 ~-112 ~5 ~33 ~-111 minecraft:black_concrete
fill ~4 ~33 ~-108 ~5 ~33 ~-107 minecraft:black_concrete
fill ~4 ~33 ~-104 ~5 ~33 ~-104 minecraft:black_concrete
fill ~6 ~33 ~-142 ~7 ~33 ~-141 minecraft:black_concrete
fill ~6 ~33 ~-138 ~7 ~33 ~-137 minecraft:black_concrete
fill ~6 ~33 ~-134 ~7 ~33 ~-133 minecraft:black_concrete
fill ~6 ~33 ~-130 ~7 ~33 ~-129 minecraft:black_concrete
fill ~6 ~33 ~-126 ~7 ~33 ~-125 minecraft:black_concrete
fill ~6 ~33 ~-122 ~7 ~33 ~-121 minecraft:black_concrete
fill ~6 ~33 ~-118 ~7 ~33 ~-117 minecraft:black_concrete
fill ~6 ~33 ~-114 ~7 ~33 ~-113 minecraft:black_concrete
fill ~6 ~33 ~-110 ~7 ~33 ~-109 minecraft:black_concrete
fill ~6 ~33 ~-106 ~7 ~33 ~-105 minecraft:black_concrete
fill ~8 ~33 ~-144 ~9 ~33 ~-143 minecraft:black_concrete
fill ~8 ~33 ~-140 ~9 ~33 ~-139 minecraft:black_concrete
fill ~8 ~33 ~-136 ~9 ~33 ~-135 minecraft:black_concrete
fill ~8 ~33 ~-132 ~9 ~33 ~-131 minecraft:black_concrete
fill ~8 ~33 ~-128 ~9 ~33 ~-127 minecraft:black_concrete
fill ~8 ~33 ~-124 ~9 ~33 ~-123 minecraft:black_concrete
fill ~8 ~33 ~-120 ~9 ~33 ~-119 minecraft:black_concrete
fill ~8 ~33 ~-116 ~9 ~33 ~-115 minecraft:black_concrete
fill ~8 ~33 ~-112 ~9 ~33 ~-111 minecraft:black_concrete
fill ~8 ~33 ~-108 ~9 ~33 ~-107 minecraft:black_concrete
fill ~8 ~33 ~-104 ~9 ~33 ~-104 minecraft:black_concrete
fill ~10 ~33 ~-142 ~10 ~33 ~-141 minecraft:black_concrete
fill ~10 ~33 ~-138 ~10 ~33 ~-137 minecraft:black_concrete
fill ~10 ~33 ~-134 ~10 ~33 ~-133 minecraft:black_concrete
fill ~10 ~33 ~-130 ~10 ~33 ~-129 minecraft:black_concrete
fill ~10 ~33 ~-126 ~10 ~33 ~-125 minecraft:black_concrete
fill ~10 ~33 ~-122 ~10 ~33 ~-121 minecraft:black_concrete
fill ~10 ~33 ~-118 ~10 ~33 ~-117 minecraft:black_concrete
fill ~10 ~33 ~-114 ~10 ~33 ~-113 minecraft:black_concrete
fill ~10 ~33 ~-110 ~10 ~33 ~-109 minecraft:black_concrete
fill ~10 ~33 ~-106 ~10 ~33 ~-105 minecraft:black_concrete
fill ~-88 ~-6 ~-132 ~-80 ~-1 ~-100 minecraft:glass
fill ~-29 ~-25 ~-119 ~-1 ~-19 ~-101 minecraft:glass
fill ~-25 ~-26 ~-119 ~-1 ~-19 ~-101 minecraft:glass
fill ~-12 ~11 ~-126 ~-11 ~11 ~-126 minecraft:glass
fill ~-91 ~-11 ~-117 ~-91 ~-11 ~-116 minecraft:cracked_deepslate_bricks
fill ~-91 ~-10 ~-118 ~-90 ~-10 ~-118 minecraft:cracked_deepslate_bricks
fill ~-89 ~-11 ~-121 ~-80 ~-11 ~-121 minecraft:cracked_deepslate_bricks
fill ~-89 ~-10 ~-117 ~-80 ~-10 ~-116 minecraft:cracked_deepslate_bricks
fill ~-32 ~-26 ~-119 ~-26 ~-26 ~-119 minecraft:cracked_deepslate_bricks
fill ~-32 ~-26 ~-101 ~-1 ~-26 ~-101 minecraft:cracked_deepslate_bricks
fill ~-32 ~-24 ~-137 ~-12 ~-24 ~-137 minecraft:cracked_deepslate_bricks
fill ~-32 ~-24 ~-135 ~-12 ~-24 ~-135 minecraft:cracked_deepslate_bricks
fill ~-32 ~-24 ~-110 ~-1 ~-24 ~-110 minecraft:cracked_deepslate_bricks
fill ~-32 ~-23 ~-115 ~-1 ~-23 ~-115 minecraft:cracked_deepslate_bricks
fill ~-32 ~-22 ~-135 ~-12 ~-22 ~-135 minecraft:cracked_deepslate_bricks
fill ~-32 ~-22 ~-131 ~31 ~-22 ~-131 minecraft:cracked_deepslate_bricks
fill ~-32 ~-22 ~-124 ~-1 ~-21 ~-124 minecraft:cracked_deepslate_bricks
fill ~-32 ~-22 ~-120 ~-1 ~-22 ~-120 minecraft:cracked_deepslate_bricks
fill ~-32 ~-21 ~-127 ~31 ~-21 ~-127 minecraft:cracked_deepslate_bricks
fill ~-32 ~-20 ~-144 ~-12 ~-20 ~-144 minecraft:cracked_deepslate_bricks
fill ~-32 ~-20 ~-105 ~-1 ~-20 ~-105 minecraft:cracked_deepslate_bricks
fill ~-32 ~-19 ~-104 ~-1 ~-19 ~-104 minecraft:cracked_deepslate_bricks
fill ~-31 ~-26 ~-100 ~-30 ~-26 ~-100 minecraft:cracked_deepslate_bricks
fill ~-31 ~-25 ~-125 ~-31 ~-25 ~-101 minecraft:cracked_deepslate_bricks
fill ~-31 ~-24 ~-150 ~-31 ~-24 ~-133 minecraft:cracked_deepslate_bricks
fill ~-31 ~-21 ~-125 ~-31 ~-21 ~-101 minecraft:cracked_deepslate_bricks
fill ~-31 ~-19 ~-132 ~-31 ~-19 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-31 ~-18 ~-138 minecraft:cracked_deepslate_bricks
setblock ~-31 ~-18 ~-136 minecraft:cracked_deepslate_bricks
setblock ~-31 ~-18 ~-124 minecraft:cracked_deepslate_bricks
setblock ~-31 ~-18 ~-115 minecraft:cracked_deepslate_bricks
setblock ~-30 ~-23 ~-100 minecraft:cracked_deepslate_bricks
setblock ~-30 ~-18 ~-133 minecraft:cracked_deepslate_bricks
fill ~-29 ~-25 ~-150 ~-29 ~-25 ~-133 minecraft:cracked_deepslate_bricks
fill ~-29 ~-19 ~-132 ~-29 ~-19 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-29 ~-18 ~-143 minecraft:cracked_deepslate_bricks
setblock ~-29 ~-18 ~-138 minecraft:cracked_deepslate_bricks
setblock ~-29 ~-18 ~-101 minecraft:cracked_deepslate_bricks
fill ~-28 ~-24 ~-150 ~-28 ~-24 ~-126 minecraft:cracked_deepslate_bricks
fill ~-28 ~-23 ~-132 ~-28 ~-23 ~-126 minecraft:cracked_deepslate_bricks
fill ~-27 ~-24 ~-132 ~-27 ~-24 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-27 ~-20 ~-100 minecraft:cracked_deepslate_bricks
setblock ~-27 ~6 ~-114 minecraft:cracked_deepslate_bricks
setblock ~-27 ~9 ~-114 minecraft:cracked_deepslate_bricks
setblock ~-27 ~12 ~-122 minecraft:cracked_deepslate_bricks
fill ~-27 ~18 ~-122 ~-27 ~20 ~-122 minecraft:cracked_deepslate_bricks
setblock ~-27 ~29 ~-114 minecraft:cracked_deepslate_bricks
fill ~-27 ~34 ~-138 ~-27 ~35 ~-138 minecraft:cracked_deepslate_bricks
setblock ~-27 ~38 ~-114 minecraft:cracked_deepslate_bricks
fill ~-26 ~-25 ~-125 ~-25 ~-25 ~-120 minecraft:cracked_deepslate_bricks
fill ~-26 ~-21 ~-132 ~-26 ~-21 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-26 ~-18 ~-118 minecraft:cracked_deepslate_bricks
setblock ~-25 ~-18 ~-147 minecraft:cracked_deepslate_bricks
setblock ~-25 ~-18 ~-133 minecraft:cracked_deepslate_bricks
setblock ~-25 ~-18 ~-105 minecraft:cracked_deepslate_bricks
fill ~-24 ~-19 ~-150 ~-24 ~-19 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-24 ~-18 ~-144 minecraft:cracked_deepslate_bricks
setblock ~-24 ~-18 ~-131 minecraft:cracked_deepslate_bricks
setblock ~-23 ~-23 ~-100 minecraft:cracked_deepslate_bricks
setblock ~-23 ~-18 ~-135 minecraft:cracked_deepslate_bricks
setblock ~-23 ~-18 ~-104 minecraft:cracked_deepslate_bricks
setblock ~-22 ~-18 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-21 ~-18 ~-136 minecraft:cracked_deepslate_bricks
setblock ~-21 ~-18 ~-116 minecraft:cracked_deepslate_bricks
setblock ~-21 ~-18 ~-113 minecraft:cracked_deepslate_bricks
setblock ~-21 ~-18 ~-108 minecraft:cracked_deepslate_bricks
setblock ~-21 ~-18 ~-102 minecraft:cracked_deepslate_bricks
fill ~-20 ~-23 ~-132 ~-20 ~-23 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-20 ~-18 ~-138 minecraft:cracked_deepslate_bricks
setblock ~-20 ~-18 ~-129 minecraft:cracked_deepslate_bricks
setblock ~-20 ~-18 ~-103 minecraft:cracked_deepslate_bricks
fill ~-19 ~-24 ~-150 ~-19 ~-23 ~-142 minecraft:cracked_deepslate_bricks
fill ~-19 ~-22 ~-132 ~-19 ~-22 ~-126 minecraft:cracked_deepslate_bricks
fill ~-19 ~-19 ~-150 ~-19 ~-19 ~-142 minecraft:cracked_deepslate_bricks
fill ~-19 ~-18 ~-147 ~-18 ~-18 ~-147 minecraft:cracked_deepslate_bricks
setblock ~-19 ~-18 ~-111 minecraft:cracked_deepslate_bricks
setblock ~-19 ~-18 ~-106 minecraft:cracked_deepslate_bricks
fill ~-18 ~-25 ~-125 ~-18 ~-25 ~-120 minecraft:cracked_deepslate_bricks
setblock ~-18 ~-18 ~-143 minecraft:cracked_deepslate_bricks
setblock ~-18 ~-18 ~-124 minecraft:cracked_deepslate_bricks
setblock ~-18 ~6 ~-101 minecraft:cracked_deepslate_bricks
setblock ~-18 ~7 ~-147 minecraft:cracked_deepslate_bricks
setblock ~-18 ~23 ~-147 minecraft:cracked_deepslate_bricks
setblock ~-18 ~36 ~-147 minecraft:cracked_deepslate_bricks
fill ~-17 ~-26 ~-132 ~-16 ~-26 ~-126 minecraft:cracked_deepslate_bricks
fill ~-17 ~-24 ~-150 ~-17 ~-24 ~-142 minecraft:cracked_deepslate_bricks
setblock ~-17 ~-18 ~-104 minecraft:cracked_deepslate_bricks
fill ~-16 ~-20 ~-125 ~-16 ~-20 ~-101 minecraft:cracked_deepslate_bricks
setblock ~-16 ~-18 ~-146 minecraft:cracked_deepslate_bricks
fill ~-15 ~-20 ~-150 ~-15 ~-20 ~-142 minecraft:cracked_deepslate_bricks
setblock ~-15 ~-18 ~-134 minecraft:cracked_deepslate_bricks
setblock ~-15 ~-18 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-15 ~-18 ~-104 minecraft:cracked_deepslate_bricks
setblock ~-14 ~-18 ~-148 minecraft:cracked_deepslate_bricks
setblock ~-14 ~-18 ~-142 minecraft:cracked_deepslate_bricks
setblock ~-14 ~-18 ~-105 minecraft:cracked_deepslate_bricks
fill ~-13 ~-25 ~-125 ~-13 ~-25 ~-120 minecraft:cracked_deepslate_bricks
setblock ~-13 ~-18 ~-146 minecraft:cracked_deepslate_bricks
setblock ~-13 ~-18 ~-144 minecraft:cracked_deepslate_bricks
setblock ~-13 ~-18 ~-123 minecraft:cracked_deepslate_bricks
setblock ~-13 ~-18 ~-115 minecraft:cracked_deepslate_bricks
fill ~-12 ~-23 ~-150 ~-12 ~-23 ~-133 minecraft:cracked_deepslate_bricks
setblock ~-12 ~-18 ~-149 minecraft:cracked_deepslate_bricks
setblock ~-12 ~-18 ~-143 minecraft:cracked_deepslate_bricks
setblock ~-12 ~-18 ~-135 minecraft:cracked_deepslate_bricks
setblock ~-12 ~-18 ~-118 minecraft:cracked_deepslate_bricks
fill ~-11 ~-26 ~-125 ~-11 ~-26 ~-123 minecraft:cracked_deepslate_bricks
fill ~-11 ~-23 ~-133 ~10 ~-23 ~-133 minecraft:cracked_deepslate_bricks
fill ~-11 ~-22 ~-139 ~10 ~-22 ~-139 minecraft:cracked_deepslate_bricks
fill ~-11 ~-21 ~-149 ~10 ~-21 ~-149 minecraft:cracked_deepslate_bricks
fill ~-11 ~-20 ~-148 ~10 ~-20 ~-148 minecraft:cracked_deepslate_bricks
fill ~-11 ~-19 ~-133 ~10 ~-19 ~-133 minecraft:cracked_deepslate_bricks
setblock ~-10 ~-18 ~-143 minecraft:cracked_deepslate_bricks
setblock ~-10 ~-18 ~-137 minecraft:cracked_deepslate_bricks
setblock ~-10 ~-18 ~-131 minecraft:cracked_deepslate_bricks
fill ~-10 ~-18 ~-124 ~-10 ~-18 ~-123 minecraft:cracked_deepslate_bricks
setblock ~-10 ~38 ~-101 minecraft:cracked_deepslate_bricks
setblock ~-10 ~42 ~-147 minecraft:cracked_deepslate_bricks
setblock ~-9 ~-21 ~-100 minecraft:cracked_deepslate_bricks
fill ~-9 ~-19 ~-125 ~-9 ~-19 ~-101 minecraft:cracked_deepslate_bricks
setblock ~-9 ~-18 ~-134 minecraft:cracked_deepslate_bricks
setblock ~-9 ~-18 ~-130 minecraft:cracked_deepslate_bricks
setblock ~-8 ~-19 ~-100 minecraft:cracked_deepslate_bricks
setblock ~-8 ~-18 ~-138 minecraft:cracked_deepslate_bricks
setblock ~-8 ~-18 ~-129 minecraft:cracked_deepslate_bricks
setblock ~-8 ~-18 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-8 ~-18 ~-122 minecraft:cracked_deepslate_bricks
setblock ~-8 ~-18 ~-113 minecraft:cracked_deepslate_bricks
setblock ~-8 ~-18 ~-103 minecraft:cracked_deepslate_bricks
fill ~-7 ~-21 ~-132 ~-7 ~-21 ~-126 minecraft:cracked_deepslate_bricks
fill ~-7 ~-19 ~-132 ~-7 ~-19 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-7 ~-18 ~-112 minecraft:cracked_deepslate_bricks
fill ~-6 ~-26 ~-132 ~-6 ~-26 ~-120 minecraft:cracked_deepslate_bricks
setblock ~-6 ~-18 ~-117 minecraft:cracked_deepslate_bricks
fill ~-5 ~-26 ~-125 ~-5 ~-26 ~-123 minecraft:cracked_deepslate_bricks
fill ~-5 ~-23 ~-132 ~-5 ~-23 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-5 ~-18 ~-135 minecraft:cracked_deepslate_bricks
setblock ~-5 ~-18 ~-127 minecraft:cracked_deepslate_bricks
setblock ~-4 ~-19 ~-100 minecraft:cracked_deepslate_bricks
setblock ~-4 ~-18 ~-114 minecraft:cracked_deepslate_bricks
setblock ~-4 ~-18 ~-102 minecraft:cracked_deepslate_bricks
setblock ~-2 ~-18 ~-149 minecraft:cracked_deepslate_bricks
setblock ~-2 ~-18 ~-119 minecraft:cracked_deepslate_bricks
setblock ~-2 ~-18 ~-104 minecraft:cracked_deepslate_bricks
setblock ~-2 ~18 ~-101 minecraft:cracked_deepslate_bricks
setblock ~-2 ~20 ~-101 minecraft:cracked_deepslate_bricks
setblock ~-2 ~26 ~-101 minecraft:cracked_deepslate_bricks
setblock ~-2 ~42 ~-147 minecraft:cracked_deepslate_bricks
fill ~-1 ~-21 ~-132 ~-1 ~-21 ~-126 minecraft:cracked_deepslate_bricks
fill ~-1 ~-19 ~-132 ~-1 ~-19 ~-126 minecraft:cracked_deepslate_bricks
setblock ~-1 ~-18 ~-135 minecraft:cracked_deepslate_bricks
setblock ~-1 ~-18 ~-112 minecraft:cracked_deepslate_bricks
fill ~ ~-26 ~-117 ~31 ~-26 ~-117 minecraft:cracked_deepslate_bricks
fill ~ ~-25 ~-125 ~ ~-25 ~-124 minecraft:cracked_deepslate_bricks
fill ~ ~-24 ~-116 ~31 ~-23 ~-116 minecraft:cracked_deepslate_bricks
fill ~ ~-24 ~-108 ~31 ~-23 ~-108 minecraft:cracked_deepslate_bricks
fill ~ ~-23 ~-114 ~31 ~-23 ~-114 minecraft:cracked_deepslate_bricks
fill ~ ~-22 ~-102 ~31 ~-22 ~-102 minecraft:cracked_deepslate_bricks
fill ~ ~-21 ~-118 ~31 ~-21 ~-118 minecraft:cracked_deepslate_bricks
fill ~ ~-21 ~-109 ~31 ~-21 ~-109 minecraft:cracked_deepslate_bricks
fill ~ ~-20 ~-115 ~31 ~-20 ~-115 minecraft:cracked_deepslate_bricks
fill ~ ~-19 ~-120 ~31 ~-19 ~-120 minecraft:cracked_deepslate_bricks
fill ~ ~-18 ~-141 ~ ~-18 ~-140 minecraft:cracked_deepslate_bricks
setblock ~ ~-18 ~-138 minecraft:cracked_deepslate_bricks
fill ~1 ~-24 ~-125 ~1 ~-24 ~-101 minecraft:cracked_deepslate_bricks
fill ~1 ~-21 ~-125 ~1 ~-21 ~-101 minecraft:cracked_deepslate_bricks
setblock ~1 ~-18 ~-139 minecraft:cracked_deepslate_bricks
fill ~1 ~-18 ~-135 ~3 ~-18 ~-135 minecraft:cracked_deepslate_bricks
setblock ~1 ~-18 ~-134 minecraft:cracked_deepslate_bricks
setblock ~1 ~-18 ~-129 minecraft:cracked_deepslate_bricks
setblock ~2 ~-18 ~-123 minecraft:cracked_deepslate_bricks
setblock ~2 ~-18 ~-119 minecraft:cracked_deepslate_bricks
fill ~3 ~-19 ~-150 ~3 ~-19 ~-133 minecraft:cracked_deepslate_bricks
setblock ~3 ~-18 ~-130 minecraft:cracked_deepslate_bricks
setblock ~3 ~-18 ~-121 minecraft:cracked_deepslate_bricks
fill ~4 ~-26 ~-132 ~4 ~-26 ~-126 minecraft:cracked_deepslate_bricks
setblock ~4 ~-18 ~-134 minecraft:cracked_deepslate_bricks
setblock ~5 ~-19 ~-100 minecraft:cracked_deepslate_bricks
setblock ~5 ~-18 ~-146 minecraft:cracked_deepslate_bricks
setblock ~5 ~-18 ~-126 minecraft:cracked_deepslate_bricks
fill ~5 ~-18 ~-124 ~6 ~-18 ~-124 minecraft:cracked_deepslate_bricks
setblock ~5 ~-18 ~-109 minecraft:cracked_deepslate_bricks
fill ~6 ~-26 ~-132 ~6 ~-26 ~-126 minecraft:cracked_deepslate_bricks
fill ~6 ~-24 ~-100 ~7 ~-24 ~-100 minecraft:cracked_deepslate_bricks
fill ~6 ~-21 ~-132 ~6 ~-21 ~-126 minecraft:cracked_deepslate_bricks
setblock ~6 ~-18 ~-128 minecraft:cracked_deepslate_bricks
fill ~6 ~-18 ~-114 ~7 ~-18 ~-114 minecraft:cracked_deepslate_bricks
setblock ~6 ~9 ~-147 minecraft:cracked_deepslate_bricks
setblock ~6 ~41 ~-101 minecraft:cracked_deepslate_bricks
fill ~7 ~-25 ~-132 ~7 ~-25 ~-126 minecraft:cracked_deepslate_bricks
setblock ~7 ~-19 ~-100 minecraft:cracked_deepslate_bricks
fill ~7 ~-18 ~-122 ~7 ~-18 ~-121 minecraft:cracked_deepslate_bricks
setblock ~8 ~-18 ~-116 minecraft:cracked_deepslate_bricks
setblock ~8 ~-18 ~-113 minecraft:cracked_deepslate_bricks
setblock ~9 ~-22 ~-100 minecraft:cracked_deepslate_bricks
fill ~9 ~-18 ~-134 ~9 ~-18 ~-133 minecraft:cracked_deepslate_bricks
setblock ~10 ~-18 ~-146 minecraft:cracked_deepslate_bricks
fill ~11 ~-24 ~-145 ~31 ~-23 ~-145 minecraft:cracked_deepslate_bricks
fill ~11 ~-24 ~-140 ~31 ~-24 ~-140 minecraft:cracked_deepslate_bricks
fill ~11 ~-24 ~-138 ~31 ~-24 ~-138 minecraft:cracked_deepslate_bricks
fill ~11 ~-23 ~-125 ~11 ~-23 ~-101 minecraft:cracked_deepslate_bricks
setblock ~11 ~-20 ~-135 minecraft:cracked_deepslate_bricks
setblock ~11 ~-18 ~-127 minecraft:cracked_deepslate_bricks
setblock ~11 ~-18 ~-110 minecraft:cracked_deepslate_bricks
setblock ~11 ~-18 ~-107 minecraft:cracked_deepslate_bricks
fill ~12 ~-24 ~-150 ~12 ~-24 ~-137 minecraft:cracked_deepslate_bricks
fill ~12 ~-23 ~-132 ~12 ~-23 ~-126 minecraft:cracked_deepslate_bricks
setblock ~12 ~-22 ~-136 minecraft:cracked_deepslate_bricks
fill ~12 ~-19 ~-125 ~12 ~-19 ~-101 minecraft:cracked_deepslate_bricks
fill ~13 ~-20 ~-125 ~13 ~-20 ~-101 minecraft:cracked_deepslate_bricks
setblock ~13 ~-19 ~-100 minecraft:cracked_deepslate_bricks
fill ~14 ~-23 ~-132 ~14 ~-22 ~-126 minecraft:cracked_deepslate_bricks
setblock ~14 ~-23 ~-100 minecraft:cracked_deepslate_bricks
fill ~14 ~-19 ~-125 ~15 ~-19 ~-101 minecraft:cracked_deepslate_bricks
setblock ~14 ~-18 ~-122 minecraft:cracked_deepslate_bricks
setblock ~14 ~-18 ~-113 minecraft:cracked_deepslate_bricks
setblock ~14 ~6 ~-147 minecraft:cracked_deepslate_bricks
setblock ~14 ~16 ~-147 minecraft:cracked_deepslate_bricks
setblock ~14 ~18 ~-147 minecraft:cracked_deepslate_bricks
setblock ~14 ~18 ~-101 minecraft:cracked_deepslate_bricks
setblock ~14 ~37 ~-147 minecraft:cracked_deepslate_bricks
setblock ~15 ~-18 ~-131 minecraft:cracked_deepslate_bricks
setblock ~15 ~-18 ~-129 minecraft:cracked_deepslate_bricks
fill ~16 ~-26 ~-132 ~16 ~-25 ~-101 minecraft:cracked_deepslate_bricks
fill ~16 ~-25 ~-150 ~16 ~-25 ~-137 minecraft:cracked_deepslate_bricks
fill ~16 ~-18 ~-145 ~16 ~-18 ~-144 minecraft:cracked_deepslate_bricks
setblock ~17 ~-18 ~-144 minecraft:cracked_deepslate_bricks
fill ~17 ~-18 ~-130 ~17 ~-18 ~-129 minecraft:cracked_deepslate_bricks
setblock ~17 ~-18 ~-126 minecraft:cracked_deepslate_bricks
fill ~18 ~-22 ~-150 ~18 ~-22 ~-137 minecraft:cracked_deepslate_bricks
setblock ~18 ~-19 ~-136 minecraft:cracked_deepslate_bricks
fill ~18 ~-18 ~-148 ~18 ~-18 ~-147 minecraft:cracked_deepslate_bricks
setblock ~18 ~-18 ~-145 minecraft:cracked_deepslate_bricks
setblock ~18 ~-18 ~-124 minecraft:cracked_deepslate_bricks
setblock ~18 ~-18 ~-106 minecraft:cracked_deepslate_bricks
fill ~19 ~-24 ~-150 ~19 ~-24 ~-137 minecraft:cracked_deepslate_bricks
fill ~19 ~-23 ~-125 ~19 ~-23 ~-101 minecraft:cracked_deepslate_bricks
setblock ~19 ~-18 ~-140 minecraft:cracked_deepslate_bricks
setblock ~19 ~-18 ~-123 minecraft:cracked_deepslate_bricks
setblock ~20 ~-18 ~-138 minecraft:cracked_deepslate_bricks
setblock ~20 ~-18 ~-126 minecraft:cracked_deepslate_bricks
setblock ~20 ~-18 ~-111 minecraft:cracked_deepslate_bricks
fill ~21 ~-24 ~-125 ~21 ~-24 ~-101 minecraft:cracked_deepslate_bricks
setblock ~21 ~-23 ~-136 minecraft:cracked_deepslate_bricks
setblock ~21 ~-18 ~-131 minecraft:cracked_deepslate_bricks
setblock ~21 ~-18 ~-114 minecraft:cracked_deepslate_bricks
fill ~22 ~-26 ~-132 ~22 ~-25 ~-126 minecraft:cracked_deepslate_bricks
fill ~22 ~-21 ~-132 ~22 ~-21 ~-126 minecraft:cracked_deepslate_bricks
fill ~23 ~-24 ~-150 ~23 ~-24 ~-137 minecraft:cracked_deepslate_bricks
setblock ~23 ~-23 ~-134 minecraft:cracked_deepslate_bricks
fill ~23 ~-23 ~-125 ~23 ~-23 ~-101 minecraft:cracked_deepslate_bricks
fill ~23 ~-22 ~-132 ~23 ~-22 ~-126 minecraft:cracked_deepslate_bricks
setblock ~23 ~-21 ~-136 minecraft:cracked_deepslate_bricks
fill ~23 ~-20 ~-125 ~23 ~-20 ~-101 minecraft:cracked_deepslate_bricks
setblock ~23 ~-18 ~-110 minecraft:cracked_deepslate_bricks
setblock ~23 ~-18 ~-106 minecraft:cracked_deepslate_bricks
fill ~24 ~-26 ~-125 ~25 ~-26 ~-101 minecraft:cracked_deepslate_bricks
fill ~24 ~-22 ~-125 ~24 ~-22 ~-101 minecraft:cracked_deepslate_bricks
setblock ~24 ~-20 ~-136 minecraft:cracked_deepslate_bricks
setblock ~24 ~-18 ~-140 minecraft:cracked_deepslate_bricks
setblock ~24 ~-18 ~-115 minecraft:cracked_deepslate_bricks
setblock ~25 ~-18 ~-148 minecraft:cracked_deepslate_bricks
setblock ~25 ~-18 ~-141 minecraft:cracked_deepslate_bricks
setblock ~25 ~-18 ~-137 minecraft:cracked_deepslate_bricks
fill ~26 ~-24 ~-150 ~26 ~-24 ~-137 minecraft:cracked_deepslate_bricks
fill ~26 ~-19 ~-150 ~26 ~-19 ~-137 minecraft:cracked_deepslate_bricks
fill ~26 ~-19 ~-132 ~26 ~-19 ~-126 minecraft:cracked_deepslate_bricks
setblock ~26 ~-18 ~-144 minecraft:cracked_deepslate_bricks
setblock ~26 ~-18 ~-117 minecraft:cracked_deepslate_bricks
setblock ~26 ~-18 ~-111 minecraft:cracked_deepslate_bricks
fill ~27 ~-25 ~-125 ~27 ~-25 ~-101 minecraft:cracked_deepslate_bricks
fill ~27 ~-20 ~-132 ~28 ~-20 ~-126 minecraft:cracked_deepslate_bricks
setblock ~27 ~-18 ~-112 minecraft:cracked_deepslate_bricks
setblock ~27 ~-18 ~-104 minecraft:cracked_deepslate_bricks
setblock ~27 ~15 ~-130 minecraft:cracked_deepslate_bricks
setblock ~27 ~15 ~-114 minecraft:cracked_deepslate_bricks
fill ~27 ~18 ~-122 ~27 ~19 ~-122 minecraft:cracked_deepslate_bricks
setblock ~27 ~21 ~-130 minecraft:cracked_deepslate_bricks
setblock ~27 ~24 ~-138 minecraft:cracked_deepslate_bricks
fill ~27 ~31 ~-122 ~28 ~31 ~-122 minecraft:cracked_deepslate_bricks
setblock ~27 ~39 ~-114 minecraft:cracked_deepslate_bricks
fill ~28 ~-19 ~-125 ~28 ~-19 ~-101 minecraft:cracked_deepslate_bricks
fill ~28 ~-18 ~-128 ~29 ~-18 ~-128 minecraft:cracked_deepslate_bricks
fill ~29 ~-26 ~-132 ~29 ~-26 ~-126 minecraft:cracked_deepslate_bricks
fill ~29 ~-25 ~-150 ~29 ~-25 ~-137 minecraft:cracked_deepslate_bricks
fill ~29 ~-22 ~-125 ~30 ~-22 ~-101 minecraft:cracked_deepslate_bricks
setblock ~29 ~-18 ~-149 minecraft:cracked_deepslate_bricks
setblock ~29 ~-18 ~-138 minecraft:cracked_deepslate_bricks
setblock ~29 ~-18 ~-108 minecraft:cracked_deepslate_bricks
setblock ~30 ~-21 ~-136 minecraft:cracked_deepslate_bricks
setblock ~30 ~-18 ~-129 minecraft:cracked_deepslate_bricks
setblock ~30 ~-18 ~-113 minecraft:cracked_deepslate_bricks
setblock ~30 ~-18 ~-101 minecraft:cracked_deepslate_bricks
fill ~31 ~-25 ~-150 ~31 ~-25 ~-137 minecraft:cracked_deepslate_bricks
fill ~31 ~-24 ~-125 ~31 ~-24 ~-101 minecraft:cracked_deepslate_bricks
setblock ~31 ~-21 ~-100 minecraft:cracked_deepslate_bricks
setblock ~31 ~-18 ~-116 minecraft:cracked_deepslate_bricks
setblock ~32 ~-25 ~-139 minecraft:cracked_deepslate_bricks
setblock ~32 ~-21 ~-149 minecraft:cracked_deepslate_bricks
setblock ~32 ~-21 ~-139 minecraft:cracked_deepslate_bricks
setblock ~32 ~-21 ~-110 minecraft:cracked_deepslate_bricks
setblock ~32 ~-20 ~-122 minecraft:cracked_deepslate_bricks
setblock ~32 ~-20 ~-120 minecraft:cracked_deepslate_bricks
setblock ~32 ~-19 ~-131 minecraft:cracked_deepslate_bricks
setblock ~32 ~-19 ~-113 minecraft:cracked_deepslate_bricks
fill ~-64 ~39 ~-96 ~-64 ~40 ~-96 minecraft:gold_block
fill ~-64 ~51 ~-160 ~-64 ~52 ~-160 minecraft:gold_block
fill ~-64 ~51 ~-32 ~-64 ~52 ~-32 minecraft:gold_block
fill ~-26 ~64 ~-146 ~-26 ~65 ~-146 minecraft:gold_block
fill ~-26 ~64 ~-102 ~-26 ~65 ~-102 minecraft:gold_block
fill ~-15 ~45 ~-30 ~-15 ~46 ~-30 minecraft:gold_block
fill ~-3 ~2 ~-143 ~-3 ~3 ~-143 minecraft:gold_block
fill ~-1 ~2 ~-144 ~1 ~2 ~-143 minecraft:gold_block
fill ~-1 ~3 ~-144 ~1 ~5 ~-144 minecraft:gold_block
setblock ~ ~6 ~-144 minecraft:gold_block
fill ~ ~39 ~-160 ~ ~40 ~-160 minecraft:gold_block
fill ~ ~85 ~-124 ~ ~86 ~-124 minecraft:gold_block
fill ~3 ~2 ~-143 ~3 ~3 ~-143 minecraft:gold_block
fill ~12 ~-26 ~-149 ~31 ~-19 ~-137 minecraft:gold_block
fill ~14 ~34 ~-142 ~22 ~34 ~-142 minecraft:gold_block
fill ~15 ~45 ~-30 ~15 ~46 ~-30 minecraft:gold_block
fill ~26 ~64 ~-146 ~26 ~65 ~-146 minecraft:gold_block
fill ~26 ~64 ~-102 ~26 ~65 ~-102 minecraft:gold_block
fill ~64 ~39 ~-96 ~64 ~40 ~-96 minecraft:gold_block
fill ~64 ~51 ~-160 ~64 ~52 ~-160 minecraft:gold_block
fill ~64 ~51 ~-32 ~64 ~52 ~-32 minecraft:gold_block
fill ~-88 ~-12 ~-132 ~-80 ~-7 ~-131 minecraft:dark_prismarine
fill ~-88 ~-12 ~-130 ~-82 ~-7 ~-100 minecraft:dark_prismarine
fill ~-81 ~-12 ~-125 ~-80 ~-7 ~-100 minecraft:dark_prismarine
fill ~-77 ~-16 ~-129 ~-72 ~-16 ~-129 minecraft:cracked_deepslate_tiles
setblock ~-75 ~-12 ~-127 minecraft:cracked_deepslate_tiles
setblock ~-72 ~36 ~-160 minecraft:cracked_deepslate_tiles
setblock ~-71 ~33 ~-166 minecraft:cracked_deepslate_tiles
setblock ~-71 ~34 ~-165 minecraft:cracked_deepslate_tiles
setblock ~-71 ~34 ~-155 minecraft:cracked_deepslate_tiles
setblock ~-71 ~37 ~-31 minecraft:cracked_deepslate_tiles
setblock ~-71 ~38 ~-32 minecraft:cracked_deepslate_tiles
setblock ~-70 ~28 ~-94 minecraft:cracked_deepslate_tiles
setblock ~-70 ~40 ~-32 minecraft:cracked_deepslate_tiles
setblock ~-69 ~27 ~-100 minecraft:cracked_deepslate_tiles
setblock ~-69 ~40 ~-33 minecraft:cracked_deepslate_tiles
setblock ~-68 ~40 ~-156 minecraft:cracked_deepslate_tiles
setblock ~-68 ~42 ~-162 minecraft:cracked_deepslate_tiles
setblock ~-67 ~27 ~-90 minecraft:cracked_deepslate_tiles
setblock ~-67 ~32 ~-95 minecraft:cracked_deepslate_tiles
fill ~-67 ~35 ~-168 ~-67 ~35 ~-167 minecraft:cracked_deepslate_tiles
setblock ~-67 ~37 ~-166 minecraft:cracked_deepslate_tiles
setblock ~-67 ~39 ~-37 minecraft:cracked_deepslate_tiles
setblock ~-67 ~41 ~-157 minecraft:cracked_deepslate_tiles
setblock ~-67 ~44 ~-30 minecraft:cracked_deepslate_tiles
setblock ~-66 ~35 ~-95 minecraft:cracked_deepslate_tiles
setblock ~-66 ~39 ~-155 minecraft:cracked_deepslate_tiles
setblock ~-66 ~45 ~-158 minecraft:cracked_deepslate_tiles
setblock ~-65 ~32 ~-150 minecraft:cracked_deepslate_tiles
setblock ~-65 ~35 ~-152 minecraft:cracked_deepslate_tiles
setblock ~-65 ~36 ~-168 minecraft:cracked_deepslate_tiles
setblock ~-65 ~36 ~-39 minecraft:cracked_deepslate_tiles
setblock ~-65 ~40 ~-155 minecraft:cracked_deepslate_tiles
setblock ~-65 ~41 ~-37 minecraft:cracked_deepslate_tiles
setblock ~-65 ~47 ~-159 minecraft:cracked_deepslate_tiles
setblock ~-65 ~47 ~-33 minecraft:cracked_deepslate_tiles
setblock ~-64 ~28 ~-90 minecraft:cracked_deepslate_tiles
setblock ~-64 ~32 ~-99 minecraft:cracked_deepslate_tiles
setblock ~-64 ~34 ~-151 minecraft:cracked_deepslate_tiles
fill ~-64 ~36 ~-167 ~-63 ~36 ~-167 minecraft:cracked_deepslate_tiles
setblock ~-64 ~37 ~-167 minecraft:cracked_deepslate_tiles
setblock ~-63 ~38 ~-26 minecraft:cracked_deepslate_tiles
setblock ~-63 ~45 ~-34 minecraft:cracked_deepslate_tiles
setblock ~-62 ~27 ~-90 minecraft:cracked_deepslate_tiles
setblock ~-62 ~28 ~-102 minecraft:cracked_deepslate_tiles
setblock ~-62 ~31 ~-170 minecraft:cracked_deepslate_tiles
setblock ~-62 ~33 ~-23 minecraft:cracked_deepslate_tiles
setblock ~-62 ~34 ~-168 minecraft:cracked_deepslate_tiles
setblock ~-62 ~35 ~-97 minecraft:cracked_deepslate_tiles
setblock ~-62 ~36 ~-39 minecraft:cracked_deepslate_tiles
setblock ~-62 ~44 ~-162 minecraft:cracked_deepslate_tiles
setblock ~-62 ~45 ~-160 minecraft:cracked_deepslate_tiles
setblock ~-62 ~46 ~-31 minecraft:cracked_deepslate_tiles
setblock ~-61 ~27 ~-101 minecraft:cracked_deepslate_tiles
setblock ~-61 ~32 ~-23 minecraft:cracked_deepslate_tiles
setblock ~-61 ~35 ~-39 minecraft:cracked_deepslate_tiles
setblock ~-61 ~37 ~-154 minecraft:cracked_deepslate_tiles
setblock ~-60 ~31 ~-169 minecraft:cracked_deepslate_tiles
setblock ~-60 ~41 ~-158 minecraft:cracked_deepslate_tiles
setblock ~-60 ~43 ~-31 minecraft:cracked_deepslate_tiles
setblock ~-59 ~38 ~-27 minecraft:cracked_deepslate_tiles
setblock ~-58 ~35 ~-166 minecraft:cracked_deepslate_tiles
setblock ~-58 ~36 ~-37 minecraft:cracked_deepslate_tiles
setblock ~-57 ~37 ~-35 minecraft:cracked_deepslate_tiles
setblock ~-56 ~33 ~-155 minecraft:cracked_deepslate_tiles
setblock ~-56 ~34 ~-33 minecraft:cracked_deepslate_tiles
setblock ~-55 ~31 ~-156 minecraft:cracked_deepslate_tiles
setblock ~-55 ~31 ~-38 minecraft:cracked_deepslate_tiles
setblock ~-55 ~32 ~-164 minecraft:cracked_deepslate_tiles
setblock ~-55 ~32 ~-37 minecraft:cracked_deepslate_tiles
setblock ~-55 ~33 ~-159 minecraft:cracked_deepslate_tiles
setblock ~-54 ~31 ~-163 minecraft:cracked_deepslate_tiles
setblock ~-52 ~-23 ~-129 minecraft:cracked_deepslate_tiles
fill ~-36 ~-27 ~-127 ~-36 ~-24 ~-127 minecraft:cracked_deepslate_tiles
setblock ~-33 ~-23 ~-129 minecraft:cracked_deepslate_tiles
setblock ~-31 ~54 ~-144 minecraft:cracked_deepslate_tiles
setblock ~-29 ~57 ~-102 minecraft:cracked_deepslate_tiles
setblock ~-27 ~54 ~-151 minecraft:cracked_deepslate_tiles
setblock ~-27 ~56 ~-143 minecraft:cracked_deepslate_tiles
setblock ~-27 ~59 ~-100 minecraft:cracked_deepslate_tiles
setblock ~-25 ~61 ~-102 minecraft:cracked_deepslate_tiles
setblock ~-24 ~60 ~-146 minecraft:cracked_deepslate_tiles
setblock ~-23 ~56 ~-101 minecraft:cracked_deepslate_tiles
setblock ~-23 ~57 ~-104 minecraft:cracked_deepslate_tiles
setblock ~-22 ~54 ~-105 minecraft:cracked_deepslate_tiles
setblock ~-22 ~56 ~-145 minecraft:cracked_deepslate_tiles
setblock ~-21 ~54 ~-104 minecraft:cracked_deepslate_tiles
setblock ~-20 ~33 ~-27 minecraft:cracked_deepslate_tiles
setblock ~-18 ~36 ~-34 minecraft:cracked_deepslate_tiles
setblock ~-17 ~34 ~-36 minecraft:cracked_deepslate_tiles
setblock ~-15 ~31 ~-23 minecraft:cracked_deepslate_tiles
setblock ~-14 ~41 ~-31 minecraft:cracked_deepslate_tiles
setblock ~-13 ~40 ~-30 minecraft:cracked_deepslate_tiles
setblock ~-12 ~31 ~-36 minecraft:cracked_deepslate_tiles
setblock ~-12 ~34 ~-35 minecraft:cracked_deepslate_tiles
setblock ~-10 ~33 ~-27 minecraft:cracked_deepslate_tiles
setblock ~-9 ~31 ~-34 minecraft:cracked_deepslate_tiles
setblock ~-9 ~31 ~-25 minecraft:cracked_deepslate_tiles
setblock ~-9 ~34 ~-31 minecraft:cracked_deepslate_tiles
setblock ~-8 ~31 ~-27 minecraft:cracked_deepslate_tiles
setblock ~-7 ~67 ~-131 minecraft:cracked_deepslate_tiles
setblock ~-7 ~70 ~-125 minecraft:cracked_deepslate_tiles
setblock ~-6 ~27 ~-159 minecraft:cracked_deepslate_tiles
setblock ~-6 ~27 ~-157 minecraft:cracked_deepslate_tiles
setblock ~-6 ~71 ~-127 minecraft:cracked_deepslate_tiles
setblock ~-5 ~29 ~-163 minecraft:cracked_deepslate_tiles
setblock ~-5 ~72 ~-129 minecraft:cracked_deepslate_tiles
setblock ~-5 ~74 ~-124 minecraft:cracked_deepslate_tiles
setblock ~-4 ~27 ~-165 minecraft:cracked_deepslate_tiles
setblock ~-4 ~30 ~-161 minecraft:cracked_deepslate_tiles
setblock ~-4 ~32 ~-161 minecraft:cracked_deepslate_tiles
setblock ~-4 ~72 ~-119 minecraft:cracked_deepslate_tiles
setblock ~-4 ~76 ~-127 minecraft:cracked_deepslate_tiles
setblock ~-3 ~28 ~-155 minecraft:cracked_deepslate_tiles
setblock ~-2 ~31 ~-156 minecraft:cracked_deepslate_tiles
fill ~-2 ~74 ~-129 ~-2 ~75 ~-129 minecraft:cracked_deepslate_tiles
setblock ~-2 ~77 ~-127 minecraft:cracked_deepslate_tiles
setblock ~-2 ~78 ~-121 minecraft:cracked_deepslate_tiles
setblock ~-1 ~36 ~-161 minecraft:cracked_deepslate_tiles
setblock ~-1 ~79 ~-121 minecraft:cracked_deepslate_tiles
setblock ~ ~71 ~-117 minecraft:cracked_deepslate_tiles
setblock ~ ~76 ~-128 minecraft:cracked_deepslate_tiles
setblock ~1 ~32 ~-157 minecraft:cracked_deepslate_tiles
setblock ~1 ~35 ~-162 minecraft:cracked_deepslate_tiles
fill ~1 ~70 ~-117 ~2 ~70 ~-117 minecraft:cracked_deepslate_tiles
setblock ~2 ~28 ~-166 minecraft:cracked_deepslate_tiles
setblock ~2 ~28 ~-154 minecraft:cracked_deepslate_tiles
setblock ~3 ~29 ~-165 minecraft:cracked_deepslate_tiles
setblock ~3 ~33 ~-159 minecraft:cracked_deepslate_tiles
setblock ~3 ~67 ~-133 minecraft:cracked_deepslate_tiles
setblock ~3 ~78 ~-126 minecraft:cracked_deepslate_tiles
setblock ~3 ~79 ~-123 minecraft:cracked_deepslate_tiles
setblock ~6 ~28 ~-162 minecraft:cracked_deepslate_tiles
setblock ~7 ~69 ~-128 minecraft:cracked_deepslate_tiles
setblock ~8 ~67 ~-128 minecraft:cracked_deepslate_tiles
setblock ~10 ~34 ~-32 minecraft:cracked_deepslate_tiles
setblock ~10 ~35 ~-30 minecraft:cracked_deepslate_tiles
setblock ~11 ~36 ~-32 minecraft:cracked_deepslate_tiles
setblock ~12 ~33 ~-36 minecraft:cracked_deepslate_tiles
setblock ~12 ~35 ~-34 minecraft:cracked_deepslate_tiles
setblock ~12 ~38 ~-30 minecraft:cracked_deepslate_tiles
setblock ~13 ~32 ~-23 minecraft:cracked_deepslate_tiles
setblock ~15 ~31 ~-23 minecraft:cracked_deepslate_tiles
setblock ~15 ~44 ~-30 minecraft:cracked_deepslate_tiles
setblock ~17 ~32 ~-24 minecraft:cracked_deepslate_tiles
setblock ~17 ~39 ~-28 minecraft:cracked_deepslate_tiles
setblock ~17 ~40 ~-31 minecraft:cracked_deepslate_tiles
setblock ~18 ~31 ~-23 minecraft:cracked_deepslate_tiles
setblock ~21 ~53 ~-144 minecraft:cracked_deepslate_tiles
setblock ~21 ~54 ~-146 minecraft:cracked_deepslate_tiles
setblock ~22 ~32 ~-29 minecraft:cracked_deepslate_tiles
setblock ~22 ~54 ~-147 minecraft:cracked_deepslate_tiles
setblock ~23 ~55 ~-149 minecraft:cracked_deepslate_tiles
setblock ~23 ~57 ~-145 minecraft:cracked_deepslate_tiles
setblock ~24 ~55 ~-143 minecraft:cracked_deepslate_tiles
setblock ~24 ~57 ~-99 minecraft:cracked_deepslate_tiles
setblock ~25 ~60 ~-103 minecraft:cracked_deepslate_tiles
setblock ~26 ~53 ~-151 minecraft:cracked_deepslate_tiles
setblock ~26 ~54 ~-107 minecraft:cracked_deepslate_tiles
setblock ~27 ~60 ~-146 minecraft:cracked_deepslate_tiles
setblock ~28 ~56 ~-149 minecraft:cracked_deepslate_tiles
setblock ~28 ~59 ~-103 minecraft:cracked_deepslate_tiles
setblock ~29 ~53 ~-151 minecraft:cracked_deepslate_tiles
setblock ~29 ~56 ~-145 minecraft:cracked_deepslate_tiles
setblock ~29 ~58 ~-103 minecraft:cracked_deepslate_tiles
fill ~30 ~54 ~-105 ~30 ~54 ~-104 minecraft:cracked_deepslate_tiles
fill ~31 ~-27 ~-129 ~31 ~-24 ~-128 minecraft:cracked_deepslate_tiles
setblock ~31 ~54 ~-147 minecraft:cracked_deepslate_tiles
fill ~33 ~-27 ~-98 ~33 ~-24 ~-98 minecraft:cracked_deepslate_tiles
fill ~33 ~-27 ~-96 ~33 ~-24 ~-96 minecraft:cracked_deepslate_tiles
setblock ~33 ~-23 ~-112 minecraft:cracked_deepslate_tiles
setblock ~34 ~-23 ~-96 minecraft:cracked_deepslate_tiles
fill ~35 ~-27 ~-121 ~35 ~-24 ~-121 minecraft:cracked_deepslate_tiles
fill ~35 ~-27 ~-77 ~35 ~-24 ~-77 minecraft:cracked_deepslate_tiles
setblock ~35 ~-23 ~-70 minecraft:cracked_deepslate_tiles
setblock ~54 ~31 ~-33 minecraft:cracked_deepslate_tiles
setblock ~54 ~32 ~-31 minecraft:cracked_deepslate_tiles
setblock ~55 ~32 ~-29 minecraft:cracked_deepslate_tiles
setblock ~55 ~33 ~-157 minecraft:cracked_deepslate_tiles
setblock ~55 ~34 ~-161 minecraft:cracked_deepslate_tiles
setblock ~56 ~34 ~-36 minecraft:cracked_deepslate_tiles
setblock ~57 ~34 ~-155 minecraft:cracked_deepslate_tiles
setblock ~58 ~31 ~-23 minecraft:cracked_deepslate_tiles
setblock ~58 ~32 ~-152 minecraft:cracked_deepslate_tiles
setblock ~58 ~35 ~-27 minecraft:cracked_deepslate_tiles
setblock ~59 ~27 ~-92 minecraft:cracked_deepslate_tiles
setblock ~59 ~29 ~-93 minecraft:cracked_deepslate_tiles
setblock ~59 ~40 ~-157 minecraft:cracked_deepslate_tiles
setblock ~60 ~29 ~-92 minecraft:cracked_deepslate_tiles
setblock ~60 ~33 ~-168 minecraft:cracked_deepslate_tiles
setblock ~60 ~36 ~-25 minecraft:cracked_deepslate_tiles
setblock ~60 ~38 ~-37 minecraft:cracked_deepslate_tiles
setblock ~60 ~41 ~-30 minecraft:cracked_deepslate_tiles
setblock ~60 ~42 ~-33 minecraft:cracked_deepslate_tiles
setblock ~61 ~29 ~-91 minecraft:cracked_deepslate_tiles
setblock ~61 ~32 ~-96 minecraft:cracked_deepslate_tiles
setblock ~61 ~35 ~-152 minecraft:cracked_deepslate_tiles
setblock ~61 ~37 ~-167 minecraft:cracked_deepslate_tiles
setblock ~61 ~38 ~-166 minecraft:cracked_deepslate_tiles
setblock ~61 ~41 ~-156 minecraft:cracked_deepslate_tiles
setblock ~62 ~29 ~-101 minecraft:cracked_deepslate_tiles
setblock ~62 ~34 ~-168 minecraft:cracked_deepslate_tiles
setblock ~62 ~40 ~-165 minecraft:cracked_deepslate_tiles
setblock ~62 ~44 ~-162 minecraft:cracked_deepslate_tiles
setblock ~63 ~31 ~-22 minecraft:cracked_deepslate_tiles
setblock ~63 ~39 ~-154 minecraft:cracked_deepslate_tiles
setblock ~63 ~46 ~-34 minecraft:cracked_deepslate_tiles
setblock ~63 ~48 ~-159 minecraft:cracked_deepslate_tiles
setblock ~64 ~32 ~-42 minecraft:cracked_deepslate_tiles
setblock ~64 ~33 ~-93 minecraft:cracked_deepslate_tiles
setblock ~64 ~37 ~-25 minecraft:cracked_deepslate_tiles
setblock ~64 ~38 ~-166 minecraft:cracked_deepslate_tiles
setblock ~64 ~45 ~-30 minecraft:cracked_deepslate_tiles
setblock ~65 ~32 ~-99 minecraft:cracked_deepslate_tiles
setblock ~65 ~32 ~-93 minecraft:cracked_deepslate_tiles
setblock ~65 ~32 ~-22 minecraft:cracked_deepslate_tiles
setblock ~65 ~37 ~-153 minecraft:cracked_deepslate_tiles
setblock ~65 ~39 ~-38 minecraft:cracked_deepslate_tiles
setblock ~65 ~41 ~-37 minecraft:cracked_deepslate_tiles
setblock ~66 ~34 ~-97 minecraft:cracked_deepslate_tiles
setblock ~66 ~44 ~-163 minecraft:cracked_deepslate_tiles
setblock ~66 ~44 ~-30 minecraft:cracked_deepslate_tiles
setblock ~66 ~45 ~-33 minecraft:cracked_deepslate_tiles
setblock ~67 ~38 ~-26 minecraft:cracked_deepslate_tiles
setblock ~67 ~40 ~-28 minecraft:cracked_deepslate_tiles
setblock ~68 ~35 ~-25 minecraft:cracked_deepslate_tiles
setblock ~68 ~40 ~-157 minecraft:cracked_deepslate_tiles
setblock ~68 ~43 ~-159 minecraft:cracked_deepslate_tiles
setblock ~69 ~27 ~-92 minecraft:cracked_deepslate_tiles
setblock ~69 ~37 ~-155 minecraft:cracked_deepslate_tiles
setblock ~69 ~41 ~-160 minecraft:cracked_deepslate_tiles
setblock ~70 ~27 ~-97 minecraft:cracked_deepslate_tiles
setblock ~70 ~37 ~-157 minecraft:cracked_deepslate_tiles
setblock ~70 ~39 ~-158 minecraft:cracked_deepslate_tiles
setblock ~70 ~39 ~-30 minecraft:cracked_deepslate_tiles
setblock ~72 ~33 ~-28 minecraft:cracked_deepslate_tiles
setblock ~72 ~34 ~-163 minecraft:cracked_deepslate_tiles
setblock ~73 ~32 ~-162 minecraft:cracked_deepslate_tiles
setblock ~74 ~31 ~-164 minecraft:cracked_deepslate_tiles
setblock ~74 ~31 ~-159 minecraft:cracked_deepslate_tiles
setblock ~74 ~31 ~-33 minecraft:cracked_deepslate_tiles
fill ~-54 ~1 ~-112 ~-54 ~5 ~-112 minecraft:spruce_log
fill ~-54 ~1 ~-92 ~-54 ~5 ~-92 minecraft:spruce_log
fill ~-54 ~1 ~-84 ~-54 ~5 ~-84 minecraft:spruce_log
fill ~-54 ~1 ~-66 ~-54 ~5 ~-66 minecraft:spruce_log
fill ~-50 ~1 ~-56 ~-50 ~4 ~-56 minecraft:spruce_log
fill ~-50 ~1 ~-49 ~-50 ~4 ~-49 minecraft:spruce_log
fill ~-43 ~1 ~-56 ~-43 ~4 ~-56 minecraft:spruce_log
fill ~-43 ~1 ~-49 ~-43 ~4 ~-49 minecraft:spruce_log
fill ~-40 ~1 ~-84 ~-40 ~5 ~-84 minecraft:spruce_log
fill ~-40 ~1 ~-66 ~-40 ~5 ~-66 minecraft:spruce_log
fill ~-40 ~1 ~-56 ~-40 ~4 ~-56 minecraft:spruce_log
fill ~-40 ~1 ~-49 ~-40 ~4 ~-49 minecraft:spruce_log
fill ~-36 ~1 ~-112 ~-36 ~5 ~-112 minecraft:spruce_log
fill ~-36 ~1 ~-92 ~-36 ~5 ~-92 minecraft:spruce_log
fill ~-33 ~1 ~-56 ~-33 ~4 ~-56 minecraft:spruce_log
fill ~-33 ~1 ~-49 ~-33 ~4 ~-49 minecraft:spruce_log
fill ~32 ~1 ~-56 ~32 ~4 ~-56 minecraft:spruce_log
fill ~32 ~1 ~-49 ~32 ~4 ~-49 minecraft:spruce_log
fill ~36 ~1 ~-138 ~36 ~6 ~-138 minecraft:spruce_log
fill ~36 ~1 ~-120 ~36 ~6 ~-120 minecraft:spruce_log
fill ~38 ~1 ~-112 ~38 ~5 ~-112 minecraft:spruce_log
fill ~38 ~1 ~-92 ~38 ~5 ~-92 minecraft:spruce_log
fill ~39 ~1 ~-56 ~39 ~4 ~-56 minecraft:spruce_log
fill ~39 ~1 ~-49 ~39 ~4 ~-49 minecraft:spruce_log
fill ~42 ~1 ~-56 ~42 ~4 ~-56 minecraft:spruce_log
fill ~42 ~1 ~-49 ~42 ~4 ~-49 minecraft:spruce_log
fill ~49 ~1 ~-56 ~49 ~4 ~-56 minecraft:spruce_log
fill ~49 ~1 ~-49 ~49 ~4 ~-49 minecraft:spruce_log
fill ~54 ~1 ~-138 ~54 ~6 ~-138 minecraft:spruce_log
fill ~54 ~1 ~-120 ~54 ~6 ~-120 minecraft:spruce_log
fill ~54 ~1 ~-112 ~54 ~5 ~-112 minecraft:spruce_log
fill ~54 ~1 ~-92 ~54 ~5 ~-92 minecraft:spruce_log
fill ~-24 ~ ~-136 ~-24 ~ ~-128 minecraft:barrel[facing=east,open=false]
fill ~2 ~-8 ~-116 ~23 ~-3 ~-107 minecraft:barrel[facing=east,open=false]
fill ~2 ~-8 ~-106 ~22 ~-3 ~-104 minecraft:barrel[facing=east,open=false]
fill ~-83 ~-12 ~-128 ~-83 ~-7 ~-128 minecraft:redstone_block
fill ~-79 ~-13 ~-128 ~-75 ~-13 ~-127 minecraft:redstone_block
fill ~-78 ~-14 ~-128 ~-74 ~-14 ~-127 minecraft:redstone_block
fill ~-77 ~-15 ~-128 ~-73 ~-15 ~-127 minecraft:redstone_block
fill ~-76 ~-16 ~-128 ~-72 ~-16 ~-127 minecraft:redstone_block
fill ~-75 ~-17 ~-128 ~-71 ~-17 ~-127 minecraft:redstone_block
fill ~-74 ~-18 ~-128 ~-70 ~-18 ~-127 minecraft:redstone_block
fill ~-73 ~-19 ~-128 ~-69 ~-19 ~-127 minecraft:redstone_block
fill ~-72 ~-20 ~-128 ~-68 ~-20 ~-127 minecraft:redstone_block
fill ~-71 ~-21 ~-128 ~-67 ~-21 ~-127 minecraft:redstone_block
fill ~-70 ~-22 ~-128 ~-66 ~-22 ~-127 minecraft:redstone_block
fill ~-69 ~-23 ~-128 ~-65 ~-23 ~-127 minecraft:redstone_block
fill ~-68 ~-24 ~-128 ~-31 ~-24 ~-127 minecraft:redstone_block
fill ~-67 ~-25 ~-128 ~-31 ~-24 ~-127 minecraft:redstone_block
fill ~-66 ~-26 ~-128 ~35 ~-26 ~-128 minecraft:redstone_block
fill ~-65 ~-27 ~-128 ~-65 ~-23 ~-128 minecraft:redstone_block
fill ~-63 ~-27 ~-128 ~-63 ~-24 ~-128 minecraft:redstone_block
fill ~-59 ~-27 ~-128 ~-59 ~-24 ~-128 minecraft:redstone_block
fill ~-55 ~-27 ~-128 ~-55 ~-24 ~-128 minecraft:redstone_block
fill ~-51 ~-27 ~-128 ~-51 ~-24 ~-128 minecraft:redstone_block
fill ~-47 ~-27 ~-128 ~-47 ~-24 ~-128 minecraft:redstone_block
fill ~-43 ~-27 ~-128 ~-43 ~-24 ~-128 minecraft:redstone_block
fill ~-39 ~-27 ~-128 ~-39 ~-24 ~-128 minecraft:redstone_block
fill ~-35 ~-27 ~-128 ~-35 ~-24 ~-128 minecraft:redstone_block
fill ~-31 ~-27 ~-128 ~-31 ~-24 ~-128 minecraft:redstone_block
fill ~-27 ~-27 ~-128 ~-27 ~-19 ~-128 minecraft:redstone_block
fill ~-23 ~-27 ~-128 ~-23 ~-19 ~-128 minecraft:redstone_block
fill ~-19 ~-27 ~-128 ~-19 ~-19 ~-128 minecraft:redstone_block
fill ~-15 ~-27 ~-128 ~-15 ~-19 ~-128 minecraft:redstone_block
fill ~-11 ~-27 ~-128 ~-11 ~-19 ~-128 minecraft:redstone_block
fill ~-7 ~-27 ~-128 ~-7 ~-19 ~-128 minecraft:redstone_block
fill ~7 ~-27 ~-128 ~7 ~-19 ~-128 minecraft:redstone_block
fill ~11 ~-27 ~-128 ~11 ~-19 ~-128 minecraft:redstone_block
fill ~15 ~-27 ~-128 ~15 ~-19 ~-128 minecraft:redstone_block
fill ~19 ~-27 ~-128 ~19 ~-19 ~-128 minecraft:redstone_block
fill ~23 ~-27 ~-128 ~23 ~-19 ~-128 minecraft:redstone_block
fill ~27 ~-27 ~-128 ~27 ~-19 ~-128 minecraft:redstone_block
fill ~31 ~-27 ~-128 ~31 ~-24 ~-128 minecraft:redstone_block
fill ~34 ~-27 ~-127 ~34 ~-24 ~-127 minecraft:redstone_block
fill ~34 ~-27 ~-123 ~34 ~-24 ~-123 minecraft:redstone_block
fill ~34 ~-27 ~-119 ~34 ~-24 ~-119 minecraft:redstone_block
fill ~34 ~-27 ~-115 ~34 ~-24 ~-115 minecraft:redstone_block
fill ~34 ~-27 ~-111 ~34 ~-24 ~-111 minecraft:redstone_block
fill ~34 ~-27 ~-107 ~34 ~-24 ~-107 minecraft:redstone_block
fill ~34 ~-27 ~-103 ~34 ~-24 ~-103 minecraft:redstone_block
fill ~34 ~-27 ~-99 ~34 ~-24 ~-99 minecraft:redstone_block
fill ~34 ~-27 ~-95 ~34 ~-24 ~-95 minecraft:redstone_block
fill ~34 ~-27 ~-91 ~34 ~-24 ~-91 minecraft:redstone_block
fill ~34 ~-27 ~-87 ~34 ~-24 ~-87 minecraft:redstone_block
fill ~34 ~-27 ~-83 ~34 ~-24 ~-83 minecraft:redstone_block
fill ~34 ~-27 ~-79 ~34 ~-24 ~-79 minecraft:redstone_block
fill ~34 ~-27 ~-75 ~34 ~-24 ~-75 minecraft:redstone_block
fill ~34 ~-27 ~-71 ~34 ~-24 ~-71 minecraft:redstone_block
fill ~34 ~-27 ~-67 ~34 ~-19 ~-67 minecraft:redstone_block
fill ~34 ~-27 ~-63 ~34 ~-19 ~-63 minecraft:redstone_block
fill ~34 ~-27 ~-59 ~34 ~-19 ~-59 minecraft:redstone_block
fill ~34 ~-27 ~-55 ~34 ~-19 ~-55 minecraft:redstone_block
fill ~-99 ~ ~-120 ~-97 ~ ~-120 minecraft:azalea_leaves[persistent=true,distance=1,waterlogged=false]
setblock ~-99 ~ ~-119 minecraft:azalea_leaves[persistent=true,distance=1,waterlogged=false]
setblock ~-97 ~ ~-119 minecraft:azalea_leaves[persistent=true,distance=1,waterlogged=false]
fill ~-19 ~ ~-98 ~-8 ~ ~-98 minecraft:azalea_leaves[persistent=true,distance=1,waterlogged=false]
fill ~-19 ~ ~-84 ~-8 ~ ~-84 minecraft:azalea_leaves[persistent=true,distance=1,waterlogged=false]
fill ~8 ~ ~-98 ~19 ~ ~-98 minecraft:azalea_leaves[persistent=true,distance=1,waterlogged=false]
fill ~8 ~ ~-84 ~19 ~ ~-84 minecraft:azalea_leaves[persistent=true,distance=1,waterlogged=false]
fill ~-5 ~-1 ~-23 ~-5 ~ ~-4 minecraft:dark_oak_log[axis=z]
fill ~5 ~-1 ~-23 ~5 ~ ~-4 minecraft:dark_oak_log[axis=z]
fill ~52 ~ ~-110 ~52 ~1 ~-94 minecraft:barrel[facing=west,open=false]
setblock ~-19 ~ ~-89 minecraft:azure_bluet
setblock ~-18 ~ ~-92 minecraft:azure_bluet
setblock ~-17 ~ ~-95 minecraft:azure_bluet
setblock ~-15 ~ ~-87 minecraft:azure_bluet
setblock ~-14 ~ ~-90 minecraft:azure_bluet
setblock ~-13 ~ ~-93 minecraft:azure_bluet
setblock ~-12 ~ ~-96 minecraft:azure_bluet
setblock ~-10 ~ ~-88 minecraft:azure_bluet
setblock ~-9 ~ ~-91 minecraft:azure_bluet
setblock ~-8 ~ ~-155 minecraft:azure_bluet
setblock ~-8 ~ ~-94 minecraft:azure_bluet
setblock ~8 ~ ~-86 minecraft:azure_bluet
setblock ~9 ~ ~-89 minecraft:azure_bluet
setblock ~10 ~ ~-92 minecraft:azure_bluet
setblock ~11 ~ ~-95 minecraft:azure_bluet
setblock ~13 ~ ~-87 minecraft:azure_bluet
setblock ~14 ~ ~-90 minecraft:azure_bluet
setblock ~15 ~ ~-93 minecraft:azure_bluet
setblock ~16 ~ ~-96 minecraft:azure_bluet
setblock ~18 ~ ~-88 minecraft:azure_bluet
setblock ~19 ~ ~-91 minecraft:azure_bluet
setblock ~48 ~ ~-155 minecraft:azure_bluet
setblock ~48 ~ ~-39 minecraft:azure_bluet
setblock ~-10 ~34 ~-144 minecraft:note_block
setblock ~-10 ~34 ~-140 minecraft:note_block
setblock ~-10 ~34 ~-136 minecraft:note_block
setblock ~-10 ~34 ~-132 minecraft:note_block
setblock ~-10 ~34 ~-128 minecraft:note_block
setblock ~-10 ~34 ~-124 minecraft:note_block
setblock ~-10 ~34 ~-120 minecraft:note_block
setblock ~-10 ~34 ~-116 minecraft:note_block
setblock ~-10 ~34 ~-112 minecraft:note_block
setblock ~-10 ~34 ~-108 minecraft:note_block
setblock ~-10 ~34 ~-104 minecraft:note_block
setblock ~10 ~34 ~-144 minecraft:note_block
setblock ~10 ~34 ~-140 minecraft:note_block
setblock ~10 ~34 ~-136 minecraft:note_block
setblock ~10 ~34 ~-132 minecraft:note_block
setblock ~10 ~34 ~-128 minecraft:note_block
setblock ~10 ~34 ~-124 minecraft:note_block
setblock ~10 ~34 ~-120 minecraft:note_block
setblock ~10 ~34 ~-116 minecraft:note_block
setblock ~10 ~34 ~-112 minecraft:note_block
setblock ~10 ~34 ~-108 minecraft:note_block
setblock ~10 ~34 ~-104 minecraft:note_block
fill ~37 ~-26 ~-69 ~43 ~-19 ~-43 minecraft:barrel[facing=south,open=false]
fill ~-5 ~-5 ~-15 ~89 ~-2 ~-7 minecraft:dark_oak_log
fill ~-53 ~ ~-137 ~-51 ~ ~-135 minecraft:quartz_block
fill ~-20 ~34 ~-143 ~-16 ~34 ~-143 minecraft:quartz_block
fill ~-87 ~-11 ~-128 ~-77 ~-11 ~-128 minecraft:polished_blackstone_bricks
fill ~-87 ~-10 ~-128 ~-82 ~-7 ~-100 minecraft:polished_blackstone_bricks
fill ~-2 ~-26 ~-128 ~35 ~-26 ~-128 minecraft:polished_blackstone_bricks
fill ~-2 ~-25 ~-128 ~29 ~-19 ~-126 minecraft:polished_blackstone_bricks
fill ~34 ~-26 ~-50 ~43 ~-19 ~-43 minecraft:polished_blackstone_bricks
setblock ~-7 ~9 ~-143 minecraft:chiseled_deepslate
setblock ~-7 ~9 ~-136 minecraft:chiseled_deepslate
setblock ~-7 ~9 ~-129 minecraft:chiseled_deepslate
setblock ~-7 ~9 ~-122 minecraft:chiseled_deepslate
setblock ~-7 ~9 ~-115 minecraft:chiseled_deepslate
setblock ~-7 ~9 ~-108 minecraft:chiseled_deepslate
setblock ~7 ~9 ~-143 minecraft:chiseled_deepslate
setblock ~7 ~9 ~-136 minecraft:chiseled_deepslate
setblock ~7 ~9 ~-129 minecraft:chiseled_deepslate
setblock ~7 ~9 ~-122 minecraft:chiseled_deepslate
setblock ~7 ~9 ~-115 minecraft:chiseled_deepslate
setblock ~7 ~9 ~-108 minecraft:chiseled_deepslate
fill ~-29 ~-26 ~-103 ~-1 ~-19 ~-101 minecraft:barrel[facing=north,open=false]
fill ~13 ~-25 ~-139 ~31 ~-19 ~-137 minecraft:iron_block
setblock ~-5 ~43 ~-138 minecraft:glowstone
setblock ~-5 ~43 ~-130 minecraft:glowstone
setblock ~-5 ~43 ~-118 minecraft:glowstone
setblock ~-5 ~43 ~-110 minecraft:glowstone
setblock ~5 ~43 ~-138 minecraft:glowstone
setblock ~5 ~43 ~-130 minecraft:glowstone
setblock ~5 ~43 ~-118 minecraft:glowstone
setblock ~5 ~43 ~-110 minecraft:glowstone
setblock ~-45 ~ ~-82 minecraft:furnace[facing=south,lit=false]
fill ~-24 ~ ~-144 ~-13 ~ ~-144 minecraft:furnace[facing=south,lit=false]
fill ~-13 ~10 ~-126 ~-11 ~10 ~-126 minecraft:smooth_stone
fill ~-13 ~10 ~-125 ~-13 ~15 ~-125 minecraft:smooth_stone
fill ~-13 ~14 ~-126 ~-11 ~15 ~-126 minecraft:smooth_stone
fill ~-12 ~11 ~-125 ~-12 ~12 ~-125 minecraft:smooth_stone
fill ~18 ~-25 ~-149 ~31 ~-19 ~-137 minecraft:emerald_block
setblock ~-23 ~ ~-144 minecraft:smoker[facing=south,lit=false]
setblock ~-21 ~ ~-144 minecraft:smoker[facing=south,lit=false]
setblock ~-19 ~ ~-144 minecraft:smoker[facing=south,lit=false]
setblock ~-17 ~ ~-144 minecraft:smoker[facing=south,lit=false]
setblock ~-15 ~ ~-144 minecraft:smoker[facing=south,lit=false]
setblock ~-13 ~ ~-144 minecraft:smoker[facing=south,lit=false]
fill ~8 ~-8 ~-143 ~9 ~-3 ~-117 minecraft:hay_block
fill ~18 ~-8 ~-143 ~19 ~-3 ~-104 minecraft:hay_block
setblock ~52 ~ ~-134 minecraft:hay_block
setblock ~52 ~ ~-130 minecraft:hay_block
setblock ~52 ~ ~-126 minecraft:hay_block
setblock ~52 ~ ~-122 minecraft:hay_block
fill ~13 ~-25 ~-142 ~31 ~-19 ~-140 minecraft:diamond_block
fill ~-81 ~-11 ~-100 ~-80 ~-7 ~-100 minecraft:crafting_table
setblock ~-14 ~ ~-132 minecraft:crafting_table
fill ~4 ~-26 ~-104 ~31 ~-19 ~-101 minecraft:crafting_table
fill ~17 ~-26 ~-43 ~43 ~-19 ~-43 minecraft:crafting_table
fill ~-20 ~-27 ~-140 ~-20 ~11 ~-140 minecraft:soul_sand
fill ~26 ~-27 ~-58 ~26 ~-1 ~-58 minecraft:soul_sand
fill ~-16 ~-27 ~-140 ~-16 ~11 ~-140 minecraft:magma_block
fill ~28 ~-27 ~-58 ~28 ~-1 ~-58 minecraft:magma_block
fill ~5 ~-26 ~-104 ~31 ~-19 ~-101 minecraft:furnace[facing=north,lit=false]
fill ~18 ~-26 ~-43 ~43 ~-19 ~-43 minecraft:furnace[facing=north,lit=false]
setblock ~-15 ~1 ~-135 minecraft:cake
setblock ~-47 ~ ~-82 minecraft:blast_furnace[facing=south,lit=false]
setblock ~-14 ~1 ~-114 minecraft:potted_blue_orchid
setblock ~20 ~12 ~-106 minecraft:potted_azure_bluet
fill ~14 ~-24 ~-138 ~31 ~-19 ~-137 minecraft:beacon
fill ~19 ~-26 ~-43 ~43 ~-19 ~-43 minecraft:smoker[facing=north,lit=false]
fill ~-84 ~-11 ~-100 ~-82 ~-7 ~-100 minecraft:conduit[waterlogged=false]
setblock ~-98 ~1 ~-120 minecraft:flowering_azalea_leaves[persistent=true,distance=1,waterlogged=false]
fill ~-99 ~-11 ~-120 ~-91 ~-11 ~-118 minecraft:air
fill ~-99 ~-10 ~-120 ~-92 ~-10 ~-118 minecraft:air
fill ~-97 ~-10 ~-122 ~-90 ~-10 ~-122 minecraft:air
fill ~-92 ~-11 ~-117 ~-92 ~-10 ~-116 minecraft:air
fill ~-91 ~-11 ~-116 ~-80 ~-10 ~-116 minecraft:air
fill ~-90 ~-9 ~-122 ~-90 ~-9 ~-118 minecraft:air
fill ~-89 ~-1 ~-185 ~89 ~-1 ~-175 minecraft:air
fill ~-89 ~-1 ~-174 ~-79 ~-1 ~-7 minecraft:air
fill ~-88 ~-11 ~-132 ~-80 ~-7 ~-131 minecraft:air
fill ~-88 ~-11 ~-130 ~-82 ~-7 ~-129 minecraft:air
fill ~-88 ~-11 ~-127 ~-82 ~-7 ~-101 minecraft:air
fill ~-88 ~-11 ~-100 ~-85 ~-7 ~-100 minecraft:air
fill ~-88 ~-10 ~-128 ~-88 ~-7 ~-100 minecraft:air
fill ~-87 ~-9 ~-128 ~-82 ~-7 ~-100 minecraft:air
fill ~-85 ~-10 ~-128 ~-82 ~-7 ~-100 minecraft:air
fill ~-83 ~-11 ~-100 ~-82 ~-7 ~-100 minecraft:air
fill ~-81 ~-11 ~-125 ~-80 ~-7 ~-101 minecraft:air
fill ~-81 ~-10 ~-100 ~-80 ~-7 ~-100 minecraft:air
fill ~-81 ~-7 ~-130 ~-80 ~-7 ~-100 minecraft:air
fill ~-80 ~-12 ~-129 ~-76 ~-12 ~-129 minecraft:air
fill ~-80 ~-12 ~-127 ~-76 ~-12 ~-127 minecraft:air
fill ~-80 ~-11 ~-129 ~-77 ~-11 ~-127 minecraft:air
fill ~-80 ~-11 ~-100 ~-80 ~-7 ~-100 minecraft:air
fill ~-80 ~-10 ~-129 ~-78 ~-10 ~-127 minecraft:air
fill ~-79 ~-13 ~-129 ~-75 ~-13 ~-129 minecraft:air
fill ~-79 ~-13 ~-127 ~-75 ~-13 ~-127 minecraft:air
fill ~-78 ~-14 ~-129 ~-74 ~-14 ~-129 minecraft:air
fill ~-78 ~-14 ~-127 ~-74 ~-14 ~-127 minecraft:air
fill ~-78 ~-12 ~-128 ~-76 ~-12 ~-127 minecraft:air
fill ~-78 ~-1 ~-17 ~-6 ~-1 ~-7 minecraft:air
fill ~-77 ~-15 ~-129 ~-73 ~-15 ~-129 minecraft:air
fill ~-77 ~-15 ~-127 ~-73 ~-15 ~-127 minecraft:air
fill ~-77 ~-13 ~-128 ~-75 ~-13 ~-127 minecraft:air
fill ~-76 ~-16 ~-129 ~-72 ~-16 ~-129 minecraft:air
fill ~-76 ~-16 ~-127 ~-72 ~-16 ~-127 minecraft:air
fill ~-76 ~-14 ~-128 ~-74 ~-14 ~-127 minecraft:air
fill ~-75 ~-17 ~-129 ~-71 ~-17 ~-129 minecraft:air
fill ~-75 ~-17 ~-127 ~-71 ~-17 ~-127 minecraft:air
fill ~-75 ~-15 ~-128 ~-73 ~-15 ~-127 minecraft:air
fill ~-74 ~-18 ~-129 ~-70 ~-18 ~-129 minecraft:air
fill ~-74 ~-18 ~-127 ~-70 ~-18 ~-127 minecraft:air
fill ~-74 ~-16 ~-128 ~-72 ~-16 ~-127 minecraft:air
fill ~-73 ~-19 ~-129 ~-69 ~-19 ~-129 minecraft:air
fill ~-73 ~-19 ~-127 ~-69 ~-19 ~-127 minecraft:air
fill ~-73 ~-17 ~-128 ~-71 ~-17 ~-127 minecraft:air
fill ~-72 ~-20 ~-129 ~-68 ~-20 ~-129 minecraft:air
fill ~-72 ~-20 ~-127 ~-68 ~-20 ~-127 minecraft:air
fill ~-72 ~-18 ~-128 ~-70 ~-18 ~-127 minecraft:air
fill ~-71 ~-21 ~-129 ~-67 ~-21 ~-129 minecraft:air
fill ~-71 ~-21 ~-127 ~-67 ~-21 ~-127 minecraft:air
fill ~-71 ~-19 ~-128 ~-69 ~-19 ~-127 minecraft:air
fill ~-70 ~-22 ~-129 ~-66 ~-22 ~-129 minecraft:air
fill ~-70 ~-22 ~-127 ~-66 ~-22 ~-127 minecraft:air
fill ~-70 ~-20 ~-128 ~-68 ~-20 ~-127 minecraft:air
fill ~-69 ~-23 ~-129 ~-65 ~-23 ~-129 minecraft:air
fill ~-69 ~-23 ~-127 ~-65 ~-23 ~-127 minecraft:air
fill ~-69 ~-21 ~-128 ~-67 ~-21 ~-127 minecraft:air
fill ~-68 ~-24 ~-129 ~-31 ~-24 ~-129 minecraft:air
fill ~-68 ~-24 ~-127 ~-31 ~-24 ~-127 minecraft:air
fill ~-68 ~-22 ~-128 ~-66 ~-22 ~-127 minecraft:air
fill ~-67 ~-25 ~-129 ~-31 ~-24 ~-129 minecraft:air
fill ~-67 ~-25 ~-127 ~-31 ~-24 ~-127 minecraft:air
fill ~-67 ~-23 ~-128 ~-65 ~-23 ~-127 minecraft:air
fill ~-66 ~-26 ~-129 ~-31 ~-24 ~-129 minecraft:air
fill ~-66 ~-26 ~-127 ~-31 ~-24 ~-127 minecraft:air
fill ~-66 ~-24 ~-128 ~-31 ~-24 ~-127 minecraft:air
fill ~-65 ~-25 ~-128 ~-31 ~-24 ~-127 minecraft:air
fill ~-31 ~-26 ~-149 ~-12 ~-19 ~-142 minecraft:air
fill ~-31 ~-26 ~-141 ~-22 ~-19 ~-133 minecraft:air
fill ~-31 ~-26 ~-131 ~31 ~-19 ~-131 minecraft:air
fill ~-31 ~-26 ~-124 ~-1 ~-19 ~-123 minecraft:air
fill ~-31 ~-26 ~-122 ~-27 ~-26 ~-104 minecraft:air
fill ~-31 ~-26 ~-103 ~-30 ~-19 ~-101 minecraft:air
fill ~-31 ~-25 ~-122 ~-1 ~-19 ~-120 minecraft:air
fill ~-31 ~-25 ~-119 ~-30 ~-19 ~-101 minecraft:air
fill ~-31 ~-21 ~-130 ~31 ~-19 ~-126 minecraft:air
fill ~-29 ~-30 ~-124 ~-3 ~-28 ~-119 minecraft:air
fill ~-29 ~-27 ~-124 ~-3 ~-19 ~-123 minecraft:air
fill ~-29 ~-27 ~-122 ~-26 ~-27 ~-119 minecraft:air
fill ~-29 ~-26 ~-130 ~29 ~-19 ~-129 minecraft:air
fill ~-29 ~-26 ~-127 ~29 ~-19 ~-126 minecraft:air
fill ~-29 ~-26 ~-102 ~-1 ~-19 ~-101 minecraft:air
fill ~-29 ~-25 ~-128 ~-3 ~-19 ~-126 minecraft:air
fill ~-29 ~-25 ~-118 ~-1 ~-19 ~-101 minecraft:air
fill ~-29 ~-23 ~-119 ~-1 ~-19 ~-101 minecraft:air
fill ~-27 ~-26 ~-103 ~-27 ~-19 ~-101 minecraft:air
fill ~-26 ~-26 ~-118 ~-1 ~-19 ~-104 minecraft:air
fill ~-25 ~-27 ~-119 ~-3 ~-27 ~-119 minecraft:air
fill ~-24 ~-27 ~-122 ~-23 ~-27 ~-119 minecraft:air
fill ~-24 ~-26 ~-122 ~-24 ~-19 ~-120 minecraft:air
fill ~-24 ~-26 ~-103 ~-24 ~-19 ~-101 minecraft:air
fill ~-21 ~-27 ~-122 ~-20 ~-27 ~-119 minecraft:air
fill ~-21 ~-26 ~-138 ~-12 ~-19 ~-133 minecraft:air
fill ~-21 ~-26 ~-132 ~-19 ~-24 ~-126 minecraft:air
fill ~-21 ~-26 ~-122 ~-21 ~-19 ~-120 minecraft:air
fill ~-21 ~-26 ~-103 ~-21 ~-19 ~-101 minecraft:air
fill ~-18 ~-27 ~-122 ~-17 ~-27 ~-119 minecraft:air
fill ~-18 ~-26 ~-141 ~-18 ~-19 ~-133 minecraft:air
fill ~-18 ~-26 ~-122 ~-18 ~-19 ~-120 minecraft:air
fill ~-18 ~-26 ~-103 ~-18 ~-19 ~-101 minecraft:air
fill ~-16 ~-26 ~-125 ~-14 ~-24 ~-123 minecraft:air
fill ~-15 ~-27 ~-122 ~-14 ~-27 ~-119 minecraft:air
fill ~-15 ~-26 ~-122 ~-15 ~-19 ~-120 minecraft:air
fill ~-15 ~-26 ~-103 ~-15 ~-19 ~-101 minecraft:air
fill ~-14 ~-26 ~-141 ~-12 ~-19 ~-133 minecraft:air
fill ~-12 ~-27 ~-122 ~-11 ~-27 ~-119 minecraft:air
fill ~-12 ~-26 ~-122 ~-12 ~-19 ~-120 minecraft:air
fill ~-12 ~-26 ~-103 ~-12 ~-19 ~-101 minecraft:air
fill ~-10 ~-26 ~-148 ~10 ~-19 ~-145 minecraft:air
fill ~-10 ~-26 ~-144 ~-7 ~-19 ~-133 minecraft:air
fill ~-10 ~-23 ~-149 ~10 ~-19 ~-133 minecraft:air
fill ~-9 ~-27 ~-122 ~-8 ~-27 ~-119 minecraft:air
fill ~-9 ~-26 ~-122 ~-9 ~-19 ~-120 minecraft:air
fill ~-9 ~-26 ~-103 ~-9 ~-19 ~-101 minecraft:air
fill ~-6 ~-27 ~-122 ~-5 ~-27 ~-119 minecraft:air
fill ~-6 ~-26 ~-137 ~10 ~-19 ~-133 minecraft:air
fill ~-6 ~-26 ~-122 ~-6 ~-19 ~-120 minecraft:air
fill ~-6 ~-26 ~-103 ~-6 ~-19 ~-101 minecraft:air
fill ~-6 ~-25 ~-144 ~10 ~-19 ~-133 minecraft:air
fill ~-4 ~-26 ~-119 ~-1 ~-26 ~-104 minecraft:air
fill ~-3 ~-27 ~-122 ~-3 ~-26 ~-119 minecraft:air
fill ~-3 ~-26 ~-103 ~-3 ~-19 ~-101 minecraft:air
fill ~-2 ~-26 ~-122 ~-1 ~-19 ~-104 minecraft:air
fill ~-2 ~-24 ~-128 ~29 ~-19 ~-126 minecraft:air
fill ~-1 ~-26 ~-132 ~1 ~-24 ~-129 minecraft:air
fill ~ ~-8 ~-144 ~4 ~-3 ~-117 minecraft:air
fill ~ ~-8 ~-116 ~1 ~-3 ~-104 minecraft:air
fill ~1 ~-26 ~-124 ~31 ~-19 ~-105 minecraft:air
fill ~1 ~-26 ~-104 ~3 ~-19 ~-101 minecraft:air
fill ~2 ~-8 ~-115 ~23 ~-3 ~-115 minecraft:air
fill ~2 ~-8 ~-113 ~23 ~-3 ~-113 minecraft:air
fill ~2 ~-8 ~-111 ~23 ~-3 ~-111 minecraft:air
fill ~2 ~-8 ~-109 ~23 ~-3 ~-109 minecraft:air
fill ~2 ~-8 ~-107 ~23 ~-3 ~-107 minecraft:air
fill ~2 ~-8 ~-105 ~23 ~-3 ~-104 minecraft:air
fill ~2 ~-6 ~-116 ~23 ~-3 ~-107 minecraft:air
fill ~2 ~-6 ~-106 ~22 ~-3 ~-104 minecraft:air
fill ~4 ~-26 ~-103 ~31 ~-19 ~-101 minecraft:air
fill ~4 ~-25 ~-128 ~29 ~-19 ~-126 minecraft:air
fill ~4 ~-25 ~-104 ~31 ~-19 ~-101 minecraft:air
fill ~5 ~-8 ~-137 ~24 ~-5 ~-137 minecraft:air
fill ~5 ~-8 ~-136 ~23 ~-3 ~-117 minecraft:air
fill ~5 ~-4 ~-137 ~23 ~-3 ~-107 minecraft:air
fill ~6 ~-8 ~-144 ~9 ~-3 ~-144 minecraft:air
fill ~6 ~-8 ~-143 ~7 ~-3 ~-117 minecraft:air
fill ~6 ~-1 ~-17 ~89 ~-1 ~-7 minecraft:air
fill ~7 ~-26 ~-144 ~10 ~-19 ~-133 minecraft:air
fill ~7 ~-26 ~-104 ~31 ~-19 ~-101 minecraft:air
fill ~8 ~-8 ~-142 ~9 ~-3 ~-117 minecraft:air
fill ~8 ~-7 ~-143 ~9 ~-3 ~-117 minecraft:air
fill ~9 ~-8 ~-143 ~9 ~-3 ~-104 minecraft:air
fill ~10 ~-8 ~-116 ~23 ~-3 ~-107 minecraft:air
fill ~10 ~-8 ~-106 ~22 ~-3 ~-104 minecraft:air
fill ~11 ~-26 ~-69 ~31 ~-19 ~-60 minecraft:air
fill ~11 ~-26 ~-58 ~24 ~-19 ~-53 minecraft:air
fill ~11 ~-26 ~-52 ~15 ~-19 ~-43 minecraft:air
fill ~11 ~-25 ~-59 ~24 ~-19 ~-43 minecraft:air
fill ~11 ~-8 ~-144 ~14 ~-3 ~-104 minecraft:air
fill ~12 ~-26 ~-134 ~13 ~-24 ~-134 minecraft:air
fill ~12 ~-25 ~-149 ~17 ~-19 ~-143 minecraft:air
fill ~12 ~-25 ~-142 ~12 ~-19 ~-137 minecraft:air
fill ~12 ~-24 ~-135 ~24 ~-24 ~-134 minecraft:air
fill ~13 ~-26 ~-59 ~24 ~-19 ~-53 minecraft:air
fill ~13 ~-25 ~-141 ~31 ~-19 ~-140 minecraft:air
fill ~13 ~-24 ~-142 ~31 ~-19 ~-139 minecraft:air
fill ~13 ~-24 ~-138 ~13 ~-19 ~-137 minecraft:air
fill ~14 ~-26 ~-125 ~16 ~-24 ~-101 minecraft:air
fill ~14 ~-25 ~-142 ~15 ~-19 ~-140 minecraft:air
fill ~14 ~-24 ~-137 ~31 ~-19 ~-137 minecraft:air
fill ~14 ~-23 ~-138 ~31 ~-19 ~-137 minecraft:air
fill ~15 ~-26 ~-134 ~19 ~-24 ~-134 minecraft:air
fill ~15 ~-24 ~-138 ~31 ~-19 ~-137 minecraft:air
fill ~16 ~-26 ~-47 ~43 ~-19 ~-44 minecraft:air
fill ~16 ~-26 ~-43 ~16 ~-19 ~-43 minecraft:air
fill ~16 ~-25 ~-139 ~31 ~-19 ~-137 minecraft:air
fill ~16 ~-8 ~-144 ~19 ~-3 ~-144 minecraft:air
fill ~16 ~-8 ~-143 ~17 ~-3 ~-104 minecraft:air
fill ~17 ~-26 ~-51 ~19 ~-19 ~-49 minecraft:air
fill ~17 ~-25 ~-142 ~18 ~-19 ~-137 minecraft:air
fill ~18 ~-26 ~-52 ~18 ~-19 ~-44 minecraft:air
fill ~18 ~-25 ~-148 ~31 ~-19 ~-143 minecraft:air
fill ~18 ~-24 ~-149 ~31 ~-19 ~-137 minecraft:air
fill ~18 ~-8 ~-142 ~19 ~-3 ~-104 minecraft:air
fill ~18 ~-7 ~-143 ~19 ~-3 ~-104 minecraft:air
fill ~19 ~-8 ~-143 ~19 ~-3 ~-104 minecraft:air
fill ~20 ~-26 ~-43 ~43 ~-19 ~-43 minecraft:air
fill ~20 ~-25 ~-142 ~21 ~-19 ~-137 minecraft:air
fill ~21 ~-26 ~-134 ~26 ~-25 ~-134 minecraft:air
fill ~21 ~-26 ~-52 ~43 ~-19 ~-51 minecraft:air
fill ~21 ~-26 ~-50 ~33 ~-19 ~-43 minecraft:air
fill ~21 ~-8 ~-144 ~23 ~-3 ~-107 minecraft:air
fill ~23 ~-25 ~-142 ~24 ~-19 ~-137 minecraft:air
fill ~25 ~-26 ~-56 ~43 ~-19 ~-51 minecraft:air
fill ~25 ~-25 ~-149 ~31 ~-19 ~-143 minecraft:air
setblock ~25 ~-24 ~-134 minecraft:air
fill ~26 ~-26 ~-136 ~26 ~-25 ~-134 minecraft:air
fill ~26 ~-25 ~-142 ~27 ~-19 ~-137 minecraft:air
fill ~29 ~-25 ~-142 ~31 ~-19 ~-137 minecraft:air
fill ~30 ~-26 ~-59 ~43 ~-19 ~-51 minecraft:air
fill ~31 ~-26 ~-129 ~35 ~-24 ~-127 minecraft:air
fill ~32 ~-26 ~-67 ~43 ~-19 ~-51 minecraft:air
fill ~32 ~-21 ~-69 ~43 ~-19 ~-43 minecraft:air
fill ~33 ~-26 ~-126 ~35 ~-24 ~-69 minecraft:air
fill ~34 ~-26 ~-49 ~43 ~-19 ~-43 minecraft:air
fill ~34 ~-24 ~-50 ~43 ~-19 ~-43 minecraft:air
fill ~35 ~-26 ~-50 ~43 ~-19 ~-43 minecraft:air
fill ~37 ~-26 ~-68 ~43 ~-19 ~-43 minecraft:air
fill ~37 ~-23 ~-69 ~43 ~-19 ~-43 minecraft:air
fill ~79 ~-1 ~-174 ~89 ~-1 ~-7 minecraft:air
fill ~-65 ~16 ~-148 ~-65 ~16 ~-104 minecraft:stone_brick_stairs[facing=east,half=top]
fill ~-65 ~16 ~-88 ~-65 ~16 ~-44 minecraft:stone_brick_stairs[facing=east,half=top]
fill ~-52 ~16 ~-161 ~-8 ~16 ~-161 minecraft:stone_brick_stairs[facing=south,half=top]
fill ~8 ~16 ~-161 ~52 ~16 ~-161 minecraft:stone_brick_stairs[facing=south,half=top]
fill ~-52 ~16 ~-31 ~-24 ~16 ~-31 minecraft:stone_brick_stairs[facing=north,half=top]
fill ~-7 ~17 ~-25 ~7 ~17 ~-25 minecraft:stone_brick_stairs[facing=north,half=top]
fill ~24 ~16 ~-31 ~52 ~16 ~-31 minecraft:stone_brick_stairs[facing=north,half=top]
fill ~65 ~16 ~-148 ~65 ~16 ~-104 minecraft:stone_brick_stairs[facing=west,half=top]
fill ~65 ~16 ~-88 ~65 ~16 ~-44 minecraft:stone_brick_stairs[facing=west,half=top]
fill ~-60 ~19 ~-149 ~-60 ~19 ~-103 minecraft:stone_brick_slab
fill ~-60 ~19 ~-89 ~-60 ~19 ~-43 minecraft:stone_brick_slab
fill ~-53 ~19 ~-156 ~-7 ~19 ~-156 minecraft:stone_brick_slab
fill ~-53 ~19 ~-36 ~-22 ~19 ~-36 minecraft:stone_brick_slab
fill ~7 ~19 ~-156 ~53 ~19 ~-156 minecraft:stone_brick_slab
fill ~22 ~19 ~-36 ~53 ~19 ~-36 minecraft:stone_brick_slab
fill ~60 ~19 ~-149 ~60 ~19 ~-103 minecraft:stone_brick_slab
fill ~60 ~19 ~-89 ~60 ~19 ~-43 minecraft:stone_brick_slab
fill ~-32 ~18 ~-38 ~-32 ~18 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-31 ~17 ~-38 ~-31 ~17 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-30 ~16 ~-38 ~-30 ~16 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-29 ~15 ~-38 ~-29 ~15 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-28 ~14 ~-38 ~-28 ~14 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-27 ~13 ~-38 ~-27 ~13 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-26 ~12 ~-38 ~-26 ~12 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-25 ~11 ~-38 ~-25 ~11 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-24 ~10 ~-38 ~-24 ~10 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-23 ~9 ~-38 ~-23 ~9 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-22 ~8 ~-38 ~-22 ~8 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-21 ~7 ~-38 ~-21 ~7 ~-37 minecraft:stone_brick_stairs[facing=east]
fill ~-20 ~6 ~-38 ~-20 ~6 ~-37 minecraft:stone_brick_stairs[facing=east]
setblock ~-19 ~5 ~-38 minecraft:stone_brick_stairs[facing=east]
setblock ~-18 ~4 ~-38 minecraft:stone_brick_stairs[facing=east]
setblock ~18 ~4 ~-38 minecraft:stone_brick_stairs[facing=west]
setblock ~19 ~5 ~-38 minecraft:stone_brick_stairs[facing=west]
fill ~20 ~6 ~-38 ~20 ~6 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~21 ~7 ~-38 ~21 ~7 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~22 ~8 ~-38 ~22 ~8 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~23 ~9 ~-38 ~23 ~9 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~24 ~10 ~-38 ~24 ~10 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~25 ~11 ~-38 ~25 ~11 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~26 ~12 ~-38 ~26 ~12 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~27 ~13 ~-38 ~27 ~13 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~28 ~14 ~-38 ~28 ~14 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~29 ~15 ~-38 ~29 ~15 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~30 ~16 ~-38 ~30 ~16 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~31 ~17 ~-38 ~31 ~17 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~32 ~18 ~-38 ~32 ~18 ~-37 minecraft:stone_brick_stairs[facing=west]
fill ~-5 ~ ~-139 ~5 ~ ~-139 minecraft:polished_deepslate_stairs[facing=north]
fill ~-4 ~1 ~-141 ~4 ~1 ~-141 minecraft:polished_deepslate_stairs[facing=north]
fill ~ ~2 ~-143 ~1 ~2 ~-143 minecraft:quartz_stairs[facing=north]
setblock ~-1 ~2 ~-143 minecraft:quartz_slab
setblock ~1 ~2 ~-143 minecraft:quartz_slab
fill ~-22 ~ ~-114 ~-14 ~ ~-114 minecraft:spruce_slab[type=top]
fill ~14 ~ ~-114 ~20 ~ ~-114 minecraft:spruce_slab[type=top]
setblock ~-22 ~ ~-115 minecraft:spruce_stairs[facing=south]
setblock ~-20 ~ ~-115 minecraft:spruce_stairs[facing=south]
setblock ~-18 ~ ~-115 minecraft:spruce_stairs[facing=south]
setblock ~-16 ~ ~-115 minecraft:spruce_stairs[facing=south]
setblock ~-14 ~ ~-115 minecraft:spruce_stairs[facing=south]
setblock ~14 ~ ~-115 minecraft:spruce_stairs[facing=south]
setblock ~16 ~ ~-115 minecraft:spruce_stairs[facing=south]
setblock ~18 ~ ~-115 minecraft:spruce_stairs[facing=south]
setblock ~20 ~ ~-115 minecraft:spruce_stairs[facing=south]
fill ~-50 ~ ~-134 ~-42 ~ ~-134 minecraft:spruce_stairs[facing=north]
fill ~-50 ~ ~-131 ~-42 ~ ~-131 minecraft:spruce_stairs[facing=north]
fill ~-50 ~ ~-128 ~-42 ~ ~-128 minecraft:spruce_stairs[facing=north]
fill ~-50 ~ ~-125 ~-42 ~ ~-125 minecraft:spruce_stairs[facing=north]
setblock ~-22 ~ ~-113 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-140 ~-14 ~34 ~-140 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-137 ~-14 ~34 ~-137 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-134 ~-14 ~34 ~-134 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-131 ~-14 ~34 ~-131 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-128 ~-14 ~34 ~-128 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-125 ~-14 ~34 ~-125 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-122 ~-14 ~34 ~-122 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-119 ~-14 ~34 ~-119 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-116 ~-14 ~34 ~-116 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-113 ~-14 ~34 ~-113 minecraft:spruce_stairs[facing=north]
fill ~-22 ~34 ~-110 ~-14 ~34 ~-110 minecraft:spruce_stairs[facing=north]
setblock ~-20 ~ ~-113 minecraft:spruce_stairs[facing=north]
setblock ~-18 ~ ~-113 minecraft:spruce_stairs[facing=north]
setblock ~-16 ~ ~-113 minecraft:spruce_stairs[facing=north]
setblock ~-14 ~ ~-113 minecraft:spruce_stairs[facing=north]
setblock ~14 ~ ~-113 minecraft:spruce_stairs[facing=north]
setblock ~16 ~ ~-113 minecraft:spruce_stairs[facing=north]
setblock ~18 ~ ~-113 minecraft:spruce_stairs[facing=north]
setblock ~20 ~ ~-113 minecraft:spruce_stairs[facing=north]
fill ~-12 ~-1 ~-78 ~12 ~-1 ~-75 minecraft:dirt_path
fill ~-12 ~-1 ~-74 ~-10 ~-1 ~-66 minecraft:dirt_path
fill ~-9 ~-1 ~-69 ~12 ~-1 ~-66 minecraft:dirt_path
fill ~-4 ~-1 ~-74 ~4 ~-1 ~-66 minecraft:dirt_path
fill ~-2 ~-1 ~-101 ~2 ~-1 ~-37 minecraft:dirt_path
fill ~10 ~-1 ~-74 ~12 ~-1 ~-66 minecraft:dirt_path
fill ~-55 ~8 ~-139 ~-35 ~8 ~-139 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~9 ~-138 ~-35 ~9 ~-138 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~10 ~-137 ~-35 ~10 ~-137 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~11 ~-136 ~-35 ~11 ~-136 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~12 ~-135 ~-35 ~12 ~-135 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~13 ~-134 ~-35 ~13 ~-134 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~14 ~-133 ~-35 ~14 ~-133 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~15 ~-132 ~-35 ~15 ~-132 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~16 ~-131 ~-35 ~16 ~-131 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~17 ~-130 ~-35 ~17 ~-130 minecraft:dark_oak_stairs[facing=south]
fill ~-51 ~6 ~-57 ~-32 ~6 ~-57 minecraft:dark_oak_stairs[facing=south]
fill ~-51 ~7 ~-56 ~-32 ~7 ~-56 minecraft:dark_oak_stairs[facing=south]
fill ~-51 ~8 ~-55 ~-32 ~8 ~-55 minecraft:dark_oak_stairs[facing=south]
fill ~-51 ~9 ~-54 ~-32 ~9 ~-54 minecraft:dark_oak_stairs[facing=south]
fill ~-51 ~10 ~-53 ~-32 ~10 ~-52 minecraft:dark_oak_stairs[facing=south]
fill ~31 ~6 ~-57 ~50 ~6 ~-57 minecraft:dark_oak_stairs[facing=south]
fill ~31 ~7 ~-56 ~50 ~7 ~-56 minecraft:dark_oak_stairs[facing=south]
fill ~31 ~8 ~-55 ~50 ~8 ~-55 minecraft:dark_oak_stairs[facing=south]
fill ~31 ~9 ~-54 ~50 ~9 ~-54 minecraft:dark_oak_stairs[facing=south]
fill ~31 ~10 ~-53 ~50 ~10 ~-52 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~8 ~-139 ~55 ~8 ~-139 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~9 ~-138 ~55 ~9 ~-138 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~10 ~-137 ~55 ~10 ~-137 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~11 ~-136 ~55 ~11 ~-136 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~12 ~-135 ~55 ~12 ~-135 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~13 ~-134 ~55 ~13 ~-134 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~14 ~-133 ~55 ~14 ~-133 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~15 ~-132 ~55 ~15 ~-132 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~16 ~-131 ~55 ~16 ~-131 minecraft:dark_oak_stairs[facing=south]
fill ~35 ~17 ~-130 ~55 ~17 ~-130 minecraft:dark_oak_stairs[facing=south]
fill ~-55 ~8 ~-119 ~-35 ~8 ~-119 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~9 ~-120 ~-35 ~9 ~-120 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~10 ~-121 ~-35 ~10 ~-121 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~11 ~-122 ~-35 ~11 ~-122 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~12 ~-123 ~-35 ~12 ~-123 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~13 ~-124 ~-35 ~13 ~-124 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~14 ~-125 ~-35 ~14 ~-125 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~15 ~-126 ~-35 ~15 ~-126 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~16 ~-127 ~-35 ~16 ~-127 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~17 ~-128 ~-35 ~17 ~-128 minecraft:dark_oak_stairs[facing=north]
fill ~-51 ~6 ~-48 ~-32 ~6 ~-48 minecraft:dark_oak_stairs[facing=north]
fill ~-51 ~7 ~-49 ~-32 ~7 ~-49 minecraft:dark_oak_stairs[facing=north]
fill ~-51 ~8 ~-50 ~-32 ~8 ~-50 minecraft:dark_oak_stairs[facing=north]
fill ~-51 ~9 ~-51 ~-32 ~9 ~-51 minecraft:dark_oak_stairs[facing=north]
fill ~-51 ~10 ~-52 ~-32 ~10 ~-52 minecraft:dark_oak_stairs[facing=north]
fill ~31 ~6 ~-48 ~50 ~6 ~-48 minecraft:dark_oak_stairs[facing=north]
fill ~31 ~7 ~-49 ~50 ~7 ~-49 minecraft:dark_oak_stairs[facing=north]
fill ~31 ~8 ~-50 ~50 ~8 ~-50 minecraft:dark_oak_stairs[facing=north]
fill ~31 ~9 ~-51 ~50 ~9 ~-51 minecraft:dark_oak_stairs[facing=north]
fill ~31 ~10 ~-52 ~50 ~10 ~-52 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~8 ~-119 ~55 ~8 ~-119 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~9 ~-120 ~55 ~9 ~-120 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~10 ~-121 ~55 ~10 ~-121 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~11 ~-122 ~55 ~11 ~-122 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~12 ~-123 ~55 ~12 ~-123 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~13 ~-124 ~55 ~13 ~-124 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~14 ~-125 ~55 ~14 ~-125 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~15 ~-126 ~55 ~15 ~-126 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~16 ~-127 ~55 ~16 ~-127 minecraft:dark_oak_stairs[facing=north]
fill ~35 ~17 ~-128 ~55 ~17 ~-128 minecraft:dark_oak_stairs[facing=north]
fill ~-55 ~19 ~-129 ~-35 ~19 ~-129 minecraft:dark_oak_slab
fill ~-47 ~16 ~-85 ~-47 ~16 ~-65 minecraft:dark_oak_slab
fill ~-45 ~18 ~-113 ~-45 ~18 ~-91 minecraft:dark_oak_slab
fill ~35 ~19 ~-129 ~55 ~19 ~-129 minecraft:dark_oak_slab
fill ~46 ~17 ~-113 ~46 ~17 ~-91 minecraft:dark_oak_slab
fill ~-55 ~7 ~-113 ~-55 ~7 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-55 ~7 ~-85 ~-55 ~7 ~-65 minecraft:dark_oak_stairs[facing=east]
fill ~-54 ~8 ~-113 ~-54 ~8 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-54 ~8 ~-85 ~-54 ~8 ~-65 minecraft:dark_oak_stairs[facing=east]
fill ~-53 ~9 ~-113 ~-53 ~9 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-53 ~9 ~-85 ~-53 ~9 ~-65 minecraft:dark_oak_stairs[facing=east]
fill ~-52 ~10 ~-113 ~-52 ~10 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-52 ~10 ~-85 ~-52 ~10 ~-65 minecraft:dark_oak_stairs[facing=east]
fill ~-51 ~11 ~-113 ~-51 ~11 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-51 ~11 ~-85 ~-51 ~11 ~-65 minecraft:dark_oak_stairs[facing=east]
fill ~-50 ~12 ~-113 ~-50 ~12 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-50 ~12 ~-85 ~-50 ~12 ~-65 minecraft:dark_oak_stairs[facing=east]
fill ~-49 ~13 ~-113 ~-49 ~13 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-49 ~13 ~-85 ~-49 ~13 ~-65 minecraft:dark_oak_stairs[facing=east]
fill ~-48 ~14 ~-113 ~-48 ~14 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-48 ~14 ~-85 ~-48 ~14 ~-65 minecraft:dark_oak_stairs[facing=east]
fill ~-47 ~15 ~-113 ~-47 ~15 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-46 ~16 ~-113 ~-46 ~16 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~37 ~7 ~-113 ~37 ~7 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~38 ~8 ~-113 ~38 ~8 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~39 ~9 ~-113 ~39 ~9 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~40 ~10 ~-113 ~40 ~10 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~41 ~11 ~-113 ~41 ~11 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~42 ~12 ~-113 ~42 ~12 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~43 ~13 ~-113 ~43 ~13 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~44 ~14 ~-113 ~44 ~14 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~45 ~15 ~-113 ~45 ~15 ~-91 minecraft:dark_oak_stairs[facing=east]
fill ~-46 ~14 ~-85 ~-46 ~14 ~-65 minecraft:dark_oak_stairs[facing=west]
fill ~-45 ~13 ~-85 ~-45 ~13 ~-65 minecraft:dark_oak_stairs[facing=west]
fill ~-44 ~12 ~-85 ~-44 ~12 ~-65 minecraft:dark_oak_stairs[facing=west]
fill ~-44 ~16 ~-113 ~-44 ~16 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~-43 ~11 ~-85 ~-43 ~11 ~-65 minecraft:dark_oak_stairs[facing=west]
fill ~-43 ~15 ~-113 ~-43 ~15 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~-42 ~10 ~-85 ~-42 ~10 ~-65 minecraft:dark_oak_stairs[facing=west]
fill ~-42 ~14 ~-113 ~-42 ~14 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~-41 ~9 ~-85 ~-41 ~9 ~-65 minecraft:dark_oak_stairs[facing=west]
fill ~-41 ~13 ~-113 ~-41 ~13 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~-40 ~8 ~-85 ~-40 ~8 ~-65 minecraft:dark_oak_stairs[facing=west]
fill ~-40 ~12 ~-113 ~-40 ~12 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~-39 ~7 ~-85 ~-39 ~7 ~-65 minecraft:dark_oak_stairs[facing=west]
fill ~-39 ~11 ~-113 ~-39 ~11 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~-38 ~10 ~-113 ~-38 ~10 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~-37 ~9 ~-113 ~-37 ~9 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~-36 ~8 ~-113 ~-36 ~8 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~-35 ~7 ~-113 ~-35 ~7 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~47 ~15 ~-113 ~47 ~15 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~48 ~14 ~-113 ~48 ~14 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~49 ~13 ~-113 ~49 ~13 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~50 ~12 ~-113 ~50 ~12 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~51 ~11 ~-113 ~51 ~11 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~52 ~10 ~-113 ~52 ~10 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~53 ~9 ~-113 ~53 ~9 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~54 ~8 ~-113 ~54 ~8 ~-91 minecraft:dark_oak_stairs[facing=west]
fill ~55 ~7 ~-113 ~55 ~7 ~-91 minecraft:dark_oak_stairs[facing=west]
setblock ~-11 ~ ~-77 minecraft:spruce_stairs[facing=east]
setblock ~-11 ~ ~-74 minecraft:spruce_stairs[facing=east]
setblock ~-11 ~ ~-70 minecraft:spruce_stairs[facing=east]
setblock ~-11 ~ ~-67 minecraft:spruce_stairs[facing=east]
setblock ~-6 ~ ~-93 minecraft:spruce_stairs[facing=east]
setblock ~-6 ~ ~-89 minecraft:spruce_stairs[facing=east]
fill ~45 ~ ~-108 ~47 ~ ~-108 minecraft:spruce_stairs[facing=east]
fill ~45 ~ ~-102 ~47 ~ ~-102 minecraft:spruce_stairs[facing=east]
fill ~45 ~ ~-96 ~47 ~ ~-96 minecraft:spruce_stairs[facing=east]
setblock ~6 ~ ~-93 minecraft:spruce_stairs[facing=west]
setblock ~6 ~ ~-89 minecraft:spruce_stairs[facing=west]
setblock ~11 ~ ~-77 minecraft:spruce_stairs[facing=west]
setblock ~11 ~ ~-74 minecraft:spruce_stairs[facing=west]
setblock ~11 ~ ~-70 minecraft:spruce_stairs[facing=west]
setblock ~11 ~ ~-67 minecraft:spruce_stairs[facing=west]
setblock ~47 ~ ~-108 minecraft:spruce_stairs[facing=west]
setblock ~47 ~ ~-102 minecraft:spruce_stairs[facing=west]
setblock ~47 ~ ~-96 minecraft:spruce_stairs[facing=west]
fill ~38 ~-1 ~-84 ~54 ~-1 ~-66 minecraft:farmland[moisture=7]
fill ~24 ~4 ~-60 ~30 ~4 ~-56 minecraft:spruce_slab
fill ~-5 ~ ~-23 ~-5 ~ ~-4 minecraft:spruce_fence[north=false,south=true,east=false,west=false]
fill ~5 ~ ~-23 ~5 ~ ~-4 minecraft:spruce_fence[north=false,south=true,east=false,west=false]
fill ~-5 ~ ~-22 ~-5 ~ ~-4 minecraft:spruce_fence[north=true,south=true,east=false,west=false]
fill ~5 ~ ~-22 ~5 ~ ~-4 minecraft:spruce_fence[north=true,south=true,east=false,west=false]
fill ~-5 ~ ~-4 ~-5 ~2 ~-4 minecraft:spruce_fence[north=true,south=false,east=false,west=false]
fill ~5 ~ ~-4 ~5 ~2 ~-4 minecraft:spruce_fence[north=true,south=false,east=false,west=false]
fill ~-5 ~1 ~-23 ~-5 ~2 ~-23 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~-5 ~1 ~-18 ~-5 ~2 ~-18 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~-5 ~1 ~-6 ~-5 ~2 ~-6 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~-5 ~1 ~-4 ~-5 ~2 ~-4 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~5 ~1 ~-23 ~5 ~2 ~-23 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~5 ~1 ~-18 ~5 ~2 ~-18 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~5 ~1 ~-6 ~5 ~2 ~-6 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~5 ~1 ~-4 ~5 ~2 ~-4 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~25 ~2 ~-59 ~25 ~3 ~-59 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~25 ~2 ~-57 ~25 ~3 ~-57 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~29 ~2 ~-59 ~29 ~3 ~-59 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~29 ~2 ~-57 ~29 ~3 ~-57 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~46 ~ ~-108 ~46 ~1 ~-108 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~46 ~ ~-102 ~46 ~1 ~-102 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~46 ~ ~-96 ~46 ~1 ~-96 minecraft:spruce_fence[north=false,south=false,east=false,west=false]
fill ~-4 ~ ~-92 ~-4 ~4 ~-92 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~-4 ~ ~-84 ~-4 ~4 ~-84 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~-4 ~ ~-60 ~-4 ~4 ~-60 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~-4 ~ ~-52 ~-4 ~4 ~-52 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~-4 ~ ~-44 ~-4 ~4 ~-44 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~4 ~ ~-92 ~4 ~4 ~-92 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~4 ~ ~-84 ~4 ~4 ~-84 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~4 ~ ~-60 ~4 ~4 ~-60 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~4 ~ ~-52 ~4 ~4 ~-52 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~4 ~ ~-44 ~4 ~4 ~-44 minecraft:dark_oak_fence[north=false,south=false,east=false,west=false]
fill ~37 ~ ~-85 ~55 ~ ~-82 minecraft:oak_fence[north=false,south=true,east=true,west=false]
fill ~37 ~ ~-84 ~55 ~ ~-82 minecraft:oak_fence[north=true,south=true,east=false,west=false]
fill ~37 ~ ~-81 ~37 ~ ~-76 minecraft:oak_fence[north=true,south=true,east=false,west=false]
fill ~37 ~ ~-73 ~55 ~ ~-70 minecraft:oak_fence[north=true,south=true,east=false,west=false]
fill ~37 ~ ~-69 ~37 ~ ~-65 minecraft:oak_fence[north=true,south=true,east=false,west=false]
fill ~55 ~ ~-81 ~55 ~ ~-65 minecraft:oak_fence[north=true,south=true,east=false,west=false]
fill ~37 ~ ~-76 ~54 ~ ~-76 minecraft:oak_fence[north=true,south=false,east=false,west=false]
fill ~37 ~ ~-74 ~54 ~ ~-74 minecraft:oak_fence[north=false,south=true,east=false,west=false]
fill ~37 ~ ~-65 ~55 ~ ~-65 minecraft:oak_fence[north=true,south=false,east=true,west=false]
fill ~38 ~ ~-85 ~55 ~ ~-85 minecraft:oak_fence[north=false,south=false,east=true,west=true]
fill ~38 ~ ~-65 ~55 ~ ~-65 minecraft:oak_fence[north=false,south=false,east=true,west=true]
fill ~46 ~ ~-136 ~53 ~ ~-136 minecraft:spruce_fence[north=false,south=false,east=true,west=false]
fill ~46 ~ ~-132 ~53 ~ ~-132 minecraft:spruce_fence[north=false,south=false,east=true,west=false]
fill ~46 ~ ~-128 ~53 ~ ~-128 minecraft:spruce_fence[north=false,south=false,east=true,west=false]
fill ~46 ~ ~-124 ~53 ~ ~-124 minecraft:spruce_fence[north=false,south=false,east=true,west=false]
fill ~47 ~ ~-136 ~53 ~ ~-136 minecraft:spruce_fence[north=false,south=false,east=true,west=true]
fill ~47 ~ ~-132 ~53 ~ ~-132 minecraft:spruce_fence[north=false,south=false,east=true,west=true]
fill ~47 ~ ~-128 ~53 ~ ~-128 minecraft:spruce_fence[north=false,south=false,east=true,west=true]
fill ~47 ~ ~-124 ~53 ~ ~-124 minecraft:spruce_fence[north=false,south=false,east=true,west=true]
setblock ~55 ~ ~-85 minecraft:oak_fence[north=false,south=true,east=false,west=true]
setblock ~55 ~ ~-65 minecraft:oak_fence[north=true,south=false,east=false,west=true]
setblock ~-70 ~-21 ~-127 minecraft:lantern
setblock ~-65 ~21 ~-143 minecraft:lantern
setblock ~-65 ~21 ~-135 minecraft:lantern
setblock ~-65 ~21 ~-127 minecraft:lantern
setblock ~-65 ~21 ~-119 minecraft:lantern
setblock ~-65 ~21 ~-111 minecraft:lantern
setblock ~-65 ~21 ~-87 minecraft:lantern
setblock ~-65 ~21 ~-79 minecraft:lantern
setblock ~-65 ~21 ~-71 minecraft:lantern
setblock ~-65 ~21 ~-63 minecraft:lantern
setblock ~-65 ~21 ~-55 minecraft:lantern
setblock ~-65 ~21 ~-47 minecraft:lantern
setblock ~-60 ~-26 ~-127 minecraft:lantern
setblock ~-50 ~-26 ~-127 minecraft:lantern
setblock ~-49 ~21 ~-31 minecraft:lantern
setblock ~-47 ~21 ~-161 minecraft:lantern
setblock ~-41 ~21 ~-31 minecraft:lantern
setblock ~-40 ~-26 ~-127 minecraft:lantern
setblock ~-39 ~21 ~-161 minecraft:lantern
setblock ~-33 ~21 ~-31 minecraft:lantern
setblock ~-31 ~21 ~-161 minecraft:lantern
setblock ~-27 ~47 ~-135 minecraft:lantern
setblock ~-27 ~47 ~-129 minecraft:lantern
setblock ~-27 ~47 ~-123 minecraft:lantern
setblock ~-27 ~47 ~-117 minecraft:lantern
setblock ~-27 ~47 ~-111 minecraft:lantern
setblock ~-25 ~21 ~-31 minecraft:lantern
setblock ~-23 ~21 ~-161 minecraft:lantern
setblock ~-19 ~47 ~-101 minecraft:lantern
setblock ~-15 ~21 ~-161 minecraft:lantern
setblock ~-15 ~47 ~-147 minecraft:lantern
setblock ~-13 ~47 ~-101 minecraft:lantern
setblock ~-9 ~47 ~-147 minecraft:lantern
setblock ~-7 ~2 ~-72 minecraft:lantern
setblock ~-7 ~47 ~-101 minecraft:lantern
setblock ~-5 ~2 ~-23 minecraft:lantern
setblock ~-5 ~2 ~-18 minecraft:lantern
setblock ~-5 ~2 ~-6 minecraft:lantern
setblock ~-5 ~2 ~-4 minecraft:lantern
setblock ~-4 ~8 ~-100 minecraft:lantern
setblock ~-3 ~3 ~-143 minecraft:lantern
setblock ~-3 ~47 ~-147 minecraft:lantern
setblock ~-1 ~47 ~-101 minecraft:lantern
setblock ~ ~-24 ~-128 minecraft:lantern
setblock ~3 ~3 ~-143 minecraft:lantern
setblock ~3 ~47 ~-147 minecraft:lantern
setblock ~4 ~8 ~-100 minecraft:lantern
setblock ~5 ~2 ~-23 minecraft:lantern
setblock ~5 ~2 ~-18 minecraft:lantern
setblock ~5 ~2 ~-6 minecraft:lantern
setblock ~5 ~2 ~-4 minecraft:lantern
setblock ~5 ~47 ~-101 minecraft:lantern
setblock ~7 ~2 ~-72 minecraft:lantern
setblock ~9 ~21 ~-161 minecraft:lantern
setblock ~9 ~47 ~-147 minecraft:lantern
setblock ~11 ~47 ~-101 minecraft:lantern
setblock ~15 ~47 ~-147 minecraft:lantern
setblock ~17 ~21 ~-161 minecraft:lantern
setblock ~17 ~47 ~-101 minecraft:lantern
setblock ~25 ~21 ~-161 minecraft:lantern
setblock ~27 ~47 ~-135 minecraft:lantern
setblock ~27 ~47 ~-129 minecraft:lantern
setblock ~27 ~47 ~-123 minecraft:lantern
setblock ~27 ~47 ~-117 minecraft:lantern
setblock ~27 ~47 ~-111 minecraft:lantern
setblock ~31 ~21 ~-31 minecraft:lantern
setblock ~33 ~21 ~-161 minecraft:lantern
setblock ~35 ~-26 ~-122 minecraft:lantern
setblock ~35 ~-26 ~-112 minecraft:lantern
setblock ~35 ~-26 ~-102 minecraft:lantern
setblock ~35 ~-26 ~-92 minecraft:lantern
setblock ~35 ~-26 ~-82 minecraft:lantern
setblock ~35 ~-26 ~-72 minecraft:lantern
setblock ~39 ~21 ~-31 minecraft:lantern
setblock ~41 ~21 ~-161 minecraft:lantern
setblock ~47 ~21 ~-31 minecraft:lantern
setblock ~49 ~21 ~-161 minecraft:lantern
setblock ~65 ~21 ~-145 minecraft:lantern
setblock ~65 ~21 ~-137 minecraft:lantern
setblock ~65 ~21 ~-129 minecraft:lantern
setblock ~65 ~21 ~-121 minecraft:lantern
setblock ~65 ~21 ~-113 minecraft:lantern
setblock ~65 ~21 ~-105 minecraft:lantern
setblock ~65 ~21 ~-81 minecraft:lantern
setblock ~65 ~21 ~-73 minecraft:lantern
setblock ~65 ~21 ~-65 minecraft:lantern
setblock ~65 ~21 ~-57 minecraft:lantern
setblock ~65 ~21 ~-49 minecraft:lantern
setblock ~-64 ~5 ~-160 minecraft:lantern[hanging=true]
setblock ~-64 ~5 ~-32 minecraft:lantern[hanging=true]
setblock ~-64 ~8 ~-96 minecraft:lantern[hanging=true]
setblock ~-64 ~11 ~-160 minecraft:lantern[hanging=true]
setblock ~-64 ~11 ~-32 minecraft:lantern[hanging=true]
setblock ~-64 ~17 ~-160 minecraft:lantern[hanging=true]
setblock ~-64 ~17 ~-96 minecraft:lantern[hanging=true]
setblock ~-64 ~17 ~-32 minecraft:lantern[hanging=true]
setblock ~-64 ~23 ~-160 minecraft:lantern[hanging=true]
setblock ~-64 ~23 ~-32 minecraft:lantern[hanging=true]
setblock ~-64 ~25 ~-96 minecraft:lantern[hanging=true]
setblock ~-64 ~29 ~-160 minecraft:lantern[hanging=true]
setblock ~-64 ~29 ~-32 minecraft:lantern[hanging=true]
setblock ~-51 ~5 ~-109 minecraft:lantern[hanging=true]
setblock ~-51 ~5 ~-103 minecraft:lantern[hanging=true]
setblock ~-51 ~5 ~-97 minecraft:lantern[hanging=true]
setblock ~-51 ~5 ~-81 minecraft:lantern[hanging=true]
setblock ~-51 ~5 ~-75 minecraft:lantern[hanging=true]
setblock ~-51 ~5 ~-69 minecraft:lantern[hanging=true]
setblock ~-51 ~6 ~-135 minecraft:lantern[hanging=true]
setblock ~-51 ~6 ~-129 minecraft:lantern[hanging=true]
setblock ~-51 ~6 ~-123 minecraft:lantern[hanging=true]
setblock ~-47 ~4 ~-53 minecraft:lantern[hanging=true]
setblock ~-45 ~5 ~-109 minecraft:lantern[hanging=true]
setblock ~-45 ~5 ~-103 minecraft:lantern[hanging=true]
setblock ~-45 ~5 ~-97 minecraft:lantern[hanging=true]
setblock ~-45 ~5 ~-81 minecraft:lantern[hanging=true]
setblock ~-45 ~5 ~-75 minecraft:lantern[hanging=true]
setblock ~-45 ~5 ~-69 minecraft:lantern[hanging=true]
setblock ~-45 ~6 ~-135 minecraft:lantern[hanging=true]
setblock ~-45 ~6 ~-129 minecraft:lantern[hanging=true]
setblock ~-45 ~6 ~-123 minecraft:lantern[hanging=true]
setblock ~-39 ~5 ~-109 minecraft:lantern[hanging=true]
setblock ~-39 ~5 ~-103 minecraft:lantern[hanging=true]
setblock ~-39 ~5 ~-97 minecraft:lantern[hanging=true]
setblock ~-39 ~6 ~-135 minecraft:lantern[hanging=true]
setblock ~-39 ~6 ~-129 minecraft:lantern[hanging=true]
setblock ~-39 ~6 ~-123 minecraft:lantern[hanging=true]
setblock ~-37 ~4 ~-53 minecraft:lantern[hanging=true]
setblock ~-18 ~9 ~-134 minecraft:lantern[hanging=true]
setblock ~-18 ~9 ~-120 minecraft:lantern[hanging=true]
setblock ~-18 ~9 ~-110 minecraft:lantern[hanging=true]
setblock ~-18 ~21 ~-132 minecraft:lantern[hanging=true]
setblock ~-18 ~21 ~-120 minecraft:lantern[hanging=true]
setblock ~-18 ~21 ~-110 minecraft:lantern[hanging=true]
setblock ~-18 ~32 ~-132 minecraft:lantern[hanging=true]
setblock ~-18 ~32 ~-108 minecraft:lantern[hanging=true]
setblock ~-15 ~8 ~-30 minecraft:lantern[hanging=true]
setblock ~-15 ~17 ~-30 minecraft:lantern[hanging=true]
setblock ~-15 ~29 ~-30 minecraft:lantern[hanging=true]
setblock ~-8 ~21 ~-140 minecraft:lantern[hanging=true]
setblock ~-8 ~21 ~-132 minecraft:lantern[hanging=true]
setblock ~-8 ~21 ~-124 minecraft:lantern[hanging=true]
setblock ~-8 ~21 ~-116 minecraft:lantern[hanging=true]
setblock ~-8 ~21 ~-108 minecraft:lantern[hanging=true]
setblock ~-6 ~23 ~-33 minecraft:lantern[hanging=true]
setblock ~-4 ~9 ~-130 minecraft:lantern[hanging=true]
setblock ~-4 ~9 ~-120 minecraft:lantern[hanging=true]
setblock ~-4 ~9 ~-110 minecraft:lantern[hanging=true]
setblock ~ ~8 ~-160 minecraft:lantern[hanging=true]
setblock ~ ~9 ~-130 minecraft:lantern[hanging=true]
setblock ~ ~9 ~-120 minecraft:lantern[hanging=true]
setblock ~ ~9 ~-110 minecraft:lantern[hanging=true]
setblock ~ ~10 ~-38 minecraft:lantern[hanging=true]
setblock ~ ~10 ~-33 minecraft:lantern[hanging=true]
setblock ~ ~10 ~-26 minecraft:lantern[hanging=true]
setblock ~ ~17 ~-160 minecraft:lantern[hanging=true]
setblock ~ ~23 ~-33 minecraft:lantern[hanging=true]
setblock ~ ~25 ~-160 minecraft:lantern[hanging=true]
setblock ~ ~32 ~-136 minecraft:lantern[hanging=true]
setblock ~ ~32 ~-110 minecraft:lantern[hanging=true]
setblock ~ ~54 ~-124 minecraft:lantern[hanging=true]
setblock ~ ~65 ~-124 minecraft:lantern[hanging=true]
setblock ~2 ~-4 ~-141 minecraft:lantern[hanging=true]
setblock ~4 ~9 ~-130 minecraft:lantern[hanging=true]
setblock ~4 ~9 ~-120 minecraft:lantern[hanging=true]
setblock ~4 ~9 ~-110 minecraft:lantern[hanging=true]
setblock ~6 ~23 ~-33 minecraft:lantern[hanging=true]
setblock ~7 ~-4 ~-141 minecraft:lantern[hanging=true]
setblock ~8 ~21 ~-140 minecraft:lantern[hanging=true]
setblock ~8 ~21 ~-132 minecraft:lantern[hanging=true]
setblock ~8 ~21 ~-124 minecraft:lantern[hanging=true]
setblock ~8 ~21 ~-116 minecraft:lantern[hanging=true]
setblock ~8 ~21 ~-108 minecraft:lantern[hanging=true]
setblock ~12 ~-4 ~-141 minecraft:lantern[hanging=true]
setblock ~12 ~-3 ~-130 minecraft:lantern[hanging=true]
setblock ~12 ~-3 ~-120 minecraft:lantern[hanging=true]
setblock ~12 ~-3 ~-110 minecraft:lantern[hanging=true]
setblock ~14 ~-19 ~-66 minecraft:lantern[hanging=true]
setblock ~14 ~-19 ~-60 minecraft:lantern[hanging=true]
setblock ~14 ~-19 ~-54 minecraft:lantern[hanging=true]
setblock ~14 ~-19 ~-48 minecraft:lantern[hanging=true]
setblock ~15 ~8 ~-30 minecraft:lantern[hanging=true]
setblock ~15 ~17 ~-30 minecraft:lantern[hanging=true]
setblock ~15 ~29 ~-30 minecraft:lantern[hanging=true]
setblock ~17 ~-4 ~-141 minecraft:lantern[hanging=true]
setblock ~18 ~9 ~-134 minecraft:lantern[hanging=true]
setblock ~18 ~9 ~-120 minecraft:lantern[hanging=true]
setblock ~18 ~9 ~-110 minecraft:lantern[hanging=true]
setblock ~18 ~21 ~-134 minecraft:lantern[hanging=true]
setblock ~18 ~21 ~-114 minecraft:lantern[hanging=true]
setblock ~18 ~32 ~-132 minecraft:lantern[hanging=true]
setblock ~18 ~32 ~-108 minecraft:lantern[hanging=true]
setblock ~18 ~43 ~-126 minecraft:lantern[hanging=true]
setblock ~20 ~-19 ~-66 minecraft:lantern[hanging=true]
setblock ~20 ~-19 ~-60 minecraft:lantern[hanging=true]
setblock ~20 ~-19 ~-54 minecraft:lantern[hanging=true]
setblock ~20 ~-19 ~-48 minecraft:lantern[hanging=true]
setblock ~22 ~-4 ~-141 minecraft:lantern[hanging=true]
setblock ~26 ~-19 ~-66 minecraft:lantern[hanging=true]
setblock ~26 ~-19 ~-60 minecraft:lantern[hanging=true]
setblock ~26 ~-19 ~-54 minecraft:lantern[hanging=true]
setblock ~26 ~-19 ~-48 minecraft:lantern[hanging=true]
setblock ~27 ~3 ~-58 minecraft:lantern[hanging=true]
setblock ~32 ~-19 ~-66 minecraft:lantern[hanging=true]
setblock ~32 ~-19 ~-60 minecraft:lantern[hanging=true]
setblock ~32 ~-19 ~-54 minecraft:lantern[hanging=true]
setblock ~32 ~-19 ~-48 minecraft:lantern[hanging=true]
setblock ~35 ~4 ~-53 minecraft:lantern[hanging=true]
setblock ~38 ~-19 ~-66 minecraft:lantern[hanging=true]
setblock ~38 ~-19 ~-60 minecraft:lantern[hanging=true]
setblock ~38 ~-19 ~-54 minecraft:lantern[hanging=true]
setblock ~38 ~-19 ~-48 minecraft:lantern[hanging=true]
setblock ~39 ~6 ~-135 minecraft:lantern[hanging=true]
setblock ~39 ~6 ~-129 minecraft:lantern[hanging=true]
setblock ~39 ~6 ~-123 minecraft:lantern[hanging=true]
setblock ~41 ~5 ~-109 minecraft:lantern[hanging=true]
setblock ~41 ~5 ~-103 minecraft:lantern[hanging=true]
setblock ~41 ~5 ~-97 minecraft:lantern[hanging=true]
setblock ~45 ~4 ~-53 minecraft:lantern[hanging=true]
setblock ~45 ~6 ~-135 minecraft:lantern[hanging=true]
setblock ~45 ~6 ~-129 minecraft:lantern[hanging=true]
setblock ~45 ~6 ~-123 minecraft:lantern[hanging=true]
setblock ~47 ~5 ~-109 minecraft:lantern[hanging=true]
setblock ~47 ~5 ~-103 minecraft:lantern[hanging=true]
setblock ~47 ~5 ~-97 minecraft:lantern[hanging=true]
setblock ~51 ~6 ~-135 minecraft:lantern[hanging=true]
setblock ~51 ~6 ~-129 minecraft:lantern[hanging=true]
setblock ~51 ~6 ~-123 minecraft:lantern[hanging=true]
setblock ~64 ~5 ~-160 minecraft:lantern[hanging=true]
setblock ~64 ~5 ~-32 minecraft:lantern[hanging=true]
setblock ~64 ~8 ~-96 minecraft:lantern[hanging=true]
setblock ~64 ~11 ~-160 minecraft:lantern[hanging=true]
setblock ~64 ~11 ~-32 minecraft:lantern[hanging=true]
setblock ~64 ~17 ~-160 minecraft:lantern[hanging=true]
setblock ~64 ~17 ~-96 minecraft:lantern[hanging=true]
setblock ~64 ~17 ~-32 minecraft:lantern[hanging=true]
setblock ~64 ~23 ~-160 minecraft:lantern[hanging=true]
setblock ~64 ~23 ~-32 minecraft:lantern[hanging=true]
setblock ~64 ~25 ~-96 minecraft:lantern[hanging=true]
setblock ~64 ~29 ~-160 minecraft:lantern[hanging=true]
setblock ~64 ~29 ~-32 minecraft:lantern[hanging=true]
fill ~-64 ~ ~-169 ~-64 ~30 ~-169 minecraft:ladder[facing=south]
fill ~64 ~ ~-169 ~64 ~30 ~-169 minecraft:ladder[facing=south]
setblock ~-64 ~40 ~-96 minecraft:lightning_rod
setblock ~-64 ~52 ~-160 minecraft:lightning_rod
setblock ~-64 ~52 ~-32 minecraft:lightning_rod
setblock ~-26 ~65 ~-146 minecraft:lightning_rod
setblock ~-26 ~65 ~-102 minecraft:lightning_rod
setblock ~-15 ~46 ~-30 minecraft:lightning_rod
setblock ~ ~40 ~-160 minecraft:lightning_rod
setblock ~ ~86 ~-124 minecraft:lightning_rod
setblock ~15 ~46 ~-30 minecraft:lightning_rod
setblock ~26 ~65 ~-146 minecraft:lightning_rod
setblock ~26 ~65 ~-102 minecraft:lightning_rod
setblock ~64 ~40 ~-96 minecraft:lightning_rod
setblock ~64 ~52 ~-160 minecraft:lightning_rod
setblock ~64 ~52 ~-32 minecraft:lightning_rod
fill ~-64 ~ ~-91 ~-64 ~26 ~-91 minecraft:ladder[facing=north]
fill ~-64 ~ ~-23 ~-64 ~30 ~-23 minecraft:ladder[facing=north]
fill ~ ~19 ~-27 ~ ~24 ~-27 minecraft:ladder[facing=north]
fill ~64 ~ ~-91 ~64 ~26 ~-91 minecraft:ladder[facing=north]
fill ~64 ~ ~-23 ~64 ~30 ~-23 minecraft:ladder[facing=north]
fill ~-98 ~-11 ~-119 ~-97 ~-11 ~-119 minecraft:ladder[facing=east]
fill ~-98 ~-10 ~-119 ~-98 ~-1 ~-119 minecraft:ladder[facing=east]
fill ~-8 ~45 ~-124 ~-8 ~66 ~-124 minecraft:ladder[facing=east]
fill ~-5 ~ ~-160 ~-5 ~26 ~-160 minecraft:ladder[facing=east]
fill ~9 ~ ~-30 ~9 ~30 ~-30 minecraft:ladder[facing=east]
fill ~-9 ~ ~-30 ~-9 ~30 ~-30 minecraft:ladder[facing=west]
fill ~22 ~-8 ~-106 ~22 ~ ~-106 minecraft:ladder[facing=west]
fill ~24 ~ ~-142 ~24 ~44 ~-142 minecraft:ladder[facing=west]
fill ~-3 ~23 ~-142 ~3 ~23 ~-132 minecraft:red_carpet
fill ~-1 ~ ~-138 ~1 ~ ~-105 minecraft:red_carpet
fill ~14 ~12 ~-110 ~22 ~12 ~-110 minecraft:red_carpet
setblock ~-16 ~ ~-132 minecraft:water_cauldron[level=3]
setblock ~-18 ~ ~-128 minecraft:campfire[facing=north,lit=true,signal_fire=false,waterlogged=false]
setblock ~-22 ~1 ~-114 minecraft:candle[candles=3,lit=true]
setblock ~-19 ~1 ~-114 minecraft:candle[candles=3,lit=true]
setblock ~-16 ~1 ~-114 minecraft:candle[candles=3,lit=true]
setblock ~14 ~1 ~-114 minecraft:candle[candles=3,lit=true]
setblock ~17 ~1 ~-114 minecraft:candle[candles=3,lit=true]
setblock ~20 ~1 ~-114 minecraft:candle[candles=3,lit=true]
setblock ~-50 ~ ~-82 minecraft:anvil[facing=north]
setblock ~16 ~ ~-144 minecraft:anvil[facing=north]
setblock ~23 ~-26 ~-43 minecraft:anvil[facing=north]
setblock ~-50 ~ ~-68 minecraft:grindstone[face=floor,facing=north]
setblock ~18 ~ ~-144 minecraft:grindstone[face=floor,facing=north]
setblock ~-52 ~ ~-72 minecraft:smithing_table
setblock ~20 ~ ~-144 minecraft:smithing_table
setblock ~14 ~ ~-128 minecraft:fletching_table
setblock ~ ~12 ~-124 minecraft:enchanting_table
setblock ~8 ~-26 ~-104 minecraft:enchanting_table
setblock ~18 ~-26 ~-50 minecraft:enchanting_table
setblock ~ ~-25 ~-141 minecraft:cartography_table
setblock ~18 ~12 ~-116 minecraft:cartography_table
setblock ~20 ~12 ~-116 minecraft:lectern[facing=west,has_book=false,powered=false]
fill ~-3 ~23 ~-120 ~3 ~23 ~-108 minecraft:blue_carpet
setblock ~-5 ~23 ~-104 minecraft:flower_pot
setblock ~-18 ~35 ~-143 minecraft:candle[candles=4,lit=true]
setblock ~-52 ~ ~-76 minecraft:lava_cauldron
setblock ~46 ~1 ~-108 minecraft:spruce_pressure_plate
setblock ~46 ~1 ~-102 minecraft:spruce_pressure_plate
setblock ~46 ~1 ~-96 minecraft:spruce_pressure_plate
fill ~38 ~ ~-84 ~54 ~ ~-82 minecraft:wheat[age=7]
fill ~38 ~ ~-79 ~54 ~ ~-76 minecraft:wheat[age=7]
fill ~38 ~ ~-73 ~54 ~ ~-70 minecraft:wheat[age=7]
fill ~38 ~ ~-67 ~54 ~ ~-66 minecraft:wheat[age=7]
fill ~39 ~ ~-80 ~54 ~ ~-76 minecraft:wheat[age=7]
fill ~39 ~ ~-74 ~54 ~ ~-70 minecraft:wheat[age=7]
fill ~39 ~ ~-68 ~54 ~ ~-66 minecraft:wheat[age=7]
setblock ~38 ~ ~-83 minecraft:carrots[age=7]
setblock ~38 ~ ~-80 minecraft:carrots[age=7]
setblock ~38 ~ ~-77 minecraft:carrots[age=7]
setblock ~38 ~ ~-74 minecraft:carrots[age=7]
setblock ~38 ~ ~-71 minecraft:carrots[age=7]
setblock ~38 ~ ~-68 minecraft:carrots[age=7]
setblock ~39 ~ ~-84 minecraft:carrots[age=7]
setblock ~39 ~ ~-78 minecraft:carrots[age=7]
setblock ~39 ~ ~-72 minecraft:carrots[age=7]
setblock ~39 ~ ~-66 minecraft:carrots[age=7]
setblock ~40 ~ ~-82 minecraft:carrots[age=7]
setblock ~40 ~ ~-79 minecraft:carrots[age=7]
setblock ~40 ~ ~-76 minecraft:carrots[age=7]
setblock ~40 ~ ~-73 minecraft:carrots[age=7]
setblock ~40 ~ ~-70 minecraft:carrots[age=7]
setblock ~40 ~ ~-67 minecraft:carrots[age=7]
setblock ~41 ~ ~-83 minecraft:carrots[age=7]
setblock ~41 ~ ~-80 minecraft:carrots[age=7]
setblock ~41 ~ ~-77 minecraft:carrots[age=7]
setblock ~41 ~ ~-74 minecraft:carrots[age=7]
setblock ~41 ~ ~-71 minecraft:carrots[age=7]
setblock ~41 ~ ~-68 minecraft:carrots[age=7]
setblock ~42 ~ ~-84 minecraft:carrots[age=7]
setblock ~42 ~ ~-78 minecraft:carrots[age=7]
setblock ~42 ~ ~-72 minecraft:carrots[age=7]
setblock ~42 ~ ~-66 minecraft:carrots[age=7]
setblock ~43 ~ ~-82 minecraft:carrots[age=7]
setblock ~43 ~ ~-79 minecraft:carrots[age=7]
setblock ~43 ~ ~-76 minecraft:carrots[age=7]
setblock ~43 ~ ~-73 minecraft:carrots[age=7]
setblock ~43 ~ ~-70 minecraft:carrots[age=7]
setblock ~43 ~ ~-67 minecraft:carrots[age=7]
setblock ~44 ~ ~-83 minecraft:carrots[age=7]
setblock ~44 ~ ~-80 minecraft:carrots[age=7]
setblock ~44 ~ ~-77 minecraft:carrots[age=7]
setblock ~44 ~ ~-74 minecraft:carrots[age=7]
setblock ~44 ~ ~-71 minecraft:carrots[age=7]
setblock ~44 ~ ~-68 minecraft:carrots[age=7]
setblock ~45 ~ ~-84 minecraft:carrots[age=7]
setblock ~45 ~ ~-78 minecraft:carrots[age=7]
setblock ~45 ~ ~-72 minecraft:carrots[age=7]
setblock ~45 ~ ~-66 minecraft:carrots[age=7]
setblock ~46 ~ ~-82 minecraft:carrots[age=7]
setblock ~46 ~ ~-79 minecraft:carrots[age=7]
setblock ~46 ~ ~-76 minecraft:carrots[age=7]
setblock ~46 ~ ~-73 minecraft:carrots[age=7]
setblock ~46 ~ ~-70 minecraft:carrots[age=7]
setblock ~46 ~ ~-67 minecraft:carrots[age=7]
setblock ~47 ~ ~-83 minecraft:carrots[age=7]
setblock ~47 ~ ~-80 minecraft:carrots[age=7]
setblock ~47 ~ ~-77 minecraft:carrots[age=7]
setblock ~47 ~ ~-74 minecraft:carrots[age=7]
setblock ~47 ~ ~-71 minecraft:carrots[age=7]
setblock ~47 ~ ~-68 minecraft:carrots[age=7]
setblock ~48 ~ ~-84 minecraft:carrots[age=7]
setblock ~48 ~ ~-78 minecraft:carrots[age=7]
setblock ~48 ~ ~-72 minecraft:carrots[age=7]
setblock ~48 ~ ~-66 minecraft:carrots[age=7]
setblock ~49 ~ ~-82 minecraft:carrots[age=7]
setblock ~49 ~ ~-79 minecraft:carrots[age=7]
setblock ~49 ~ ~-76 minecraft:carrots[age=7]
setblock ~49 ~ ~-73 minecraft:carrots[age=7]
setblock ~49 ~ ~-70 minecraft:carrots[age=7]
setblock ~49 ~ ~-67 minecraft:carrots[age=7]
setblock ~50 ~ ~-83 minecraft:carrots[age=7]
setblock ~50 ~ ~-80 minecraft:carrots[age=7]
setblock ~50 ~ ~-77 minecraft:carrots[age=7]
setblock ~50 ~ ~-74 minecraft:carrots[age=7]
setblock ~50 ~ ~-71 minecraft:carrots[age=7]
setblock ~50 ~ ~-68 minecraft:carrots[age=7]
setblock ~51 ~ ~-84 minecraft:carrots[age=7]
setblock ~51 ~ ~-78 minecraft:carrots[age=7]
setblock ~51 ~ ~-72 minecraft:carrots[age=7]
setblock ~51 ~ ~-66 minecraft:carrots[age=7]
setblock ~52 ~ ~-82 minecraft:carrots[age=7]
setblock ~52 ~ ~-79 minecraft:carrots[age=7]
setblock ~52 ~ ~-76 minecraft:carrots[age=7]
setblock ~52 ~ ~-73 minecraft:carrots[age=7]
setblock ~52 ~ ~-70 minecraft:carrots[age=7]
setblock ~52 ~ ~-67 minecraft:carrots[age=7]
setblock ~53 ~ ~-83 minecraft:carrots[age=7]
setblock ~53 ~ ~-80 minecraft:carrots[age=7]
setblock ~53 ~ ~-77 minecraft:carrots[age=7]
setblock ~53 ~ ~-74 minecraft:carrots[age=7]
setblock ~53 ~ ~-71 minecraft:carrots[age=7]
setblock ~53 ~ ~-68 minecraft:carrots[age=7]
setblock ~54 ~ ~-84 minecraft:carrots[age=7]
setblock ~54 ~ ~-78 minecraft:carrots[age=7]
setblock ~54 ~ ~-72 minecraft:carrots[age=7]
setblock ~54 ~ ~-66 minecraft:carrots[age=7]
setblock ~-48 ~12 ~-155 minecraft:red_wall_banner[facing=south]
setblock ~-26 ~9 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~-26 ~20 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~-26 ~31 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~-18 ~9 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~-18 ~20 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~-18 ~31 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~-12 ~12 ~-155 minecraft:red_wall_banner[facing=south]
setblock ~-10 ~9 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~-10 ~18 ~-23 minecraft:red_wall_banner[facing=south]
setblock ~-10 ~20 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~-10 ~31 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~6 ~9 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~6 ~20 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~6 ~31 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~10 ~18 ~-23 minecraft:red_wall_banner[facing=south]
setblock ~14 ~9 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~14 ~20 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~14 ~31 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~22 ~9 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~22 ~20 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~22 ~31 ~-100 minecraft:red_wall_banner[facing=south]
setblock ~24 ~12 ~-155 minecraft:red_wall_banner[facing=south]
setblock ~-26 ~9 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~-26 ~20 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~-26 ~31 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~-18 ~9 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~-18 ~20 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~-18 ~31 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~-10 ~9 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~-10 ~20 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~-10 ~31 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~6 ~9 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~6 ~20 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~6 ~31 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~14 ~9 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~14 ~20 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~14 ~31 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~22 ~9 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~22 ~20 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~22 ~31 ~-148 minecraft:red_wall_banner[facing=north]
setblock ~-28 ~9 ~-146 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~9 ~-138 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~9 ~-130 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~9 ~-122 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~9 ~-114 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~9 ~-106 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~20 ~-146 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~20 ~-138 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~20 ~-130 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~20 ~-122 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~20 ~-114 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~20 ~-106 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~31 ~-146 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~31 ~-138 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~31 ~-130 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~31 ~-122 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~31 ~-114 minecraft:blue_wall_banner[facing=west]
setblock ~-28 ~31 ~-106 minecraft:blue_wall_banner[facing=west]
setblock ~59 ~12 ~-120 minecraft:blue_wall_banner[facing=west]
setblock ~59 ~12 ~-48 minecraft:blue_wall_banner[facing=west]
setblock ~-59 ~12 ~-120 minecraft:blue_wall_banner[facing=east]
setblock ~-59 ~12 ~-48 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~9 ~-146 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~9 ~-138 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~9 ~-130 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~9 ~-122 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~9 ~-114 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~9 ~-106 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~20 ~-146 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~20 ~-138 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~20 ~-130 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~20 ~-122 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~20 ~-114 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~20 ~-106 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~31 ~-146 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~31 ~-138 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~31 ~-130 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~31 ~-122 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~31 ~-114 minecraft:blue_wall_banner[facing=east]
setblock ~28 ~31 ~-106 minecraft:blue_wall_banner[facing=east]
setblock ~-59 ~12 ~-144 minecraft:red_wall_banner[facing=east]
setblock ~-59 ~12 ~-108 minecraft:red_wall_banner[facing=east]
setblock ~-59 ~12 ~-72 minecraft:red_wall_banner[facing=east]
setblock ~59 ~12 ~-144 minecraft:red_wall_banner[facing=west]
setblock ~59 ~12 ~-108 minecraft:red_wall_banner[facing=west]
setblock ~59 ~12 ~-72 minecraft:red_wall_banner[facing=west]
setblock ~-36 ~12 ~-155 minecraft:yellow_wall_banner[facing=south]
setblock ~12 ~12 ~-155 minecraft:yellow_wall_banner[facing=south]
setblock ~36 ~12 ~-155 minecraft:yellow_wall_banner[facing=south]
setblock ~-59 ~12 ~-132 minecraft:yellow_wall_banner[facing=east]
setblock ~-59 ~12 ~-84 minecraft:yellow_wall_banner[facing=east]
setblock ~-59 ~12 ~-60 minecraft:yellow_wall_banner[facing=east]
setblock ~59 ~12 ~-132 minecraft:yellow_wall_banner[facing=west]
setblock ~59 ~12 ~-84 minecraft:yellow_wall_banner[facing=west]
setblock ~59 ~12 ~-60 minecraft:yellow_wall_banner[facing=west]
setblock ~-24 ~12 ~-155 minecraft:blue_wall_banner[facing=south]
setblock ~48 ~12 ~-155 minecraft:blue_wall_banner[facing=south]
setblock ~ ~12 ~-155 minecraft:black_wall_banner[facing=south]
setblock ~-59 ~12 ~-96 minecraft:black_wall_banner[facing=east]
setblock ~59 ~12 ~-96 minecraft:black_wall_banner[facing=west]
setblock ~-6 ~7 ~-144 minecraft:purple_wall_banner[facing=south]
setblock ~6 ~7 ~-144 minecraft:purple_wall_banner[facing=south]
fill ~-9 ~ ~-136 ~-9 ~ ~-108 minecraft:purple_carpet
fill ~9 ~ ~-136 ~9 ~ ~-108 minecraft:purple_carpet
setblock ~-8 ~34 ~-104 minecraft:potted_red_tulip
setblock ~16 ~1 ~-114 minecraft:potted_red_tulip
setblock ~-20 ~12 ~-106 minecraft:potted_fern
setblock ~-8 ~23 ~-104 minecraft:potted_oxeye_daisy
setblock ~8 ~23 ~-104 minecraft:potted_lily_of_the_valley
setblock ~8 ~34 ~-104 minecraft:potted_allium
setblock ~-20 ~23 ~-140 minecraft:white_carpet
setblock ~-20 ~23 ~-120 minecraft:white_carpet
setblock ~20 ~23 ~-140 minecraft:white_carpet
setblock ~20 ~23 ~-120 minecraft:white_carpet
setblock ~-20 ~23 ~-116 minecraft:light_blue_carpet
setblock ~-20 ~23 ~-111 minecraft:light_blue_carpet
setblock ~-20 ~23 ~-106 minecraft:light_blue_carpet
setblock ~-19 ~23 ~-117 minecraft:light_blue_carpet
fill ~-19 ~23 ~-112 ~-18 ~23 ~-112 minecraft:light_blue_carpet
setblock ~-19 ~23 ~-107 minecraft:light_blue_carpet
setblock ~-18 ~23 ~-118 minecraft:light_blue_carpet
setblock ~-18 ~23 ~-108 minecraft:light_blue_carpet
setblock ~-17 ~23 ~-119 minecraft:light_blue_carpet
setblock ~-17 ~23 ~-114 minecraft:light_blue_carpet
setblock ~-17 ~23 ~-109 minecraft:light_blue_carpet
setblock ~-16 ~23 ~-120 minecraft:light_blue_carpet
setblock ~-16 ~23 ~-115 minecraft:light_blue_carpet
setblock ~-16 ~23 ~-110 minecraft:light_blue_carpet
setblock ~-15 ~23 ~-116 minecraft:light_blue_carpet
setblock ~-15 ~23 ~-111 minecraft:light_blue_carpet
setblock ~-15 ~23 ~-106 minecraft:light_blue_carpet
setblock ~-14 ~23 ~-117 minecraft:light_blue_carpet
setblock ~-14 ~23 ~-112 minecraft:light_blue_carpet
setblock ~-14 ~23 ~-107 minecraft:light_blue_carpet
setblock ~-24 ~ ~-155 minecraft:oxeye_daisy
setblock ~-24 ~ ~-39 minecraft:oxeye_daisy
setblock ~-19 ~ ~-91 minecraft:oxeye_daisy
setblock ~-18 ~ ~-94 minecraft:oxeye_daisy
setblock ~-16 ~ ~-86 minecraft:oxeye_daisy
setblock ~-15 ~ ~-89 minecraft:oxeye_daisy
setblock ~-14 ~ ~-92 minecraft:oxeye_daisy
setblock ~-13 ~ ~-95 minecraft:oxeye_daisy
setblock ~-11 ~ ~-87 minecraft:oxeye_daisy
setblock ~-10 ~ ~-90 minecraft:oxeye_daisy
setblock ~-9 ~ ~-93 minecraft:oxeye_daisy
setblock ~-8 ~ ~-96 minecraft:oxeye_daisy
setblock ~8 ~ ~-88 minecraft:oxeye_daisy
setblock ~9 ~ ~-91 minecraft:oxeye_daisy
setblock ~10 ~ ~-94 minecraft:oxeye_daisy
setblock ~12 ~ ~-86 minecraft:oxeye_daisy
setblock ~13 ~ ~-89 minecraft:oxeye_daisy
setblock ~14 ~ ~-92 minecraft:oxeye_daisy
setblock ~15 ~ ~-95 minecraft:oxeye_daisy
setblock ~17 ~ ~-87 minecraft:oxeye_daisy
setblock ~18 ~ ~-90 minecraft:oxeye_daisy
setblock ~19 ~ ~-93 minecraft:oxeye_daisy
setblock ~32 ~ ~-155 minecraft:oxeye_daisy
setblock ~32 ~ ~-39 minecraft:oxeye_daisy
setblock ~-48 ~ ~-155 minecraft:dandelion
setblock ~-48 ~ ~-39 minecraft:dandelion
setblock ~-19 ~ ~-87 minecraft:dandelion
setblock ~-18 ~ ~-90 minecraft:dandelion
setblock ~-17 ~ ~-93 minecraft:dandelion
setblock ~-16 ~ ~-96 minecraft:dandelion
setblock ~-14 ~ ~-88 minecraft:dandelion
setblock ~-13 ~ ~-91 minecraft:dandelion
setblock ~-12 ~ ~-94 minecraft:dandelion
setblock ~-10 ~ ~-86 minecraft:dandelion
setblock ~-9 ~ ~-89 minecraft:dandelion
setblock ~-8 ~ ~-92 minecraft:dandelion
setblock ~8 ~ ~-155 minecraft:dandelion
setblock ~9 ~ ~-87 minecraft:dandelion
setblock ~10 ~ ~-90 minecraft:dandelion
setblock ~11 ~ ~-93 minecraft:dandelion
setblock ~12 ~ ~-96 minecraft:dandelion
setblock ~14 ~ ~-88 minecraft:dandelion
setblock ~15 ~ ~-91 minecraft:dandelion
setblock ~16 ~ ~-94 minecraft:dandelion
setblock ~18 ~ ~-86 minecraft:dandelion
setblock ~19 ~ ~-89 minecraft:dandelion
setblock ~-32 ~ ~-155 minecraft:allium
setblock ~-32 ~ ~-39 minecraft:allium
setblock ~-18 ~ ~-88 minecraft:allium
setblock ~-17 ~ ~-91 minecraft:allium
setblock ~-16 ~ ~-94 minecraft:allium
setblock ~-14 ~ ~-86 minecraft:allium
setblock ~-13 ~ ~-89 minecraft:allium
setblock ~-12 ~ ~-92 minecraft:allium
setblock ~-11 ~ ~-95 minecraft:allium
setblock ~-9 ~ ~-87 minecraft:allium
setblock ~-8 ~ ~-90 minecraft:allium
setblock ~8 ~ ~-96 minecraft:allium
setblock ~10 ~ ~-88 minecraft:allium
setblock ~11 ~ ~-91 minecraft:allium
setblock ~12 ~ ~-94 minecraft:allium
setblock ~14 ~ ~-86 minecraft:allium
setblock ~15 ~ ~-89 minecraft:allium
setblock ~16 ~ ~-92 minecraft:allium
setblock ~17 ~ ~-95 minecraft:allium
setblock ~19 ~ ~-87 minecraft:allium
setblock ~24 ~ ~-155 minecraft:allium
setblock ~24 ~ ~-39 minecraft:allium
setblock ~-18 ~ ~-86 minecraft:red_tulip
setblock ~-17 ~ ~-89 minecraft:red_tulip
setblock ~-16 ~ ~-155 minecraft:red_tulip
setblock ~-16 ~ ~-92 minecraft:red_tulip
setblock ~-15 ~ ~-95 minecraft:red_tulip
setblock ~-13 ~ ~-87 minecraft:red_tulip
setblock ~-12 ~ ~-90 minecraft:red_tulip
setblock ~-11 ~ ~-93 minecraft:red_tulip
setblock ~-10 ~ ~-96 minecraft:red_tulip
setblock ~-8 ~ ~-88 minecraft:red_tulip
setblock ~8 ~ ~-94 minecraft:red_tulip
setblock ~10 ~ ~-86 minecraft:red_tulip
setblock ~11 ~ ~-89 minecraft:red_tulip
setblock ~12 ~ ~-92 minecraft:red_tulip
setblock ~13 ~ ~-95 minecraft:red_tulip
setblock ~15 ~ ~-87 minecraft:red_tulip
setblock ~16 ~ ~-90 minecraft:red_tulip
setblock ~17 ~ ~-93 minecraft:red_tulip
setblock ~18 ~ ~-96 minecraft:red_tulip
setblock ~40 ~ ~-155 minecraft:red_tulip
setblock ~40 ~ ~-39 minecraft:red_tulip
setblock ~-56 ~ ~-39 minecraft:poppy
setblock ~-19 ~ ~-95 minecraft:poppy
setblock ~-17 ~ ~-87 minecraft:poppy
setblock ~-16 ~ ~-90 minecraft:poppy
setblock ~-15 ~ ~-93 minecraft:poppy
setblock ~-14 ~ ~-96 minecraft:poppy
setblock ~-12 ~ ~-88 minecraft:poppy
setblock ~-11 ~ ~-91 minecraft:poppy
setblock ~-10 ~ ~-94 minecraft:poppy
setblock ~-8 ~ ~-86 minecraft:poppy
setblock ~8 ~ ~-92 minecraft:poppy
setblock ~9 ~ ~-95 minecraft:poppy
setblock ~11 ~ ~-87 minecraft:poppy
setblock ~12 ~ ~-90 minecraft:poppy
setblock ~13 ~ ~-93 minecraft:poppy
setblock ~14 ~ ~-96 minecraft:poppy
setblock ~16 ~ ~-88 minecraft:poppy
setblock ~17 ~ ~-91 minecraft:poppy
setblock ~18 ~ ~-94 minecraft:poppy
setblock ~56 ~ ~-39 minecraft:poppy
setblock ~-40 ~ ~-155 minecraft:cornflower
setblock ~-40 ~ ~-39 minecraft:cornflower
setblock ~-19 ~ ~-93 minecraft:cornflower
setblock ~-18 ~ ~-96 minecraft:cornflower
setblock ~-16 ~ ~-88 minecraft:cornflower
setblock ~-15 ~ ~-91 minecraft:cornflower
setblock ~-14 ~ ~-94 minecraft:cornflower
setblock ~-12 ~ ~-86 minecraft:cornflower
setblock ~-11 ~ ~-89 minecraft:cornflower
setblock ~-10 ~ ~-92 minecraft:cornflower
setblock ~-9 ~ ~-95 minecraft:cornflower
setblock ~8 ~ ~-90 minecraft:cornflower
setblock ~9 ~ ~-93 minecraft:cornflower
setblock ~10 ~ ~-96 minecraft:cornflower
setblock ~12 ~ ~-88 minecraft:cornflower
setblock ~13 ~ ~-91 minecraft:cornflower
setblock ~14 ~ ~-94 minecraft:cornflower
setblock ~16 ~ ~-155 minecraft:cornflower
setblock ~16 ~ ~-86 minecraft:cornflower
setblock ~17 ~ ~-89 minecraft:cornflower
setblock ~18 ~ ~-92 minecraft:cornflower
setblock ~19 ~ ~-95 minecraft:cornflower
setblock ~3 ~-8 ~-143 minecraft:cobweb
setblock ~13 ~-8 ~-143 minecraft:cobweb
setblock ~23 ~-8 ~-143 minecraft:cobweb
setblock ~-88 ~-9 ~-130 minecraft:sea_lantern
setblock ~-88 ~-9 ~-125 minecraft:sea_lantern
setblock ~-88 ~-9 ~-120 minecraft:sea_lantern
setblock ~-88 ~-9 ~-115 minecraft:sea_lantern
setblock ~-88 ~-9 ~-110 minecraft:sea_lantern
setblock ~-88 ~-9 ~-105 minecraft:sea_lantern
setblock ~-80 ~-9 ~-125 minecraft:sea_lantern
setblock ~-80 ~-9 ~-120 minecraft:sea_lantern
setblock ~-80 ~-9 ~-115 minecraft:sea_lantern
setblock ~-80 ~-9 ~-110 minecraft:sea_lantern
setblock ~-80 ~-9 ~-105 minecraft:sea_lantern
setblock ~-27 ~-19 ~-145 minecraft:sea_lantern
setblock ~-27 ~-19 ~-137 minecraft:sea_lantern
setblock ~-27 ~-19 ~-129 minecraft:sea_lantern
setblock ~-27 ~-19 ~-121 minecraft:sea_lantern
setblock ~-27 ~-19 ~-113 minecraft:sea_lantern
setblock ~-27 ~-19 ~-105 minecraft:sea_lantern
setblock ~-19 ~-19 ~-145 minecraft:sea_lantern
setblock ~-19 ~-19 ~-137 minecraft:sea_lantern
setblock ~-19 ~-19 ~-129 minecraft:sea_lantern
setblock ~-19 ~-19 ~-121 minecraft:sea_lantern
setblock ~-19 ~-19 ~-113 minecraft:sea_lantern
setblock ~-19 ~-19 ~-105 minecraft:sea_lantern
setblock ~-11 ~-19 ~-129 minecraft:sea_lantern
setblock ~-11 ~-19 ~-121 minecraft:sea_lantern
setblock ~-11 ~-19 ~-113 minecraft:sea_lantern
setblock ~-11 ~-19 ~-105 minecraft:sea_lantern
setblock ~-3 ~-19 ~-145 minecraft:sea_lantern
setblock ~-3 ~-19 ~-137 minecraft:sea_lantern
setblock ~-3 ~-19 ~-129 minecraft:sea_lantern
setblock ~-3 ~-19 ~-121 minecraft:sea_lantern
setblock ~-3 ~-19 ~-113 minecraft:sea_lantern
setblock ~-3 ~-19 ~-105 minecraft:sea_lantern
setblock ~5 ~-19 ~-145 minecraft:sea_lantern
setblock ~5 ~-19 ~-137 minecraft:sea_lantern
setblock ~5 ~-19 ~-129 minecraft:sea_lantern
setblock ~5 ~-19 ~-121 minecraft:sea_lantern
setblock ~5 ~-19 ~-113 minecraft:sea_lantern
setblock ~5 ~-19 ~-105 minecraft:sea_lantern
setblock ~13 ~-19 ~-145 minecraft:sea_lantern
setblock ~13 ~-19 ~-137 minecraft:sea_lantern
setblock ~13 ~-19 ~-129 minecraft:sea_lantern
setblock ~13 ~-19 ~-121 minecraft:sea_lantern
setblock ~13 ~-19 ~-113 minecraft:sea_lantern
setblock ~13 ~-19 ~-105 minecraft:sea_lantern
setblock ~21 ~-19 ~-145 minecraft:sea_lantern
setblock ~21 ~-19 ~-137 minecraft:sea_lantern
setblock ~21 ~-19 ~-129 minecraft:sea_lantern
setblock ~21 ~-19 ~-121 minecraft:sea_lantern
setblock ~21 ~-19 ~-113 minecraft:sea_lantern
setblock ~21 ~-19 ~-105 minecraft:sea_lantern
setblock ~29 ~-19 ~-145 minecraft:sea_lantern
setblock ~29 ~-19 ~-137 minecraft:sea_lantern
setblock ~29 ~-19 ~-129 minecraft:sea_lantern
setblock ~29 ~-19 ~-121 minecraft:sea_lantern
setblock ~29 ~-19 ~-113 minecraft:sea_lantern
setblock ~29 ~-19 ~-105 minecraft:sea_lantern
setblock ~-4 ~-25 ~-141 minecraft:lectern[facing=south,has_book=false,powered=false]
setblock ~4 ~-25 ~-141 minecraft:lectern[facing=south,has_book=false,powered=false]
setblock ~-28 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-25 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-22 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-19 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-16 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-13 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-10 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-7 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-4 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-1 ~-26 ~-103 minecraft:chest[facing=north,type=single]
setblock ~-82 ~-11 ~-100 minecraft:brewing_stand[has_bottle_0=false,has_bottle_1=false,has_bottle_2=false]
