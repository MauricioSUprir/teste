execute as @e[type=minecraft:marker,tag=castelo_origem,limit=1] at @s run function castelo:_blocos2
tellraw @a [{"text":"[Castelo] ","color":"gold"},{"text":"Construindo... 25%","color":"gray"}]
schedule function castelo:_etapa3 1t
