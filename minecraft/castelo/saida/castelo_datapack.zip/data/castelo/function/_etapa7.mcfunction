execute as @e[type=minecraft:marker,tag=castelo_origem,limit=1] at @s run function castelo:_blocos7
tellraw @a [{"text":"[Castelo] ","color":"gold"},{"text":"Construindo... 87%","color":"gray"}]
schedule function castelo:_etapa8 1t
